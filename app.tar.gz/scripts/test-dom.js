#!/usr/bin/env node
// 可爱的乖乖 v2 前端 DOM 冒烟测试（jsdom，跑在 /tmp，不污染项目）
// 用法：node /tmp/v2-dom-test/test.js [no-key|dummy-key]
// 启动真实后端（3126 端口），在真实 DOM 里加载迁移后的前端，验证：
//  - 页面 JS 无报错；小猪、聊天框、设置面板都存在
//  - 点小猪有反应；发消息走离线脑子能回话
//  - dummy-key 时：发消息走后端 401 → 页面如实提示 401 并切回离线
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const { JSDOM } = require('jsdom');

const MODE = process.argv[2] || 'no-key';
const PORT = 3126;
const DB = '/tmp/guai-v2-dom.sqlite';
const ROOT = path.resolve(__dirname, '..');

let pass = 0, fail = 0;
function ck(name, ok, extra) {
  if (ok) { pass++; console.log('PASS ' + name); }
  else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + extra : '')); }
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
async function waitFor(fn, timeout, step) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) { if (fn()) return true; await sleep(step || 300); }
  return fn();
}

(async () => {
  // ---- start server ----
  const env = Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: DB });
  if (MODE === 'dummy-key') env.DEEPSEEK_API_KEY = 'sk-test-dummy-key';
  const srv = spawn('node', ['backend/server.js'], { cwd: ROOT, env, stdio: 'ignore' });
  const base = 'http://127.0.0.1:' + PORT;
  let up = false;
  for (let i = 0; i < 20 && !up; i++) {
    await sleep(500);
    up = await new Promise(res => {
      http.get(base + '/', r => { res(r.statusCode === 200); }).on('error', () => res(false));
    });
  }
  ck('server starts on ' + PORT, up);
  if (!up) { srv.kill(); process.exit(1); }

  const errors = [];
  const dom = await JSDOM.fromURL(base + '/', {
    resources: 'usable',
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    beforeParse(window) {
      // Node's fetch needs absolute URLs; the page uses relative /api/* paths,
      // so resolve them against the page origin (a real browser does this natively).
      // It also rejects jsdom's AbortSignal, so bridge it to a Node signal.
      const _f = globalThis.fetch;
      window.fetch = (input, init) => {
        if (typeof input === 'string' && input.startsWith('/')) input = base + input;
        if (init && init.signal) {
          const ctrl = new AbortController();
          const sig = init.signal;
          if (sig.aborted) ctrl.abort();
          else sig.addEventListener('abort', () => ctrl.abort());
          init = Object.assign({}, init, { signal: ctrl.signal });
        }
        return _f(input, init);
      };
      window.AudioContext = function () {
        this.currentTime = 0; this.destination = {};
        this.resume = () => Promise.resolve();
        this.createOscillator = () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0 }, type: '' });
        this.createGain = () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} } });
      };
      window.webkitAudioContext = window.AudioContext;
      window.navigator.vibrate = () => true;
      window.addEventListener('error', e => errors.push('window.onerror: ' + (e.message || e.error)));
    },
  });
  const { window } = dom;
  const { document } = window;
  window.addEventListener('error', e => errors.push('late error: ' + (e.message || e.error)));
  dom.virtualConsole.on('jsdomError', e => errors.push('jsdomError: ' + (e.message || e)));

  await sleep(2500); // let /api/health + /api/state + /api/history settle

  ck('pig element exists', !!document.getElementById('pig'));
  ck('chat form + input exist', !!document.getElementById('chatForm') && !!document.getElementById('chatInput'));
  ck('settings toggle exists', !!document.getElementById('aiSettingsToggle'));
  const statusText = (document.getElementById('aiStatusText') || {}).textContent || '';
  if (MODE === 'no-key') ck('status shows backend has no key', statusText.indexOf('未配置钥匙') > -1, statusText);
  else ck('status shows backend configured', statusText.indexOf('已配置') > -1, statusText);

  // settings panel: open it, check new backend-edition controls
  document.getElementById('aiSettingsToggle').click();
  await sleep(300);
  ck('settings panel opens', !document.getElementById('aiSettings').hidden);
  ck('backup button exists (no key input any more)', !!document.getElementById('dataBackupBtn') && !document.getElementById('dsKeyInput'));
  ck('restore button exists', !!document.getElementById('dataRestoreBtn'));

  // tap the pig
  const logBefore = document.getElementById('chatLog').textContent.length;
  const bubble = document.querySelector('.bubble-text, .speech, [class*=bubble]');
  const bubbleBefore = bubble ? bubble.textContent : '';
  document.getElementById('pig').dispatchEvent(new window.MouseEvent('click', { bubbles: true }));
  await sleep(800);
  const bubbleAfter = bubble ? bubble.textContent : document.getElementById('chatLog').textContent;
  ck('tapping pig reacts (bubble or log changes)', bubbleAfter !== bubbleBefore || document.getElementById('chatLog').textContent.length !== logBefore);

  // send a chat message (note: the static opener is already one .msg-pig row,
  // so require MORE pig rows than before sending, not just > 0)
  const pigRowsBefore = document.querySelectorAll('#chatLog .msg-pig').length;
  const input = document.getElementById('chatInput');
  input.value = '你好';
  document.getElementById('chatForm').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  const gotReply = await waitFor(() => {
    const rows = document.querySelectorAll('#chatLog .msg-pig');
    return rows.length > pigRowsBefore && (document.getElementById('chatLog').textContent.indexOf('你好') > -1);
  }, MODE === 'dummy-key' ? 15000 : 6000);
  ck('chat round-trip renders user msg + pig reply', gotReply);
  if (MODE === 'dummy-key') {
    const notice = document.getElementById('aiNotice');
    ck('401 notice shown honestly', notice && !notice.hidden && notice.textContent.indexOf('401') > -1, notice ? notice.textContent : 'no notice');
  } else {
    // By design, no-key mode attempts /api/chat once, gets 503, shows the
    // honest "server has no key yet" notice, then falls back to offline chat.
    const notice = document.getElementById('aiNotice');
    ck('offline mode shows the honest 503 (no key) notice, not 401',
      notice && !notice.hidden && notice.textContent.indexOf('还没配置') > -1 && notice.textContent.indexOf('401') === -1,
      notice ? notice.textContent : 'no notice');
  }

  ck('no page JS errors during the whole run', errors.length === 0, errors.slice(0, 3).join(' | '));

  window.close();
  srv.kill();
  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('test crashed:', e); process.exit(1); });
