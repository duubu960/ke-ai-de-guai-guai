'use strict';
// 后端自测：只用 Node 内置模块（http / assert / fs / os / path / crypto）。
// 启动临时服务器（随机端口、临时数据库文件），逐项断言并打印 PASS/FAIL，
// 任一失败退出码非 0。测试不使用真实 Key：启动时不设 DEEPSEEK_API_KEY。
const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');

const { start } = require('../backend/server');
const { closeDb } = require('../backend/database/db');

const TOKEN = crypto.randomUUID();
const OTHER_TOKEN = crypto.randomUUID();

let port = 0;
const results = [];

function req({ method, path: urlPath, token, body, rawBody, headers }) {
  return new Promise((resolve, reject) => {
    const data =
      rawBody !== undefined ? rawBody : body !== undefined ? JSON.stringify(body) : null;
    const r = http.request(
      {
        hostname: '127.0.0.1',
        port,
        path: encodeURI(urlPath), // 查询串里可能有中文，需编码
        method,
        headers: Object.assign(
          { 'Content-Type': 'application/json' },
          token ? { 'X-User-Token': token } : {},
          headers || {}
        ),
      },
      (res) => {
        let text = '';
        res.on('data', (chunk) => {
          text += chunk;
        });
        res.on('end', () => {
          let parsed = null;
          try {
            parsed = JSON.parse(text);
          } catch (e) {
            // 非 JSON 响应时 parsed 保持 null。
          }
          resolve({ status: res.statusCode, headers: res.headers, text, body: parsed });
        });
      }
    );
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

async function test(name, fn) {
  try {
    await fn();
    results.push({ name, ok: true });
    console.log(`PASS ${name}`);
  } catch (err) {
    results.push({ name, ok: false, error: err });
    console.log(`FAIL ${name}: ${err.message}`);
  }
}

async function main() {
  // 确保测试环境里没有 Key：覆盖 /api/chat 无 Key 时的 503 行为。
  delete process.env.DEEPSEEK_API_KEY;
  delete process.env.DEEPSEEK_MODEL;

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'gg-test-'));
  const dbPath = path.join(tmpDir, 'app.sqlite');
  const { server } = await start({ port: 0, host: '127.0.0.1', dbPath });
  port = server.address().port;

  try {
    await test('GET /api/health 无 Token → 400', async () => {
      const r = await req({ method: 'GET', path: '/api/health' });
      assert.strictEqual(r.status, 400);
      assert.strictEqual(r.body.error, 'invalid_user_token');
    });

    await test('GET /healthz 不走 token 校验 → 200（给 Render 健康检查用）', async () => {
      const r = await req({ method: 'GET', path: '/healthz' });
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.body.ok, true);
      assert.strictEqual(typeof r.body.time, 'string');
    });

    await test('GET /api/health 有 Token → 200，deepseek missing', async () => {
      const r = await req({ method: 'GET', path: '/api/health', token: TOKEN });
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.body.ok, true);
      assert.strictEqual(r.body.deepseek, 'missing');
      assert.strictEqual(r.body.model, 'deepseek-chat');
      assert.strictEqual(typeof r.body.time, 'string');
    });

    await test('POST /api/chat 无 Key → 503 deepseek_key_missing', async () => {
      const r = await req({
        method: 'POST',
        path: '/api/chat',
        token: TOKEN,
        body: { messages: [{ role: 'user', content: '你好' }] },
      });
      assert.strictEqual(r.status, 503);
      assert.strictEqual(r.body.error, 'deepseek_key_missing');
    });

    await test('POST /api/chat 非法 body → 400', async () => {
      const badBodies = [
        { messages: [] },
        { messages: [{ role: 'bad', content: 'hi' }] },
        { messages: [{ role: 'user', content: '   ' }] },
        { messages: [{ role: 'user', content: 'x'.repeat(4001) }] },
        {
          messages: [
            { role: 'user', content: 'hi' },
            { role: 'assistant', content: 'ok' },
          ],
        },
        { messages: Array.from({ length: 31 }, () => ({ role: 'user', content: 'x' })) },
        {},
      ];
      for (const bad of badBodies) {
        const r = await req({ method: 'POST', path: '/api/chat', token: TOKEN, body: bad });
        assert.strictEqual(r.status, 400, `应为 400，实际 ${r.status}：${r.text}`);
        assert.strictEqual(r.body.error, 'invalid_request');
      }
    });

    await test('GET /api/history 初始为空（失败的聊天不写库）', async () => {
      const r = await req({ method: 'GET', path: '/api/history', token: TOKEN });
      assert.strictEqual(r.status, 200);
      assert.deepStrictEqual(r.body.messages, []);
    });

    await test('GET /api/state 默认值', async () => {
      const r = await req({ method: 'GET', path: '/api/state', token: TOKEN });
      assert.strictEqual(r.status, 200);
      assert.deepStrictEqual(r.body.profile, { name: '', likes: [] });
      assert.strictEqual(r.body.affection, 60);
      assert.deepStrictEqual(r.body.memories, []);
      assert.strictEqual(r.body.firstMet, 0);
      assert.strictEqual(r.body.lastVisit, 0);
      assert.strictEqual(r.body.lastTopic, '');
      assert.deepStrictEqual(r.body.recentReplies, []);
      assert.strictEqual(r.body.dailyGiftDate, '');
      assert.strictEqual(r.body.coins, 0);
      assert.deepStrictEqual(r.body.meters, { hunger: 72, mood: 82, energy: 76 });
      assert.strictEqual(r.body.hat, 'bow');
      assert.deepStrictEqual(r.body.seenFaces, {});
    });

    await test('POST /api/state 非法值 → 400', async () => {
      const r1 = await req({
        method: 'POST',
        path: '/api/state',
        token: TOKEN,
        body: { affection: 999 },
      });
      assert.strictEqual(r1.status, 400);
      assert.strictEqual(r1.body.error, 'invalid_request');
      const r2 = await req({
        method: 'POST',
        path: '/api/state',
        token: TOKEN,
        body: { profile: { likes: Array.from({ length: 51 }, (_, i) => `喜好${i}`) } },
      });
      assert.strictEqual(r2.status, 400);
      assert.strictEqual(r2.body.error, 'invalid_request');
    });

    await test('POST /api/state 存取往返', async () => {
      const saved = {
        profile: { name: '小可', likes: ['草莓', '看海'] },
        affection: 120,
        memories: [{ t: 1730000000000, title: '第一次见面', detail: '在公园散步', emotion: '开心' }],
        firstMet: 1730000000000,
        lastVisit: 1730000001000,
        lastTopic: '想去看海',
        recentReplies: ['想你啦'],
        dailyGiftDate: '2026-11-11',
        coins: 5,
        meters: { hunger: 70, mood: 90, energy: 60 },
        hat: 'flower',
        seenFaces: { laugh: true },
      };
      const r1 = await req({ method: 'POST', path: '/api/state', token: TOKEN, body: saved });
      assert.strictEqual(r1.status, 200);
      assert.deepStrictEqual(r1.body, { ok: true });
      const r2 = await req({ method: 'GET', path: '/api/state', token: TOKEN });
      assert.strictEqual(r2.status, 200);
      assert.deepStrictEqual(r2.body, saved);
    });

    await test('GET /api/backup 返回完整导出', async () => {
      const r = await req({ method: 'GET', path: '/api/backup', token: TOKEN });
      assert.strictEqual(r.status, 200);
      assert.ok(
        String(r.headers['content-disposition'] || '').includes('attachment'),
        '应带 attachment 下载头'
      );
      assert.strictEqual(typeof r.body.exportedAt, 'string');
      assert.strictEqual(r.body.token, TOKEN);
      assert.strictEqual(r.body.state.profile.name, '小可');
      assert.ok(Array.isArray(r.body.messages));
    });

    await test('POST /api/restore 后 state 与 history 一致', async () => {
      const restored = {
        state: {
          profile: { name: '宝宝', likes: ['蛋糕'] },
          affection: 88,
          memories: [{ t: 1730000002000, title: '第一次约会', detail: '看电影', emotion: '开心' }],
          firstMet: 1730000002000,
          lastVisit: 1730000003000,
          lastTopic: '晚安',
          recentReplies: [],
          dailyGiftDate: '2026-11-12',
        },
        messages: [
          { role: 'user', content: '你好', created_at: 1730000002000 },
          { role: 'assistant', content: '你好呀', created_at: 1730000003000 },
        ],
      };
      const r1 = await req({ method: 'POST', path: '/api/restore', token: TOKEN, body: restored });
      assert.strictEqual(r1.status, 200);
      assert.strictEqual(r1.body.ok, true);
      assert.strictEqual(r1.body.imported.messages, 2);
      assert.strictEqual(r1.body.imported.memories, 0);
      const r2 = await req({ method: 'GET', path: '/api/state', token: TOKEN });
      assert.strictEqual(r2.body.profile.name, '宝宝');
      assert.strictEqual(r2.body.affection, 88);
      assert.strictEqual(r2.body.memories[0].title, '第一次约会');
      const r3 = await req({ method: 'GET', path: '/api/history', token: TOKEN });
      assert.strictEqual(r3.body.messages.length, 2);
      assert.strictEqual(r3.body.messages[0].role, 'user');
      assert.strictEqual(r3.body.messages[0].content, '你好');
      assert.strictEqual(r3.body.messages[1].role, 'assistant');
      assert.strictEqual(r3.body.messages[1].content, '你好呀');
      const r4 = await req({ method: 'GET', path: '/api/backup', token: TOKEN });
      assert.strictEqual(r4.body.messages.length, 2);
    });

    await test('POST /api/restore 非法数据 → 400 且原数据不动', async () => {
      const r1 = await req({
        method: 'POST',
        path: '/api/restore',
        token: TOKEN,
        body: { messages: [{ role: 'bad', content: 'x' }] },
      });
      assert.strictEqual(r1.status, 400);
      assert.strictEqual(r1.body.error, 'invalid_request');
      const r2 = await req({ method: 'GET', path: '/api/history', token: TOKEN });
      assert.strictEqual(r2.body.messages.length, 2);
    });

    await test('未知路由 → 404 not_found', async () => {
      const r = await req({ method: 'GET', path: '/api/unknown', token: TOKEN });
      assert.strictEqual(r.status, 404);
      assert.strictEqual(r.body.error, 'not_found');
    });

    await test('非法 Token 格式 → 400', async () => {
      const r = await req({ method: 'GET', path: '/api/health', token: 'not-a-uuid' });
      assert.strictEqual(r.status, 400);
      assert.strictEqual(r.body.error, 'invalid_user_token');
    });

    await test('JSON 解析失败 → 400 invalid_json', async () => {
      const r = await req({
        method: 'POST',
        path: '/api/state',
        token: TOKEN,
        rawBody: '{bad json',
      });
      assert.strictEqual(r.status, 400);
      assert.strictEqual(r.body.error, 'invalid_json');
    });

    await test('不同 Token 数据隔离', async () => {
      const r1 = await req({ method: 'GET', path: '/api/state', token: OTHER_TOKEN });
      assert.strictEqual(r1.body.profile.name, '');
      assert.strictEqual(r1.body.affection, 60);
      const r2 = await req({ method: 'GET', path: '/api/history', token: OTHER_TOKEN });
      assert.deepStrictEqual(r2.body.messages, []);
    });

    // ===== Phase 3 新接口 =====

    await test('迁移幂等：再次应用不报错、15 张新表都在', async () => {
      const { applyMigrations } = require('../backend/database/migrate');
      const { getDb } = require('../backend/database/db');
      const db = getDb();
      await applyMigrations(db); // 第二次运行，不应抛错
      let names;
      if (db.dialect === 'pg') {
        names = (await db.all("SELECT tablename AS name FROM pg_tables WHERE schemaname = 'public'")).map((r) => r.name);
      } else {
        names = (await db.all("SELECT name FROM sqlite_master WHERE type='table'")).map((r) => r.name);
      }
      for (const t of ['memories', 'anniversaries', 'wishlists', 'daily_surprises', 'surprise_history', 'preferences', 'game_records', 'daily_reports', 'letters', 'vault_items', 'user_settings', 'events', 'gift_favorites', 'photos', 'migrations']) {
        assert.ok(names.includes(t), `缺表 ${t}`);
      }
      const migs = (await db.all('SELECT name FROM migrations')).map((r) => r.name).sort();
      const expected = db.dialect === 'pg'
        ? ['002-phase3.pg.sql', '003-photos.pg.sql']
        : ['002-phase3.sql', '003-photos.sql'];
      assert.deepStrictEqual(migs, expected);
    });

    await test('memories CRUD + 按月/搜索/收藏 + 跨 token 隔离', async () => {
      const bad = await req({ method: 'POST', path: '/api/memories', token: TOKEN, body: { title: 'x', date: '2026-02-30' } });
      assert.strictEqual(bad.status, 400);
      const c1 = await req({ method: 'POST', path: '/api/memories', token: TOKEN, body: { title: '第一次约会', date: '2026-11-10', location: '公园', description: '一起散步', category: '约会' } });
      assert.strictEqual(c1.status, 201);
      const id = c1.body.id;
      assert.strictEqual(c1.body.title, '第一次约会');
      assert.strictEqual(c1.body.favorite, false);
      const c2 = await req({ method: 'POST', path: '/api/memories', token: TOKEN, body: { title: '看海', date: '2026-11-02', description: '海边散步' } });
      assert.strictEqual(c2.status, 201);
      const rMonth = await req({ method: 'GET', path: '/api/memories?month=2026-11', token: TOKEN });
      assert.strictEqual(rMonth.body.memories.length, 2);
      const rQ = await req({ method: 'GET', path: '/api/memories?q=海边', token: TOKEN });
      assert.strictEqual(rQ.body.memories.length, 1);
      assert.strictEqual(rQ.body.memories[0].title, '看海');
      const badMonth = await req({ method: 'GET', path: '/api/memories?month=2026-13', token: TOKEN });
      assert.strictEqual(badMonth.status, 400);
      const u = await req({ method: 'PUT', path: `/api/memories/${id}`, token: TOKEN, body: { favorite: true } });
      assert.strictEqual(u.status, 200);
      assert.strictEqual(u.body.favorite, true);
      const rFav = await req({ method: 'GET', path: '/api/memories?favorite=1', token: TOKEN });
      assert.strictEqual(rFav.body.memories.length, 1);
      const cross = await req({ method: 'GET', path: `/api/memories/${id}`, token: OTHER_TOKEN });
      assert.strictEqual(cross.status, 404);
      const del = await req({ method: 'DELETE', path: `/api/memories/${c2.body.id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
      const gone = await req({ method: 'GET', path: `/api/memories/${c2.body.id}`, token: TOKEN });
      assert.strictEqual(gone.status, 404);
    });

    await test('anniversaries CRUD + summary（daysTogether 与下一次）', async () => {
      const first = await req({ method: 'POST', path: '/api/anniversaries', token: TOKEN, body: { title: '第一次见面', date: '2025-11-11', type: 'first_meet' } });
      assert.strictEqual(first.status, 201);
      const second = await req({ method: 'POST', path: '/api/anniversaries', token: TOKEN, body: { title: '宝宝生日', date: '2026-01-01', type: 'birthday' } });
      assert.strictEqual(second.status, 201);
      const bad = await req({ method: 'POST', path: '/api/anniversaries', token: TOKEN, body: { title: 'x', date: '2026-01-01', type: 'wedding' } });
      assert.strictEqual(bad.status, 400);
      const s = await req({ method: 'GET', path: '/api/anniversaries/summary', token: TOKEN });
      assert.strictEqual(s.status, 200);
      // 期望天数按本地当天日期动态算（容器时区可能是 UTC，别写死 365）。
      const d0 = new Date(2025, 10, 11);
      const now = new Date();
      const todayMid = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const expectedDays = Math.round((todayMid - d0) / 86400000);
      assert.strictEqual(s.body.daysTogether, expectedDays);
      assert.ok(Array.isArray(s.body.next));
      assert.ok(s.body.next.length >= 2);
      assert.ok(s.body.next[0].daysLeft <= s.body.next[1].daysLeft);
      const u = await req({ method: 'PUT', path: `/api/anniversaries/${second.body.id}`, token: TOKEN, body: { note: '准备礼物' } });
      assert.strictEqual(u.body.note, '准备礼物');
      const del = await req({ method: 'DELETE', path: `/api/anniversaries/${second.body.id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
    });

    await test('surprise open 每天一次：第二次返回同一份', async () => {
      const o1 = await req({ method: 'POST', path: '/api/surprise/open', token: TOKEN, body: {} });
      assert.strictEqual(o1.status, 201);
      assert.strictEqual(o1.body.isNew, true);
      assert.ok(o1.body.id);
      assert.ok(o1.body.title);
      assert.ok(o1.body.content);
      const o2 = await req({ method: 'POST', path: '/api/surprise/open', token: TOKEN, body: {} });
      assert.strictEqual(o2.status, 200);
      assert.strictEqual(o2.body.isNew, false);
      assert.strictEqual(o2.body.id, o1.body.id);
      assert.strictEqual(o2.body.title, o1.body.title);
      const h = await req({ method: 'GET', path: '/api/surprises/history', token: TOKEN });
      assert.strictEqual(h.status, 200);
      assert.strictEqual(h.body.surprises.length, 1);
      const fav = await req({ method: 'POST', path: `/api/surprises/${o1.body.id}/favorite`, token: TOKEN });
      assert.strictEqual(fav.status, 200);
      assert.strictEqual(fav.body.favorite, true);
      const o3 = await req({ method: 'POST', path: '/api/surprise/open', token: OTHER_TOKEN, body: {} });
      assert.strictEqual(o3.status, 201); // 另一个 token 各开一次，不受影响
      assert.notStrictEqual(o3.body.id, o1.body.id);
    });

    await test('wishlists CRUD + complete + summary', async () => {
      const c = await req({ method: 'POST', path: '/api/wishlists', token: TOKEN, body: { title: '一起去海边', category: '旅行', priority: 1 } });
      assert.strictEqual(c.status, 201);
      const id = c.body.id;
      assert.strictEqual(c.body.done, false);
      const bad = await req({ method: 'POST', path: '/api/wishlists', token: TOKEN, body: { title: 'x', priority: 5 } });
      assert.strictEqual(bad.status, 400);
      // 回归：前端无照片时发 photo_url: null，可选字段的 null 必须当作“没有”接受。
      const nullPhoto = await req({ method: 'POST', path: '/api/wishlists', token: TOKEN, body: { title: '没有照片的心愿', category: '礼物', priority: 2, note: null, photo_url: null } });
      assert.strictEqual(nullPhoto.status, 201, `photo_url:null 应 201，实际 ${nullPhoto.status} ${JSON.stringify(nullPhoto.body)}`);
      await req({ method: 'DELETE', path: `/api/wishlists/${nullPhoto.body.id}`, token: TOKEN });
      const done = await req({ method: 'POST', path: `/api/wishlists/${id}/complete`, token: TOKEN });
      assert.strictEqual(done.status, 200);
      assert.strictEqual(done.body.done, true);
      assert.ok(done.body.completedAt);
      const s = await req({ method: 'GET', path: '/api/wishlists/summary', token: TOKEN });
      assert.strictEqual(s.body.total, 1);
      assert.strictEqual(s.body.done, 1);
      assert.strictEqual(s.body.pending, 0);
      const del = await req({ method: 'DELETE', path: `/api/wishlists/${id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
    });

    await test('可选字段的 null 当作“没有”（memories/anniversaries）', async () => {
      const m = await req({ method: 'POST', path: '/api/memories', token: TOKEN, body: { title: '无照片的回忆', date: '2026-11-10', location: null, description: null, photo_url: null } });
      assert.strictEqual(m.status, 201, `memories photo_url:null 应 201，实际 ${m.status} ${JSON.stringify(m.body)}`);
      await req({ method: 'DELETE', path: `/api/memories/${m.body.id}`, token: TOKEN });
      const a = await req({ method: 'POST', path: '/api/anniversaries', token: TOKEN, body: { title: '无备注的纪念日', date: '2026-12-25', type: 'anniversary', note: null } });
      assert.strictEqual(a.status, 201, `anniversaries note:null 应 201，实际 ${a.status} ${JSON.stringify(a.body)}`);
      await req({ method: 'DELETE', path: `/api/anniversaries/${a.body.id}`, token: TOKEN });
    });

    await test('preferences CRUD + pending + extract 不自动保存', async () => {
      const ex = await req({ method: 'POST', path: '/api/preferences/extract', token: TOKEN, body: { text: '我喜欢吃草莓，最喜欢粉色，讨厌胡萝卜' } });
      assert.strictEqual(ex.status, 200);
      assert.ok(Array.isArray(ex.body.candidates));
      const values = ex.body.candidates.map((c) => `${c.category}:${c.value}`);
      assert.ok(values.includes('food:草莓'), `候选里应有 food:草莓，实际 ${values}`);
      assert.ok(values.includes('color:粉色'), `候选里应有 color:粉色，实际 ${values}`);
      assert.ok(values.includes('dislike:胡萝卜'), `候选里应有 dislike:胡萝卜，实际 ${values}`);
      assert.ok(ex.body.candidates.every((c) => c.confirmed === false));
      const list0 = await req({ method: 'GET', path: '/api/preferences', token: TOKEN });
      assert.strictEqual(list0.body.preferences.length, 0); // extract 不自动保存
      const c = await req({ method: 'POST', path: '/api/preferences', token: TOKEN, body: { category: 'food', value: '草莓' } });
      assert.strictEqual(c.status, 201);
      assert.strictEqual(c.body.confirmed, true);
      const ai = await req({ method: 'POST', path: '/api/preferences', token: TOKEN, body: { category: 'color', value: '粉色', source: 'ai' } });
      assert.strictEqual(ai.status, 201);
      assert.strictEqual(ai.body.confirmed, false); // AI 提取的要等用户确认
      const pending = await req({ method: 'GET', path: '/api/preferences/pending', token: TOKEN });
      assert.strictEqual(pending.body.preferences.length, 1);
      assert.strictEqual(pending.body.preferences[0].value, '粉色');
      const dup = await req({ method: 'POST', path: '/api/preferences', token: TOKEN, body: { category: 'food', value: '草莓' } });
      assert.strictEqual(dup.status, 200);
      assert.strictEqual(dup.body.id, c.body.id);
      const bad = await req({ method: 'POST', path: '/api/preferences', token: TOKEN, body: { category: 'secret', value: 'x' } });
      assert.strictEqual(bad.status, 400);
      const del = await req({ method: 'DELETE', path: `/api/preferences/${c.body.id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
      const del2 = await req({ method: 'DELETE', path: `/api/preferences/${ai.body.id}`, token: TOKEN });
      assert.strictEqual(del2.status, 200);
    });

    await test('gifts recommend 返回 6 条且不含价格/店铺/链接', async () => {
      const r = await req({ method: 'GET', path: '/api/gifts/recommend', token: TOKEN });
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.body.gifts.length, 6);
      for (const g of r.body.gifts) {
        assert.deepStrictEqual(Object.keys(g).sort(), ['budget', 'name', 'occasion', 'reason']);
        assert.ok(typeof g.name === 'string' && g.name.length > 0);
      }
      assert.ok(!JSON.stringify(r.body).includes('http'));
      const fav = await req({ method: 'POST', path: '/api/gifts/favorite', token: TOKEN, body: { name: '手工陶艺课', reason: '一起体验' } });
      assert.strictEqual(fav.status, 201);
      const list = await req({ method: 'GET', path: '/api/gifts/favorites', token: TOKEN });
      assert.strictEqual(list.body.favorites.length, 1);
      const del = await req({ method: 'DELETE', path: `/api/gifts/favorites/${fav.body.id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
    });

    await test('games record 每日每游戏金币上限 30 + 金币进 state', async () => {
      const r1 = await req({ method: 'POST', path: '/api/games/record', token: TOKEN, body: { game: 'strawberry', score: 10, coins: 10 } });
      assert.strictEqual(r1.status, 201);
      assert.strictEqual(r1.body.awarded, 10);
      const r2 = await req({ method: 'POST', path: '/api/games/record', token: TOKEN, body: { game: 'strawberry', score: 5, coins: 25 } });
      assert.strictEqual(r2.status, 409); // 当天 strawberry 已得 10，+25 超过 30 上限
      assert.strictEqual(r2.body.error, 'daily_coin_cap');
      assert.strictEqual(r2.body.awarded, 0);
      const r3 = await req({ method: 'POST', path: '/api/games/record', token: TOKEN, body: { game: 'guess', score: 5, coins: 30 } });
      assert.strictEqual(r3.status, 201);
      assert.strictEqual(r3.body.awarded, 30);
      const bad = await req({ method: 'POST', path: '/api/games/record', token: TOKEN, body: { game: 'chess', score: 1, coins: 1 } });
      assert.strictEqual(bad.status, 400);
      const s = await req({ method: 'GET', path: '/api/games/summary', token: TOKEN });
      assert.strictEqual(s.body.totalCoins, 40);
      assert.strictEqual(s.body.totalPlays, 2);
      assert.strictEqual(s.body.byGame.strawberry.coins, 10);
      assert.strictEqual(s.body.byGame.guess.coins, 30);
      assert.strictEqual(s.body.walletCoins, 40);
      const state = await req({ method: 'GET', path: '/api/state', token: TOKEN });
      assert.strictEqual(state.body.coins, 40); // 前面的 restore 把 coins 归零后累计
    });

    await test('state 新字段：coins/meters/hat/seenFaces，meters 按子字段合并', async () => {
      const bad1 = await req({ method: 'POST', path: '/api/state', token: TOKEN, body: { coins: -1 } });
      assert.strictEqual(bad1.status, 400);
      const bad2 = await req({ method: 'POST', path: '/api/state', token: TOKEN, body: { meters: { hunger: 101 } } });
      assert.strictEqual(bad2.status, 400);
      const bad3 = await req({ method: 'POST', path: '/api/state', token: TOKEN, body: { seenFaces: { x: 'yes' } } });
      assert.strictEqual(bad3.status, 400);
      const ok = await req({ method: 'POST', path: '/api/state', token: TOKEN, body: { coins: 42, meters: { hunger: 50 }, hat: 'flower', seenFaces: { laugh: true } } });
      assert.strictEqual(ok.status, 200);
      assert.strictEqual(ok.body.ok, true); // POST 只返回 ok，取值再 GET
      const got = await req({ method: 'GET', path: '/api/state', token: TOKEN });
      assert.strictEqual(got.body.coins, 42);
      assert.deepStrictEqual(got.body.meters, { hunger: 50, mood: 82, energy: 76 }); // 只改 hunger，其余保持默认值
      assert.strictEqual(got.body.hat, 'flower');
      assert.deepStrictEqual(got.body.seenFaces, { laugh: true });
    });

    await test('vault 只存密文：含 password 的请求拒绝', async () => {
      const bad = await req({ method: 'POST', path: '/api/vault/items', token: TOKEN, body: { blob: 'xyz', iv: 'iv', salt: 'salt', password: '123456' } });
      assert.strictEqual(bad.status, 400);
      const c = await req({ method: 'POST', path: '/api/vault/items', token: TOKEN, body: { blob: 'aGVsbG8=', iv: 'abc123', salt: 'def456' } });
      assert.strictEqual(c.status, 201);
      const id = c.body.id;
      assert.strictEqual(c.body.blob, 'aGVsbG8=');
      assert.strictEqual(c.body.password, undefined);
      const cross = await req({ method: 'GET', path: `/api/vault/items/${id}`, token: OTHER_TOKEN });
      assert.strictEqual(cross.status, 404);
      const u = await req({ method: 'PUT', path: `/api/vault/items/${id}`, token: TOKEN, body: { blob: 'd29ybGQ=', iv: 'abc123', salt: 'def456' } });
      assert.strictEqual(u.body.blob, 'd29ybGQ=');
      const list = await req({ method: 'GET', path: '/api/vault/items', token: TOKEN });
      assert.strictEqual(list.body.items.length, 1);
      assert.ok(!('password' in list.body.items[0]));
      const del = await req({ method: 'DELETE', path: `/api/vault/items/${id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
    });

    await test('photos 校验：合法 PNG 可取回，非法类型/超大拒绝，跨 token 隔离', async () => {
      const png1x1 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
      const pngBytes = Buffer.from(png1x1, 'base64');
      const up = await req({ method: 'POST', path: '/api/photos', token: TOKEN, body: { dataUrl: `data:image/png;base64,${png1x1}`, name: 'test.png' } });
      assert.strictEqual(up.status, 201);
      assert.ok(up.body.url.startsWith(`/photos/${TOKEN}/`));
      assert.ok(up.body.url.endsWith('.png'));
      const get = await fetch(new URL(up.body.url, `http://127.0.0.1:${port}`));
      assert.strictEqual(get.status, 200);
      assert.ok(get.headers.get('content-type').startsWith('image/'));
      assert.strictEqual(await get.arrayBuffer().then((b) => b.byteLength), pngBytes.length);
      // 照片存在数据库里：别人拿着另一个 token 的路径、或猜一个文件名都取不到。
      const filename = up.body.url.split('/').pop();
      const cross = await fetch(new URL(`/photos/${OTHER_TOKEN}/${filename}`, `http://127.0.0.1:${port}`));
      assert.strictEqual(cross.status, 404);
      const wrongName = await fetch(new URL(`/photos/${TOKEN}/00000000-0000-4000-8000-000000000000.png`, `http://127.0.0.1:${port}`));
      assert.strictEqual(wrongName.status, 404);
      const badToken = await fetch(new URL(`/photos/not-a-uuid/${filename}`, `http://127.0.0.1:${port}`));
      assert.strictEqual(badToken.status, 400);
      // 备份里有这张照片（base64），解码后字节一致。
      const bk = await req({ method: 'GET', path: '/api/backup', token: TOKEN });
      assert.strictEqual(bk.status, 200);
      assert.ok(Array.isArray(bk.body.photos));
      const entry = bk.body.photos.find((p) => p.filename === filename);
      assert.ok(entry, '备份里应有这张照片');
      assert.strictEqual(entry.size, pngBytes.length);
      assert.deepStrictEqual(Buffer.from(entry.data, 'base64'), pngBytes);
      const gif = await req({ method: 'POST', path: '/api/photos', token: TOKEN, body: { dataUrl: 'data:image/gif;base64,R0lGODlhAQABAAAAACw=', name: 'x.gif' } });
      assert.strictEqual(gif.status, 400);
      const big = Buffer.alloc(5 * 1024 * 1024 + 1).toString('base64');
      const over = await req({ method: 'POST', path: '/api/photos', token: TOKEN, body: { dataUrl: `data:image/jpeg;base64,${big}`, name: 'big.jpg' } });
      assert.strictEqual(over.status, 400);
    });

    await test('events 记录与校验', async () => {
      const ok = await req({ method: 'POST', path: '/api/events', token: TOKEN, body: { type: 'interact', detail: '摸摸头' } });
      assert.strictEqual(ok.status, 201);
      assert.strictEqual(ok.body.ok, true);
      // 回归：前端各模块发来的事件类型（情绪/礼物收藏/信件/回忆）必须被接受。
      for (const t of ['emotion_select', 'gift_favorite', 'letter_saved', 'memory_saved']) {
        const r = await req({ method: 'POST', path: '/api/events', token: TOKEN, body: { type: t, detail: 'x' } });
        assert.strictEqual(r.status, 201, `事件类型 ${t} 应 201，实际 ${r.status}`);
      }
      const bad = await req({ method: 'POST', path: '/api/events', token: TOKEN, body: { type: 'hacking' } });
      assert.strictEqual(bad.status, 400);
    });

    await test('letters CRUD + 收藏 + 离线 ai-draft（无 Key 时模板 + source:offline）', async () => {
      const c = await req({ method: 'POST', path: '/api/letters', token: TOKEN, body: { title: '给宝宝的信', content: '今天想你了。', occasionDate: '2026-11-11' } });
      assert.strictEqual(c.status, 201);
      const id = c.body.id;
      assert.strictEqual(c.body.status, 'draft');
      const fav = await req({ method: 'POST', path: `/api/letters/${id}/favorite`, token: TOKEN });
      assert.strictEqual(fav.body.favorite, true);
      const draft = await req({ method: 'POST', path: '/api/letters/ai-draft', token: TOKEN, body: { occasion: '纪念日' } });
      assert.strictEqual(draft.status, 200);
      assert.strictEqual(draft.body.source, 'offline'); // 测试服务器未配 Key
      assert.ok(draft.body.title.length > 0);
      assert.ok(draft.body.content.length > 0);
      assert.ok(!draft.body.content.includes('AI 生成成功'));
      const list = await req({ method: 'GET', path: '/api/letters', token: TOKEN });
      assert.strictEqual(list.body.letters.length, 1); // ai-draft 不自动保存
      // 回归：前端不填纪念日时发 occasion_date: null，可选日期的 null 必须当作“没有”接受。
      const nullDate = await req({ method: 'POST', path: '/api/letters', token: TOKEN, body: { title: '没有纪念日的信', content: '想你。', occasion_date: null, status: 'draft' } });
      assert.strictEqual(nullDate.status, 201, `occasion_date:null 应 201，实际 ${nullDate.status} ${JSON.stringify(nullDate.body)}`);
      await req({ method: 'DELETE', path: `/api/letters/${nullDate.body.id}`, token: TOKEN });
      const del = await req({ method: 'DELETE', path: `/api/letters/${id}`, token: TOKEN });
      assert.strictEqual(del.status, 200);
    });

    await test('reports today：无数据 hasData:false，有数据时真实计算', async () => {
      const empty = await req({ method: 'GET', path: '/api/reports?date=2000-01-01', token: TOKEN });
      assert.strictEqual(empty.status, 200);
      assert.strictEqual(empty.body.hasData, false);
      assert.strictEqual(empty.body.date, '2000-01-01');
      const bad = await req({ method: 'GET', path: '/api/reports?date=2000-13-01', token: TOKEN });
      assert.strictEqual(bad.status, 400);
      // 注入两条今天的聊天记录（restore 会替换该 token 全部数据）。
      const now = Date.now();
      const seeded = await req({ method: 'POST', path: '/api/restore', token: TOKEN, body: { messages: [
        { role: 'user', content: '今天开心', created_at: now },
        { role: 'assistant', content: '嘿嘿，开心就好', created_at: now },
      ] } });
      assert.strictEqual(seeded.status, 200);
      const today = await req({ method: 'GET', path: '/api/reports/today', token: TOKEN });
      assert.strictEqual(today.status, 200);
      assert.strictEqual(today.body.hasData, true);
      assert.strictEqual(today.body.chatCount, 1);
      assert.ok(typeof today.body.summary === 'string' && today.body.summary.length > 0);
      assert.strictEqual(today.body.source, 'offline'); // 未配 Key
      const cached = await req({ method: 'GET', path: '/api/reports/today', token: TOKEN });
      assert.strictEqual(cached.body.summary, today.body.summary); // 第二次读缓存，同一份
    });

    await test('backup 含全部新表、restore 回滚与恢复（含照片）', async () => {
      // 注意：前面的 reports 测试调过一次只带 messages 的 restore，按“全量替换”
      // 语义会清掉该 token 的照片；这里重新传一张，再验证备份/恢复带照片。
      const png1x1 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
      const pngBytes = Buffer.from(png1x1, 'base64');
      const up = await req({ method: 'POST', path: '/api/photos', token: TOKEN, body: { dataUrl: `data:image/png;base64,${png1x1}`, name: 'backup.png' } });
      assert.strictEqual(up.status, 201);
      const photoUrl = up.body.url;
      const photoFilename = photoUrl.split('/').pop();
      const mem = await req({ method: 'POST', path: '/api/memories', token: TOKEN, body: { title: '备份测试', date: '2026-11-11' } });
      assert.strictEqual(mem.status, 201);
      const let1 = await req({ method: 'POST', path: '/api/letters', token: TOKEN, body: { title: '信', content: '内容' } });
      assert.strictEqual(let1.status, 201);
      const v = await req({ method: 'POST', path: '/api/vault/items', token: TOKEN, body: { blob: 'Y2lwaGVy', iv: 'iv1', salt: 's1' } });
      assert.strictEqual(v.status, 201);
      const backup = await req({ method: 'GET', path: '/api/backup', token: TOKEN });
      assert.strictEqual(backup.status, 200);
      assert.ok(Array.isArray(backup.body.memories) && backup.body.memories.length >= 1);
      assert.ok(Array.isArray(backup.body.letters) && backup.body.letters.length >= 1);
      assert.ok(Array.isArray(backup.body.vault_items) && backup.body.vault_items.length >= 1);
      assert.ok(!('password' in backup.body.vault_items[0]));
      assert.ok(Array.isArray(backup.body.game_records));
      assert.ok(Array.isArray(backup.body.daily_reports));
      assert.ok(Array.isArray(backup.body.photos) && backup.body.photos.length >= 1);
      const photoEntry = backup.body.photos.find((p) => p.filename === photoFilename);
      assert.ok(photoEntry, '备份里应有刚上传的照片');
      assert.deepStrictEqual(Buffer.from(photoEntry.data, 'base64'), pngBytes);
      // 非法备份：恢复应 400，且原数据完好（回滚）。
      const badRestore = await req({ method: 'POST', path: '/api/restore', token: TOKEN, body: { memories: [{ title: '', date: '2026-11-11' }] } });
      assert.strictEqual(badRestore.status, 400);
      const stillThere = await req({ method: 'GET', path: `/api/memories/${mem.body.id}`, token: TOKEN });
      assert.strictEqual(stillThere.status, 200);
      // 删了再用备份恢复。
      await req({ method: 'DELETE', path: `/api/memories/${mem.body.id}`, token: TOKEN });
      const restored = await req({ method: 'POST', path: '/api/restore', token: TOKEN, body: backup.body });
      assert.strictEqual(restored.status, 200);
      assert.ok(restored.body.imported.memories >= 1);
      assert.ok(restored.body.imported.letters >= 1);
      assert.ok(restored.body.imported.vault_items >= 1);
      assert.ok(restored.body.imported.photos >= 1);
      const back = await req({ method: 'GET', path: '/api/memories?q=备份测试', token: TOKEN });
      assert.strictEqual(back.body.memories.length, 1);
      // 恢复后照片能取回，字节一致。
      const getPhoto = await fetch(new URL(photoUrl, `http://127.0.0.1:${port}`));
      assert.strictEqual(getPhoto.status, 200);
      assert.deepStrictEqual(Buffer.from(await getPhoto.arrayBuffer()), pngBytes);
    });
  } finally {
    await new Promise((resolve) => server.close(resolve));
    await closeDb();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }

  const failed = results.filter((r) => !r.ok);
  console.log(`\n${results.length - failed.length}/${results.length} 通过`);
  process.exit(failed.length ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
