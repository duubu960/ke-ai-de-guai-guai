#!/usr/bin/env bash
# 可爱的乖乖 v2 联调测试（curl 版，不用真实 Key）
# 用法：bash scripts/test-integration.sh
# 阶段一（无 Key）：静态文件、health、chat 503、state 存取往返、history、隔离、备份、DB 检查
# 阶段二（假 Key）：证明代理真的打到了 DeepSeek（上游 401 正确映射），失败聊天不写库
set -u
cd "$(dirname "$0")/.."

# PostgreSQL 模式：设置了 DATABASE_URL 时走 pg（Neon/本地 pg），DB 检查改用 pg-query.js；
# 未设置时走原来的 SQLite 文件检查。
PGMODE=0; [ -n "${DATABASE_URL:-}" ] && PGMODE=1
pgq() { node scripts/pg-query.js "$1"; }
db_tables() { if [ $PGMODE -eq 1 ]; then pgq "SELECT tablename AS name FROM pg_tables WHERE schemaname='public' ORDER BY 1"; else sqlite3 "$1" ".tables"; fi; }
db_count() { # $1=SQL（返回一列 n） $2=sqlite 文件；输出一个数字
  if [ $PGMODE -eq 1 ]; then pgq "$1" | grep -o '"n":[0-9]*' | grep -o '[0-9]*'; else sqlite3 "$2" "$1"; fi; }

PASS=0; FAIL=0
T1=123e4567-e89b-42d3-a456-426614174000
T2=123e4567-e89b-42d3-a456-426614174001

ck() { if [ "$2" = "$3" ]; then PASS=$((PASS+1)); echo "PASS $1"; else FAIL=$((FAIL+1)); echo "FAIL $1: expected [$2] got [$3]"; fi; }
has() { if grep -qF "$2" "$3"; then ck "$1" ok ok; else ck "$1" ok "missing: $2"; fi; }
start_server() { # $1=port $2=db $3=extra env assignment or empty
  env DB_PATH="$2" PORT="$1" $3 node backend/server.js > "/tmp/v2-server-$1.log" 2>&1 &
  echo $!
}
wait_up() { for _ in $(seq 1 20); do curl -s -o /dev/null "http://127.0.0.1:$1/" && return 0; sleep 0.5; done; return 1; }

# ---------- Phase 1: 无 Key ----------
PORT=3124; DB=/tmp/guai-v2-phase1.sqlite
rm -f "$DB" "$DB-wal" "$DB-shm"
SRV=$(start_server $PORT "$DB" "")
wait_up $PORT || { echo "server failed to start"; tail -20 /tmp/v2-server-$PORT.log; exit 1; }
B=http://127.0.0.1:$PORT
ck 'GET / -> 200' 200 "$(curl -s -o /tmp/v2-index.html -w '%{http_code}' $B/)"
has 'index 引用 css' 'css/style.css' /tmp/v2-index.html
has 'index 引用 js' 'js/app.js' /tmp/v2-index.html
ck 'GET /css/style.css -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' $B/css/style.css)"
ck 'GET /js/app.js -> 200' 200 "$(curl -s -o /tmp/v2-app.js -w '%{http_code}' $B/js/app.js)"
has 'app.js 走后端接口' '/api/chat' /tmp/v2-app.js
ck 'GET /assets/avatar.jpg -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' $B/assets/avatar.jpg)"
ck 'health 无 Token -> 400' 400 "$(curl -s -o /dev/null -w '%{http_code}' $B/api/health)"
curl -s -H "X-User-Token: $T1" $B/api/health > /tmp/v2-health.json
ck 'health 有 Token -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" $B/api/health)"
has 'health 报 missing' 'missing' /tmp/v2-health.json
ck 'chat 无 Key -> 503' 503 "$(curl -s -o /tmp/v2-chat.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"messages":[{"role":"user","content":"你好"}]}' $B/api/chat)"
has 'chat 503 错误码' 'deepseek_key_missing' /tmp/v2-chat.json
# 注意：后端有意只接受零补的 YYYY-MM-DD；前端发送前会把 "2026-1-5" 补成 "2026-01-05"，
# 所以这里按前端实际发送的格式传。直接传 "2026-1-5" 应得 400（后端校验在工作）。
ck 'state 保存 -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"profile":{"name":"测试","likes":["草莓"]},"affection":80,"memories":[{"t":1762800000000,"title":"第一次见面","detail":"测试","emotion":"开心"}],"firstMet":1762800000000,"lastVisit":1762800000000,"lastTopic":"草莓","recentReplies":["你好呀"],"dailyGiftDate":"2026-01-05"}' $B/api/state)"
curl -s -H "X-User-Token: $T1" $B/api/state > /tmp/v2-state.json
has 'state 读回名字' '测试' /tmp/v2-state.json
has 'state 日期被规范化' '2026-01-05' /tmp/v2-state.json
curl -s -H "X-User-Token: $T1" "$B/api/history" > /tmp/v2-history.json
has 'history 初始为空' '"messages":[]' /tmp/v2-history.json
curl -s -H "X-User-Token: $T2" $B/api/state > /tmp/v2-state2.json
has '不同 Token 数据隔离' '"name":""' /tmp/v2-state2.json
ck 'backup -> 200' 200 "$(curl -s -o /tmp/v2-backup.json -w '%{http_code}' -H "X-User-Token: $T1" $B/api/backup)"
has 'backup 含 messages' '"messages"' /tmp/v2-backup.json
kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
db_tables "$DB" > /tmp/v2-tables.txt
has 'DB 有三张表' 'user_state' /tmp/v2-tables.txt
CNT=$(db_count "SELECT COUNT(*) AS n FROM messages" "$DB")
ck 'DB messages 为空（失败聊天不写库）' 0 "$CNT"
rm -f "$DB" "$DB-wal" "$DB-shm"

# ---------- Phase 2: 假 Key 直连 ----------
PORT=3125; DB=/tmp/guai-v2-phase2.sqlite
rm -f "$DB" "$DB-wal" "$DB-shm"
SRV=$(start_server $PORT "$DB" "DEEPSEEK_API_KEY=sk-test-dummy-key")
wait_up $PORT || { echo "server failed to start (phase 2)"; tail -20 /tmp/v2-server-$PORT.log; exit 1; }
B=http://127.0.0.1:$PORT
ck 'health 假 Key -> configured' configured "$(curl -s -H "X-User-Token: $T1" $B/api/health | grep -o 'configured')"
START=$(date +%s)
HTTP=$(curl -s -o /tmp/v2-chat2.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"messages":[{"role":"user","content":"你好"}]}' $B/api/chat)
ELAPSED=$(( $(date +%s) - START ))
ck 'chat 假 Key -> 401（代理已打到 DeepSeek）' 401 "$HTTP"
has 'chat 401 错误码' 'deepseek_unauthorized' /tmp/v2-chat2.json
echo "  （本次假 Key 调用耗时约 ${ELAPSED}s，上游拒绝后正确映射，未写库）"
curl -s -H "X-User-Token: $T1" "$B/api/history" > /tmp/v2-history2.json
has 'history 失败后仍为空' '"messages":[]' /tmp/v2-history2.json
kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
rm -f "$DB" "$DB-wal" "$DB-shm"

# ---------- Phase 3: 新接口冒烟（无 Key） ----------
PORT=3126; DB=/tmp/guai-v2-phase3.sqlite
rm -f "$DB" "$DB-wal" "$DB-shm"
SRV=$(start_server $PORT "$DB" "")
wait_up $PORT || { echo "server failed to start (phase 3)"; tail -20 /tmp/v2-server-$PORT.log; exit 1; }
B=http://127.0.0.1:$PORT
ck 'health -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" $B/api/health)"
ck 'memories 创建 -> 201' 201 "$(curl -s -o /tmp/v2-mem.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"title":"第一次约会","date":"2026-11-10","description":"一起散步"}' $B/api/memories)"
has 'memories 读回' '第一次约会' /tmp/v2-mem.json
curl -s -H "X-User-Token: $T1" "$B/api/memories?month=2026-11" > /tmp/v2-memlist.json
has 'memories 按月筛选' '第一次约会' /tmp/v2-memlist.json
ck 'anniversaries 创建 -> 201' 201 "$(curl -s -o /tmp/v2-ann.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"title":"第一次见面","date":"2025-11-11","type":"first_meet"}' $B/api/anniversaries)"
curl -s -H "X-User-Token: $T1" $B/api/anniversaries/summary > /tmp/v2-annsum.json
has 'anniversaries summary 有 daysTogether' 'daysTogether' /tmp/v2-annsum.json
ck 'surprise 第一次开 -> 201' 201 "$(curl -s -o /tmp/v2-surp1.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{}' $B/api/surprise/open)"
has 'surprise 是新开的' '"isNew":true' /tmp/v2-surp1.json
ck 'surprise 第二次开 -> 200（同一份）' 200 "$(curl -s -o /tmp/v2-surp2.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{}' $B/api/surprise/open)"
has 'surprise 第二次非新' '"isNew":false' /tmp/v2-surp2.json
ID1=$(grep -o '"id":[0-9]*' /tmp/v2-surp1.json | head -1)
ID2=$(grep -o '"id":[0-9]*' /tmp/v2-surp2.json | head -1)
ck 'surprise 两次同一 id' "$ID1" "$ID2"
ck 'wishlists 创建 -> 201' 201 "$(curl -s -o /tmp/v2-wish.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"title":"一起去海边","category":"旅行","priority":1}' $B/api/wishlists)"
WID=$(grep -o '"id":[0-9]*' /tmp/v2-wish.json | head -1 | grep -o '[0-9]*')
ck 'wishlists 完成 -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -X POST $B/api/wishlists/$WID/complete)"
ck 'preferences 创建 -> 201' 201 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"category":"food","value":"草莓"}' $B/api/preferences)"
curl -s -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"text":"我喜欢吃草莓，最喜欢粉色"}' $B/api/preferences/extract > /tmp/v2-prefex.json
has 'preferences extract 出候选' '草莓' /tmp/v2-prefex.json
has 'preferences extract 待确认' '"confirmed":false' /tmp/v2-prefex.json
curl -s -H "X-User-Token: $T1" $B/api/gifts/recommend > /tmp/v2-gifts.json
has 'gifts recommend 返回礼物' '"name"' /tmp/v2-gifts.json
ck 'games 记录 -> 201' 201 "$(curl -s -o /tmp/v2-game.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"game":"strawberry","score":10,"coins":10}' $B/api/games/record)"
has 'games 得 10 金币' '"awarded":10' /tmp/v2-game.json
ck 'games 超每日上限 -> 409' 409 "$(curl -s -o /tmp/v2-game2.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"game":"strawberry","score":5,"coins":25}' $B/api/games/record)"
has 'games 上限错误码' 'daily_coin_cap' /tmp/v2-game2.json
curl -s -H "X-User-Token: $T1" $B/api/reports/today > /tmp/v2-report.json
has 'reports today 有数据' '"hasData":true' /tmp/v2-report.json
has 'reports today 离线总结' '"source":"offline"' /tmp/v2-report.json
curl -s -H "X-User-Token: $T1" "$B/api/reports?date=2000-01-01" > /tmp/v2-report0.json
has 'reports 无数据 hasData:false' '"hasData":false' /tmp/v2-report0.json
ck 'letters 创建 -> 201' 201 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"title":"给宝宝的信","content":"今天想你了。"}' $B/api/letters)"
curl -s -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"occasion":"纪念日"}' $B/api/letters/ai-draft > /tmp/v2-draft.json
has 'letters ai-draft 离线模板' '"source":"offline"' /tmp/v2-draft.json
ck 'vault 存密文 -> 201' 201 "$(curl -s -o /tmp/v2-vault.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"blob":"Y2lwaGVy","iv":"iv1","salt":"s1"}' $B/api/vault/items)"
has 'vault 返回密文' 'Y2lwaGVy' /tmp/v2-vault.json
ck 'vault 拒收密码 -> 400' 400 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"blob":"x","iv":"i","salt":"s","password":"123"}' $B/api/vault/items)"
PNG='iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
ck 'photos 上传 -> 201' 201 "$(curl -s -o /tmp/v2-photo.json -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d "{\"dataUrl\":\"data:image/png;base64,$PNG\",\"name\":\"test.png\"}" $B/api/photos)"
PHOTO_URL=$(grep -o '"/photos/[^"]*"' /tmp/v2-photo.json | head -1 | tr -d '"')
ck 'photos 取回 -> 200' 200 "$(curl -s -o /dev/null -w '%{http_code}' $B$PHOTO_URL)"
ck 'photos 拒 GIF -> 400' 400 "$(curl -s -o /dev/null -w '%{http_code}' -H "X-User-Token: $T1" -H 'Content-Type: application/json' -d '{"dataUrl":"data:image/gif;base64,R0lGODlhAQABAAAAACw=","name":"x.gif"}' $B/api/photos)"
ck 'backup 含新表 -> 200' 200 "$(curl -s -o /tmp/v2-backup3.json -w '%{http_code}' -H "X-User-Token: $T1" $B/api/backup)"
has 'backup 含 memories' '"memories"' /tmp/v2-backup3.json
has 'backup 含 vault_items' '"vault_items"' /tmp/v2-backup3.json
kill $SRV 2>/dev/null; wait $SRV 2>/dev/null
db_tables "$DB" > /tmp/v2-tables3.txt
has 'DB 有 memories 表' 'memories' /tmp/v2-tables3.txt
has 'DB 有 vault_items 表' 'vault_items' /tmp/v2-tables3.txt
has 'DB 有 photos 表' 'photos' /tmp/v2-tables3.txt
if [ $PGMODE -eq 1 ]; then
  MIG=$(db_count "SELECT COUNT(*) AS n FROM migrations" "$DB")
  ck '迁移记录 2 条（002-phase3.pg.sql + 003-photos.pg.sql）' 2 "$MIG"
else
  MIG=$(sqlite3 "$DB" "SELECT COUNT(*) FROM migrations WHERE name='002-phase3.sql';")
  ck '迁移记录 002-phase3.sql' 1 "$MIG"
  MIG3=$(sqlite3 "$DB" "SELECT COUNT(*) FROM migrations WHERE name='003-photos.sql';")
  ck '迁移记录 003-photos.sql' 1 "$MIG3"
fi
rm -f "$DB" "$DB-wal" "$DB-shm"

echo "----------------------------------------"
echo "PASS: $PASS  FAIL: $FAIL"
[ $FAIL -eq 0 ]
