#!/usr/bin/env node
// Phase 3 feature integration test: jsdom + REAL server, REAL APIs, no stubs.
// Covers the B + C modules (surprise/wishlist/preferences/gifts/sleep/games/
// voice/report/vault) end to end. A modules (memories/emotion/anniversaries/
// letters) get their own integration run once they land.
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const { JSDOM } = require('jsdom');

const PORT = 3100 + Math.floor(Math.random() * 800); // 每次随机端口：旧测试崩溃留下的
// 服务器不能再“冒名顶替”这个端口（之前有个 01:39 的残留进程就导致联调一直测旧代码）。
const DB = '/tmp/guai-v3-features-' + PORT + '.sqlite';
const ROOT = path.resolve(__dirname, '..');
const TOKEN = '123e4567-e89b-42d3-a456-426614174001';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
function ck(name, ok, extra) {
  if (ok) { pass++; console.log('PASS ' + name); }
  else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + String(extra).slice(0, 300) : '')); }
}
async function waitFor(fn, timeoutMs, intervalMs) {
  const end = Date.now() + (timeoutMs || 8000);
  while (Date.now() < end) {
    let v = null;
    try { v = fn(); } catch (e) { v = null; }
    if (v) return v;
    await sleep(intervalMs || 250);
  }
  return null;
}
function api(method, p, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request({
      host: '127.0.0.1', port: PORT, path: p, method,
      headers: { 'Content-Type': 'application/json', 'X-User-Token': TOKEN },
    }, res => {
      let d = '';
      res.on('data', c => { d += c; });
      res.on('end', () => {
        let j = null;
        try { j = JSON.parse(d); } catch (e) { j = null; }
        resolve({ status: res.statusCode, body: j, raw: d });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// List endpoints wrap arrays in an object ({surprises: [...]}, {wishlists: [...]},
// {preferences: [...]}, {records: [...]}, ...). Unwrap generically.
function asList(body) {
  if (Array.isArray(body)) return body;
  if (!body || typeof body !== 'object') return [];
  const keys = ['surprises', 'wishlists', 'preferences', 'candidates', 'gifts', 'favorites', 'records', 'items', 'letters', 'memories', 'anniversaries'];
  for (const k of keys) if (Array.isArray(body[k])) return body[k];
  return [];
}

(async () => {
  const env = Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: DB });
  const srv = spawn('node', ['backend/server.js'], { cwd: ROOT, env, stdio: 'pipe' });
  try {
    await run(srv);
  } finally {
    srv.kill(); // 哪怕中途崩溃也要杀掉服务器，不能留下残留进程占端口。
  }
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('test crashed:', e); process.exit(1); });

async function run(srv) {
  let srvErr = '';
  srv.stderr.on('data', d => { srvErr += d.toString(); });
  const base = 'http://127.0.0.1:' + PORT;
  let up = false;
  for (let i = 0; i < 20 && !up; i++) {
    await sleep(500);
    up = await new Promise(res => { http.get(base + '/', r => res(r.statusCode === 200)).on('error', () => res(false)); });
  }
  ck('server starts', up, srvErr.slice(0, 300));
  if (!up) { srv.kill(); process.exit(1); }

  // Seed real data via /api/restore (a real endpoint, legitimate test setup).
  const now = Date.now();
  const seed = await api('POST', '/api/restore', {
    state: {
      profile: { name: '测试宝宝', likes: ['草莓'] },
      affection: 90, memories: [], firstMet: now - 5 * 86400000,
      lastVisit: now, lastTopic: '草莓', recentReplies: [], dailyGiftDate: '',
    },
    messages: [
      { role: 'user', content: '我喜欢吃芒果，我喜欢喝珍珠奶茶', created_at: now - 60000 },
      { role: 'assistant', content: '好，记下了', created_at: now - 59000 },
    ],
  });
  ck('seed via /api/restore', seed.status === 200, seed.raw);

  // Seed confirmed preferences + an anniversary so gift recommendations have
  // real data to work with (an empty recommendation list is honest, not a bug).
  const pref1 = await api('POST', '/api/preferences', { category: 'food', value: '草莓', confirmed: true, source: 'manual' });
  const pref2 = await api('POST', '/api/preferences', { category: 'gift', value: '手写信', confirmed: true, source: 'manual' });
  const ann1 = await api('POST', '/api/anniversaries', { title: '恋爱纪念日', date: '2026-12-25', type: 'anniversary', note: '' });
  const okStatus = s => s === 200 || s === 201;
  ck('seed preferences + anniversary', okStatus(pref1.status) && okStatus(pref2.status) && okStatus(ann1.status), [pref1.raw, pref2.raw, ann1.raw].join(' | '));

  const dom = await JSDOM.fromURL(base + '/', {
    resources: 'usable', runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(window) {
      window.localStorage.setItem('gg_user_token_v1', TOKEN);
      window.confirm = () => true;
      // jsdom 的 window.crypto 没有 subtle（保险箱会以为浏览器不支持加密）；
      // 把 Node 的 WebCrypto 交给页面，行为和真浏览器一致。
      try { window.crypto = globalThis.crypto; } catch (e) {
        try { Object.defineProperty(window, 'crypto', { value: globalThis.crypto, configurable: true }); } catch (e2) {}
      }
      const _f = globalThis.fetch;
      window.fetch = (input, init) => {
        if (typeof input === 'string' && input.startsWith('/')) input = base + input;
        if (init && init.signal) {
          const ctrl = new AbortController();
          const sig = init.signal;
          if (sig.aborted) ctrl.abort();
          else sig.addEventListener('abort', () => ctrl.abort());
          init = Object.assign({}, init, { signal: ctrl.signal });
        }
        return _f(input, init);
      };
      window.AudioContext = function () {
        this.currentTime = 0; this.destination = {};
        this.resume = () => Promise.resolve();
        this.createOscillator = () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0 }, type: '' });
        this.createGain = () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {}, linearRampToValueAtTime() {}, setTargetAtTime() {} } });
      };
      window.webkitAudioContext = window.AudioContext;
      window.navigator.vibrate = () => true;
    },
  });
  const { window } = dom;
  const { document } = window;
  const errors = [];
  window.addEventListener('error', e => errors.push(e.message || String(e.error)));
  dom.virtualConsole.on('jsdomError', e => errors.push(e.message || String(e)));
  const q = s => document.querySelector(s);
  const qa = s => Array.from(document.querySelectorAll(s));

  // Wait for the B + C modules to render.
  const rendered = await waitFor(() => (
    q('#spOpenBtn') && q('#wlAddBtn') && q('#pfExtractBtn') &&
    q('#games-root .gm-card') && q('#voiceMicBtn') &&
    q('[data-report-body]') && q('[data-vault-body]') &&
    q('#gfList') && q('#gfList').textContent.trim().length > 0
  ), 15000);
  if (!rendered) {
    const missing = ['#spOpenBtn', '#wlAddBtn', '#pfExtractBtn', '#games-root .gm-card', '#voiceMicBtn', '[data-report-body]', '[data-vault-body]', '#gfList'].filter(s => !q(s));
    ck('B + C modules render', false, 'missing: ' + missing.join(', '));
  } else {
    ck('B + C modules render', true);
  }
  ck('GG bridge present', !!window.GG);
  ck('gifts recommend renders 6 items', (q('#gfList').textContent.match(/收藏/g) || []).length >= 6, q('#gfList').textContent.slice(0, 120));

  // ---- 1. Surprise box (real once-a-day rule) ----
  q('#spOpenBtn').click();
  const surpriseShown = await waitFor(() => {
    const t = q('#spTodayBody').textContent;
    return t && t.indexOf('正在看看') === -1 && t.length > 10 ? t : null;
  }, 8000);
  ck('surprise opens with real content', !!surpriseShown, surpriseShown && surpriseShown.slice(0, 80));
  const hist1 = await api('GET', '/api/surprises/history?limit=5');
  const hist1List = asList(hist1.body);
  ck('surprise history has 1 item (server)', hist1.status === 200 && hist1List.length === 1, hist1.raw);
  const openAgain = await api('POST', '/api/surprise/open', {});
  ck('second open returns the same surprise (once a day)', openAgain.status === 200 && openAgain.body && openAgain.body.isNew === false && hist1List[0] && openAgain.body.id === hist1List[0].id, openAgain.raw);
  const hist2 = await api('GET', '/api/surprises/history?limit=5');
  ck('history still 1 item after second open', asList(hist2.body).length === 1);

  // ---- 2. Wishlist: create + complete (real API) ----
  q('#wlAddBtn').click();
  const titleInput = await waitFor(() => q('#wlFTitle'), 5000);
  ck('wishlist form opens', !!titleInput);
  if (titleInput) titleInput.value = '去看海';
  q('#wlSaveBtn').click();
  const wishInList = await waitFor(() => q('#wlList') && q('#wlList').textContent.indexOf('去看海') > -1, 8000);
  ck('wishlist item created and listed', !!wishInList, wishInList ? '' : 'notice: ' + (q('#aiNotice') ? q('#aiNotice').textContent : '') + ' | wlList: ' + (q('#wlList') ? q('#wlList').textContent.slice(0, 100) : ''));
  const wl1 = await api('GET', '/api/wishlists');
  const wl1List = asList(wl1.body);
  ck('wishlist API has the item', wl1.status === 200 && wl1List.length === 1 && wl1List[0].title === '去看海', wl1.raw);
  const completeBtn = q('#wlList [data-act="complete"]');
  if (completeBtn) completeBtn.click();
  const celebrated = await waitFor(() => q('#wlCele') && q('#wlCele').textContent.indexOf('完成啦') > -1, 8000);
  ck('completing a wish shows celebration', !!celebrated);
  const wl2 = await api('GET', '/api/wishlists/summary');
  ck('wishlist summary done=1', wl2.status === 200 && wl2.body && wl2.body.done === 1 && wl2.body.total === 1, wl2.raw);

  // ---- 3. Preferences: extract from REAL chat history + confirm ----
  q('#pfExtractBtn').click();
  const cand = await waitFor(() => {
    const items = qa('#pfPendList [data-act="ok"]');
    return items.length ? items : null;
  }, 10000);
  ck('extract finds candidates from real chat history', !!cand, 'pending buttons: ' + (cand ? cand.length : 0));
  let confirmedValue = '';
  if (cand) {
    const pendText = q('#pfPendList').textContent;
    const m = pendText.match(/(芒果|珍珠奶茶|奶茶)/);
    confirmedValue = m ? m[1] : '';
    cand[0].click();
    const confirmedShown = await waitFor(() => q('#pfList') && confirmedValue && q('#pfList').textContent.indexOf(confirmedValue) > -1, 8000);
    ck('confirming a candidate moves it to confirmed', !!confirmedShown, 'value: ' + confirmedValue);
    const prefs = await api('GET', '/api/preferences');
    const prefsList = asList(prefs.body);
    const row = prefsList.find(p => p.value === confirmedValue && p.confirmed);
    ck('confirmed preference persisted on server', !!row, prefs.raw);
  }

  // ---- 4. Gifts: favorite one ----
  const favBtn = qa('#gfList button').find(b => b.textContent.indexOf('收藏') > -1);
  ck('gift favorite button exists', !!favBtn);
  let favName = '';
  if (favBtn) {
    const card = favBtn.closest('.gf-item');
    favName = card ? (card.querySelector('.gf-name') ? card.querySelector('.gf-name').textContent.replace('🎁', '').trim() : '') : '';
    favBtn.click();
  }
  const favShown = await waitFor(() => q('#gfFavList') && favName && q('#gfFavList').textContent.indexOf(favName) > -1, 8000);
  ck('gift favorite shows in favorites list', !!favShown, 'name: ' + favName + ' favlist: ' + (q('#gfFavList') ? q('#gfFavList').textContent.slice(0, 80) : ''));
  const gf = await api('GET', '/api/gifts/favorites');
  ck('gift favorite persisted on server', gf.status === 200 && asList(gf.body).length === 1, gf.raw);

  // ---- 5. Games: guess-the-number, binary search to a real win ----
  // 游戏卡片的玩法是点「开始玩」后才展开构建的。
  const guessToggle = qa('#games-root .gm-toggle')[0];
  ck('guess game card renders', !!guessToggle);
  if (guessToggle) guessToggle.click();
  await waitFor(() => q('#games-root [data-guess-input]'), 5000);
  const guessInput = q('#games-root [data-guess-input]');
  const guessCard = guessInput ? guessInput.closest('.gm-card') : null;
  ck('guess game opens and shows its input', !!guessCard && !!guessInput);
  let won = false;
  let lo = 1, hi = 100;
  for (let i = 0; i < 7 && !won && guessCard; i++) {
    const mid = Math.floor((lo + hi) / 2);
    const input = guessCard.querySelector('[data-guess-input]');
    const go = guessCard.querySelector('[data-guess-go]');
    input.value = String(mid);
    go.click();
    await sleep(400);
    // 注意：卡片副标题里就有“猜中”两个字，必须只读结果行（.gm-result）。
    const resEl = guessCard.querySelector('.gm-result');
    const text = resEl ? resEl.textContent : '';
    if (text.indexOf('猜中啦') > -1) { won = true; break; }
    if (text.indexOf('小了') > -1) lo = mid + 1;
    else if (text.indexOf('大了') > -1) hi = mid - 1;
    else if (text.indexOf('机会用完') > -1) break;
  }
  ck('guess game can be won by binary search (<=7 tries)', won);
  // 成绩是异步记的，等一下再查服务器。
  await sleep(800);
  const recs = await api('GET', '/api/games/records?game=guess&limit=5');
  ck('game record persisted on server', recs.status === 200 && asList(recs.body).length >= 1, recs.raw);
  const sum = await api('GET', '/api/games/summary');
  ck('games summary shows the play', sum.status === 200 && sum.body && sum.body.byGame && sum.body.byGame.guess && sum.body.byGame.guess.plays >= 1, sum.raw);
  const st = await api('GET', '/api/state');
  ck('coins increased by the win', st.status === 200 && st.body && typeof st.body.coins === 'number' && st.body.coins >= 10, st.raw);

  // ---- 6. Vault: real WebCrypto round-trip ----
  const vaultBody = () => q('[data-vault-body]');
  const setPw = await waitFor(() => vaultBody() && vaultBody().querySelector('[data-vt-pw1]'), 5000);
  ck('vault setup form renders', !!setPw, setPw ? '' : 'vault body: ' + (vaultBody() ? vaultBody().textContent.slice(0, 150) : '(no body)'));
  if (setPw) {
    vaultBody().querySelector('[data-vt-pw1]').value = 'test1234';
    vaultBody().querySelector('[data-vt-pw2]').value = 'test1234';
    vaultBody().querySelector('[data-vt-setup]').click();
    const addForm = await waitFor(() => vaultBody() && vaultBody().querySelector('[data-vt-title]'), 8000);
    ck('vault unlocks after setup', !!addForm);
    if (addForm) {
      vaultBody().querySelector('[data-vt-title]').value = '小秘密';
      vaultBody().querySelector('[data-vt-content]').value = '今天很开心';
      vaultBody().querySelector('[data-vt-add]').click();
      const itemShown = await waitFor(() => vaultBody().textContent.indexOf('小秘密') > -1, 8000);
      ck('vault item saved and listed', !!itemShown);
      const vi = await api('GET', '/api/vault/items');
      const viList = asList(vi.body);
      ck('vault stores only ciphertext on server', vi.status === 200 && viList.length === 1 && JSON.stringify(viList).indexOf('小秘密') === -1 && JSON.stringify(viList).indexOf('今天很开心') === -1, vi.raw);
      const lockBtn = vaultBody().querySelector('[data-vt-lock]');
      if (lockBtn) lockBtn.click();
      const unlockForm = await waitFor(() => vaultBody() && vaultBody().querySelector('input[type="password"]'), 5000);
      ck('lock returns to password prompt', !!unlockForm);
      if (unlockForm) {
        vaultBody().querySelector('input[type="password"]').value = 'wrong123';
        const unlockBtn = qa('[data-vault-body] button').find(b => b.textContent.indexOf('解锁') > -1 || b.textContent.indexOf('打开') > -1);
        if (unlockBtn) unlockBtn.click();
        const wrongMsg = await waitFor(() => vaultBody().textContent.indexOf('不对') > -1, 5000);
        ck('wrong password is rejected', !!wrongMsg);
        vaultBody().querySelector('input[type="password"]').value = 'test1234';
        const unlockBtn2 = qa('[data-vault-body] button').find(b => b.textContent.indexOf('解锁') > -1 || b.textContent.indexOf('打开') > -1);
        if (unlockBtn2) unlockBtn2.click();
        const itemBack = await waitFor(() => vaultBody().textContent.indexOf('小秘密') > -1, 8000);
        ck('right password decrypts the item back', !!itemBack);
        const delBtn = vaultBody().querySelector('[data-vt-del]');
        if (delBtn) delBtn.click();
        const gone = await waitFor(() => vaultBody().textContent.indexOf('小秘密') === -1, 5000);
        ck('vault item deletes', !!gone);
      }
    }
  }

  // ---- 7. Daily report: real numbers, cross-checked with the API ----
  const repBtn = q('[data-report-refresh]');
  if (repBtn) repBtn.click();
  const repShown = await waitFor(() => {
    const t = q('[data-report-body]').textContent;
    return t && t.indexOf('正在整理') === -1 && t.length > 20 ? t : null;
  }, 8000);
  ck('daily report renders', !!repShown, repShown && repShown.slice(0, 100));
  const repApi = await api('GET', '/api/reports/today');
  ck('report API has real data', repApi.status === 200 && repApi.body && repApi.body.hasData === true, repApi.raw);
  if (repApi.body && repApi.body.hasData) {
    const chatCount = repApi.body.chatCount;
    ck('report UI shows the same chat count as the API', typeof chatCount === 'number' && repShown.indexOf(String(chatCount)) > -1, 'api chatCount=' + chatCount + ' ui=' + (repShown || '').slice(0, 120));
  }

  // ---- 8. Sleep mode overlay ----
  const sleepEntry = qa('.actions button').find(b => b.textContent.indexOf('陪我睡觉') > -1);
  ck('sleep entry button exists on home', !!sleepEntry);
  if (sleepEntry) sleepEntry.click();
  const overlay = await waitFor(() => q('[data-sleep-close]'), 5000);
  ck('sleep overlay opens (moon/stars/pig)', !!overlay && !!q('.sleep-moon'));
  if (overlay) {
    const storyBtn = qa('[data-sleep-quick]').find(b => b.textContent.indexOf('睡前故事') > -1);
    ck('sleep story shortcut exists', !!storyBtn);
    const chatBefore = document.querySelectorAll('#chatLog .msg-row').length;
    if (storyBtn) storyBtn.click();
    const storySent = await waitFor(() => document.querySelectorAll('#chatLog .msg-row').length > chatBefore, 8000);
    ck('sleep story sends a message into home chat', !!storySent);
    q('[data-sleep-close]').click();
    await sleep(400);
    ck('sleep overlay closes', !q('[data-sleep-close]') || q('[data-sleep-close]').offsetParent === null);
  }

  // ---- 9. Voice: unsupported browsers get an honest notice ----
  ck('voice mic button exists', !!q('#voiceMicBtn'));
  q('#voiceMicBtn').click();
  await sleep(600);
  const notice = q('#aiNotice');
  ck('voice input honestly reports unsupported in jsdom', notice && !notice.hidden && notice.textContent.indexOf('不支持') > -1, notice && notice.textContent);

  ck('no page JS errors', errors.length === 0, errors.slice(0, 3).join(' | '));

  window.close();
  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
}
