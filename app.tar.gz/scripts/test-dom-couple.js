#!/usr/bin/env node
// 可爱的乖乖 v2.2.0 情侣绑定 DOM 验证（jsdom，伪造 window.GG.apiFetch）
// 用法：node scripts/test-dom-couple.js
// 不启动真实服务器：后端接口由另一个 agent 在做，这里用写死的响应验证渲染逻辑：
//  - 未绑定态有生成按钮、点生成后出现 6 位码
//  - 已绑定态（role a / role b）显示已绑定与解除按钮
//  - 输入不足 6 位会提示；join 的 404/400/409 各有对应提示
//  - 点解除绑定（confirm 通过）后回到未绑定态
'use strict';
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const ROOT = path.resolve(__dirname, '..');
const SRC = fs.readFileSync(path.join(ROOT, 'frontend/js/features/couple.js'), 'utf8');

let pass = 0, fail = 0;
function ck(name, ok, extra) {
  if (ok) { pass++; console.log('PASS ' + name); }
  else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + extra : '')); }
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function resp(status, data) {
  return {
    ok: status >= 200 && status < 300,
    status: status,
    json: function () { return Promise.resolve(data); }
  };
}

/* 新建一个干净的 jsdom 世界：容器 #me-couple、伪造的 window.GG、注入 couple.js。
 * readyState 若还是 loading，模块会等 DOMContentLoaded，这里手动补发一次。 */
async function makeWorld(apiFetch, confirmFn) {
  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body><div id="me-couple"></div></body></html>', {
    url: 'http://127.0.0.1/',
    runScripts: 'outside-only'
  });
  const { window } = dom;
  const notices = [];
  window.GG = {
    apiFetch: apiFetch,
    showNotice: function (msg) { notices.push(String(msg)); }
  };
  window.confirm = confirmFn || function () { return true; };
  window.eval(SRC);
  await sleep(30);
  if (!window.document.querySelector('#cpBody')) {
    window.document.dispatchEvent(new window.Event('DOMContentLoaded'));
    await sleep(30);
  }
  return { window: window, document: window.document, notices: notices, dom: dom };
}

/* 场景 A 的后端替身：可变的绑定状态；join 按码返回成功或 404/400/409。 */
function makeMockA(calls) {
  var state = { paired: false, role: null, code: null };
  return function apiFetch(path, opts) {
    var method = (opts && opts.method) || 'GET';
    calls.push(method + ' ' + path);
    if (path === '/api/couple/status' && method === 'GET') {
      return Promise.resolve(resp(200, state.paired
        ? { paired: true, code: state.code, role: state.role }
        : { paired: false }));
    }
    if (path === '/api/couple/create' && method === 'POST') {
      return Promise.resolve(resp(200, { code: '123456' }));
    }
    if (path === '/api/couple/join' && method === 'POST') {
      var body = {};
      try { body = JSON.parse((opts && opts.body) || '{}'); } catch (e) {}
      if (body.code === '123456') {
        state.paired = true; state.role = 'b'; state.code = '123456';
        return Promise.resolve(resp(200, { paired: true, code: '123456' }));
      }
      if (body.code === '000000') return Promise.resolve(resp(404, { error: 'code_not_found' }));
      if (body.code === '111111') return Promise.resolve(resp(400, { error: 'cannot_join_own' }));
      if (body.code === '222222') return Promise.resolve(resp(409, { error: 'already_paired' }));
      return Promise.resolve(resp(404, { error: 'code_not_found' }));
    }
    if (path === '/api/couple/unbind' && method === 'POST') {
      state.paired = false; state.role = null; state.code = null;
      return Promise.resolve(resp(200, { ok: true }));
    }
    return Promise.resolve(resp(404, { error: 'not_found' }));
  };
}

function textOf(doc, sel) {
  var el = doc.querySelector(sel);
  return el ? el.textContent : '';
}

(async () => {
  // ---------- 场景 A：从未绑定开始 ----------
  var calls = [];
  var w = await makeWorld(makeMockA(calls));
  var doc = w.document;

  ck('未绑定态渲染出卡片与生成按钮',
    !!doc.getElementById('cpCreateBtn') && textOf(doc, '.cp-card h3').indexOf('情侣绑定') > -1);
  ck('底部有共享范围说明（金币/保险箱/照片不共享）',
    textOf(doc, '.cp-note').indexOf('不共享') > -1 && textOf(doc, '.cp-note').indexOf('发起方') > -1);

  // 点生成绑定码
  doc.getElementById('cpCreateBtn').click();
  await sleep(30);
  var codeEl = doc.querySelector('.cp-code');
  ck('点生成后出现 6 位绑定码',
    !!codeEl && /^\d{6}$/.test(codeEl.textContent.trim()), codeEl ? codeEl.textContent : 'no .cp-code');
  ck('生成后有“让对方在她的手机上打开”提示',
    textOf(doc, '.cp-hint').indexOf('让对方在她的手机上打开') > -1);

  // 输入不足 6 位就点加入：应提示，且不调 join 接口
  var joinCallsBefore = calls.filter(function (c) { return c.indexOf('/api/couple/join') > -1; }).length;
  doc.getElementById('cpJoinInput').value = '123';
  doc.getElementById('cpJoinBtn').click();
  await sleep(30);
  ck('输入不足 6 位会提示 6 位数字',
    w.notices.length > 0 && w.notices[w.notices.length - 1].indexOf('6 位数字') > -1,
    w.notices.join(' | '));
  ck('不足 6 位没有发出 join 请求',
    calls.filter(function (c) { return c.indexOf('/api/couple/join') > -1; }).length === joinCallsBefore);

  // join 按状态码给不同提示
  var joinInput = doc.getElementById('cpJoinInput');
  joinInput.value = '000000';
  doc.getElementById('cpJoinBtn').click();
  await sleep(30);
  ck('join 404 提示码不存在', w.notices[w.notices.length - 1].indexOf('不存在') > -1,
    w.notices[w.notices.length - 1]);

  joinInput = doc.getElementById('cpJoinInput');
  joinInput.value = '111111';
  doc.getElementById('cpJoinBtn').click();
  await sleep(30);
  ck('join 400 提示不能加入自己发起的', w.notices[w.notices.length - 1].indexOf('自己') > -1,
    w.notices[w.notices.length - 1]);

  joinInput = doc.getElementById('cpJoinInput');
  joinInput.value = '222222';
  doc.getElementById('cpJoinBtn').click();
  await sleep(30);
  ck('join 409 提示已在绑定里', w.notices[w.notices.length - 1].indexOf('已经') > -1,
    w.notices[w.notices.length - 1]);

  // join 成功 → 已绑定态（role b）
  joinInput = doc.getElementById('cpJoinInput');
  joinInput.value = '123456';
  doc.getElementById('cpJoinBtn').click();
  await sleep(30);
  ck('join 成功后显示“已绑定”', textOf(doc, '.cp-paired').indexOf('已绑定') > -1);
  ck('role b 显示“你加入了对方的绑定”',
    textOf(doc, '.cp-role').indexOf('你加入了对方的绑定') > -1, textOf(doc, '.cp-role'));
  ck('已绑定态有解除绑定按钮', !!doc.getElementById('cpUnbindBtn'));

  // 解除绑定 → 回到未绑定态
  doc.getElementById('cpUnbindBtn').click();
  await sleep(30);
  ck('解除后回到未绑定态（生成按钮回来）', !!doc.getElementById('cpCreateBtn'));
  w.dom.window.close();

  // ---------- 场景 B：加载时已绑定，role a ----------
  var wB = await makeWorld(function (path, opts) {
    if (path === '/api/couple/status') return Promise.resolve(resp(200, { paired: true, code: '654321', role: 'a' }));
    return Promise.resolve(resp(404, {}));
  });
  ck('role a 显示“对方已加入你的绑定”',
    textOf(wB.document, '.cp-role').indexOf('对方已加入你的绑定') > -1, textOf(wB.document, '.cp-role'));
  ck('role a 显示绑定码 654321',
    textOf(wB.document, '.cp-code').indexOf('654321') > -1, textOf(wB.document, '.cp-code'));
  wB.dom.window.close();

  // ---------- 场景 C：加载时已绑定，role b ----------
  var wC = await makeWorld(function (path, opts) {
    if (path === '/api/couple/status') return Promise.resolve(resp(200, { paired: true, code: '123456', role: 'b' }));
    return Promise.resolve(resp(404, {}));
  });
  ck('role b 加载时显示“你加入了对方的绑定”',
    textOf(wC.document, '.cp-role').indexOf('你加入了对方的绑定') > -1, textOf(wC.document, '.cp-role'));
  wC.dom.window.close();

  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
  process.exit(fail === 0 ? 0 : 1);
})().catch(function (e) { console.error('test crashed:', e); process.exit(1); });
