'use strict';
// 小工具：对 DATABASE_URL 指向的 PostgreSQL 跑一条 SQL，打印 JSON 结果。
// 用法：DATABASE_URL=... node scripts/pg-query.js "SELECT COUNT(*) AS n FROM messages"
// 只给测试脚本用；SQL 由调用方写死，不接用户输入。
const { Client, types } = require('pg');
// COUNT(*) 等 int8 在 pg 驱动里默认返回字符串；解析成数字，
// 否则下游 grep '"n":[0-9]*' 拿不到数（与 backend/database/db.js 保持一致）。
types.setTypeParser(20, (v) => Number(v));

(async () => {
  const sql = process.argv[2];
  if (!sql) {
    console.error('用法：node scripts/pg-query.js "<SQL>"');
    process.exit(2);
  }
  const c = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
  });
  await c.connect();
  try {
    const r = await c.query(sql);
    console.log(JSON.stringify(r.rows));
  } finally {
    await c.end();
  }
})().catch((e) => {
  console.error(e.message);
  process.exit(1);
});
