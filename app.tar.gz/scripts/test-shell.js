#!/usr/bin/env node
// Phase 3 shell probe (jsdom, /tmp): GG bridge + five-page nav + persona + old features.
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const { JSDOM } = require('jsdom');

const PORT = 3136;
const DB = '/tmp/guai-v2-shell-probe.sqlite';
const ROOT = require('path').resolve(__dirname, '..');
const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
function ck(name, ok, extra) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + extra : '')); } }

(async () => {
  const env = Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: DB });
  const srv = spawn('node', ['backend/server.js'], { cwd: ROOT, env, stdio: 'pipe' });
  let srvErr = '';
  srv.stderr.on('data', d => { srvErr += d.toString(); });
  const base = 'http://127.0.0.1:' + PORT;
  let up = false;
  for (let i = 0; i < 20 && !up; i++) { await sleep(500); up = await new Promise(res => { http.get(base + '/', r => res(r.statusCode === 200)).on('error', () => res(false)); }); }
  ck('server starts', up, srvErr.slice(0, 300));
  if (!up) { srv.kill(); process.exit(1); }

  const dom = await JSDOM.fromURL(base + '/', {
    resources: 'usable', runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(window) {
      const _f = globalThis.fetch;
      window.fetch = (input, init) => {
        if (typeof input === 'string' && input.startsWith('/')) input = base + input;
        if (init && init.signal) {
          const ctrl = new AbortController();
          const sig = init.signal;
          if (sig.aborted) ctrl.abort();
          else sig.addEventListener('abort', () => ctrl.abort());
          init = Object.assign({}, init, { signal: ctrl.signal });
        }
        return _f(input, init);
      };
      window.AudioContext = function () { this.currentTime = 0; this.destination = {}; this.resume = () => Promise.resolve(); this.createOscillator = () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0 }, type: '' }); this.createGain = () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} } }); };
      window.webkitAudioContext = window.AudioContext;
      window.navigator.vibrate = () => true;
    },
  });
  const { window } = dom;
  const { document } = window;
  const errors = [];
  window.addEventListener('error', e => errors.push(e.message || String(e.error)));
  dom.virtualConsole.on('jsdomError', e => errors.push(e.message || String(e)));
  await sleep(2500);

  ck('window.GG exists', !!window.GG, typeof window.GG);
  ck('GG bridge API present', window.GG && typeof window.GG.setEmotion === 'function' && typeof window.GG.getEmotion === 'function' && typeof window.GG.sendChat === 'function' && typeof window.GG.apiFetch === 'function' && typeof window.GG.logEvent === 'function');
  if (window.GG) {
    window.GG.setEmotion('sad');
    ck('setEmotion/getEmotion round-trip', window.GG.getEmotion() === 'sad');
    window.GG.setEmotion(null);
    ck('setEmotion(null) clears', window.GG.getEmotion() === null);
    ck('GG.coins is a number', typeof window.GG.coins === 'number', String(window.GG.coins));
    ck('GG.meters has 3 values', window.GG.meters && typeof window.GG.meters.hunger === 'number' && typeof window.GG.meters.mood === 'number' && typeof window.GG.meters.energy === 'number');
  }
  ck('5 nav buttons', document.querySelectorAll('#bottomNav button').length === 5, String(document.querySelectorAll('#bottomNav button').length));
  ck('5 page sections', document.querySelectorAll('.page').length === 5, String(document.querySelectorAll('.page').length));
  ck('home active by default', document.getElementById('page-home').classList.contains('active'));
  ck('other pages hidden by default', ['memories', 'surprise', 'games', 'me'].every(p => !document.getElementById('page-' + p).classList.contains('active')));
  ck('opener uses 宝宝 (persona)', document.getElementById('chatLog').textContent.indexOf('宝宝你终于来啦') > -1);
  ck('no 哥哥 left in rendered page', document.body.textContent.indexOf('哥哥') === -1);

  // nav switching (click games, then back home)
  const gamesBtn = document.querySelector('#bottomNav button[data-page="games"]');
  gamesBtn.click();
  await sleep(300);
  ck('switch to games page', document.getElementById('page-games').classList.contains('active') && !document.getElementById('page-home').classList.contains('active'));
  ck('page remembered in localStorage', window.localStorage.getItem('gg_page_v1') === 'games');
  ck('pig DOM survives switching (no data loss)', !!document.getElementById('pig'));
  document.querySelector('#bottomNav button[data-page="home"]').click();
  await sleep(300);
  ck('switch back to home', document.getElementById('page-home').classList.contains('active'));

  // old features still work on home
  const bubble = document.getElementById('bubbleText');
  const before = bubble.textContent;
  document.getElementById('pigArea').click();
  await sleep(400);
  ck('tap pig still reacts', bubble.textContent !== before);
  const chatLog = document.getElementById('chatLog');
  const pigBefore = chatLog.querySelectorAll('.msg-pig').length;
  const input = document.getElementById('chatInput');
  input.value = '你好';
  document.getElementById('chatForm').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true }));
  let replied = false;
  for (let i = 0; i < 16 && !replied; i++) { await sleep(500); replied = chatLog.querySelectorAll('.msg-pig').length > pigBefore; }
  ck('send chat renders pig reply', replied);
  ck('no page JS errors', errors.length === 0, errors.slice(0, 3).join(' | '));

  window.close();
  srv.kill();
  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('probe crashed:', e); process.exit(1); });
