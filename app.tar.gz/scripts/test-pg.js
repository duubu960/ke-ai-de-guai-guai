'use strict';
// 给 PostgreSQL 模式跑测试的包装器：为本次运行建一个全新的空数据库，
// 把 DATABASE_URL 指过去，跑完删除。保证每个测试脚本都从空库开始，
// 互不污染（测试里用了固定 token，共享库会互相干扰）。
// 用法：DATABASE_URL=postgres://user:pass@host:5432/postgres node scripts/test-pg.js npm test
// 要求：DATABASE_URL 指向的账号能 CREATE DATABASE（本地 postgres 超级用户可以；
// Neon 免费档的默认账号也可以；如果被拒，先在 Neon 控制台手动建一个空库，
// 再把 DATABASE_URL 直接指向它跑测试）。
const { spawn } = require('child_process');
const crypto = require('crypto');
const { Client } = require('pg');

function withDb(url, dbname) {
  const u = new URL(url);
  u.pathname = `/${dbname}`;
  return u.toString();
}

(async () => {
  const base = process.env.DATABASE_URL;
  if (!base) {
    console.error('请先设置 DATABASE_URL（指向任意一个可建库的 PostgreSQL）');
    process.exit(2);
  }
  const cmd = process.argv.slice(2);
  if (!cmd.length) {
    console.error('用法：node scripts/test-pg.js <命令...>');
    process.exit(2);
  }
  const dbname = `gg_test_${crypto.randomBytes(6).toString('hex')}`;
  const admin = new Client({
    connectionString: withDb(base, 'postgres'),
    ssl: { rejectUnauthorized: false },
  });
  await admin.connect();
  try {
    await admin.query(`CREATE DATABASE "${dbname}"`);
  } catch (e) {
    console.error(`建库失败：${e.message}`);
    await admin.end();
    process.exit(1);
  }
  await admin.end();
  console.log(`[test-pg] 本次测试用全新空库：${dbname}`);
  const child = spawn(cmd[0], cmd.slice(1), {
    stdio: 'inherit',
    env: Object.assign({}, process.env, { DATABASE_URL: withDb(base, dbname) }),
  });
  const code = await new Promise((resolve) => child.on('exit', (c) => resolve(c === null ? 1 : c)));
  const admin2 = new Client({
    connectionString: withDb(base, 'postgres'),
    ssl: { rejectUnauthorized: false },
  });
  try {
    await admin2.connect();
    await admin2.query(`DROP DATABASE IF EXISTS "${dbname}"`);
  } catch (e) {
    console.error(`[test-pg] 删库失败（请手动删 ${dbname}）：${e.message}`);
  } finally {
    await admin2.end();
  }
  process.exit(code);
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
