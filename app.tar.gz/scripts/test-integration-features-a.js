#!/usr/bin/env node
// Phase 3 A-module integration test: jsdom + REAL server, REAL APIs, no stubs.
// Covers memories / emotion / anniversaries / letters.
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const { JSDOM } = require('jsdom');

const PORT = 3100 + Math.floor(Math.random() * 800); // 每次随机端口，避免残留服务器冒名顶替。
const DB = '/tmp/guai-v3-features-a-' + PORT + '.sqlite';
const ROOT = path.resolve(__dirname, '..');
const TOKEN = '123e4567-e89b-42d3-a456-426614174002';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
function ck(name, ok, extra) {
  if (ok) { pass++; console.log('PASS ' + name); }
  else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + String(extra).slice(0, 300) : '')); }
}
async function waitFor(fn, timeoutMs, intervalMs) {
  const end = Date.now() + (timeoutMs || 8000);
  while (Date.now() < end) {
    let v = null;
    try { v = await fn(); } catch (e) { v = null; }
    if (v) return v;
    await sleep(intervalMs || 250);
  }
  return null;
}
function asList(body) {
  if (Array.isArray(body)) return body;
  if (!body || typeof body !== 'object') return [];
  const keys = ['surprises', 'wishlists', 'preferences', 'candidates', 'gifts', 'favorites', 'records', 'items', 'letters', 'memories', 'anniversaries'];
  for (const k of keys) if (Array.isArray(body[k])) return body[k];
  return [];
}
function api(method, p, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request({
      host: '127.0.0.1', port: PORT, path: p, method,
      headers: { 'Content-Type': 'application/json', 'X-User-Token': TOKEN },
    }, res => {
      let d = '';
      res.on('data', c => { d += c; });
      res.on('end', () => {
        let j = null;
        try { j = JSON.parse(d); } catch (e) { j = null; }
        resolve({ status: res.statusCode, body: j, raw: d });
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

(async () => {
  const env = Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: DB });
  const srv = spawn('node', ['backend/server.js'], { cwd: ROOT, env, stdio: 'pipe' });
  try {
    await run(srv);
  } finally {
    srv.kill();
  }
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('test crashed:', e); process.exit(1); });

async function run(srv) {
  const base = 'http://127.0.0.1:' + PORT;
  let up = false;
  for (let i = 0; i < 20 && !up; i++) {
    await sleep(500);
    up = await new Promise(res => { http.get(base + '/', r => res(r.statusCode === 200)).on('error', () => res(false)); });
  }
  ck('server starts', up);
  if (!up) return;

  // Seed: one first-meet anniversary + one memory (real API).
  const ann = await api('POST', '/api/anniversaries', { title: '第一次见面', date: '2026-11-01', type: 'first_meet', note: '' });
  const mem = await api('POST', '/api/memories', { title: '第一次看电影', date: '2026-11-05', category: 'date', location: '电影院', description: '一起看了电影' });
  const okStatus = s => s === 200 || s === 201;
  ck('seed anniversary + memory', okStatus(ann.status) && okStatus(mem.status), [ann.raw, mem.raw].join(' | '));

  const dom = await JSDOM.fromURL(base + '/', {
    resources: 'usable', runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(window) {
      window.localStorage.setItem('gg_user_token_v1', TOKEN);
      window.confirm = () => true;
      try { window.crypto = globalThis.crypto; } catch (e) {
        try { Object.defineProperty(window, 'crypto', { value: globalThis.crypto, configurable: true }); } catch (e2) {}
      }
      const _f = globalThis.fetch;
      window.fetch = (input, init) => {
        if (typeof input === 'string' && input.startsWith('/')) input = base + input;
        if (init && init.signal) {
          const ctrl = new AbortController();
          const sig = init.signal;
          if (sig.aborted) ctrl.abort();
          else sig.addEventListener('abort', () => ctrl.abort());
          init = Object.assign({}, init, { signal: ctrl.signal });
        }
        return _f(input, init);
      };
      window.AudioContext = function () {
        this.currentTime = 0; this.destination = {};
        this.resume = () => Promise.resolve();
        this.createOscillator = () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0 }, type: '' });
        this.createGain = () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {}, linearRampToValueAtTime() {}, setTargetAtTime() {} } });
      };
      window.webkitAudioContext = window.AudioContext;
      window.navigator.vibrate = () => true;
    },
  });
  const { window } = dom;
  const { document } = window;
  const errors = [];
  window.addEventListener('error', e => errors.push(e.message || String(e.error)));
  dom.virtualConsole.on('jsdomError', e => errors.push(e.message || String(e)));
  const q = s => document.querySelector(s);
  const qa = s => Array.from(document.querySelectorAll(s));

  // Wait for the A modules to render.
  const rendered = await waitFor(() => (
    q('#mem-timeline') && q('#mem-timeline').textContent.trim().length > 0 &&
    q('#mem-anniversaries .ft-ann-days-n') &&
    q('#mem-letters') && q('#mem-letters').textContent.trim().length > 0 &&
    q('[data-feature-emotion-btn]')
  ), 15000);
  if (!rendered) {
    const missing = ['#mem-timeline', '#mem-anniversaries .ft-ann-days-n', '#mem-letters', '[data-feature-emotion-btn]'].filter(s => !q(s));
    ck('A modules render', false, 'missing: ' + missing.join(', ') + ' | timeline: ' + (q('#mem-timeline') ? q('#mem-timeline').textContent.slice(0, 100) : ''));
  } else {
    ck('A modules render', true);
  }
  ck('GG bridge present', !!window.GG);

  // ---- 1. Memories: seeded item listed, create + favorite + search + delete ----
  ck('seeded memory listed', q('#mem-timeline').textContent.indexOf('第一次看电影') > -1);
  q('.ft-mem-new').click();
  const memTitle = await waitFor(() => q('.ft-mem-f-title'), 5000);
  ck('memory form opens', !!memTitle);
  if (memTitle) {
    q('.ft-mem-f-title').value = '第一次去海边';
    q('.ft-mem-f-date').value = '2026-11-08';
    q('.ft-mem-f-loc').value = '海边';
    q('.ft-mem-f-desc').value = '一起看日落';
    q('.ft-mem-f-save').click();
    const inList = await waitFor(() => q('#mem-timeline').textContent.indexOf('第一次去海边') > -1, 8000);
    ck('memory created and listed', !!inList, inList ? '' : 'notice: ' + (q('#aiNotice') ? q('#aiNotice').textContent : ''));
    const ml = await api('GET', '/api/memories');
    const mlList = asList(ml.body);
    ck('memories API has 2 items', ml.status === 200 && mlList.length === 2, ml.raw);
    // Search filters the list.
    const qInput = q('.ft-mem-q');
    if (qInput) {
      qInput.value = '海边';
      qInput.dispatchEvent(new window.Event('input', { bubbles: true }));
      await sleep(600);
      ck('memory search filters by keyword', q('#mem-timeline').textContent.indexOf('第一次去海边') > -1 && q('#mem-timeline').textContent.indexOf('第一次看电影') === -1);
      qInput.value = '';
      qInput.dispatchEvent(new window.Event('input', { bubbles: true }));
      await sleep(600);
    }
    // Favorite the new memory, then delete it.
    const newItem = mlList.find(m => m.title === '第一次去海边');
    if (newItem) {
      const favBtn = q('.ft-mem-favb[data-id="' + newItem.id + '"]');
      if (favBtn) favBtn.click();
      await sleep(800);
      const ml2 = await api('GET', '/api/memories');
      const row = asList(ml2.body).find(m => m.id === newItem.id);
      ck('memory favorite persists on server', !!row && row.favorite === true, ml2.raw);
      const delBtn = q('#mem-timeline [data-del="' + newItem.id + '"]');
      if (delBtn) delBtn.click();
      const gone = await waitFor(async () => {
        const r = await api('GET', '/api/memories');
        return asList(r.body).find(m => m.id === newItem.id) ? null : true;
      }, 8000);
      ck('memory deletes', !!gone);
    } else {
      ck('memory favorite persists on server', false, 'new memory not found in API list');
      ck('memory deletes', false, 'new memory not found in API list');
    }
  }

  // ---- 2. Anniversaries: daysTogether is real, create + delete ----
  const daysEl = q('#mem-anniversaries .ft-ann-days-n');
  const parseLocal = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const expectedDays = Math.round((today - parseLocal('2026-11-01')) / 86400000);
  ck('daysTogether is real (first_meet 2026-11-01)', !!daysEl && Number(daysEl.textContent) === expectedDays, 'hero: ' + (daysEl ? daysEl.textContent : '') + ' expected: ' + expectedDays);
  const sum = await api('GET', '/api/anniversaries/summary');
  ck('anniversaries summary API agrees', sum.status === 200 && sum.body && sum.body.daysTogether === expectedDays, sum.raw);
  q('.ft-ann-new').click();
  const annTitle = await waitFor(() => q('.ft-ann-f-title'), 5000);
  ck('anniversary form opens', !!annTitle);
  if (annTitle) {
    q('.ft-ann-f-title').value = '一周年';
    q('.ft-ann-f-date').value = '2027-11-01';
    q('.ft-ann-f-save').click();
    const inList = await waitFor(() => q('#mem-anniversaries').textContent.indexOf('一周年') > -1, 8000);
    ck('anniversary created and listed', !!inList);
    const al = await api('GET', '/api/anniversaries');
    const alList = asList(al.body);
    const newAnn = alList.find(a => a.title === '一周年');
    ck('anniversary API has the new item', !!newAnn, al.raw);
    if (newAnn) {
      const delBtn = q('#mem-anniversaries [data-del="' + newAnn.id + '"]') || qa('#mem-anniversaries [data-del]').find(b => b.closest('.ft-ann-item') && b.closest('.ft-ann-item').textContent.indexOf('一周年') > -1);
      if (delBtn) delBtn.click();
      const gone = await waitFor(async () => {
        const r = await api('GET', '/api/anniversaries');
        return asList(r.body).find(a => a.id === newAnn.id) ? null : true;
      }, 8000);
      ck('anniversary deletes', !!gone);
    }
  }

  // ---- 3. Letters: create + AI draft (offline, honest) + favorite + delete ----
  q('.ft-let-new').click();
  const letTitle = await waitFor(() => q('.ft-let-f-title'), 5000);
  ck('letter form opens', !!letTitle);
  if (letTitle) {
    q('.ft-let-f-title').value = '给宝宝的信';
    q('.ft-let-f-content').value = '今天想你了。';
    q('.ft-let-f-save').click();
    // 注意：容器标题就是“写给宝宝的信”，必须只在列表区里找，不能拿整个容器匹配。
    const inList = await waitFor(() => { const l = q('.ft-let-list'); return l && l.textContent.indexOf('给宝宝的信') > -1; }, 8000);
    ck('letter created and listed', !!inList, inList ? '' : 'notice: ' + (q('#aiNotice') ? q('#aiNotice').textContent : '') + ' | form err: ' + (q('.ft-let-f-err') ? q('.ft-let-f-err').textContent : ''));
    const ll = await api('GET', '/api/letters');
    const llList = asList(ll.body);
    ck('letters API has the item', ll.status === 200 && llList.length === 1 && llList[0].title === '给宝宝的信', ll.raw);
    const newLetter = llList[0];
    if (!newLetter) {
      ck('AI draft fills the letter (offline template, no key)', false, 'no letter in API list');
      ck('ai-draft API is honest about offline source', false, 'no letter in API list');
      ck('letter favorite persists on server', false, 'no letter in API list');
      ck('letter deletes', false, 'no letter in API list');
    } else {
    // AI draft with no key: must fall back to an offline template, honestly labeled.
    q('.ft-let-new').click();
    await waitFor(() => q('.ft-let-f-ai'), 5000);
    q('.ft-let-f-ai').click();
    const drafted = await waitFor(() => {
      const c = q('.ft-let-f-content');
      return c && c.value && c.value.length > 10 ? c.value : null;
    }, 10000);
    ck('AI draft fills the letter (offline template, no key)', !!drafted, drafted ? drafted.slice(0, 80) : 'content stayed empty');
    const draftApi = await api('POST', '/api/letters/ai-draft', { occasion: '纪念日', tone: '温柔' });
    ck('ai-draft API is honest about offline source', draftApi.status === 200 && draftApi.body && draftApi.body.source === 'offline', draftApi.raw);
    // Cancel the draft form, then favorite + delete the saved letter.
    const cancelBtn = q('.ft-let-f-cancel');
    if (cancelBtn) cancelBtn.click();
    await sleep(400);
    const favBtn = q('#mem-letters [data-fav="' + newLetter.id + '"]');
    if (favBtn) favBtn.click();
    await sleep(800);
    const ll2 = await api('GET', '/api/letters');
    const favRow = asList(ll2.body).find(l => l.id === newLetter.id);
    ck('letter favorite persists on server', !!favRow && favRow.favorite === true, ll2.raw);
    const delBtn = q('#mem-letters [data-del="' + newLetter.id + '"]');
    if (delBtn) delBtn.click();
    const gone = await waitFor(async () => {
      const r = await api('GET', '/api/letters');
      return asList(r.body).find(l => l.id === newLetter.id) ? null : true;
    }, 8000);
    ck('letter deletes', !!gone);
    }
  }

  // ---- 4. Emotion room: open, pick an emotion, talk, quiet mode ----
  const emoBtn = q('[data-feature-emotion-btn]');
  ck('emotion button exists on home', !!emoBtn);
  if (emoBtn) emoBtn.click();
  const overlay = await waitFor(() => {
    const o = q('.ft-emo-overlay');
    return o && !o.hidden ? o : null;
  }, 5000);
  ck('emotion overlay opens', !!overlay);
  const cards = qa('.ft-emo-card');
  ck('emotion room shows 8 emotions', cards.length === 8, 'cards: ' + cards.length);
  if (overlay && cards.length === 8) {
    const sadCard = qa('.ft-emo-card[data-emotion="sad"]')[0];
    sadCard.click();
    const talkOpen = await waitFor(() => {
      const t = q('.ft-emo-talk');
      return t && !t.hidden && q('.ft-emo-open') && q('.ft-emo-open').textContent.length > 0 ? q('.ft-emo-open').textContent : null;
    }, 5000);
    ck('picking an emotion shows a gentle opening line', !!talkOpen, talkOpen && talkOpen.slice(0, 60));
    const chatBefore = document.querySelectorAll('#chatLog .msg-row').length;
    q('.ft-emo-text').value = '今天工作很累';
    q('.ft-emo-send').click();
    const sent = await waitFor(() => document.querySelectorAll('#chatLog .msg-row').length > chatBefore, 8000);
    ck('emotion talk sends the message into home chat', !!sent);
    // Quiet mode: open again, pick an emotion, choose "不想说话".
    await sleep(500);
    emoBtn.click();
    await waitFor(() => { const o = q('.ft-emo-overlay'); return o && !o.hidden ? o : null; }, 5000);
    qa('.ft-emo-card[data-emotion="tired"]')[0].click();
    await waitFor(() => { const t = q('.ft-emo-talk'); return t && !t.hidden ? t : null; }, 5000);
    q('.ft-emo-quiet-btn').click();
    const quietShown = await waitFor(() => {
      const qq = q('.ft-emo-quiet');
      return qq && !qq.hidden ? qq.textContent : null;
    }, 5000);
    ck('quiet mode shows the silent-companion screen', !!quietShown, quietShown && quietShown.slice(0, 40));
    q('.ft-emo-back').click();
    await sleep(400);
    const exitBtn = q('.ft-emo-exit');
    if (exitBtn) exitBtn.click();
    await sleep(400);
    ck('emotion overlay closes', !q('.ft-emo-overlay') || q('.ft-emo-overlay').hidden);
  }

  ck('no page JS errors', errors.length === 0, errors.slice(0, 3).join(' | '));

  window.close();
  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
}
