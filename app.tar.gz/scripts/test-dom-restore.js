#!/usr/bin/env node
// 可爱的乖乖 v2 持久化恢复测试（jsdom，跑在 /tmp，不污染项目）
// 先用 /api/restore 把一轮聊天 + 一份状态写入数据库，再用同一 token 打开页面，
// 验证：刷新后聊天记录、名字、好感度、回忆都从服务器恢复出来了。
'use strict';
const { spawn } = require('child_process');
const http = require('http');
const path = require('path');
const { JSDOM } = require('jsdom');

const PORT = 3129;
const DB = '/tmp/guai-v2-dom-restore.sqlite';
const ROOT = path.resolve(__dirname, '..');
const TOKEN = '123e4567-e89b-42d3-a456-426614174000';
const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
function ck(name, ok, extra) { if (ok) { pass++; console.log('PASS ' + name); } else { fail++; console.log('FAIL ' + name + (extra ? ' — ' + extra : '')); } }

function req(method, p, body) {
  return new Promise((resolve, reject) => {
    const r = http.request({ host: '127.0.0.1', port: PORT, path: p, method, headers: { 'Content-Type': 'application/json', 'X-User-Token': TOKEN } }, res => {
      let d = ''; res.on('data', c => d += c); res.on('end', () => resolve({ status: res.statusCode, body: d }));
    });
    r.on('error', reject);
    if (body) r.write(JSON.stringify(body));
    r.end();
  });
}

(async () => {
  const env = Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: DB });
  const srv = spawn('node', ['backend/server.js'], { cwd: ROOT, env, stdio: 'ignore' });
  const base = 'http://127.0.0.1:' + PORT;
  let up = false;
  for (let i = 0; i < 20 && !up; i++) { await sleep(500); up = await new Promise(res => { http.get(base + '/', r => res(r.statusCode === 200)).on('error', () => res(false)); }); }
  ck('server starts', up);
  if (!up) { srv.kill(); process.exit(1); }

  const seed = await req('POST', '/api/restore', {
    state: { profile: { name: '测试', likes: ['草莓'] }, affection: 90, memories: [{ t: 1762800000000, title: '第一次见面', detail: '测试回忆', emotion: '开心' }], firstMet: 1762800000000, lastVisit: 1762800000000, lastTopic: '草莓', recentReplies: [], dailyGiftDate: '2026-11-11' },
    messages: [
      { role: 'user', content: '你好呀', created_at: 1762800001000 },
      { role: 'assistant', content: '哼哼，我在呢', created_at: 1762800002000 },
    ],
  });
  ck('seed via /api/restore -> 200', seed.status === 200, seed.body);

  const dom = await JSDOM.fromURL(base + '/', {
    resources: 'usable', runScripts: 'dangerously', pretendToBeVisual: true,
    beforeParse(window) {
      window.localStorage.setItem('gg_user_token_v1', TOKEN);
      const _f = globalThis.fetch;
      window.fetch = (input, init) => {
        if (typeof input === 'string' && input.startsWith('/')) input = base + input;
        if (init && init.signal) {
          const ctrl = new AbortController();
          const sig = init.signal;
          if (sig.aborted) ctrl.abort();
          else sig.addEventListener('abort', () => ctrl.abort());
          init = Object.assign({}, init, { signal: ctrl.signal });
        }
        return _f(input, init);
      };
      window.AudioContext = function () { this.currentTime = 0; this.destination = {}; this.resume = () => Promise.resolve(); this.createOscillator = () => ({ connect() {}, start() {}, stop() {}, frequency: { value: 0 }, type: '' }); this.createGain = () => ({ connect() {}, gain: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} } }); };
      window.webkitAudioContext = window.AudioContext;
      window.navigator.vibrate = () => true;
    },
  });
  const { window } = dom;
  const { document } = window;
  const errors = [];
  window.addEventListener('error', e => errors.push(e.message || String(e.error)));
  dom.virtualConsole.on('jsdomError', e => errors.push(e.message || String(e)));

  // wait for restoreChatHistory + loadStateFromServer to finish
  let ok = false;
  for (let i = 0; i < 20 && !ok; i++) {
    await sleep(500);
    const t = document.getElementById('chatLog').textContent;
    ok = t.indexOf('你好呀') > -1 && t.indexOf('哼哼，我在呢') > -1;
  }
  ck('seeded chat turns render after page load', ok);
  const profile = JSON.parse(window.localStorage.getItem('gg_profile_v1') || '{}');
  ck('profile name restored from server', profile.name === '测试', JSON.stringify(profile));
  ck('affection restored from server', window.localStorage.getItem('gg_affection_v1') === '90', window.localStorage.getItem('gg_affection_v1'));
  const mems = JSON.parse(window.localStorage.getItem('gg_memories_v1') || '[]');
  ck('memories restored from server', mems.length === 1 && mems[0].title === '第一次见面', JSON.stringify(mems));
  ck('no page JS errors', errors.length === 0, errors.slice(0, 3).join(' | '));

  window.close();
  srv.kill();
  console.log('----------------------------------------');
  console.log('PASS: ' + pass + '  FAIL: ' + fail);
  process.exit(fail === 0 ? 0 : 1);
})().catch(e => { console.error('test crashed:', e); process.exit(1); });
