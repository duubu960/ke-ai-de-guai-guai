# 可爱的乖乖 Phase 3 开发契约（v2 → v3）

> 本文件是唯一契约。后端、前端各模块都按它实现；有冲突以本文件为准。
> 项目根目录：`/home/hatch/workspace/ke-ai-de-guai-guai-v2/`
> 原始备份（不要覆盖）：`/home/hatch/workspace/ke-ai-de-guai-guai-v2-backup-2026-11-11-phase3-before/`
> 旧项目（不要动）：`/home/hatch/workspace/your_files/ke-ai-de-guai-guai/`

## 0. 总则

- **不删原有功能**：小猪形象、头像、紫粉 UI、三人格、互动、换装、金币、表情包、接草莓、离线脑子、DeepSeek 聊天、长期记忆全部保留。只改调用路径，不改行为。
- **不用假数据**：所有数字、次数、日期、推荐都来自真实数据库或用户输入。没有数据时如实显示“还没有”，不编。
- **Key 只在服务器**：DeepSeek Key 只在 `.env`；前端任何文件不得出现 Key、不得出现 `api.deepseek.com` 直接调用。
- **用户隔离**：全部新旧数据都按 `X-User-Token`（uuid v4）隔离；跨 token 读写一律拒绝。
- **文件归属**：每个 agent 只写自己负责的文件（见各任务），不许编辑别人的文件；不许改 `README.md`、`TEST-REPORT.md`（主助手统一写）。
- **测试**：每个模块完成后跑 `node --check` + 对应测试脚本；失败先修再继续；回报时写真实输出，不许编造通过。

## 1. 人设（统一标准，2026-11-11 修正版——以此为准，旧版作废）

- **身份**：AI 是送给女朋友的专属 **AI 小男友**（男性），不是小女友、不是女朋友式陪伴。小猪名字仍是「可爱的乖乖」；称呼用户为「宝宝」。
- **核心性格**：**外冷内热、傲娇、专一、特别偏爱宝宝**。嘴上有点冷、心里很在意；平时会傲娇嘴硬、轻微毒舌，但绝不真的伤害宝宝；偏爱通过细节、关心和行动体现，不靠每句甜言蜜语。
- **三模式保留**（搞笑 / 暖心 / 高冷傲娇）：高冷傲娇是默认核心味，但不是「上位者」——**不用「朕、本宫、退下吧、准了、圣旨、御赐」等居高临下的词**；傲娇的表现是嘴硬、心软、留一个温柔破绽。难过 / 委屈 / 生气 / 生病时只用暖心模式：傲娇收起来，认真倾听、温柔安慰，不讲道理、不开玩笑。开心时可以打趣斗嘴。
- **称呼与情话**：不每句话都带「宝宝」；不重复「我永远陪着你」「我最爱你」等套路话；爱意藏在细节里（记得她吃饭了没、睡够了没、今天累不累）。
- **记忆感**：自然记住宝宝确认过的喜好、纪念日和重要回忆，在相关话题里主动用起来，不刻意表功。
- **边界**：偶尔吃醋、撒娇、开玩笑可以，但不控制、不限制、不贬低宝宝，不制造占有欲、情感控制或不健康依赖。**不冒充现实中的男朋友（Justin）**：乖乖就是乖乖，一只 AI 小猪男友；不自称真人，也不编造自己真实存在过的经历（玩笑式的假装动作可以，但要让宝宝一眼看出是玩笑，不能当真事讲）。
- **说话**：像真实情侣微信聊天，短句为主，不像客服、不像机器人、不列条目、不说教。
- 新功能文案一律按本标准写；旧文案里与本标准冲突的（上位者口吻、套路情话、女友式描述）一并按本标准改。

## 2. 数据库（SQLite，`backend/database/`）

- `init.sql` 保持原样（新装库仍可用）。新表一律走迁移。
- 新建 `backend/database/migrations/002-phase3.sql`，建以下表（全部含 `token TEXT NOT NULL` + `created_at INTEGER`；主键 `id INTEGER PRIMARY KEY AUTOINCREMENT`，除非注明）：
  - `memories`：`title TEXT, date TEXT(YYYY-MM-DD), location TEXT, description TEXT, category TEXT, photo_url TEXT, favorite INTEGER DEFAULT 0, updated_at INTEGER`
  - `anniversaries`：`title TEXT, date TEXT(YYYY-MM-DD), type TEXT(first_meet/anniversary/birthday/custom), note TEXT, updated_at INTEGER`
  - `wishlists`：`title TEXT, category TEXT, priority INTEGER(1-3), note TEXT, photo_url TEXT, done INTEGER DEFAULT 0, completed_at INTEGER, updated_at INTEGER`
  - `daily_surprises`：`date TEXT(YYYY-MM-DD), kind TEXT, title TEXT, content TEXT, source TEXT(ai/offline), favorite INTEGER DEFAULT 0`；唯一键 `(token, date)`（每天只能开一次，靠这个约束保证）
  - `surprise_history`：与 daily_surprises 同字段的只读历史（开盒时写入；查询用它）
  - `preferences`：`category TEXT(food/drink/color/animal/music/movie/gift/activity/dislike/date), value TEXT, confirmed INTEGER DEFAULT 0, source TEXT(manual/ai), updated_at INTEGER`
  - `game_records`：`game TEXT, score INTEGER, coins INTEGER, played_at INTEGER`；每日每游戏金币上限 30（服务端校验）
  - `daily_reports`：`date TEXT(YYYY-MM-DD), summary TEXT, data_json TEXT`；唯一键 `(token, date)`
  - `letters`：`title TEXT, content TEXT, occasion_date TEXT, favorite INTEGER DEFAULT 0, status TEXT(draft/sent), updated_at INTEGER`
  - `vault_items`：`blob TEXT（密文 JSON）, iv TEXT, salt TEXT, updated_at INTEGER`；**服务器只存密文，永远不收密码**
  - `user_settings`：`key TEXT, value TEXT, updated_at INTEGER`；唯一键 `(token, key)`
  - `events`：`type TEXT, detail TEXT, created_at INTEGER`（互动/聊天/游戏等事件，供报告统计）
  - `gift_favorites`：`name TEXT, reason TEXT, occasion TEXT, budget TEXT, created_at INTEGER`
  - `migrations`：`name TEXT PRIMARY KEY, applied_at INTEGER`（记录已应用的迁移）
- 新建 `backend/database/migrate.js`：启动时（`server.js` 在 `initDb` 之后调用）按顺序应用 `migrations/` 下未应用的 SQL 文件；幂等；不破坏现有三张表和数据。
- 照片存数据库（部署准备 v2.1.0 已改）：`photos` 表（token、filename、mime、data BYTEA/BLOB、size），不存本地文件——Render 免费档无持久磁盘，文件会在重启后丢失；`photo_url` 仍为 `/photos/<token>/<uuid>.<ext>` 形状。

## 3. 后端 API（全部要 `X-User-Token`；错误用 `{error, detail?}`）

在现有 API 之外新增（`backend/routes/` 可新增文件，`server.js` 挂载）：

- `GET /api/memories?month=YYYY-MM&q=&favorite=` / `POST /api/memories` / `GET /api/memories/:id` / `PUT /api/memories/:id` / `DELETE /api/memories/:id`
- `GET /api/anniversaries` / `POST /api/anniversaries` / `PUT /api/anniversaries/:id` / `DELETE /api/anniversaries/:id` / `GET /api/anniversaries/summary` → `{daysTogether, next:[{id,title,date,daysLeft}]}`（daysTogether 取最早的 first_meet 或 `user_state.first_met`；没有日期时 `daysTogether: null`，不编）
- `POST /api/surprise/open` → 当天已开过则返回已有的（不再生成）；未开过则生成 1 个并写入 `daily_surprises` + `surprise_history`。种类 8 种：love_note / note / blessing / story / question / task / memory / ai。内容结合 `preferences`（已确认的 likes）和 `memories`（随机一条）；`ai` 种由 DeepSeek 生成（有 Key 时），无 Key 时用本地模板并标注 `source:"offline"`。
- `GET /api/surprises/history?limit=` / `POST /api/surprises/:id/favorite`
- `GET /api/wishlists` / `POST /api/wishlists` / `PUT /api/wishlists/:id` / `DELETE /api/wishlists/:id` / `POST /api/wishlists/:id/complete` / `GET /api/wishlists/summary` → `{total, done, pending}`
- `GET /api/preferences` / `POST /api/preferences` / `PUT /api/preferences/:id` / `DELETE /api/preferences/:id` / `GET /api/preferences/pending` / `POST /api/preferences/extract {text}` → 返回候选清单，不自动保存（规则提取；有 Key 时可用 DeepSeek 辅助提取，仍需用户确认）
- `GET /api/gifts/recommend` → 按已确认喜好 + 最近纪念日 + 未完成心愿，用规则生成 6 条（`{name, reason, occasion, budget}`；budget 是区间标签如“100元以内”，**不编具体价格、店铺、链接**；明显不符合喜好的不推）；`POST /api/gifts/favorite {name,reason,occasion,budget}` / `GET /api/gifts/favorites` / `DELETE /api/gifts/favorites/:id`
- `POST /api/games/record {game, score, coins}`（校验 + 每日每游戏上限 30 金币；超限返回 `{error:"daily_coin_cap", awarded:0}`；成功时把金币加进 `user_state` 的 coins 字段） / `GET /api/games/records?game=&limit=` / `GET /api/games/summary`
- `GET /api/reports/today` / `GET /api/reports?date=YYYY-MM-DD` → 从 `messages`、`events`、`wishlists`、`daily_surprises` 的真实数据计算（聊天次数、互动次数、心情记录、心愿完成、惊喜、值得收藏的话语、AI 温柔总结；无数据时 `{hasData:false}`，不编；AI 总结有 Key 时用 DeepSeek，无 Key 时用模板并标注）
- `GET /api/letters` / `POST /api/letters` / `GET /api/letters/:id` / `PUT /api/letters/:id` / `DELETE /api/letters/:id` / `POST /api/letters/:id/favorite` / `POST /api/letters/ai-draft {occasion?, tone?}`（有 Key 用 DeepSeek，无 Key 用模板并标注）
- `GET /api/vault/items` / `POST /api/vault/items {blob, iv, salt}` / `GET /api/vault/items/:id` / `PUT /api/vault/items/:id` / `DELETE /api/vault/items/:id`（只存密文；请勿设计任何“找回密码”接口——忘密码=无法解密，如实提示）
- `POST /api/photos {dataUrl, name}` → 校验 `data:image/(jpeg|png|webp)` 且解码后 ≤ 5MB，写文件，返回 `{url}`；`GET /photos/*` 由 `express.static` 提供
- `POST /api/events {type, detail?}`（前端日志，批量、失败静默）
- **扩展 `GET/POST /api/state`**：新增可选字段 `coins`（整数 ≥0）、`meters`（`{hunger,mood,energy}` 各 0-100）、`hat`（字符串）、`seenFaces`（对象）；校验与现有字段一致；`POST /api/state` 只更新提供的字段。
- **扩展 `GET /api/backup` 与 `POST /api/restore`**：覆盖全部 token 专属表（vault 只导密文）；restore 在事务内替换，失败回滚。
- 输入校验：全部新接口校验类型、长度、枚举、日期格式；上传图片限制类型与大小；错误码统一 `invalid_request` / `not_found` / `daily_coin_cap` / `conflict`。

## 4. 前端（`frontend/`）

### 4.1 页面外壳（主助手负责，模块只按它渲染）

- `index.html`：`<div class="wrap">` 内原有内容整体包进 `<section class="page active" id="page-home">`；新增 `<section class="page" id="page-memories">`、`<section class="page" id="page-surprise">`、`<section class="page" id="page-games">`、`<section class="page" id="page-me">`，每个含一个 `page-head`（标题+一句副标题）与一个空容器：
  - 回忆页：`<div id="mem-anniversaries"></div><div id="mem-timeline"></div><div id="mem-letters"></div>`
  - 惊喜页：`<div id="surprise-box"></div><div id="surprise-wishlist"></div><div id="surprise-gifts"></div>`
  - 游戏页：`<div id="games-root"></div>`
  - 我的页：`<div id="me-preferences"></div><div id="me-report"></div><div id="me-vault"></div><div id="me-settings"></div>`
- 底部导航 `<nav id="bottomNav">`：5 个按钮 `data-page="home|memories|surprise|games|me"`，图标+文字（🏠 首页 / 💗 回忆 / 🎁 惊喜 / 🎮 游戏 / 👤 我的）。点击切换：只改 `active` 类 + 导航态 + 记住 `gg_page_v1`；**不重建首页 DOM**，切换不丢数据。
- 各模块 `<script src="js/features/<name>.js"></script>` 由主助手在 `app.js` 之后按顺序引入；模块不得自己改 `index.html`。

### 4.2 `window.GG` 桥接（主助手负责，模块直接用）

```js
window.GG = {
  userToken(), apiFetch(path, opts),          // 带 X-User-Token 的 fetch
  get profile(), get affection(), get memories(), addMemory(t,d,e), saveProfile(),
  get coins(), get meters(), get hat(), get seenFaces(),
  setEmotion(name|null), getEmotion(),        // 情绪覆盖；callDeepSeek 会读它
  sendChat(text, opts),                      // 走原有 sendChat；opts.emotion 可临时覆盖
  say(text, sub, anim, extra), addSticker(face), burstHearts(n),
  showNotice(msg), hideAINotice(), refreshAIStatus(),
  loadStateFromServer(), pushStateToServer(),
  logEvent(type, detail),                    // POST /api/events，失败静默
}
```
- `setEmotion` 的 8 种情绪：`happy / sad / wronged / angry / anxious / lonely / tired / miss`；callDeepSeek 在情绪非空时用情绪系统提示块（温柔倾听、不说教、难过时不用玩笑、不机械重复情话），并优先暖心模式。
- 事件日志：在 `interact()`（摸摸头/喂食/抱抱/晚安）、游戏完成、聊天成功时调用 `logEvent`。

### 4.3 模块约定（各前端模块必须遵守）

- 一个功能一个文件：`frontend/js/features/<name>.js`，顶层 IIFE，`document.readyState` 决定立即执行或等 `DOMContentLoaded`。
- 只渲染到契约 4.1 指定的容器；找不到容器时静默退出（不报错、不改其它页）。
- 自己的样式用模块内注入的 `<style>`（`document.head.appendChild`，带 `data-feature` 标记），只用现有 CSS 变量（`--ink/--muted/--card/--accent/--line` 等）与卡片/按钮类名，不重定义全局样式。
- 数据一律走 `GG.apiFetch` 调后端；失败时页面如实提示，不用假数据填充。
- 照片上传：客户端用 canvas 压缩到最长边 ≤ 1200、JPEG 0.8，再 `POST /api/photos`，用返回的 `url`；不得把 base64 大图塞进 localStorage。
- 语音：`SpeechRecognition`（`webkitSpeechRecognition` 兜底）+ `speechSynthesis`；不支持时如实提示，不假装可用；语速可调（0.6–1.4），可暂停/关闭。
- 保险箱：WebCrypto `AES-GCM` + `PBKDF2`（salt 随机 16B，迭代 100k，SHA-256）；密码只在内存里派生密钥，从不发给服务器；忘密码明确提示无法恢复。
- 文案按 §1 人设写；不要写 TODO 占位；每个按钮都要有真实处理函数。

### 4.4 风格

- 紫粉高级风：圆角卡片、柔和渐变、轻阴影、留白；不要后台管理系统的表格堆砌。
- 手机优先；按钮最小高度 44px；触屏友好。

## 5. 测试

- 后端：扩展示有 `scripts/test-backend.js`（新接口的 CRUD、隔离、校验、每日上限、开盒一次）+ `scripts/test-integration.sh` 增加新接口冒烟。
- 前端：每个模块跑 `node --check`；联调后 `npm run test:dom` 仍须通过（主助手负责）。
- 回报时写：改了哪些文件、测试命令与真实结果、未验证的事项；不许写“已通过”而没有运行记录。
