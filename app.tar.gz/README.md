# 可爱的乖乖 v3 — 第三阶段：14 个功能全部完成

这是「可爱的乖乖」的第三阶段成果：在第二阶段（Node.js + Express + SQLite 后端架构）之上，把 **14 个阶段的新功能全部做完了**，都是真能点的、数据都进数据库的。

> **v2.1.0 部署准备（2026-11-11）**：后端已改成双模式——不填 `DATABASE_URL` 时用本地 SQLite（和原来一样，零配置）；填了就用 PostgreSQL（目标是 Neon 免费档），全部接口行为一致。照片已从磁盘文件改成存进数据库（Render 免费档没有持久化磁盘，文件会在重启后丢失）。`render.yaml`、健康检查 `/healthz`、安卓手机版部署教程都已准备好（见 `部署教程-安卓手机版.md`），**还没有真的部署**，部署要你注册账号后手动操作。

原页面（小猪、紫粉 UI、三人格、互动、接草莓、长期记忆）全部保留。

**⚠️ 人设按你的要求改了（2026-11-11 修正版）**：小猪是送给女朋友的专属 **AI 小男友**（男性），核心性格是外冷内热、傲娇、专一、特别偏爱宝宝——嘴上有点冷、心里很在意，难过时收起傲娇认真安慰。叫用户「宝宝」，聊天显示名是「可爱的乖乖」。旧的「小女友式陪伴」说法和「上位者 / 朕 / 退下吧」口吻已经全部改掉，以 `docs/phase3-contract.md` §1 为准。三种人格、小猪形象、头像、互动都没动。想改回来随时说，有备份。

原项目没有被删除：
- 第一阶段单文件版在 `~/workspace/your_files/ke-ai-de-guai-guai/`（备份在 `backup/`）
- 第二阶段交付前备份在 `~/workspace/ke-ai-de-guai-guai-v2-backup-2026-11-11-phase3-before/`

## 五页导航

底部固定导航，切换不重建页面、不丢数据：

| 页 | 内容 |
|---|---|
| 首页 | 小猪、聊天、三种人格、摸摸头/喂食/抱抱、接草莓、换装、表情包、每日礼物、哄睡入口、情绪急救室入口 |
| 回忆 | 纪念日与倒计时、回忆时光机（可搜索、按月筛选、收藏、照片）、专属信件 |
| 惊喜 | 每日惊喜盲盒（每天一次）、心愿清单、礼物推荐 |
| 游戏 | 接草莓入口 + 8 个新游戏（猜数字、记忆翻牌、幸运转盘、反应力、默契小考验、石头剪刀布、每日幸运测试、小猪喂养） |
| 我的 | 喜好档案、今日报告、隐私保险箱、AI 与数据设置（备份/恢复） |

## 14 个阶段都做了什么

1. **五页导航**：首页/回忆/惊喜/游戏/我的，底部导航，记住上次停在哪页。
2. **回忆时光机**：新建/编辑/删除/收藏回忆，可写标题、日期、地点、文字，照片上传后自动压缩再保存；支持搜索和按月筛选。
3. **情绪急救室**：首页「我需要抱抱」入口，8 种情绪（开心/难过/委屈/生气/焦虑/孤独/疲惫/想念）。选了情绪后，小猪的回话会按情绪变（难过/委屈/生气时不玩笑、不说教）；可以倾诉，也可以选「现在不想说话」，小猪安安静静陪着。
4. **纪念日与倒计时**：记第一次见面、在一起天数（真实计算，不编）、最近的日子还剩几天、当天到了会庆祝。
5. **每日盲盒**：每天只能开一次（服务器强制，第二天才能再开），8 种惊喜：AI 专属情话、小纸条、祝福、故事、问题、任务、回忆、AI 生成。没配钥匙时 AI 类用本地模板，并老实标注「乖乖自己写的小惊喜」。
6. **心愿清单**：新建/编辑/删除/完成/优先级/备注/照片；完成后有庆祝；「AI 帮我想一个」只给建议，点了「加入心愿」才保存，绝不自动添加。
7. **哄睡模式**：深紫夜空、月亮星星、小猪呼吸动画；本地生成的摇篮曲（WebAudio 合成的小星星旋律，标注「本地生成」，不偷用任何音乐文件）；呼吸引导；睡前故事/晚安情话/今天的回忆；15/30/60 分钟定时，到时停音乐说晚安。
8. **喜好档案**：10 类喜好（食物/饮品/颜色/动物/音乐/电影/活动/礼物/讨厌的/日期）。可以手动记，也可以从最近的真实聊天记录里提取候选——**提取只返回候选，必须你逐条点确认才保存**，绝不自动写进档案。
9. **礼物推荐**：按已确认的喜好、快到的纪念日、未完成的心愿，用规则挑 6 条。只给名字、理由、场合、预算区间（「100元以内」「100-300元」），**不编具体价格、不编店铺、不编链接、不自动购买**。可以收进收藏夹。
10. **游戏乐园**：接草莓入口（回首页玩原来的）+ 8 个新游戏，全部可玩、有分数。成绩和金币记在服务器上；**每个游戏每天最多拿 30 金币**，拿满了会老实告诉你，明天再来。
11. **语音陪伴**：浏览器自带的语音识别（Chrome 直接能用）和朗读。不支持的浏览器会老实提示，不装样子。朗读可以开关、调语速（0.6–1.4）。
12. **每日报告**：只用今天真实发生过的数据（聊天次数、互动次数、完成的心愿、开过的盲盒），没有数据就老实说「今天还没有足够的回忆」，不编数字。有钥匙时 AI 写总结，没钥匙用本地模板并标注来源。
13. **隐私保险箱**：真加密——WebCrypto AES-GCM + PBKDF2（随机盐、10 万次迭代）。密码只存在你的脑子里，服务器只收到一串谁也读不懂的密文，**忘了密码就真的打不开，没有任何找回接口**，页面里写明了。
14. **专属信件**：写信、读信、收藏、删除；「AI 帮我写一封」没钥匙时用本地模板并老实标注「不是 AI 在线写的」。

## 项目结构

```
ke-ai-de-guai-guai-v2/
  package.json                 # 依赖：express + pg；jsdom 是测试用的开发依赖
  .env.example                 # 配置示例，复制为 .env 后填写（含 DATABASE_URL）
  render.yaml                  # Render 部署蓝图（免费 Web Service；密钥不在文件里）
  README.md                    # 本文件
  TEST-REPORT.md               # 测试报告（每一项都真实跑过）
  部署教程-安卓手机版.md        # 手机一步步部署教程（GitHub + Neon + Render）
  docs/phase3-contract.md      # Phase 3 开发契约（API/数据库/前端桥接）
  docs/deploy-research-notes.md# Render/Neon 免费档限制调研笔记（2026-11-11 核实）
  frontend/
    index.html                 # 页面（五页导航 + 13 个功能模块的挂载点）
    css/style.css
    js/app.js                  # 逻辑 + window.GG 桥接（情绪、事件、状态同步）
    js/nav.js                  # 底部导航
    js/features/               # 13 个功能模块（回忆/情绪/纪念日/信件/盲盒/心愿/
                               #   喜好/礼物/哄睡/游戏/语音/报告/保险箱）
    assets/avatar.jpg          # 聊天头像
  backend/
    server.js                  # Express 入口：读 .env、迁移、挂路由、托管前端
    database/
      init.sql                 # 建表 SQL（SQLite：users / messages / user_state）
      init.pg.sql              # 建表 SQL（PostgreSQL / Neon：同一组表）
      db.js                    # 双模式数据库层（DATABASE_URL 有则 pg，否则 SQLite）
      migrate.js               # 启动时按顺序应用 migrations/ 下的迁移（幂等）
      migrations/002-phase3.sql     # 14 张新表 + user_state 加 4 列（SQLite）
      migrations/002-phase3.pg.sql  # 同上（PostgreSQL）
      migrations/003-photos.sql     # 照片进数据库（SQLite）
      migrations/003-photos.pg.sql  # 同上（PostgreSQL）
      app.sqlite               # 首次启动自动生成，不要提交、不要外发
    services/
      deepseek.js              # 调 DeepSeek（只在后端，钥匙绝不离开服务器）
      content.js               # 盲盒/信件/报告模板、喜好提取规则、礼物推荐规则
      context.js               # 已确认喜好、随机回忆、相识天数（只读）
    routes/                    # chat / state / health + memories / anniversaries /
                               #   surprise / wishlists / preferences / gifts / games /
                               #   reports / letters / vault / photos / events
    middleware/
      userToken.js             # X-User-Token 校验
      errors.js                # 统一错误处理
  scripts/
    test-backend.js            # 后端自测（npm test，32 项）
    test-integration.sh        # 联调测试（curl，65 项，含假 Key 直连验证）
    test-dom.js                # 前端 DOM 冒烟测试（jsdom，12+12 项）
    test-dom-restore.js        # 持久化恢复测试（jsdom，7 项）
    test-shell.js              # 导航 + 桥接测试（jsdom，20 项）
    test-integration-features.js   # B+C 模块联调（jsdom + 真实服务器，46 项）
    test-integration-features-a.js # A 模块联调（jsdom + 真实服务器，32 项）
    pg-query.js                # 对 DATABASE_URL 跑一条 SQL（给联调脚本的 pg 检查用）
    test-pg.js                 # 建全新空 pg 库跑测试，跑完删除（npm run test:pg）
  tools/
    split-frontend.py          # 单文件 → 前后端分离的拆分脚本（已用过，留档）
    migrate-frontend.py        # DeepSeek 直连 → 后端接口的迁移脚本（已用过，留档）
```

## 1. 在电脑上运行

前置：Node.js 22 或更高版本（`node --version` 查看；没有就去 [nodejs.org](https://nodejs.org) 装 LTS）。

```bash
cd ke-ai-de-guai-guai-v2
npm install
cp .env.example .env
# 用文本编辑器打开 .env，把 DEEPSEEK_API_KEY= 后面填上你的钥匙（见第 2 节）
npm start
```

看到 `[ok] 可爱的乖乖 v2 后端已启动：http://0.0.0.0:3000` 后，用浏览器打开：

- **http://localhost:3000**

页面顶部的 AI 状态会显示「DeepSeek 在线模式 · 后端已配置」。如果显示「离线模式 · 服务器未配置钥匙」，就是钥匙还没填好或服务没重启。

> 注意：不要直接双击打开 `frontend/index.html`。那样是没有后端的，AI 用不了，页面会显示「连不上后端」。必须通过 `npm start` 启动的服务器访问。

## 2. 配置 DeepSeek API（钥匙只放服务器）

1. 打开 https://platform.deepseek.com ，用手机号登录。
2. 左侧菜单 → **API keys** → **创建 API key**，名字随便填，复制生成的钥匙（以 `sk-` 开头，只显示一次，丢了就重新创建）。
3. 打开项目里的 `.env` 文件，找到这一行填进去：
   ```
   DEEPSEEK_API_KEY=sk-你复制的钥匙
   ```
4. 保存后重启服务（Ctrl+C 停掉，再 `npm start`）。

**安全规则：**
- 钥匙只写在你自己电脑/服务器的 `.env` 里，**不要写进前端代码、不要发到聊天里、不要提交到 git**（`.gitignore` 已屏蔽 `.env` 和数据库文件）。
- 你的 DeepSeek 账号余额之前是 ¥1.00，平时聊天够用一阵；盲盒、报告、信件等功能以后会增加调用量。
- 页面里如果提示 **401** = 钥匙不对或失效，去平台重新创建一把换上；**402** = 账号余额不足，去平台充值；**503** = 服务器没配钥匙。

## 3. 在手机上访问（同一 Wi-Fi）

服务默认监听 `0.0.0.0`，同一局域网内的手机可以直接访问：

1. 查电脑的局域网 IP：
   - Windows：`ipconfig`，看 IPv4 地址，如 `192.168.1.5`
   - Mac：`ipconfig getifaddr en0`
2. 手机连同一个 Wi-Fi，打开浏览器输入：
   ```
   http://192.168.1.5:3000
   ```
   （把 IP 换成你电脑的实际地址）
3. 电脑关机或服务停掉，手机就打不开——这是本机运行的正常情况，长期可用要走第 4 节的公网部署。

## 4. 部署到公网（Render + Neon 免费方案，推荐）

**手机一步步操作见 `部署教程-安卓手机版.md`**（每一步点哪里、填什么、复制什么都写了）。这里只写要点：

1. **Neon（数据库）**：注册 → 建项目（选 AWS 区域，如新加坡）→ 复制 **pooled 连接串**（带 `-pooler` 的那个），格式是 `postgres://用户名:密码@ep-xxx-pooler.…neon.tech/neondb?sslmode=require`。以后所有数据（聊天、回忆、照片、保险箱）都存在这里。
2. **GitHub（放代码）**：注册 → 新建仓库 → 把项目推上去（手机用 Termux + git，教程里有完整命令）。
3. **Render（跑服务）**：注册 → New → Blueprint → 选仓库 → 填两个环境变量：`DATABASE_URL`（贴 Neon 的连接串）、`DEEPSEEK_API_KEY`（贴 DeepSeek 钥匙）。部署完成后 Render 给一个 `https://xxx.onrender.com` 地址。
4. 打开那个地址，页面能打开、AI 状态显示「DeepSeek 在线模式」就成功了。

**免费档的真实限制（提前说清楚，不是永久无限免费）：**
- Render 免费服务 **15 分钟没人访问就休眠**，下次打开要等约 1 分钟唤醒（会先看到 Render 加载页）；每月 750 小时免费时长，超了当月暂停。
- Neon 免费档：存储 1 GB/项目、每月 100 CU-小时、闲置 5 分钟后计算挂起（下次查询几百毫秒恢复）；**没有自动定时备份**，备份靠页面里的「备份数据」按钮导出 JSON 文件，自己保存好。
- 照片存在 Neon 数据库里（不是 Render 磁盘），所以不怕服务重启；但照片占 1 GB 存储额度，压缩后的照片一般 100-300KB 一张，够存几千张。
- Render 自己的免费 Postgres **30 天过期会删数据**，不要用它；就用 Neon。

### 其他部署方式（有电脑时再考虑）

#### 方案 A：云服务器（长期可用）

1. 买一台云服务器（腾讯云/阿里云/华为云等，最低配即可），系统 Ubuntu 22.04/24.04。
2. 装 Node.js 22+：
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```
3. 把项目传到服务器（如 `/opt/ke-ai-de-guai-guai-v2`），执行：
   ```bash
   npm install
   cp .env.example .env
   # 编辑 .env 填好 DEEPSEEK_API_KEY 和 PORT
   ```
4. 用 pm2 保持服务运行（掉线自动重启、开机自启）：
   ```bash
   sudo npm install -g pm2
   pm2 start backend/server.js --name guai-guai
   pm2 save && pm2 startup
   ```
5. 买个域名并解析到服务器 IP，用 Nginx 反向代理 + HTTPS（以宝塔面板或 certbot 为例）：
   ```bash
   sudo apt-get install -y nginx certbot python3-certbot-nginx
   sudo certbot --nginx -d 你的域名
   ```
   Nginx 里把域名代理到 `http://127.0.0.1:3000`。
6. 云服务器的安全组/防火墙放行 80、443 端口。

### 方案 B：PaaS 平台（快，不用管服务器）

Railway / Render / Fly.io 任选：新建项目 → 导入代码 → 设置启动命令 `npm start`，在平台的 **Environment Variables** 里设置 `DEEPSEEK_API_KEY` **和 `DATABASE_URL`**（不要写进代码），平台会给一个 `https://xxx.up.railway.app` 这样的地址。免费套餐可能会休眠，介意的话用方案 A。**注意：如果用 Render 免费档，不要用它自带的免费 Postgres（30 天过期删数据），数据库就用 Neon。**

## 5. 让女朋友通过链接访问

- **公网部署好之后**：把 `https://你的域名`（或平台给的地址）发给她，点开即用，不用装任何东西。
- 她第一次打开时，浏览器会自动生成一个专属 token，她的聊天记录、名字、喜好、回忆都存在服务器上，只属于这个 token，**和你的数据是隔离的**。
- **没有公网部署时**：她只能在和你同一 Wi-Fi 下，用第 3 节的局域网地址访问；或者你把电脑开着、用内网穿透工具临时分享——长期用还是建议走第 4 节。
- **旧的离线文件还能用**：原来那个单文件 HTML（离线脑子版）不受影响，但它没有后端、没有数据库，AI 聊天要靠她自己在页面里填钥匙；新版必须走服务器访问。

## 数据说明

**存在服务器数据库里，刷新、关网页、换浏览器都还在：**
聊天记录、名字和喜好、好感度、回忆、每日礼物日期、心情/饱腹/精力数值、金币、帽子、表情包收藏册、回忆时光机、纪念日、心愿清单、喜好档案、礼物收藏、游戏成绩、每日报告、信件、保险箱密文、每日盲盒、事件记录、**照片（存在数据库里，不再放磁盘）**。

数据库二选一（由 `DATABASE_URL` 决定）：
- **本地 SQLite**（`backend/database/app.sqlite`）：不填 `DATABASE_URL` 时用，电脑上跑着玩、测试时用。
- **Neon PostgreSQL**：填了 `DATABASE_URL` 就用它。部署到 Render 时必须填，否则服务一重启数据全丢（Render 免费档没有持久化磁盘）。

**备份与恢复**（页面里点「⚙ AI 设置」）：
- **备份数据**：下载一个 JSON 文件，里面有全部数据（照片以 base64 跟着备份走；保险箱只导密文，没有密码也打不开）。
- **恢复数据**：选择之前下载的备份文件，点恢复后刷新页面即可。
- 也可以直接复制 `backend/database/app.sqlite` 文件，这就是完整数据库（服务运行时先停掉服务再复制；只适用于本地 SQLite 模式）。Neon 模式的完整备份靠应用内导出 + Neon 控制台的手动快照（免费档有 1 个手动快照）。

**隔离机制（说实话）：** 目前是按浏览器生成的 token 隔离数据，不是账号密码登录。知道 token 才能访问对应数据，所以不要把 token 或备份文件发给外人；登录功能后续再做。

## 故障排查

| 现象 | 原因 | 办法 |
|---|---|---|
| AI 状态显示「服务器未配置钥匙」 | `.env` 里没填 `DEEPSEEK_API_KEY` | 按第 2 节填好，重启服务 |
| 发消息后提示 401 | 服务器上的钥匙不对/失效 | 去 DeepSeek 平台重新创建一把，更新 `.env` 后重启 |
| 提示 402 | 账号余额不足 | 去 DeepSeek 平台充值 |
| 显示「连不上后端」 | 页面不是通过服务器打开的，或服务没启动 | 用 `http://localhost:3000` 访问；检查 `npm start` 是否在运行 |
| 手机打不开 | 不在同一 Wi-Fi，或 IP/端口不对 | 按第 3 节核对 IP；电脑防火墙放行 3000 端口 |
| 刷新后记录没了 | 用了不同的浏览器/token，或数据库文件被删 | 换浏览器会生成新 token；用备份文件恢复；检查 `app.sqlite` 还在不在 |
| 语音输入点完没反应 | 浏览器不支持语音识别 | 换 Chrome（电脑版/安卓版）再试；Safari/微信内置浏览器可能不支持 |
| 保险箱密码忘了 | 密码只存在脑子里，服务器也没有 | **真的打不开**，只能把保险箱清空重建（清空前先导出备份，但备份也是密文） |
| Render 上服务启动失败，日志报数据库连不上 | `DATABASE_URL` 贴错了或 Neon 项目挂起 | 检查 Render 环境变量里的 `DATABASE_URL` 是不是带 `-pooler` 的 pooled 连接串；打开 Neon 控制台看项目状态 |
| 打开公网地址先看到 Render 加载页，要等一会儿 | 免费服务休眠后唤醒 | 等约 1 分钟；每天第一次打开都会这样，正常 |
| 照片打不开（404） | 照片 URL 里的 token 对不上 | 照片按上传时的 token 隔离；换浏览器/token 后旧照片的 URL 打不开是正常的，照片本身还在数据库里，用原来的浏览器打开回忆就能看到 |

## 测试

```bash
npm test                                   # 后端自测（32 项，本地 SQLite）
bash scripts/test-integration.sh            # 联调测试（curl，65 项，含假 Key 直连验证）
npm run test:dom                           # 前端 DOM 冒烟 + 持久化恢复（jsdom，31 项）
node scripts/test-shell.js                  # 导航 + 桥接（jsdom，20 项）
node scripts/test-integration-features.js   # B+C 模块联调（jsdom + 真实服务器，46 项）
node scripts/test-integration-features-a.js # A 模块联调（jsdom + 真实服务器，32 项）
```

**SQLite 模式合计 226 项检查，0 失败。** 详细结果见 `TEST-REPORT.md`。

PostgreSQL 模式（Neon 同款方言）：设好 `DATABASE_URL` 后同样跑一遍，`scripts/test-pg.js` 会为每次运行建一个全新空库、跑完删除：

```bash
# 本地 PostgreSQL（本机装了 postgres 且当前用户能建库）
DATABASE_URL=postgres://用户名:密码@127.0.0.1:5432/postgres node scripts/test-pg.js npm test
DATABASE_URL=postgres://用户名:密码@127.0.0.1:5432/postgres node scripts/test-pg.js bash scripts/test-integration.sh
```
