'use strict';
// 数据库迁移：启动时按顺序应用 backend/database/migrations/ 下未应用的 SQL 文件。
// 幂等：靠 migrations 表记录已应用的文件名；每个文件在一个事务里执行，
// 任一语句失败即整体回滚并抛出错误（由 server.js 启动流程决定退出，
// 数据库不留半成品）。init.sql / init.pg.sql 不动；现有数据不受影响。
// 方言：pg 模式只应用 *.pg.sql，sqlite 模式只应用 *.sql（不含 .pg.sql）。
const fs = require('fs');
const path = require('path');

const MIGRATIONS_DIR = path.join(__dirname, 'migrations');

async function applyMigrations(db) {
  const isPg = db.dialect === 'pg';
  // migrations 表：applied_at 是 epoch 毫秒（BIGINT），与 init 的其它时间戳一致。
  await db.exec(
    'CREATE TABLE IF NOT EXISTS migrations (name TEXT PRIMARY KEY, applied_at BIGINT NOT NULL)'
  );
  let applied;
  try {
    const rows = await db.all('SELECT name FROM migrations');
    applied = new Set(rows.map((r) => r.name));
  } catch (err) {
    throw new Error(`读取 migrations 记录失败：${err.message}`);
  }

  let files = [];
  try {
    files = fs
      .readdirSync(MIGRATIONS_DIR)
      .filter((f) => (isPg ? f.endsWith('.pg.sql') : f.endsWith('.sql') && !f.endsWith('.pg.sql')))
      .sort();
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
    return; // 没有迁移目录：没有可应用的迁移。
  }

  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), 'utf8');
    await db.tx(async (t) => {
      await t.exec(sql);
      await t.run('INSERT INTO migrations (name, applied_at) VALUES (?, ?)', file, Date.now());
    }).catch((err) => {
      throw new Error(`数据库迁移 ${file} 失败，已回滚：${err.message}`);
    });
    console.log(`[ok] 已应用数据库迁移：${file}`);
  }
}

module.exports = { applyMigrations, MIGRATIONS_DIR };
