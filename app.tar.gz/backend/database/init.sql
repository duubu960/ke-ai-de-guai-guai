-- 可爱的乖乖 v2 数据库初始化
-- SQLite。由 backend/database/db.js 在服务启动时执行（不存在则创建）。

CREATE TABLE IF NOT EXISTS users (
  token TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS user_state (
  token TEXT PRIMARY KEY,
  profile_json TEXT,
  affection INTEGER,
  memories_json TEXT,
  first_met INTEGER,
  last_visit INTEGER,
  last_topic TEXT,
  recent_replies_json TEXT,
  daily_gift_date TEXT,
  updated_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_messages_token_created ON messages (token, created_at);
