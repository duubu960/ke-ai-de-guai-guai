-- 可爱的乖乖 v2 数据库初始化
-- PostgreSQL（Neon）。由 backend/database/db.js 在服务启动时执行（不存在则创建）。
-- 与 init.sql（SQLite）同一组表，只改方言：自增 id 用 IDENTITY，时间戳用 BIGINT。

CREATE TABLE IF NOT EXISTS users (
  token TEXT PRIMARY KEY,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  token TEXT NOT NULL,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS user_state (
  token TEXT PRIMARY KEY,
  profile_json TEXT,
  affection INTEGER,
  memories_json TEXT,
  first_met BIGINT,
  last_visit BIGINT,
  last_topic TEXT,
  recent_replies_json TEXT,
  daily_gift_date TEXT,
  updated_at BIGINT
);

CREATE INDEX IF NOT EXISTS idx_messages_token_created ON messages (token, created_at);
