'use strict';
// 数据库访问层：双模式，同一套异步接口。
// - 设置 DATABASE_URL 时走 PostgreSQL（pg；部署目标是 Neon）。
// - 未设置时走本地 SQLite（node:sqlite；本地零配置运行，行为与原来一致）。
// - 上层（路由 / 服务）只用这里的 get / all / run / exec / tx，SQL 统一用 `?`
//   占位符写；pg 模式自动翻译成 $1、$2……（翻译器会跳过字符串字面量里的 `?`）。
// - 时间戳全部是 JS 侧的 epoch 毫秒整数（BIGINT），两种数据库行为一致。
// - 0/1 标志位用 INTEGER 存，两种数据库都返回 JS 数字；pg 的 int8（BIGINT）
//   已注册解析器，返回 JS 数字而不是字符串。
const fs = require('fs');
const path = require('path');

let adapter = null;

function isPgMode() {
  return Boolean((process.env.DATABASE_URL || '').trim());
}

// 把 `?` 占位符翻译成 pg 的 $1、$2……；跳过单引号字符串、双引号标识符、
// 行注释与块注释里的 `?`。
function toPgParams(sql) {
  let out = '';
  let n = 0;
  let i = 0;
  const len = sql.length;
  while (i < len) {
    const ch = sql[i];
    if (ch === "'") {
      // 单引号字符串：'' 是转义的单引号。
      let j = i + 1;
      while (j < len) {
        if (sql[j] === "'") {
          if (sql[j + 1] === "'") { j += 2; continue; }
          j += 1;
          break;
        }
        j += 1;
      }
      out += sql.slice(i, j);
      i = j;
      continue;
    }
    if (ch === '"') {
      let j = i + 1;
      while (j < len && sql[j] !== '"') j += 1;
      out += sql.slice(i, Math.min(j + 1, len));
      i = Math.min(j + 1, len);
      continue;
    }
    if (ch === '-' && sql[i + 1] === '-') {
      let j = sql.indexOf('\n', i);
      if (j === -1) j = len;
      out += sql.slice(i, j);
      i = j;
      continue;
    }
    if (ch === '/' && sql[i + 1] === '*') {
      let j = sql.indexOf('*/', i + 2);
      j = j === -1 ? len : j + 2;
      out += sql.slice(i, j);
      i = j;
      continue;
    }
    if (ch === '?') {
      n += 1;
      out += '$' + n;
      i += 1;
      continue;
    }
    out += ch;
    i += 1;
  }
  return out;
}

function isUniqueViolation(err) {
  if (!err) return false;
  // SQLite：SQLITE_CONSTRAINT_UNIQUE；PostgreSQL：23505。
  return err.code === 'SQLITE_CONSTRAINT_UNIQUE' || err.code === '23505';
}

// ---------- SQLite 适配 ----------
function createSqliteAdapter(dbPath) {
  const { DatabaseSync } = require('node:sqlite');
  const file = resolveDbPath(dbPath);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  const initSql = fs.readFileSync(path.join(__dirname, 'init.sql'), 'utf8');
  db.exec(initSql);

  const api = {
    dialect: 'sqlite',
    async get(sql, ...params) {
      return db.prepare(sql).get(...params);
    },
    async all(sql, ...params) {
      return db.prepare(sql).all(...params);
    },
    // 返回 { changes }；需要新行 id 的地方请在 SQL 里写 RETURNING id 并用 get()。
    async run(sql, ...params) {
      const info = db.prepare(sql).run(...params);
      return { changes: info.changes };
    },
    async exec(sql) {
      db.exec(sql);
    },
    async tx(fn) {
      db.exec('BEGIN');
      try {
        const r = await fn(api);
        db.exec('COMMIT');
        return r;
      } catch (e) {
        try { db.exec('ROLLBACK'); } catch (_) { /* 以原始错误为准 */ }
        throw e;
      }
    },
    async close() {
      db.close();
    },
  };
  return api;
}

// ---------- PostgreSQL 适配 ----------
function createPgAdapter(connectionString) {
  const { Pool, types } = require('pg');
  // int8（BIGINT）默认返回字符串；本项目的时间戳/计数都是 epoch 毫秒，
  // 在 JS 安全整数范围内，直接解析成数字，保持与 SQLite 一致的行为。
  types.setTypeParser(20, (v) => parseInt(v, 10));
  const pool = new Pool({
    connectionString,
    max: 5, // Neon 免费档 + 池化端点：小连接池足够，留有余量。
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
    ssl: { rejectUnauthorized: false }, // Neon 要求 TLS；证书由平台托管。
  });
  pool.on('error', (err) => {
    console.error('[db] pg pool error:', err.message);
  });

  // queryFn：带参数的查询（扩展协议）；execFn：原始 SQL（简单协议），
  // 专门给多语句的 schema/迁移文件用——带参数数组调用会强制走扩展协议，
  // 多语句会报错，所以 exec 必须不传参数。
  function makeApi(queryFn, execFn) {
    return {
      dialect: 'pg',
      async get(sql, ...params) {
        const r = await queryFn(toPgParams(sql), params);
        return r.rows[0];
      },
      async all(sql, ...params) {
        const r = await queryFn(toPgParams(sql), params);
        return r.rows;
      },
      async run(sql, ...params) {
        const r = await queryFn(toPgParams(sql), params);
        return { changes: r.rowCount };
      },
      async exec(sql) {
        await execFn(sql);
      },
      async tx(fn) {
        const client = await pool.connect();
        try {
          await client.query('BEGIN');
          const r = await fn(
            makeApi(
              (text, params) => client.query(text, params),
              (text) => client.query(text)
            )
          );
          await client.query('COMMIT');
          return r;
        } catch (e) {
          try { await client.query('ROLLBACK'); } catch (_) { /* 以原始错误为准 */ }
          throw e;
        } finally {
          client.release();
        }
      },
      async close() {
        await pool.end();
      },
    };
  }

  const api = makeApi(
    (text, params) => pool.query(text, params),
    (text) => pool.query(text)
  );
  api._pool = pool;
  return api;
}

function defaultDbPath() {
  return path.join(__dirname, 'app.sqlite');
}

function resolveDbPath(dbPath) {
  const raw = dbPath || process.env.DB_PATH || '';
  if (!raw) return defaultDbPath();
  return path.isAbsolute(raw) ? raw : path.resolve(process.cwd(), raw);
}

// 初始化数据库并返回适配器。pg 模式：先连通再执行 init.pg.sql；
// sqlite 模式：建目录、开 WAL、执行 init.sql。调用方用完请 closeDb()。
async function initDb(dbPath) {
  if (isPgMode()) {
    const connectionString = process.env.DATABASE_URL.trim();
    adapter = createPgAdapter(connectionString);
    // 先确认能连上，失败时启动即报错（不要等到第一次请求才暴露）。
    await adapter.exec('SELECT 1');
    const initSql = fs.readFileSync(path.join(__dirname, 'init.pg.sql'), 'utf8');
    await adapter.exec(initSql);
    console.log('[ok] 数据库：PostgreSQL（DATABASE_URL 已设置）');
    return adapter;
  }
  adapter = createSqliteAdapter(dbPath);
  console.log('[ok] 数据库：本地 SQLite');
  return adapter;
}

function getDb() {
  if (!adapter) throw new Error('database not initialized');
  return adapter;
}

// 首次访问自动建 users 行（已存在则忽略）。两种方言同一条 SQL。
async function ensureUser(token) {
  const db = getDb();
  await db.run(
    'INSERT INTO users (token, created_at) VALUES (?, ?) ON CONFLICT (token) DO NOTHING',
    token,
    Date.now()
  );
}

async function closeDb() {
  if (adapter) {
    await adapter.close();
    adapter = null;
  }
}

module.exports = {
  initDb,
  getDb,
  ensureUser,
  closeDb,
  resolveDbPath,
  isUniqueViolation,
  isPgMode,
  toPgParams,
};
