-- 可爱的乖乖 Phase 3 数据库迁移（002）
-- 由 backend/database/migrate.js 在服务启动时应用；幂等（靠 migrations 表记录）。
-- 不动 init.sql 与现有三张表（users / messages / user_state）的数据；
-- 只新增表，并给 user_state 补 coins / meters / hat / seenFaces 四列。

CREATE TABLE IF NOT EXISTS migrations (
  name TEXT PRIMARY KEY,
  applied_at INTEGER NOT NULL
);

-- 回忆时光机
CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  location TEXT DEFAULT '',
  description TEXT DEFAULT '',
  category TEXT DEFAULT '',
  photo_url TEXT DEFAULT '',
  favorite INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_memories_token_date ON memories (token, date);
CREATE INDEX IF NOT EXISTS idx_memories_token_fav ON memories (token, favorite);

-- 情侣纪念日与倒计时
CREATE TABLE IF NOT EXISTS anniversaries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'custom',
  note TEXT DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_anniversaries_token_date ON anniversaries (token, date);

-- 心愿清单
CREATE TABLE IF NOT EXISTS wishlists (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  title TEXT NOT NULL,
  category TEXT DEFAULT '',
  priority INTEGER NOT NULL DEFAULT 2,
  note TEXT DEFAULT '',
  photo_url TEXT DEFAULT '',
  done INTEGER NOT NULL DEFAULT 0,
  completed_at INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_wishlists_token_done ON wishlists (token, done);

-- 每日惊喜盲盒（每天只能开一次：唯一键保证）
CREATE TABLE IF NOT EXISTS daily_surprises (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  date TEXT NOT NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'offline',
  favorite INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  UNIQUE (token, date)
);

-- 惊喜历史（开盒时写入；查询用它；只读）
CREATE TABLE IF NOT EXISTS surprise_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  date TEXT NOT NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'offline',
  favorite INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_surprise_history_token_date ON surprise_history (token, date);

-- 喜好档案
CREATE TABLE IF NOT EXISTS preferences (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  category TEXT NOT NULL,
  value TEXT NOT NULL,
  confirmed INTEGER NOT NULL DEFAULT 0,
  source TEXT NOT NULL DEFAULT 'manual',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_preferences_token_cat ON preferences (token, category);

-- 游戏记录
CREATE TABLE IF NOT EXISTS game_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  game TEXT NOT NULL,
  score INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0,
  played_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_game_records_token_game ON game_records (token, game, played_at);

-- 每日情侣报告（缓存当天算出的报告）
CREATE TABLE IF NOT EXISTS daily_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  date TEXT NOT NULL,
  summary TEXT NOT NULL DEFAULT '',
  data_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL,
  UNIQUE (token, date)
);

-- 专属信件
CREATE TABLE IF NOT EXISTS letters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  occasion_date TEXT DEFAULT '',
  favorite INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_letters_token_status ON letters (token, status);

-- 隐私保险箱（只存密文；服务器永远不收密码）
CREATE TABLE IF NOT EXISTS vault_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  blob TEXT NOT NULL,
  iv TEXT NOT NULL,
  salt TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vault_token ON vault_items (token);

-- 用户设置（键值对）
CREATE TABLE IF NOT EXISTS user_settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  key TEXT NOT NULL,
  value TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  UNIQUE (token, key)
);

-- 事件日志（互动/聊天/游戏等，供每日报告统计）
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  type TEXT NOT NULL,
  detail TEXT DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_token_created ON events (token, created_at);

-- 礼物收藏
CREATE TABLE IF NOT EXISTS gift_favorites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  name TEXT NOT NULL,
  reason TEXT DEFAULT '',
  occasion TEXT DEFAULT '',
  budget TEXT DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_gift_favorites_token ON gift_favorites (token);

-- user_state 扩展列：金币 / 心情数值 / 帽子 / 表情包收藏
-- （老库已有行：DEFAULT 会自动填上，不丢数据）
ALTER TABLE user_state ADD COLUMN coins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_state ADD COLUMN meters_json TEXT DEFAULT '{"hunger":72,"mood":82,"energy":76}';
ALTER TABLE user_state ADD COLUMN hat TEXT DEFAULT 'bow';
ALTER TABLE user_state ADD COLUMN seen_faces_json TEXT DEFAULT '{}';
