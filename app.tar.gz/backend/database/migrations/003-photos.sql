-- 照片进数据库（003）
-- SQLite 版。照片原来只写磁盘文件（backend/data/photos/<token>/<uuid>.jpg），
-- Render 免费档没有持久化磁盘，重启/重新部署/休眠后文件全部丢失；
-- 从本迁移起照片存进 photos 表（BLOB），备份/恢复也随数据库走。
-- 旧文件如已存在，不会自动导入（部署前的项目里没有真实照片文件）。
CREATE TABLE IF NOT EXISTS photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  token TEXT NOT NULL,
  filename TEXT NOT NULL,
  mime TEXT NOT NULL,
  data BLOB NOT NULL,
  size INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  UNIQUE (token, filename)
);
CREATE INDEX IF NOT EXISTS idx_photos_token ON photos (token);
