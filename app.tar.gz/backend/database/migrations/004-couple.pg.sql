-- 情侣绑定（004）
-- PostgreSQL（Neon）版。一方生成 6 位数字绑定码，另一方输入后加入；绑定后双方共享
-- 同一份空间：messages、memories、letters、wishlists 四张表都以发起方
-- （token_a）的 token 读写；加入时 B 的旧行一次性并入 token_a 名下。
-- 不共享：user_state（金币、meters、喜好）、vault_items、photos、
-- anniversaries、game_records、events、daily_reports、preferences、
-- gift_favorites。
CREATE TABLE IF NOT EXISTS couples (
  id SERIAL PRIMARY KEY,
  code TEXT UNIQUE NOT NULL,
  token_a TEXT NOT NULL,
  token_b TEXT,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_couples_token_a ON couples (token_a);
CREATE INDEX IF NOT EXISTS idx_couples_token_b ON couples (token_b);
