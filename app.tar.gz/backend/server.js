'use strict';
// 入口：解析 .env、建 Express、挂路由、托管 frontend/ 静态文件、统一错误处理、监听。
// 不引入 dotenv：启动时自己读项目根目录 .env（KEY=VALUE 行，忽略 # 注释与空行）。
// .env 不存在时只告警、不崩溃；DEEPSEEK_API_KEY 缺失时 /api/health 报 missing、/api/chat 报 503。
// 数据库：DATABASE_URL 设置时走 PostgreSQL（Neon），未设置时走本地 SQLite。
const fs = require('fs');
const path = require('path');
const express = require('express');
const { initDb, closeDb } = require('./database/db');
const { applyMigrations } = require('./database/migrate');
const { userToken } = require('./middleware/userToken');
const { notFound, errorHandler } = require('./middleware/errors');
const { createHealthRouter } = require('./routes/health');
const { createChatRouter } = require('./routes/chat');
const { createStateRouter } = require('./routes/state');
const { createMemoriesRouter } = require('./routes/memories');
const { createAnniversariesRouter } = require('./routes/anniversaries');
const { createSurpriseRouter } = require('./routes/surprise');
const { createWishlistsRouter } = require('./routes/wishlists');
const { createPreferencesRouter } = require('./routes/preferences');
const { createGiftsRouter } = require('./routes/gifts');
const { createGamesRouter } = require('./routes/games');
const { createReportsRouter } = require('./routes/reports');
const { createLettersRouter } = require('./routes/letters');
const { createVaultRouter } = require('./routes/vault');
const { createPhotosRouter, createPhotoFileHandler } = require('./routes/photos');
const { createEventsRouter } = require('./routes/events');
const { createCoupleRouter } = require('./routes/couple');

const PROJECT_ROOT = path.join(__dirname, '..');

function loadEnv() {
  const envPath = path.join(PROJECT_ROOT, '.env');
  if (!fs.existsSync(envPath)) {
    console.warn('[warn] 未找到 .env 文件，使用默认配置；AI 聊天需要 DEEPSEEK_API_KEY。');
    return;
  }
  const lines = fs.readFileSync(envPath, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    let value = trimmed.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    // 已有的环境变量优先，不被 .env 覆盖。
    if (!(key in process.env)) process.env[key] = value;
  }
}

function getConfig() {
  return {
    port: parseInt(process.env.PORT, 10) || 3000,
    host: process.env.HOST || '0.0.0.0',
    model: process.env.DEEPSEEK_MODEL || 'deepseek-chat',
    getApiKey: () => (process.env.DEEPSEEK_API_KEY || '').trim(),
    dbPath: process.env.DB_PATH || undefined,
  };
}

function createApp(db, config) {
  const app = express();
  // 8MB：照片是 base64 JSON 上传（解码后 ≤5MB 约为 6.7MB 文本），其余接口仍按各自规则校验。
  app.use(express.json({ limit: '8mb' }));

  // 健康检查（给 Render 用）：不走 token 校验，返回 200 即表示服务活着。
  app.get('/healthz', (req, res) => {
    res.json({ ok: true, time: new Date().toISOString() });
  });

  // 全部 /api/* 都要求 X-User-Token。
  app.use('/api', userToken);
  app.use('/api', createHealthRouter(config));
  app.use('/api', createChatRouter(db, config));
  app.use('/api', createStateRouter(db));
  app.use('/api', createMemoriesRouter(db));
  app.use('/api', createAnniversariesRouter(db));
  app.use('/api', createSurpriseRouter(db, config));
  app.use('/api', createWishlistsRouter(db));
  app.use('/api', createPreferencesRouter(db, config));
  app.use('/api', createGiftsRouter(db));
  app.use('/api', createGamesRouter(db));
  app.use('/api', createReportsRouter(db, config));
  app.use('/api', createLettersRouter(db, config));
  app.use('/api', createVaultRouter(db));
  app.use('/api', createPhotosRouter(db));
  app.use('/api', createEventsRouter(db));
  app.use('/api', createCoupleRouter(db));
  // 未知的 /api/* 路由。
  app.use('/api', notFound);

  // 照片文件：/photos/<token>/<uuid>.jpg，从数据库取回原始字节。
  app.get('/photos/:token/:filename', createPhotoFileHandler(db));

  // 托管前端（frontend/ 由前端阶段提供；目录不存在时静态中间件直接放行）。
  app.use(express.static(path.join(PROJECT_ROOT, 'frontend')));

  app.use(errorHandler);
  return app;
}

async function start(options = {}) {
  loadEnv();
  const config = getConfig();
  if (options.port !== undefined) config.port = options.port;
  if (options.host !== undefined) config.host = options.host;
  if (options.dbPath) config.dbPath = options.dbPath;

  const db = await initDb(config.dbPath);
  // 启动时应用未应用的数据库迁移（幂等；失败则报错退出，不留半成品）。
  await applyMigrations(db);
  const app = createApp(db, config);
  const server = await new Promise((resolve, reject) => {
    const s = app.listen(config.port, config.host, () => resolve(s));
    s.on('error', reject);
  });
  const addr = server.address();
  console.log(`[ok] 可爱的乖乖 v2 后端已启动：http://${config.host}:${addr.port}`);
  if (!config.getApiKey()) {
    console.warn('[warn] 未配置 DEEPSEEK_API_KEY，AI 聊天将返回 503，可先用离线模式。');
  }

  const shutdown = () => {
    server.close(() => {
      closeDb().finally(() => process.exit(0));
    });
  };
  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);

  return { app, server, db, config };
}

if (require.main === module) {
  start().catch((err) => {
    console.error('[fatal] 启动失败：', err.message);
    process.exit(1);
  });
}

module.exports = { createApp, start, loadEnv, getConfig };
