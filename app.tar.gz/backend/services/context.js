'use strict';
// 跨模块读取用户上下文的只读小工具（全部按 token 隔离）：
// - 已确认的喜好值
// - 随机一条回忆
// - 认识天数（最早 first_meet 纪念日，或 user_state.first_met；没有时 null）
// 全部是异步（数据库层统一走异步接口，SQLite 与 PostgreSQL 同一套）。
const v = require('../routes/validate');

async function getConfirmedLikes(db, token) {
  const rows = await db.all(
    'SELECT value FROM preferences WHERE token = ? AND confirmed = 1',
    token
  );
  return rows.map((r) => r.value).filter(Boolean);
}

async function getRandomMemory(db, token) {
  const rows = await db.all(
    'SELECT * FROM memories WHERE token = ? ORDER BY RANDOM() LIMIT 1',
    token
  );
  return rows[0] || null;
}

async function getDaysTogether(db, token) {
  const today = v.todayStr();
  const firstMeet = await db.get(
    "SELECT date FROM anniversaries WHERE token = ? AND type = 'first_meet' ORDER BY date ASC LIMIT 1",
    token
  );
  if (firstMeet) return v.daysBetween(today, firstMeet.date);
  const state = await db.get('SELECT first_met FROM user_state WHERE token = ?', token);
  if (state && state.first_met) {
    const d = new Date(state.first_met);
    const s = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return v.daysBetween(today, s);
  }
  return null;
}

module.exports = { getConfirmedLikes, getRandomMemory, getDaysTogether };
