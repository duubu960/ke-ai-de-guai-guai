'use strict';
// DeepSeek API 调用：只在后端使用。
// Key 只以参数传入，绝不打印、不写日志、不返回给前端。
const DEEPSEEK_URL = 'https://api.deepseek.com/chat/completions';
const TIMEOUT_MS = 25000;

class DeepSeekError extends Error {
  constructor(status, code, upstreamStatus) {
    super(code);
    this.status = status;
    this.code = code;
    if (upstreamStatus) this.upstreamStatus = upstreamStatus;
  }
}

// 调 DeepSeek 聊天接口。成功返回 { reply, model, usage }，失败抛 DeepSeekError。
async function chatWithDeepSeek({ apiKey, model, messages }) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(DEEPSEEK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + apiKey,
      },
      body: JSON.stringify({
        model: model || 'deepseek-chat',
        messages,
        stream: false,
        temperature: 0.85,
        presence_penalty: 0.4,
        frequency_penalty: 0.3,
        max_tokens: 600,
      }),
      signal: controller.signal,
    });

    if (!res.ok) {
      if (res.status === 401) throw new DeepSeekError(401, 'deepseek_unauthorized');
      if (res.status === 402) throw new DeepSeekError(402, 'deepseek_insufficient_balance');
      if (res.status === 429) throw new DeepSeekError(429, 'deepseek_rate_limited');
      throw new DeepSeekError(502, 'deepseek_upstream_error', res.status);
    }

    const data = await res.json();
    const reply =
      data && data.choices && data.choices[0] && data.choices[0].message
        ? data.choices[0].message.content
        : null;
    if (typeof reply !== 'string' || reply.length === 0) {
      throw new DeepSeekError(502, 'deepseek_upstream_error', res.status);
    }
    return {
      reply,
      model: (data && data.model) || model || 'deepseek-chat',
      usage: (data && data.usage) || null,
    };
  } catch (err) {
    if (err instanceof DeepSeekError) throw err;
    // 超时（AbortError）与网络错误都映射为不可达，不透传原始错误。
    throw new DeepSeekError(502, 'deepseek_unreachable');
  } finally {
    clearTimeout(timer);
  }
}

module.exports = { chatWithDeepSeek, DeepSeekError };
