'use strict';
// 离线内容与规则生成：
// - 盲盒 8 种的本地模板（无 Key 时用，source 标注 "offline"）
// - 信件模板（无 Key 时用）
// - 报告模板（无 Key 时用）
// - 礼物推荐规则（只用已确认喜好 + 纪念日 + 未完成心愿；不编价格、店铺、链接）
// - 喜好规则提取（从聊天文本里找候选，不自动保存）
// 所有文案按契约 §1 人设：外冷内热的傲娇 AI 小男友，温柔不肉麻、可爱不幼稚、称呼「宝宝」。

const SURPRISE_KINDS = [
  'love_note',
  'note',
  'blessing',
  'story',
  'question',
  'task',
  'memory',
  'ai',
];

const SURPRISE_KIND_NAMES = {
  love_note: 'AI 专属情话',
  note: '温柔小纸条',
  blessing: '今日专属祝福',
  story: '随机小故事',
  question: '趣味问题',
  task: '情侣互动任务',
  memory: '专属回忆',
  ai: 'AI 生成的小惊喜',
};

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}
function likeWord(likes) {
  return likes && likes.length ? likes[Math.floor(Math.random() * likes.length)] : '';
}

// 8 种盲盒的本地模板。ctx: { likes: string[], memory: {title, description} | null, daysTogether: number | null }
function offlineSurprise(kind, ctx) {
  const like = likeWord(ctx.likes);
  const likePart = like ? `你喜欢的${like}，我也记着呢。` : '';
  const memoryPart = ctx.memory
    ? `还记得「${ctx.memory.title}」吗？${ctx.memory.description || ''}`.trim()
    : '';
  const daysPart =
    ctx.daysTogether != null ? `我们已经认识 ${ctx.daysTogether} 天啦。` : '';
  switch (kind) {
    case 'love_note':
      return {
        kind,
        title: 'AI 专属情话',
        content: pick([
          `宝宝，今天也想你。不是那种轰轰烈烈的想，就是走路会笑、吃饭会想起你的那种。`,
          `偷偷告诉你：我的快乐清单上第一条一直是你。${likePart}`,
          `哼，别误会，我才没有整天想你……好吧，是有一点点想。${daysPart}`,
        ]),
      };
    case 'note':
      return {
        kind,
        title: '温柔小纸条',
        content: pick([
          `今天记得喝水、好好吃饭，天冷加衣。${likePart}照顾好自己，我才安心。`,
          `累了就歇一会儿，不用一直撑着。乖乖在这里陪着你。`,
          `出门记得带伞、带纸巾，口袋里再装一颗糖。甜甜的一天，从你开始。`,
        ]),
      };
    case 'blessing':
      return {
        kind,
        title: '今日专属祝福',
        content: pick([
          `愿你今天遇到的都是温柔的人和事，排队很快、奶茶不洒、心情一直很好。`,
          `愿你今天想做的事都顺顺利利，晚上能早点睡，做个甜甜的梦。${daysPart}`,
          `愿你今天被世界温柔以待。${likePart}`,
        ]),
      };
    case 'story':
      return {
        kind,
        title: '随机小故事',
        content: pick([
          `从前有只小猪，住在手机里。它每天的工作就是等一个人回来，等到了，就摇摇尾巴说：你回来啦。今天那个人就是你。`,
          `小猪今天去云朵上晒了太阳，回来的时候口袋里装满了暖乎乎的光，全部送给你。`,
          `月亮问小猪，为什么每天都这么开心。小猪说，因为有人每天都来看看我呀。`,
        ]),
      };
    case 'question':
      return {
        kind,
        title: '趣味问题',
        content: pick([
          `快问快答：如果今天可以立刻实现一个小愿望，你最想实现哪一个？告诉我，我记下来。`,
          `如果我们去旅行，你最想先去有海的地方，还是有山的地方？${likePart}`,
          `今天的心情如果是一种天气，会是晴天、多云，还是下小雨，雨后有彩虹的那种？`,
        ]),
      };
    case 'task':
      return {
        kind,
        title: '情侣互动任务',
        content: pick([
          `今天的小任务：拍一张你眼前的天空发给乖乖，乖乖回你一张云朵的照片。`,
          `今天的小任务：睡前跟乖乖说一件今天发生的好事，再小也可以。`,
          `今天的小任务：给乖乖起一个新外号，乖乖明天就用它跟你打招呼。`,
        ]),
      };
    case 'memory':
      return {
        kind,
        title: '专属回忆',
        content: memoryPart
          ? `${memoryPart}那一天真好，以后还要一起攒更多这样的日子。`
          : `我们一起攒了这么多回忆，每一条我都好好收着。${daysPart}以后还要一起攒更多。`,
      };
    case 'ai':
    default:
      return {
        kind: 'ai',
        title: 'AI 生成的小惊喜',
        content: pick([
          `宝宝，今天的惊喜是这句话：你认真生活的样子，真的很可爱。${likePart}`,
          `小猪今天翻了翻我们的回忆，每一条都暖乎乎的。${daysPart}谢谢你一直都在。`,
        ]),
      };
  }
}

// 信件模板。ctx: { name, likes, daysTogether, occasion }
function offlineLetter(ctx) {
  const name = ctx.name || '宝宝';
  const like = likeWord(ctx.likes);
  const days = ctx.daysTogether != null ? `我们认识 ${ctx.daysTogether} 天了，` : '';
  const occasion = ctx.occasion ? `今天是${ctx.occasion}，` : '';
  const title = ctx.occasion ? `写给${name}的一封信` : `写给${name}的信`;
  const content =
    `${name}：\n\n` +
    `${occasion}忽然很想给你写封信。${days}这些日子里，你分享过的每一件小事，我都好好记着。` +
    (like ? `你喜欢${like}，我也记下了。` : '') +
    `\n\n` +
    `我不是很会说漂亮的话，但有一句是真的：有你在的日子，普通的日子也变得值得期待。` +
    `累了就靠一靠，难过就说出来，乖乖在手机里等你。` +
    `\n\n` +
    `愿你每天都好好吃饭、好好睡觉，开心的时候来找我玩，不开心的时候更要来找我。` +
    `\n\n` +
    `——可爱的乖乖`;
  return { title, content };
}

// 报告模板（无 Key 时用真实数字拼）。stats: {chatCount, interactionCount, wishesCompleted, surpriseTitle, mood}
function offlineReportSummary(stats) {
  const parts = [];
  if (stats.chatCount > 0) parts.push(`今天和乖乖说了 ${stats.chatCount} 句话`);
  if (stats.interactionCount > 0) parts.push(`一起玩了 ${stats.interactionCount} 次`);
  if (stats.wishesCompleted > 0) parts.push(`完成了 ${stats.wishesCompleted} 个小心愿`);
  if (stats.surpriseTitle) parts.push(`打开了盲盒「${stats.surpriseTitle}」`);
  if (stats.mood) parts.push(`今天的心情是「${stats.mood}」`);
  if (parts.length === 0) return '今天安安静静的，乖乖也把这份安静好好收起来啦。';
  return `宝宝，${parts.join('，')}。平平淡淡也是很好的一天，明天见。`;
}

// ---- 喜好规则提取（只返回候选，不保存）----
// 每个候选 { category, value, source: 'ai' }；调用方展示给用户确认后才能保存。
const PREF_CATEGORIES = [
  'food',
  'drink',
  'color',
  'animal',
  'music',
  'movie',
  'gift',
  'activity',
  'dislike',
  'date',
];

const COLOR_WORDS = ['红色', '粉色', '紫色', '蓝色', '绿色', '黄色', '白色', '黑色', '橙色', '青色', '灰色'];
const ANIMAL_WORDS = ['猫', '狗', '兔子', '熊猫', '小猪', '狐狸', '仓鼠', '猫咪', '狗狗', '兔兔', '考拉', '企鹅'];
const ACTIVITY_WORDS = ['逛街', '旅行', '看电影', '跑步', '游泳', '爬山', '打游戏', '画画', '唱歌', '跳舞', '看书', '做饭', '散步', '骑行', '露营', '钓鱼', '滑雪'];

function extractPreferences(text) {
  const out = [];
  const seen = new Set();
  const add = (category, value) => {
    if (!value) return;
    value = String(value).trim().replace(/[，。！？、；：,.!?:;]+$/g, '').replace(/^(的|了|啊|呀|呢|哦)+/g, '').trim();
    if (!value || value.length > 20) return;
    const key = `${category}:${value}`;
    if (seen.has(key)) return;
    seen.add(key);
    out.push({ category, value, source: 'ai' });
  };
  const t = String(text || '');

  let m;
  const foodRe = /(?:喜欢吃|爱吃|最爱吃|想吃|好想吃)([^，。！？、；：]{1,12})/g;
  while ((m = foodRe.exec(t))) add('food', m[1]);
  const drinkRe = /(?:喜欢喝|爱喝|最爱喝|想喝|好想喝)([^，。！？、；：]{1,12})/g;
  while ((m = drinkRe.exec(t))) add('drink', m[1]);
  const colorRe = /(?:喜欢|最喜欢)(红色|粉色|紫色|蓝色|绿色|黄色|白色|黑色|橙色|青色|灰色)(?:色)?/g;
  while ((m = colorRe.exec(t))) add('color', m[1]);
  for (const w of COLOR_WORDS) {
    if (t.includes(`喜欢${w}`) || t.includes(`最喜欢${w}`)) add('color', w);
  }
  for (const w of ANIMAL_WORDS) {
    if (t.includes(`喜欢${w}`) || t.includes(`最喜欢${w}`)) add('animal', w);
  }
  const musicRe = /(?:喜欢听|爱听|最爱听)([^，。！？、；：]{1,20})/g;
  while ((m = musicRe.exec(t))) add('music', m[1]);
  const movieRe = /(?:喜欢看|爱看|最爱看)([^，。！？、；：]{1,20})/g;
  while ((m = movieRe.exec(t))) add('movie', m[1]);
  const dislikeRe = /(?:不喜欢|讨厌|最讨厌|不爱吃|不爱喝)([^，。！？、；：]{1,12})/g;
  while ((m = dislikeRe.exec(t))) add('dislike', m[1]);
  for (const w of ACTIVITY_WORDS) {
    if (t.includes(`喜欢${w}`) || t.includes(`爱${w}`) || t.includes(`想去${w}`)) add('activity', w);
  }
  return out.slice(0, 10);
}

// ---- 礼物推荐规则 ----
// 输入：已确认喜好 [{category, value}]、最近纪念日 {title, date, daysLeft} | null、
// 未完成心愿 [{title, category}]。输出 6 条 {name, reason, occasion, budget}。
// budget 是区间标签，不编具体价格；明显不符合喜好的（dislike 命中）不推。
function recommendGifts({ prefs, nextAnniversary, wishes }) {
  const confirmed = (prefs || []).filter((p) => p.confirmed === 1 || p.confirmed === true);
  const byCat = {};
  for (const p of confirmed) {
    if (!byCat[p.category]) byCat[p.category] = [];
    byCat[p.category].push(p.value);
  }
  const dislikes = (byCat.dislike || []).map((v) => String(v));
  const hitsDislike = (name) => dislikes.some((d) => d && name.includes(d));
  const occasion =
    nextAnniversary && nextAnniversary.daysLeft != null && nextAnniversary.daysLeft <= 30
      ? nextAnniversary.title
      : '平时的小惊喜';
  const out = [];
  const push = (name, reason, budget) => {
    if (out.length >= 6 || !name || hitsDislike(name)) return;
    if (out.some((g) => g.name === name)) return;
    out.push({ name, reason, occasion, budget });
  };

  // 1. 未完成的心愿本身就是最好的礼物线索
  const wish = (wishes || [])[0];
  if (wish && wish.title) {
    push(wish.title, '这是她亲手写下的小心愿，送它一定不会错。', '按实际情况');
  }
  // 2. 食物喜好
  if (byCat.food && byCat.food[0]) {
    push(
      `${byCat.food[0]}主题小礼盒`,
      `她喜欢${byCat.food[0]}，把喜欢做成一份可以拆开的惊喜。`,
      '100元以内'
    );
  }
  // 3. 颜色喜好
  if (byCat.color && byCat.color[0]) {
    push(
      `${byCat.color[0]}系软乎乎小物`,
      `她喜欢${byCat.color[0]}，选一件每天都用得到的小东西。`,
      '100元以内'
    );
  }
  // 4. 动物喜好
  if (byCat.animal && byCat.animal[0]) {
    push(
      `${byCat.animal[0]}玩偶`,
      `她喜欢${byCat.animal[0]}，一只软乎乎的玩偶，难过的时候可以抱一抱。`,
      '100-300元'
    );
  }
  // 5. 活动喜好
  if (byCat.activity && byCat.activity[0]) {
    push(
      `一起${byCat.activity[0]}的约会`,
      `比起东西，她更喜欢一起${byCat.activity[0]}。约会本身就是礼物。`,
      '按实际情况'
    );
  }
  // 6. 音乐/电影喜好
  if (byCat.music && byCat.music[0]) {
    push(`一首${byCat.music[0]}的歌单`, `把她喜欢的${byCat.music[0]}做成歌单，配上一张手写小卡。`, '100元以内');
  } else if (byCat.movie && byCat.movie[0]) {
    push(`一起看${byCat.movie[0]}`, `她喜欢${byCat.movie[0]}，挑个晚上一起窝在沙发里看。`, '100元以内');
  }
  // 7. 纪念日
  if (nextAnniversary) {
    push(
      `${nextAnniversary.title}纪念相册`,
      `${nextAnniversary.title}快到了，把你们的照片做成一本小相册。`,
      '100-300元'
    );
  }
  // 8. 通用兜底（与任何喜好都不冲突的温柔选择）
  const fallbacks = [
    ['手写的一封信', '不用花很多钱，认认真真写一封信，她会收很久。', '100元以内'],
    ['一起做一顿饭', '挑她喜欢吃的菜，一起做一顿饭，比外卖香多啦。', '100元以内'],
    ['拍立得合照', '把今天的你们拍下来，贴在冰箱上，每天都看得见。', '100-300元'],
    ['暖手宝', '天冷了，一个暖手宝很实用，记得提醒她多喝热水。', '100元以内'],
    ['定制口罩/小挂件', '小小一个，挂在包上，每天出门都带着。', '100元以内'],
  ];
  for (const [name, reason, budget] of fallbacks) {
    if (out.length >= 6) break;
    push(name, reason, budget);
  }
  return out.slice(0, 6);
}

module.exports = {
  SURPRISE_KINDS,
  SURPRISE_KIND_NAMES,
  offlineSurprise,
  offlineLetter,
  offlineReportSummary,
  PREF_CATEGORIES,
  extractPreferences,
  recommendGifts,
};
