'use strict';
// X-User-Token 校验：必须是 uuid v4 格式。
// 缺失或格式错误返回 400 { error: 'invalid_user_token' }。
const UUID_V4_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function userToken(req, res, next) {
  const token = req.get('x-user-token');
  if (!token || !UUID_V4_RE.test(token)) {
    return res.status(400).json({ error: 'invalid_user_token' });
  }
  req.userToken = token;
  next();
}

module.exports = { userToken, UUID_V4_RE };
