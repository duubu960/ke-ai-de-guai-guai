'use strict';
// 统一错误处理 + 404。

// 未知 /api/* 路由。
function notFound(req, res) {
  res.status(404).json({ error: 'not_found' });
}

// JSON 解析失败返回 400；请求体超过限额也返回 400（不透传内部细节）。
function errorHandler(err, req, res, next) {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'invalid_json' });
  }
  if (err && err.type === 'entity.too.large') {
    return res.status(400).json({ error: 'invalid_request', detail: '请求体过大' });
  }
  if (err instanceof SyntaxError && err.status === 400) {
    return res.status(400).json({ error: 'invalid_json' });
  }
  console.error(err);
  res.status(500).json({ error: 'internal_error' });
}

module.exports = { notFound, errorHandler };
