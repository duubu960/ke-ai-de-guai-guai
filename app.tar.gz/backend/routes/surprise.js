'use strict';
// 每日惊喜盲盒：POST /api/surprise/open（每天只能开一次，靠唯一键保证；
// 当天已开过直接返回已有的）、GET /api/surprises/history、POST /api/surprises/:id/favorite
// 8 种：love_note / note / blessing / story / question / task / memory / ai。
// 内容结合已确认喜好与随机回忆；ai 种有 Key 时调 DeepSeek，无 Key 或失败时
// 用本地模板并标注 source:"offline"（不假装 AI 生成成功）。
const express = require('express');
const { ensureUser, isUniqueViolation } = require('../database/db');
const { chatWithDeepSeek } = require('../services/deepseek');
const { offlineSurprise, SURPRISE_KINDS, SURPRISE_KIND_NAMES } = require('../services/content');
const { getConfirmedLikes, getRandomMemory, getDaysTogether } = require('../services/context');
const v = require('./validate');

function rowToSurprise(r) {
  return {
    id: r.id,
    date: r.date,
    kind: r.kind,
    kindName: SURPRISE_KIND_NAMES[r.kind] || r.kind,
    title: r.title,
    content: r.content,
    source: r.source,
    favorite: r.favorite === 1,
    createdAt: r.created_at,
  };
}

// 最近 7 天已用过的种类（避免每天重复）。
async function recentKinds(db, token) {
  const since = v.todayStr(-7);
  const rows = await db.all(
    'SELECT DISTINCT kind FROM surprise_history WHERE token = ? AND date >= ?',
    token, since
  );
  return new Set(rows.map((r) => r.kind));
}

async function generateSurprise(db, config, token, wantKind) {
  const likes = await getConfirmedLikes(db, token);
  const memory = await getRandomMemory(db, token);
  const daysTogether = await getDaysTogether(db, token);
  const ctx = {
    likes,
    memory: memory ? { title: memory.title, description: memory.description } : null,
    daysTogether,
  };

  let kind = wantKind || null;
  if (!kind || !SURPRISE_KINDS.includes(kind)) {
    const used = await recentKinds(db, token);
    let pool = SURPRISE_KINDS.filter((k) => !used.has(k));
    if (pool.length === 0) pool = SURPRISE_KINDS.slice();
    if (!memory) pool = pool.filter((k) => k !== 'memory');
    if (pool.length === 0) pool = SURPRISE_KINDS.filter((k) => k !== 'memory');
    kind = pool[Math.floor(Math.random() * pool.length)];
  }
  if (kind === 'memory' && !memory) kind = 'love_note';

  // ai 种：有 Key 才调 DeepSeek；失败则回落本地模板。
  if (kind === 'ai' && config.getApiKey()) {
    try {
      const likeText = likes.length ? `她喜欢：${likes.slice(0, 5).join('、')}。` : '';
      const daysText = daysTogether != null ? `认识第 ${daysTogether} 天。` : '';
      const result = await chatWithDeepSeek({
        apiKey: config.getApiKey(),
        model: config.model,
        messages: [
          {
            role: 'system',
            content:
              '你是可爱的乖乖，一只粉色小猪，宝宝的 AI 小男友。写一句温柔、可爱、不肉麻的小惊喜，一到两句短句，带一点傲娇的味儿也行，但不要居高临下。不要编造经历，不要自称真人，不要每句都重复同一句情话。',
          },
          {
            role: 'user',
            content: `给宝宝写一句今天专属的小惊喜。${likeText}${daysText}`,
          },
        ],
      });
      const content = String(result.reply || '').trim().slice(0, 500);
      if (content) return { kind, title: 'AI 生成的小惊喜', content, source: 'ai' };
    } catch (e) {
      // 回落本地模板（不把上游错误透给前端）。
    }
  }
  const tpl = offlineSurprise(kind, ctx);
  return { kind: tpl.kind, title: tpl.title, content: tpl.content, source: 'offline' };
}

function createSurpriseRouter(db, config) {
  const router = express.Router();

  router.post('/surprise/open', async (req, res, next) => {
    try {
      const body = v.isPlainObject(req.body) ? req.body : {};
      let wantKind = null;
      if (body.kind !== undefined) {
        if (!SURPRISE_KINDS.includes(body.kind)) {
          return res.status(400).json({ error: 'invalid_request', detail: 'kind 必须是 8 种盲盒之一' });
        }
        wantKind = body.kind;
      }
      await ensureUser(req.userToken);
      const today = v.todayStr();
      const existing = await db.get(
        'SELECT * FROM daily_surprises WHERE token = ? AND date = ?',
        req.userToken, today
      );
      if (existing) {
        return res.json(Object.assign(rowToSurprise(existing), { isNew: false }));
      }
      const gen = await generateSurprise(db, config, req.userToken, wantKind);
      const now = Date.now();
      try {
        await db.run(
          `INSERT INTO daily_surprises (token, date, kind, title, content, source, favorite, created_at)
           VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
          req.userToken, today, gen.kind, gen.title, gen.content, gen.source, now
        );
      } catch (err) {
        // 并发双开时唯一键冲突：返回已写入的那一份。
        if (isUniqueViolation(err)) {
          const again = await db.get(
            'SELECT * FROM daily_surprises WHERE token = ? AND date = ?',
            req.userToken, today
          );
          if (again) return res.json(Object.assign(rowToSurprise(again), { isNew: false }));
        }
        throw err;
      }
      const row = await db.get(
        'SELECT * FROM daily_surprises WHERE token = ? AND date = ?',
        req.userToken, today
      );
      await db.run(
        `INSERT INTO surprise_history (token, date, kind, title, content, source, favorite, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
        req.userToken, today, gen.kind, gen.title, gen.content, gen.source, now
      );
      await db.run(
        'INSERT INTO events (token, type, detail, created_at) VALUES (?, ?, ?, ?)',
        req.userToken, 'surprise', gen.title, now
      );
      res.status(201).json(Object.assign(rowToSurprise(row), { isNew: true }));
    } catch (err) {
      next(err);
    }
  });

  router.get('/surprises/history', async (req, res, next) => {
    try {
      let limit = parseInt(req.query.limit, 10);
      if (Number.isNaN(limit)) limit = 30;
      limit = Math.max(1, Math.min(100, limit));
      const rows = await db.all(
        'SELECT * FROM surprise_history WHERE token = ? ORDER BY date DESC, id DESC LIMIT ?',
        req.userToken, limit
      );
      res.json({ surprises: rows.map(rowToSurprise) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/surprises/:id/favorite', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get(
        'SELECT * FROM surprise_history WHERE id = ? AND token = ?',
        id, req.userToken
      );
      if (!row) return res.status(404).json({ error: 'not_found' });
      await db.run(
        'UPDATE surprise_history SET favorite = 1 WHERE id = ? AND token = ?',
        id, req.userToken
      );
      await db.run(
        'UPDATE daily_surprises SET favorite = 1 WHERE token = ? AND date = ?',
        req.userToken, row.date
      );
      const updated = await db.get('SELECT * FROM surprise_history WHERE id = ?', id);
      res.json(rowToSurprise(updated));
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createSurpriseRouter, rowToSurprise, generateSurprise };
