'use strict';
// 专属信件：CRUD + 收藏 + POST /api/letters/ai-draft
// ai-draft 有 Key 时用 DeepSeek 生成，无 Key 时用模板并标注 source:"offline"。
// 信件风格：自然、真诚、温柔，不写过度夸张的网络情话。
const express = require('express');
const { ensureUser } = require('../database/db');
const { chatWithDeepSeek } = require('../services/deepseek');
const { offlineLetter } = require('../services/content');
const { getConfirmedLikes, getDaysTogether } = require('../services/context');
const v = require('./validate');

function rowToLetter(r) {
  return {
    id: r.id,
    title: r.title,
    content: r.content,
    occasionDate: r.occasion_date || '',
    favorite: r.favorite === 1,
    status: r.status,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function validateLetter(body, isUpdate) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  const need = (f) => !isUpdate || body[f] !== undefined;
  if (need('title') && !v.isNonEmptyStr(body.title, 100)) return 'title 不能为空且不超过 100 字';
  if (need('content') && !v.isNonEmptyStr(body.content, 10000)) return 'content 不能为空且不超过 10000 字';
  if (body.occasion_date !== undefined && body.occasion_date !== '' && body.occasion_date !== null && !v.isDateStr(body.occasion_date)) {
    return 'occasion_date 必须是 YYYY-MM-DD 或空';
  }
  if (body.occasionDate !== undefined && body.occasionDate !== '' && body.occasionDate !== null && !v.isDateStr(body.occasionDate)) {
    return 'occasionDate 必须是 YYYY-MM-DD 或空';
  }
  if (body.status !== undefined && body.status !== 'draft' && body.status !== 'sent') {
    return 'status 必须是 draft 或 sent';
  }
  if (body.favorite !== undefined && v.toBool(body.favorite) === null) return 'favorite 必须是布尔值';
  return null;
}

function createLettersRouter(db, config) {
  const router = express.Router();

  router.get('/letters', async (req, res, next) => {
    try {
      const { status, favorite } = req.query;
      if (status !== undefined && status !== 'draft' && status !== 'sent') {
        return res.status(400).json({ error: 'invalid_request', detail: 'status 必须是 draft 或 sent' });
      }
      if (favorite !== undefined && favorite !== '0' && favorite !== '1') {
        return res.status(400).json({ error: 'invalid_request', detail: 'favorite 必须是 0 或 1' });
      }
      let sql = 'SELECT * FROM letters WHERE token = ?';
      const params = [req.userToken];
      if (status) {
        sql += ' AND status = ?';
        params.push(status);
      }
      if (favorite !== undefined) {
        sql += ' AND favorite = ?';
        params.push(Number(favorite));
      }
      sql += ' ORDER BY favorite DESC, created_at DESC, id DESC';
      const rows = await db.all(sql, ...params);
      res.json({ letters: rows.map(rowToLetter) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/letters', async (req, res, next) => {
    try {
      const errMsg = validateLetter(req.body, false);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const b = req.body;
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO letters (token, title, content, occasion_date, favorite, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.title.trim(), b.content,
        b.occasionDate !== undefined ? b.occasionDate : b.occasion_date || '',
        v.toBool(b.favorite) === 1 ? 1 : 0,
        b.status || 'draft', now, now
      );
      const row = await db.get('SELECT * FROM letters WHERE id = ?', created.id);
      res.status(201).json(rowToLetter(row));
    } catch (err) {
      next(err);
    }
  });

  // AI 辅助写信（不保存草稿，调用方拿到 draft 后自己决定保存）。
  router.post('/letters/ai-draft', async (req, res, next) => {
    try {
      const body = v.isPlainObject(req.body) ? req.body : {};
      const occasion = typeof body.occasion === 'string' ? body.occasion.slice(0, 50) : '';
      const tone = typeof body.tone === 'string' ? body.tone.slice(0, 20) : '';
      const state = await db.get('SELECT profile_json FROM user_state WHERE token = ?', req.userToken);
      let name = '';
      try {
        if (state && state.profile_json) name = JSON.parse(state.profile_json).name || '';
      } catch (e) {
        // 解析失败按无名处理。
      }
      const likes = await getConfirmedLikes(db, req.userToken);
      const daysTogether = await getDaysTogether(db, req.userToken);
      if (config.getApiKey()) {
        try {
          const likeText = likes.length ? `她喜欢：${likes.slice(0, 5).join('、')}。` : '';
          const daysText = daysTogether != null ? `认识第 ${daysTogether} 天。` : '';
          const result = await chatWithDeepSeek({
            apiKey: config.getApiKey(),
            model: config.model,
            messages: [
              {
                role: 'system',
                content:
                  '你是可爱的乖乖，一只粉色小猪，宝宝的 AI 小男友。给宝宝写一封信，署名可爱的乖乖。语气自然、真诚、温柔，带一点傲娇和嘴硬心软的味儿，不肉麻，不写过度夸张的网络情话，不编造没有发生过的经历，不自称真人，不冒充宝宝现实中的男朋友。先给一个标题，再写信正文，200-400 字。',
              },
              {
                role: 'user',
                content: `给${name || '宝宝'}写一封信。${occasion ? `场合：${occasion}。` : ''}${tone ? `语气：${tone}。` : ''}${likeText}${daysText}`,
              },
            ],
          });
          const text = String(result.reply || '').trim();
          if (text) {
            const lines = text.split('\n').filter((l) => l.trim());
            const title = lines.length > 1 && lines[0].length <= 100 ? lines[0].trim() : `写给${name || '宝宝'}的信`;
            const content = lines.length > 1 && lines[0].length <= 100 ? lines.slice(1).join('\n').trim() : text;
            return res.json({ title, content, source: 'ai' });
          }
        } catch (e) {
          // 回落模板。
        }
      }
      const tpl = offlineLetter({ name, likes, daysTogether, occasion });
      res.json({ title: tpl.title, content: tpl.content, source: 'offline' });
    } catch (err) {
      next(err);
    }
  });

  router.get('/letters/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get('SELECT * FROM letters WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      res.json(rowToLetter(row));
    } catch (err) {
      next(err);
    }
  });

  router.put('/letters/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validateLetter(req.body, true);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM letters WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      const b = req.body;
      await db.run(
        `UPDATE letters SET title = ?, content = ?, occasion_date = ?, favorite = ?, status = ?, updated_at = ? WHERE id = ? AND token = ?`,
        b.title !== undefined ? b.title.trim() : row.title,
        b.content !== undefined ? b.content : row.content,
        b.occasionDate !== undefined ? b.occasionDate : b.occasion_date !== undefined ? b.occasion_date : row.occasion_date,
        b.favorite !== undefined ? v.toBool(b.favorite) : row.favorite,
        b.status !== undefined ? b.status : row.status,
        Date.now(),
        id,
        req.userToken
      );
      const updated = await db.get('SELECT * FROM letters WHERE id = ?', id);
      res.json(rowToLetter(updated));
    } catch (err) {
      next(err);
    }
  });

  router.post('/letters/:id/favorite', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get('SELECT * FROM letters WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      await db.run(
        'UPDATE letters SET favorite = 1, updated_at = ? WHERE id = ? AND token = ?',
        Date.now(), id, req.userToken
      );
      const updated = await db.get('SELECT * FROM letters WHERE id = ?', id);
      res.json(rowToLetter(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/letters/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM letters WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createLettersRouter, validateLetter, rowToLetter };
