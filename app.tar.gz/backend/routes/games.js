'use strict';
// 小游戏乐园：POST /api/games/record（每日每游戏金币上限 30；
// 超限返回 {error:"daily_coin_cap", awarded:0}；成功时金币加进 user_state.coins）
// GET /api/games/records / GET /api/games/summary
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

const GAMES = new Set([
  'strawberry',
  'guess',
  'memory',
  'wheel',
  'reaction',
  'quiz',
  'rps',
  'luck',
  'feed',
]);
const DAILY_COIN_CAP = 30;

function rowToGameRecord(r) {
  return {
    id: r.id,
    game: r.game,
    score: r.score,
    coins: r.coins,
    playedAt: r.played_at,
    createdAt: r.created_at,
  };
}

function createGamesRouter(db) {
  const router = express.Router();

  router.post('/games/record', async (req, res, next) => {
    try {
      const b = req.body;
      if (!v.isPlainObject(b)) return res.status(400).json({ error: 'invalid_request', detail: 'body 必须是对象' });
      if (!GAMES.has(b.game)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'game 必须是已知游戏之一' });
      }
      if (!v.isNonNegInt(b.score)) return res.status(400).json({ error: 'invalid_request', detail: 'score 必须是不小于 0 的整数' });
      if (!v.isIntRange(b.coins, 0, DAILY_COIN_CAP)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'coins 必须是 0-30 的整数' });
      }
      await ensureUser(req.userToken);
      const today = v.todayStr();
      const [start, end] = v.dayRange(today);
      const row = await db.get(
        'SELECT COALESCE(SUM(coins), 0) AS earned FROM game_records WHERE token = ? AND game = ? AND played_at >= ? AND played_at < ?',
        req.userToken, b.game, start, end
      );
      const earned = row.earned || 0;
      if (earned + b.coins > DAILY_COIN_CAP) {
        return res.status(409).json({ error: 'daily_coin_cap', awarded: 0, earnedToday: earned, cap: DAILY_COIN_CAP });
      }
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO game_records (token, game, score, coins, played_at, created_at)
         VALUES (?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.game, b.score, b.coins, now, now
      );
      // 金币进 user_state.coins（行不存在时先建行，其它字段留默认）。
      await db.run(
        `INSERT INTO user_state (token, coins, updated_at) VALUES (?, ?, ?)
         ON CONFLICT(token) DO UPDATE SET coins = COALESCE(user_state.coins, 0) + excluded.coins, updated_at = excluded.updated_at`,
        req.userToken, b.coins, now
      );
      await db.run(
        'INSERT INTO events (token, type, detail, created_at) VALUES (?, ?, ?, ?)',
        req.userToken, 'game', `${b.game}:${b.score}`, now
      );
      const total = await db.get('SELECT coins FROM user_state WHERE token = ?', req.userToken);
      const record = await db.get('SELECT * FROM game_records WHERE id = ?', created.id);
      res.status(201).json({
        record: rowToGameRecord(record),
        awarded: b.coins,
        totalCoins: total ? total.coins || 0 : 0,
      });
    } catch (err) {
      next(err);
    }
  });

  router.get('/games/records', async (req, res, next) => {
    try {
      const { game } = req.query;
      if (game !== undefined && !GAMES.has(game)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'game 不合法' });
      }
      let limit = parseInt(req.query.limit, 10);
      if (Number.isNaN(limit)) limit = 30;
      limit = Math.max(1, Math.min(200, limit));
      let sql = 'SELECT * FROM game_records WHERE token = ?';
      const params = [req.userToken];
      if (game) {
        sql += ' AND game = ?';
        params.push(game);
      }
      sql += ' ORDER BY played_at DESC, id DESC LIMIT ?';
      params.push(limit);
      const rows = await db.all(sql, ...params);
      res.json({ records: rows.map(rowToGameRecord) });
    } catch (err) {
      next(err);
    }
  });

  router.get('/games/summary', async (req, res, next) => {
    try {
      const rows = await db.all(
        `SELECT game, COUNT(*) AS plays, MAX(score) AS bestScore, COALESCE(SUM(coins), 0) AS coins
         FROM game_records WHERE token = ? GROUP BY game`,
        req.userToken
      );
      const byGame = {};
      let totalPlays = 0;
      let totalCoins = 0;
      for (const r of rows) {
        byGame[r.game] = { plays: r.plays, bestScore: r.bestScore, coins: r.coins };
        totalPlays += r.plays;
        totalCoins += r.coins;
      }
      const state = await db.get('SELECT coins FROM user_state WHERE token = ?', req.userToken);
      res.json({
        byGame,
        totalPlays,
        totalCoins,
        // user_state.coins 是钱包余额（可能含旧金币/历史调整），与 game_records 的 coins 合计可能不同。
        walletCoins: state ? state.coins || 0 : 0,
      });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createGamesRouter, rowToGameRecord, GAMES, DAILY_COIN_CAP };
