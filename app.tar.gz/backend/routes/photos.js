'use strict';
// 照片上传：POST /api/photos {dataUrl, name}
// 校验 data:image/(jpeg|png|webp);base64 且解码后 ≤ 5MB，存进数据库 photos 表
// （BYTEA/BLOB），不再写磁盘——Render 免费档没有持久化磁盘，文件在重启、
// 重新部署、休眠后会全部丢失；进数据库后照片随 Neon 一起持久化，备份也带上。
// GET /photos/<token>/<uuid>.<ext> 从数据库取回原始字节；URL 形状与原来一致，
// 前端不用改。token 在 URL 里，本身就是隔离边界（文件名是随机 UUID，不可枚举）。
const crypto = require('crypto');
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

const MAX_BYTES = 5 * 1024 * 1024;
const MIME_EXT = { jpeg: 'jpg', png: 'png', webp: 'webp' };
const PHOTO_MIME = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const MAX_PHOTO_BYTES = MAX_BYTES;
// 一次备份恢复最多带回的照片数（防超大备份把服务拖垮；一对情侣日常够用）。
const MAX_PHOTOS_PER_RESTORE = 500;
const DATA_URL_RE = /^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/;
const FILENAME_RE = /^[0-9a-f-]+\.(jpg|png|webp)$/i;

function createPhotosRouter(db) {
  const router = express.Router();

  router.post('/photos', async (req, res, next) => {
    try {
      const b = req.body;
      if (!v.isPlainObject(b)) return res.status(400).json({ error: 'invalid_request', detail: 'body 必须是对象' });
      if (typeof b.dataUrl !== 'string') {
        return res.status(400).json({ error: 'invalid_request', detail: 'dataUrl 必须是 data:image/(jpeg|png|webp);base64,…' });
      }
      const m = DATA_URL_RE.exec(b.dataUrl);
      if (!m) {
        return res.status(400).json({ error: 'invalid_request', detail: '只支持 jpeg/png/webp 的 base64 图片' });
      }
      if (b.name !== undefined && !v.isStr(b.name, 100)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'name 不超过 100 字' });
      }
      let buf;
      try {
        buf = Buffer.from(m[2], 'base64');
      } catch (e) {
        return res.status(400).json({ error: 'invalid_request', detail: 'base64 解码失败' });
      }
      if (buf.length === 0 || buf.length > MAX_BYTES) {
        return res.status(400).json({ error: 'invalid_request', detail: '图片解码后必须在 1 字节-5MB 之间' });
      }
      await ensureUser(req.userToken);
      const ext = MIME_EXT[m[1]];
      const filename = `${crypto.randomUUID()}.${ext}`;
      const mime = `image/${m[1]}`;
      await db.run(
        'INSERT INTO photos (token, filename, mime, data, size, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        req.userToken, filename, mime, buf, buf.length, Date.now()
      );
      res.status(201).json({ url: `/photos/${req.userToken}/${filename}`, size: buf.length });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

// GET /photos/:token/:filename：从数据库取回照片原始字节。
// 与 POST 分开挂载（不在 /api 下，不走 X-User-Token 校验，token 在 URL 里）。
function createPhotoFileHandler(db) {
  return async (req, res, next) => {
    try {
      const { token, filename } = req.params;
      if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(token)) {
        return res.status(400).json({ error: 'invalid_user_token' });
      }
      if (!FILENAME_RE.test(filename)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'filename 不合法' });
      }
      const row = await db.get(
        'SELECT mime, data FROM photos WHERE token = ? AND filename = ?',
        token, filename
      );
      if (!row) return res.status(404).json({ error: 'not_found' });
      res.setHeader('Content-Type', row.mime);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.send(Buffer.from(row.data));
    } catch (err) {
      next(err);
    }
  };
}

module.exports = {
  createPhotosRouter,
  createPhotoFileHandler,
  MAX_BYTES,
  MAX_PHOTO_BYTES,
  MAX_PHOTOS_PER_RESTORE,
  PHOTO_MIME,
  MIME_EXT,
};
