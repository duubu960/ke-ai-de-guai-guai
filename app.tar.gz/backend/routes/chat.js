'use strict';
// POST /api/chat：经后端代理调 DeepSeek，并把对话写入数据库。
// GET /api/history：按时间升序返回该用户的聊天记录。
const express = require('express');
const { chatWithDeepSeek, DeepSeekError } = require('../services/deepseek');
const { ensureUser } = require('../database/db');
const { resolveScope } = require('./couple');

const ROLES = new Set(['system', 'user', 'assistant']);

// 校验请求体 messages：非空数组、每条 role 合法、content 为 1..4000 字符非空串、
// 总数不超过 30 条、最后一条必须是 user。
function validateMessages(messages) {
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) return false;
  for (const m of messages) {
    if (!m || typeof m !== 'object' || Array.isArray(m)) return false;
    if (!ROLES.has(m.role)) return false;
    if (typeof m.content !== 'string') return false;
    if (m.content.trim().length < 1 || m.content.length > 4000) return false;
  }
  if (messages[messages.length - 1].role !== 'user') return false;
  return true;
}

function createChatRouter(db, config) {
  const router = express.Router();

  router.post('/chat', async (req, res, next) => {
    try {
      const messages = req.body && req.body.messages;
      if (!validateMessages(messages)) {
        return res.status(400).json({ error: 'invalid_request' });
      }
      const apiKey = config.getApiKey();
      if (!apiKey) {
        return res.status(503).json({ error: 'deepseek_key_missing' });
      }
      const result = await chatWithDeepSeek({ apiKey, model: config.model, messages });
      const lastUser = messages[messages.length - 1];
      const now = Date.now();
      await ensureUser(req.userToken);
      // 已绑定时对话写进共享空间（token_a 名下）；ensureUser 仍用原始 token。
      const scope = await resolveScope(db, req.userToken);
      await db.run(
        'INSERT INTO messages (token, role, content, created_at) VALUES (?, ?, ?, ?)',
        scope, 'user', lastUser.content, now
      );
      await db.run(
        'INSERT INTO messages (token, role, content, created_at) VALUES (?, ?, ?, ?)',
        scope, 'assistant', result.reply, now
      );
      res.json({ reply: result.reply, model: result.model, usage: result.usage });
    } catch (err) {
      if (err instanceof DeepSeekError) {
        const body = { error: err.code };
        if (err.upstreamStatus) body.status = err.upstreamStatus;
        return res.status(err.status).json(body);
      }
      next(err);
    }
  });

  router.get('/history', async (req, res, next) => {
    try {
      let limit = parseInt(req.query.limit, 10);
      if (Number.isNaN(limit)) limit = 50;
      limit = Math.max(1, Math.min(200, limit));
      await ensureUser(req.userToken);
      const scope = await resolveScope(db, req.userToken);
      const rows = await db.all(
        'SELECT role, content, created_at FROM messages WHERE token = ? ORDER BY created_at ASC, id ASC LIMIT ?',
        scope, limit
      );
      res.json({ messages: rows });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createChatRouter, validateMessages };
