'use strict';
// 各路由共享的输入校验（风格与现有 routes/state.js、routes/chat.js 一致）。
// 返回错误字符串，合法返回 null；错误码由路由统一成 { error: 'invalid_request', detail }。

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isNonNegInt(v) {
  return Number.isInteger(v) && v >= 0;
}
function isIntRange(v, min, max) {
  return Number.isInteger(v) && v >= min && v <= max;
}
function isStr(v, max) {
  return typeof v === 'string' && v.length <= max;
}
// 可选字符串字段：null/缺失都算“没有”，只校验传了字符串时的长度。
function isOptStr(v, max) {
  return v === null || v === undefined || (typeof v === 'string' && v.length <= max);
}
function isNonEmptyStr(v, max) {
  return typeof v === 'string' && v.trim().length > 0 && v.length <= max;
}
// 严格 YYYY-MM-DD，且是真实日历日期。
function isDateStr(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const [y, m, d] = v.split('-').map(Number);
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}
// YYYY-MM 月份（供 ?month= 筛选）。
function isMonthStr(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}$/.test(v)) return false;
  const m = Number(v.slice(5, 7));
  return m >= 1 && m <= 12;
}
// :id 必须是正整数。
function parseId(raw) {
  if (typeof raw !== 'string' || !/^\d+$/.test(raw)) return null;
  const n = Number(raw);
  return n >= 1 && Number.isSafeInteger(n) ? n : null;
}
// 布尔字段：接受 true/false/0/1。
function toBool(v) {
  if (v === true || v === 1) return 1;
  if (v === false || v === 0) return 0;
  return null;
}
// 服务端本地日期 YYYY-MM-DD（报告、盲盒按服务器本地日走）。
function todayStr(offsetDays) {
  const d = new Date();
  if (offsetDays) d.setDate(d.getDate() + offsetDays);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
// [startMs, endMs) —— 本地某日的毫秒区间（created_at 是毫秒时间戳）。
function dayRange(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const start = new Date(y, m - 1, d, 0, 0, 0, 0).getTime();
  const end = new Date(y, m - 1, d + 1, 0, 0, 0, 0).getTime();
  return [start, end];
}
// 两地日期相差天数（dateStr - baseStr，可为负）。
function daysBetween(dateStr, baseStr) {
  const [y1, m1, d1] = dateStr.split('-').map(Number);
  const [y2, m2, d2] = baseStr.split('-').map(Number);
  const t1 = Date.UTC(y1, m1 - 1, d1);
  const t2 = Date.UTC(y2, m2 - 1, d2);
  return Math.round((t1 - t2) / 86400000);
}
// 给定纪念日，求下一次到来日期与剩余天数（按年循环）。
function nextOccurrence(dateStr, today) {
  const [, m, d] = dateStr.split('-').map(Number);
  const year = Number(today.slice(0, 4));
  let cand = `${year}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  // 2 月 29 日：当年没有则顺到 3 月 1 日。
  if (!isDateStr(cand)) cand = `${year}-03-01`;
  if (daysBetween(cand, today) < 0) {
    cand = `${year + 1}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    if (!isDateStr(cand)) cand = `${year + 1}-03-01`;
  }
  return { date: cand, daysLeft: daysBetween(cand, today) };
}

module.exports = {
  isPlainObject,
  isNonNegInt,
  isIntRange,
  isStr,
  isOptStr,
  isNonEmptyStr,
  isDateStr,
  isMonthStr,
  parseId,
  toBool,
  todayStr,
  dayRange,
  daysBetween,
  nextOccurrence,
};
