'use strict';
// 情侣绑定：一方生成 6 位数字绑定码，另一方输入后加入。
// POST /api/couple/create / POST /api/couple/join / GET /api/couple/status
// POST /api/couple/unbind
// 绑定后双方共享同一份空间：messages、memories、letters、wishlists 四张表
// 都以发起方（token_a）的 token 读写；加入时 B 的旧行一次性并入 token_a 名下。
// 不共享：user_state（金币、meters、喜好）、vault_items、photos、
// anniversaries、game_records、events、daily_reports、preferences、
// gift_favorites——这些表和路由仍按原始 token 隔离，见各自文件。
// 解除绑定时共享行留在 token_a 名下，不迁回（返回的 note 会写清楚）。
const crypto = require('crypto');
const express = require('express');
const { isUniqueViolation } = require('../database/db');

// 只接受 6 位数字串。
const CODE_RE = /^\d{6}$/;

// 解析共享空间：token 是某对情侣的任一方时返回发起方 token_a，
// 否则返回原 token。共享表（messages / memories / letters / wishlists）
// 的全部读写都走这个解析结果；ensureUser 仍用原始 token。
async function resolveScope(db, token) {
  const row = await db.get(
    'SELECT token_a FROM couples WHERE token_a = ? OR token_b = ?',
    token, token
  );
  return row ? row.token_a : token;
}

// 100000–999999，保证 6 位数字。
function randomCode() {
  return String(crypto.randomInt(100000, 1000000));
}

function createCoupleRouter(db) {
  const router = express.Router();

  async function findCouple(token) {
    return db.get(
      'SELECT * FROM couples WHERE token_a = ? OR token_b = ?',
      token, token
    );
  }

  // 生成绑定码。已是 token_a 时返回已有的码；已是 token_b 时 409。
  router.post('/couple/create', async (req, res, next) => {
    try {
      const mine = await findCouple(req.userToken);
      if (mine) {
        if (mine.token_a === req.userToken) {
          return res.json({ code: mine.code, joined: mine.token_b !== null });
        }
        return res.status(409).json({ error: 'already_paired', detail: '已加入别人的绑定，先解除' });
      }
      // 生成唯一码：code 有 UNIQUE 约束，碰撞时重试。
      let code = null;
      for (let i = 0; i < 10; i++) {
        const candidate = randomCode();
        try {
          await db.run(
            'INSERT INTO couples (code, token_a, token_b, created_at) VALUES (?, ?, ?, ?)',
            candidate, req.userToken, null, Date.now()
          );
          code = candidate;
          break;
        } catch (err) {
          if (!isUniqueViolation(err)) throw err;
        }
      }
      if (!code) {
        return res.status(503).json({ error: 'code_generation_failed', detail: '绑定码生成失败，请重试' });
      }
      res.json({ code, joined: false });
    } catch (err) {
      next(err);
    }
  });

  // 输入绑定码加入。成功时在一个事务里把调用方在四张共享表里的旧行
  // token 改成 token_a（并入共享空间），再把 token_b 设为调用方。
  router.post('/couple/join', async (req, res, next) => {
    try {
      const code = req.body && req.body.code;
      if (typeof code !== 'string' || !CODE_RE.test(code)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'code 必须是 6 位数字' });
      }
      const row = await db.get('SELECT * FROM couples WHERE code = ?', code);
      if (!row) return res.status(404).json({ error: 'not_found', detail: '绑定码不存在' });
      if (row.token_a === req.userToken) {
        return res.status(400).json({ error: 'invalid_request', detail: '不能加入自己发起的绑定' });
      }
      const mine = await findCouple(req.userToken);
      if (mine) {
        return res.status(409).json({ error: 'already_paired', detail: '已在别的绑定里，先解除' });
      }
      if (row.token_b !== null) {
        return res.status(409).json({ error: 'already_paired', detail: '该绑定已被加入' });
      }
      await db.tx(async (t) => {
        for (const table of ['messages', 'memories', 'letters', 'wishlists']) {
          await t.run(`UPDATE ${table} SET token = ? WHERE token = ?`, row.token_a, req.userToken);
        }
        await t.run('UPDATE couples SET token_b = ? WHERE code = ?', req.userToken, code);
      });
      res.json({ ok: true, code, role: 'b', joined: true });
    } catch (err) {
      next(err);
    }
  });

  router.get('/couple/status', async (req, res, next) => {
    try {
      const row = await findCouple(req.userToken);
      if (!row) return res.json({ paired: false });
      res.json({
        paired: true,
        code: row.code,
        role: row.token_a === req.userToken ? 'a' : 'b',
        joined: row.token_b !== null,
      });
    } catch (err) {
      next(err);
    }
  });

  // 任一方都可解除。共享行留在 token_a 名下，不迁回。
  router.post('/couple/unbind', async (req, res, next) => {
    try {
      const row = await findCouple(req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found', detail: '未加入任何绑定' });
      await db.run('DELETE FROM couples WHERE id = ?', row.id);
      res.json({
        ok: true,
        code: row.code,
        note: '解除后共享的回忆、信件、心愿与聊天记录仍保留在发起方名下，不会迁回',
      });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createCoupleRouter, resolveScope };
