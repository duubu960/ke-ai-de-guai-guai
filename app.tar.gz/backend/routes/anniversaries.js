'use strict';
// 情侣纪念日与倒计时：CRUD + GET /api/anniversaries/summary
// summary → { daysTogether, next: [{id, title, date, daysLeft}] }
// daysTogether 取最早的 first_meet 纪念日，或 user_state.first_met；没有时为 null，不编。
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

const TYPES = new Set(['first_meet', 'anniversary', 'birthday', 'custom']);

function rowToAnniversary(r) {
  return {
    id: r.id,
    title: r.title,
    date: r.date,
    type: r.type,
    note: r.note || '',
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function validateAnniversary(body, isUpdate) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  const need = (f) => !isUpdate || body[f] !== undefined;
  if (need('title') && !v.isNonEmptyStr(body.title, 100)) return 'title 不能为空且不超过 100 字';
  if (need('date') && !v.isDateStr(body.date)) return 'date 必须是 YYYY-MM-DD';
  if (body.type !== undefined && !TYPES.has(body.type)) return 'type 必须是 first_meet/anniversary/birthday/custom';
  if (body.note !== undefined && !v.isOptStr(body.note, 500)) return 'note 不超过 500 字';
  return null;
}

function createAnniversariesRouter(db) {
  const router = express.Router();

  router.get('/anniversaries/summary', async (req, res, next) => {
    try {
      const today = v.todayStr();
      const rows = await db.all('SELECT * FROM anniversaries WHERE token = ? ORDER BY date ASC', req.userToken);
      const state = await db.get('SELECT first_met FROM user_state WHERE token = ?', req.userToken);
      let daysTogether = null;
      const firstMeet = rows.find((r) => r.type === 'first_meet');
      if (firstMeet) {
        daysTogether = v.daysBetween(today, firstMeet.date);
      } else if (state && state.first_met) {
        const d = new Date(state.first_met);
        const firstMetStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
        daysTogether = v.daysBetween(today, firstMetStr);
      }
      const next = rows
        .map((r) => {
          const occ = v.nextOccurrence(r.date, today);
          return { id: r.id, title: r.title, date: occ.date, daysLeft: occ.daysLeft };
        })
        .sort((a, b) => a.daysLeft - b.daysLeft)
        .slice(0, 5);
      res.json({ daysTogether, next });
    } catch (err) {
      next(err);
    }
  });

  router.get('/anniversaries', async (req, res, next) => {
    try {
      const rows = await db.all(
        'SELECT * FROM anniversaries WHERE token = ? ORDER BY date ASC, id ASC',
        req.userToken
      );
      res.json({ anniversaries: rows.map(rowToAnniversary) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/anniversaries', async (req, res, next) => {
    try {
      const errMsg = validateAnniversary(req.body, false);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const b = req.body;
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO anniversaries (token, title, date, type, note, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.title.trim(), b.date, b.type || 'custom', b.note || '', now, now
      );
      const row = await db.get('SELECT * FROM anniversaries WHERE id = ?', created.id);
      res.status(201).json(rowToAnniversary(row));
    } catch (err) {
      next(err);
    }
  });

  router.put('/anniversaries/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validateAnniversary(req.body, true);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM anniversaries WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      const b = req.body;
      await db.run(
        `UPDATE anniversaries SET title = ?, date = ?, type = ?, note = ?, updated_at = ? WHERE id = ? AND token = ?`,
        b.title !== undefined ? b.title.trim() : row.title,
        b.date !== undefined ? b.date : row.date,
        b.type !== undefined ? b.type : row.type,
        b.note !== undefined ? b.note : row.note,
        Date.now(),
        id,
        req.userToken
      );
      const updated = await db.get('SELECT * FROM anniversaries WHERE id = ?', id);
      res.json(rowToAnniversary(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/anniversaries/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM anniversaries WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createAnniversariesRouter, validateAnniversary, rowToAnniversary };
