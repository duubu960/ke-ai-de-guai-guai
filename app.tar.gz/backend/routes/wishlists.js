'use strict';
// 心愿清单：CRUD + 完成 + summary {total, done, pending}
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

function rowToWishlist(r) {
  return {
    id: r.id,
    title: r.title,
    category: r.category || '',
    priority: r.priority,
    note: r.note || '',
    photoUrl: r.photo_url || '',
    done: r.done === 1,
    completedAt: r.completed_at || null,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function validateWishlist(body, isUpdate) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  const need = (f) => !isUpdate || body[f] !== undefined;
  if (need('title') && !v.isNonEmptyStr(body.title, 100)) return 'title 不能为空且不超过 100 字';
  if (body.category !== undefined && !v.isOptStr(body.category, 20)) return 'category 不超过 20 字';
  if (body.priority !== undefined && !v.isIntRange(body.priority, 1, 3)) return 'priority 必须是 1-3';
  if (body.note !== undefined && !v.isOptStr(body.note, 1000)) return 'note 不超过 1000 字';
  if (body.photo_url !== undefined && !v.isOptStr(body.photo_url, 500)) return 'photo_url 不超过 500 字';
  if (body.photoUrl !== undefined && !v.isOptStr(body.photoUrl, 500)) return 'photoUrl 不超过 500 字';
  if (body.done !== undefined && v.toBool(body.done) === null) return 'done 必须是布尔值';
  return null;
}

function createWishlistsRouter(db) {
  const router = express.Router();

  router.get('/wishlists/summary', async (req, res, next) => {
    try {
      const row = await db.get(
        'SELECT COUNT(*) AS total, COALESCE(SUM(done), 0) AS done FROM wishlists WHERE token = ?',
        req.userToken
      );
      const total = row.total || 0;
      const done = row.done || 0;
      res.json({ total, done, pending: total - done });
    } catch (err) {
      next(err);
    }
  });

  router.get('/wishlists', async (req, res, next) => {
    try {
      const { done } = req.query;
      if (done !== undefined && done !== '0' && done !== '1') {
        return res.status(400).json({ error: 'invalid_request', detail: 'done 必须是 0 或 1' });
      }
      let sql = 'SELECT * FROM wishlists WHERE token = ?';
      const params = [req.userToken];
      if (done !== undefined) {
        sql += ' AND done = ?';
        params.push(Number(done));
      }
      sql += ' ORDER BY done ASC, priority ASC, created_at DESC';
      const rows = await db.all(sql, ...params);
      res.json({ wishlists: rows.map(rowToWishlist) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/wishlists', async (req, res, next) => {
    try {
      const errMsg = validateWishlist(req.body, false);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const b = req.body;
      const now = Date.now();
      const done = v.toBool(b.done) === 1 ? 1 : 0;
      const created = await db.get(
        `INSERT INTO wishlists (token, title, category, priority, note, photo_url, done, completed_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.title.trim(), b.category || '', b.priority || 2, b.note || '',
        b.photoUrl || b.photo_url || '', done, done ? now : null, now, now
      );
      const row = await db.get('SELECT * FROM wishlists WHERE id = ?', created.id);
      res.status(201).json(rowToWishlist(row));
    } catch (err) {
      next(err);
    }
  });

  router.put('/wishlists/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validateWishlist(req.body, true);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM wishlists WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      const b = req.body;
      const done = b.done !== undefined ? v.toBool(b.done) : row.done;
      const completedAt = b.done !== undefined ? (done ? Date.now() : null) : row.completed_at;
      await db.run(
        `UPDATE wishlists SET title = ?, category = ?, priority = ?, note = ?, photo_url = ?, done = ?, completed_at = ?, updated_at = ? WHERE id = ? AND token = ?`,
        b.title !== undefined ? b.title.trim() : row.title,
        b.category !== undefined ? b.category : row.category,
        b.priority !== undefined ? b.priority : row.priority,
        b.note !== undefined ? b.note : row.note,
        b.photoUrl !== undefined ? b.photoUrl : b.photo_url !== undefined ? b.photo_url : row.photo_url,
        done, completedAt, Date.now(), id, req.userToken
      );
      const updated = await db.get('SELECT * FROM wishlists WHERE id = ?', id);
      res.json(rowToWishlist(updated));
    } catch (err) {
      next(err);
    }
  });

  router.post('/wishlists/:id/complete', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get('SELECT * FROM wishlists WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      if (row.done === 1) return res.json(rowToWishlist(row));
      const now = Date.now();
      await db.run(
        'UPDATE wishlists SET done = 1, completed_at = ?, updated_at = ? WHERE id = ? AND token = ?',
        now, now, id, req.userToken
      );
      await db.run(
        'INSERT INTO events (token, type, detail, created_at) VALUES (?, ?, ?, ?)',
        req.userToken, 'wishlist_done', row.title, now
      );
      const updated = await db.get('SELECT * FROM wishlists WHERE id = ?', id);
      res.json(rowToWishlist(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/wishlists/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM wishlists WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createWishlistsRouter, validateWishlist, rowToWishlist };
