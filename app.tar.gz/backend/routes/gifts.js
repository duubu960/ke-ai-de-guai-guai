'use strict';
// AI 礼物推荐：GET /api/gifts/recommend（规则生成 6 条，不编价格/店铺/链接）
// + 收藏 CRUD（gift_favorites）。
const express = require('express');
const { ensureUser } = require('../database/db');
const { recommendGifts } = require('../services/content');
const v = require('./validate');

function rowToGiftFavorite(r) {
  return {
    id: r.id,
    name: r.name,
    reason: r.reason || '',
    occasion: r.occasion || '',
    budget: r.budget || '',
    createdAt: r.created_at,
  };
}

function createGiftsRouter(db) {
  const router = express.Router();

  router.get('/gifts/recommend', async (req, res, next) => {
    try {
      const prefs = (await db.all(
        'SELECT category, value, confirmed FROM preferences WHERE token = ?',
        req.userToken
      )).map((p) => ({ category: p.category, value: p.value, confirmed: p.confirmed === 1 }));
      const today = v.todayStr();
      const anns = await db.all(
        'SELECT * FROM anniversaries WHERE token = ? ORDER BY date ASC',
        req.userToken
      );
      let nextAnniversary = null;
      if (anns.length) {
        const occs = anns
          .map((a) => {
            const occ = v.nextOccurrence(a.date, today);
            return { title: a.title, date: occ.date, daysLeft: occ.daysLeft };
          })
          .sort((a, b) => a.daysLeft - b.daysLeft);
        nextAnniversary = occs[0];
      }
      const wishes = await db.all(
        'SELECT title, category FROM wishlists WHERE token = ? AND done = 0 ORDER BY priority ASC, created_at DESC',
        req.userToken
      );
      const gifts = recommendGifts({ prefs, nextAnniversary, wishes });
      res.json({ gifts, occasion: nextAnniversary ? nextAnniversary.title : '平时的小惊喜' });
    } catch (err) {
      next(err);
    }
  });

  router.post('/gifts/favorite', async (req, res, next) => {
    try {
      const b = req.body;
      if (!v.isPlainObject(b)) return res.status(400).json({ error: 'invalid_request', detail: 'body 必须是对象' });
      if (!v.isNonEmptyStr(b.name, 100)) return res.status(400).json({ error: 'invalid_request', detail: 'name 不能为空且不超过 100 字' });
      if (b.reason !== undefined && !v.isStr(b.reason, 500)) return res.status(400).json({ error: 'invalid_request', detail: 'reason 不超过 500 字' });
      if (b.occasion !== undefined && !v.isStr(b.occasion, 100)) return res.status(400).json({ error: 'invalid_request', detail: 'occasion 不超过 100 字' });
      if (b.budget !== undefined && !v.isStr(b.budget, 50)) return res.status(400).json({ error: 'invalid_request', detail: 'budget 不超过 50 字' });
      await ensureUser(req.userToken);
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO gift_favorites (token, name, reason, occasion, budget, created_at)
         VALUES (?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.name.trim(), b.reason || '', b.occasion || '', b.budget || '', now
      );
      const row = await db.get('SELECT * FROM gift_favorites WHERE id = ?', created.id);
      res.status(201).json(rowToGiftFavorite(row));
    } catch (err) {
      next(err);
    }
  });

  router.get('/gifts/favorites', async (req, res, next) => {
    try {
      const rows = await db.all(
        'SELECT * FROM gift_favorites WHERE token = ? ORDER BY created_at DESC, id DESC',
        req.userToken
      );
      res.json({ favorites: rows.map(rowToGiftFavorite) });
    } catch (err) {
      next(err);
    }
  });

  router.delete('/gifts/favorites/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM gift_favorites WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createGiftsRouter, rowToGiftFavorite };
