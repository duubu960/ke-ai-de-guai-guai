'use strict';
// 用户状态读写 + 数据备份 / 恢复。
// GET  /api/state  ：返回该用户状态，无数据时给空默认值。
// POST /api/state  ：校验后 upsert（只更新提供的字段）。
// GET  /api/backup  ：导出该用户全部数据（下载用；照片以 base64 随备份走）。
// POST /api/restore ：校验后在事务里替换该用户数据。
const express = require('express');
const { ensureUser } = require('../database/db');
const { validateMemory } = require('./memories');
const { validateAnniversary } = require('./anniversaries');
const { validateWishlist } = require('./wishlists');
const { validatePreference } = require('./preferences');
const { validateLetter } = require('./letters');
const { validateVault } = require('./vault');
const { GAMES } = require('./games');
const { EVENT_TYPES } = require('./events');
const { SURPRISE_KINDS } = require('../services/content');
const { PHOTO_MIME, MAX_PHOTO_BYTES, MAX_PHOTOS_PER_RESTORE } = require('./photos');
const { isDateStr } = require('./validate');

function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}
function isNonNegInt(v) {
  return Number.isInteger(v) && v >= 0;
}
function isStr(v, max) {
  return typeof v === 'string' && v.length <= max;
}

// 校验 state 子集：只校验出现的字段，返回错误字符串，合法返回 null。
function validateState(body) {
  if (!isPlainObject(body)) return 'body must be an object';
  if (body.profile !== undefined) {
    if (!isPlainObject(body.profile)) return 'profile must be an object';
    if (body.profile.name !== undefined && !isStr(body.profile.name, 20)) {
      return 'profile.name too long';
    }
    if (body.profile.likes !== undefined) {
      if (!Array.isArray(body.profile.likes) || body.profile.likes.length > 50) {
        return 'profile.likes invalid';
      }
      for (const like of body.profile.likes) {
        if (!isStr(like, 20)) return 'profile.likes item too long';
      }
    }
  }
  if (
    body.affection !== undefined &&
    (!Number.isInteger(body.affection) || body.affection < 0 || body.affection > 200)
  ) {
    return 'affection must be 0..200';
  }
  if (body.memories !== undefined) {
    if (!Array.isArray(body.memories) || body.memories.length > 200) {
      return 'memories invalid';
    }
    for (const m of body.memories) {
      if (!isPlainObject(m)) return 'memory must be an object';
      if (!isNonNegInt(m.t)) return 'memory.t must be a timestamp';
      if (!isStr(m.title, 100)) return 'memory.title too long';
      if (m.detail !== undefined && !isStr(m.detail, 500)) return 'memory.detail too long';
      if (m.emotion !== undefined && !isStr(m.emotion, 20)) return 'memory.emotion too long';
    }
  }
  if (body.firstMet !== undefined && !isNonNegInt(body.firstMet)) {
    return 'firstMet must be a timestamp';
  }
  if (body.lastVisit !== undefined && !isNonNegInt(body.lastVisit)) {
    return 'lastVisit must be a timestamp';
  }
  if (body.lastTopic !== undefined && !isStr(body.lastTopic, 100)) return 'lastTopic too long';
  if (body.recentReplies !== undefined) {
    if (!Array.isArray(body.recentReplies) || body.recentReplies.length > 20) {
      return 'recentReplies invalid';
    }
    for (const r of body.recentReplies) {
      if (!isStr(r, 500)) return 'recentReplies item too long';
    }
  }
  if (
    body.dailyGiftDate !== undefined &&
    !(body.dailyGiftDate === '' || /^\d{4}-\d{2}-\d{2}$/.test(body.dailyGiftDate))
  ) {
    return 'dailyGiftDate must be YYYY-MM-DD';
  }
  if (body.coins !== undefined && (!Number.isInteger(body.coins) || body.coins < 0)) {
    return 'coins 必须是不小于 0 的整数';
  }
  if (body.meters !== undefined) {
    if (!isPlainObject(body.meters)) return 'meters 必须是一个对象';
    for (const k of ['hunger', 'mood', 'energy']) {
      if (
        body.meters[k] !== undefined &&
        (!Number.isInteger(body.meters[k]) || body.meters[k] < 0 || body.meters[k] > 100)
      ) {
        return `meters.${k} 必须是 0-100 的整数`;
      }
    }
  }
  if (body.hat !== undefined && !isStr(body.hat, 50)) return 'hat 不超过 50 字';
  if (body.seenFaces !== undefined) {
    if (!isPlainObject(body.seenFaces)) return 'seenFaces 必须是一个对象';
    const keys = Object.keys(body.seenFaces);
    if (keys.length > 100) return 'seenFaces 最多 100 项';
    for (const k of keys) {
      if (k.length > 50 || typeof body.seenFaces[k] !== 'boolean') {
        return 'seenFaces 的键不超过 50 字且值必须是布尔值';
      }
    }
  }
  return null;
}

function emptyState() {
  return {
    profile: { name: '', likes: [] },
    affection: 60,
    memories: [],
    firstMet: 0,
    lastVisit: 0,
    lastTopic: '',
    recentReplies: [],
    dailyGiftDate: '',
    coins: 0,
    meters: { hunger: 72, mood: 82, energy: 76 },
    hat: 'bow',
    seenFaces: {},
  };
}

function rowToState(row) {
  const state = emptyState();
  if (!row) return state;
  try {
    if (row.profile_json) {
      const p = JSON.parse(row.profile_json);
      if (isPlainObject(p)) {
        if (typeof p.name === 'string') state.profile.name = p.name;
        if (Array.isArray(p.likes)) state.profile.likes = p.likes;
      }
    }
  } catch (e) {
    // 损坏的 JSON 按默认值处理，不崩溃。
  }
  if (Number.isInteger(row.affection)) state.affection = row.affection;
  try {
    if (row.memories_json) {
      const m = JSON.parse(row.memories_json);
      if (Array.isArray(m)) state.memories = m;
    }
  } catch (e) {
    // 同上。
  }
  if (Number.isInteger(row.first_met)) state.firstMet = row.first_met;
  if (Number.isInteger(row.last_visit)) state.lastVisit = row.last_visit;
  if (typeof row.last_topic === 'string') state.lastTopic = row.last_topic;
  try {
    if (row.recent_replies_json) {
      const r = JSON.parse(row.recent_replies_json);
      if (Array.isArray(r)) state.recentReplies = r;
    }
  } catch (e) {
    // 同上。
  }
  if (typeof row.daily_gift_date === 'string') state.dailyGiftDate = row.daily_gift_date;
  if (Number.isInteger(row.coins)) state.coins = row.coins;
  try {
    if (row.meters_json) {
      const mt = JSON.parse(row.meters_json);
      if (isPlainObject(mt)) {
        for (const k of ['hunger', 'mood', 'energy']) {
          if (Number.isInteger(mt[k])) state.meters[k] = Math.max(0, Math.min(100, mt[k]));
        }
      }
    }
  } catch (e) {
    // 损坏的 JSON 按默认值处理，不崩溃。
  }
  if (typeof row.hat === 'string' && row.hat) state.hat = row.hat;
  try {
    if (row.seen_faces_json) {
      const sf = JSON.parse(row.seen_faces_json);
      if (isPlainObject(sf)) state.seenFaces = sf;
    }
  } catch (e) {
    // 同上。
  }
  return state;
}

function stateToRow(token, state) {
  return {
    token,
    profile_json: JSON.stringify(state.profile || { name: '', likes: [] }),
    affection: state.affection,
    memories_json: JSON.stringify(state.memories || []),
    first_met: state.firstMet || 0,
    last_visit: state.lastVisit || 0,
    last_topic: state.lastTopic || '',
    recent_replies_json: JSON.stringify(state.recentReplies || []),
    daily_gift_date: state.dailyGiftDate || '',
    coins: Number.isInteger(state.coins) ? state.coins : 0,
    meters_json: JSON.stringify(state.meters || { hunger: 72, mood: 82, energy: 76 }),
    hat: typeof state.hat === 'string' ? state.hat : 'bow',
    seen_faces_json: JSON.stringify(state.seenFaces || {}),
    updated_at: Date.now(),
  };
}

// 校验 restore 的 messages 数组。
function validateRestoreMessages(messages) {
  if (!Array.isArray(messages) || messages.length > 5000) return false;
  const roles = new Set(['system', 'user', 'assistant']);
  for (const m of messages) {
    if (!isPlainObject(m)) return false;
    if (!roles.has(m.role)) return false;
    if (typeof m.content !== 'string' || m.content.trim().length < 1 || m.content.length > 4000) {
      return false;
    }
    if (m.created_at !== undefined && !isNonNegInt(m.created_at)) return false;
  }
  return true;
}

// 备份/恢复用：其余表的行校验（备份导出的是数据库原始行，snake_case）。
function validateSurpriseRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (!isDateStr(r.date)) return 'date 必须是 YYYY-MM-DD';
  if (!SURPRISE_KINDS.includes(r.kind)) return 'kind 不合法';
  if (typeof r.title !== 'string' || !r.title.trim() || r.title.length > 200) return 'title 不合法';
  if (!isStr(r.content, 2000)) return 'content 不合法';
  if (r.source !== 'ai' && r.source !== 'offline') return 'source 不合法';
  if (r.favorite !== undefined && r.favorite !== 0 && r.favorite !== 1) return 'favorite 不合法';
  return null;
}
function validateGameRecordRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (!GAMES.has(r.game)) return 'game 不合法';
  if (!isNonNegInt(r.score) || r.score > 1000000) return 'score 不合法';
  if (!isNonNegInt(r.coins) || r.coins > 30) return 'coins 不合法';
  if (!isNonNegInt(r.played_at)) return 'played_at 不合法';
  return null;
}
function validateDailyReportRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (!isDateStr(r.date)) return 'date 不合法';
  if (!isStr(r.summary, 10000)) return 'summary 不合法';
  if (!isStr(r.data_json, 200000)) return 'data_json 不合法';
  try {
    JSON.parse(r.data_json || '{}');
  } catch (e) {
    return 'data_json 必须是合法 JSON';
  }
  return null;
}
function validateUserSettingRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (typeof r.key !== 'string' || !r.key.trim() || r.key.length > 100) return 'key 不合法';
  if (typeof r.value !== 'string' || r.value.length > 5000) return 'value 不合法';
  return null;
}
function validateEventRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (!EVENT_TYPES.has(r.type)) return 'type 不合法';
  if (r.detail !== undefined && !isStr(r.detail, 500)) return 'detail 不合法';
  if (!isNonNegInt(r.created_at)) return 'created_at 不合法';
  return null;
}
function validateGiftFavoriteRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (typeof r.name !== 'string' || !r.name.trim() || r.name.length > 100) return 'name 不合法';
  if (r.reason !== undefined && !isStr(r.reason, 500)) return 'reason 不合法';
  if (r.occasion !== undefined && !isStr(r.occasion, 100)) return 'occasion 不合法';
  if (r.budget !== undefined && !isStr(r.budget, 50)) return 'budget 不合法';
  return null;
}
// 照片行校验（备份里的照片是 base64 字符串，不是二进制）。
function validatePhotoRow(r) {
  if (!isPlainObject(r)) return '必须是对象';
  if (typeof r.filename !== 'string' || !/^[0-9a-f-]+\.(jpg|png|webp)$/i.test(r.filename)) {
    return 'filename 不合法';
  }
  if (typeof r.mime !== 'string' || !PHOTO_MIME[r.mime]) return 'mime 不合法';
  if (!isNonNegInt(r.size) || r.size === 0 || r.size > MAX_PHOTO_BYTES) return 'size 不合法';
  if (typeof r.data !== 'string' || r.data.length === 0 || r.data.length > 7000000) {
    return 'data 不合法';
  }
  if (!/^[A-Za-z0-9+/=]+$/.test(r.data)) return 'data 不是合法 base64';
  let buf;
  try {
    buf = Buffer.from(r.data, 'base64');
  } catch (e) {
    return 'data 不是合法 base64';
  }
  if (buf.length !== r.size) return 'data 与 size 对不上';
  if (r.created_at !== undefined && !isNonNegInt(r.created_at)) return 'created_at 不合法';
  return null;
}
// 校验一组恢复行：不存在时返回 null（表示该表不替换）；非法时返回错误信息。
function validateRows(rows, fn, name) {
  if (rows === undefined) return null;
  if (!Array.isArray(rows) || rows.length > 5000) return `${name} 必须是数组且不超过 5000 条`;
  for (const r of rows) {
    const err = fn(r);
    if (err) return `${name}: ${err}`;
  }
  return null;
}

function createStateRouter(db) {
  const router = express.Router();

  router.get('/state', async (req, res, next) => {
    try {
      await ensureUser(req.userToken);
      const row = await db.get('SELECT * FROM user_state WHERE token = ?', req.userToken);
      res.json(rowToState(row));
    } catch (err) {
      next(err);
    }
  });

  router.post('/state', async (req, res, next) => {
    try {
      const errMsg = validateState(req.body);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const row = await db.get('SELECT * FROM user_state WHERE token = ?', req.userToken);
      // 只更新提供的字段，其余保留原值；profile / meters 按子字段合并（避免局部更新丢字段）。
      const current = rowToState(row);
      const merged = Object.assign({}, current, req.body);
      if (req.body.profile) merged.profile = Object.assign({}, current.profile, req.body.profile);
      if (req.body.meters) merged.meters = Object.assign({}, current.meters, req.body.meters);
      const r = stateToRow(req.userToken, merged);
      await db.run(
        `INSERT INTO user_state
           (token, profile_json, affection, memories_json, first_met, last_visit, last_topic, recent_replies_json, daily_gift_date, coins, meters_json, hat, seen_faces_json, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(token) DO UPDATE SET
           profile_json = excluded.profile_json,
           affection = excluded.affection,
           memories_json = excluded.memories_json,
           first_met = excluded.first_met,
           last_visit = excluded.last_visit,
           last_topic = excluded.last_topic,
           recent_replies_json = excluded.recent_replies_json,
           daily_gift_date = excluded.daily_gift_date,
           coins = excluded.coins,
           meters_json = excluded.meters_json,
           hat = excluded.hat,
           seen_faces_json = excluded.seen_faces_json,
           updated_at = excluded.updated_at`,
        r.token,
        r.profile_json,
        r.affection,
        r.memories_json,
        r.first_met,
        r.last_visit,
        r.last_topic,
        r.recent_replies_json,
        r.daily_gift_date,
        r.coins,
        r.meters_json,
        r.hat,
        r.seen_faces_json,
        r.updated_at
      );
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  router.get('/backup', async (req, res, next) => {
    try {
      await ensureUser(req.userToken);
      const row = await db.get('SELECT * FROM user_state WHERE token = ?', req.userToken);
      const messages = await db.all(
        'SELECT role, content, created_at FROM messages WHERE token = ? ORDER BY created_at ASC, id ASC',
        req.userToken
      );
      const all = (table) =>
        db.all(`SELECT * FROM ${table} WHERE token = ? ORDER BY id ASC`, req.userToken);
      const photoRows = await all('photos');
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader(
        'Content-Disposition',
        'attachment; filename="ke-ai-de-guai-guai-backup.json"'
      );
      res.json({
        exportedAt: new Date().toISOString(),
        token: req.userToken,
        state: rowToState(row),
        messages,
        memories: await all('memories'),
        anniversaries: await all('anniversaries'),
        wishlists: await all('wishlists'),
        daily_surprises: await all('daily_surprises'),
        surprise_history: await all('surprise_history'),
        preferences: await all('preferences'),
        game_records: await all('game_records'),
        daily_reports: await all('daily_reports'),
        letters: await all('letters'),
        vault_items: await all('vault_items'), // 只含密文（服务器本来就只存密文）
        user_settings: await all('user_settings'),
        events: await all('events'),
        gift_favorites: await all('gift_favorites'),
        photos: photoRows.map((p) => ({
          filename: p.filename,
          mime: p.mime,
          size: p.size,
          created_at: p.created_at,
          data: Buffer.from(p.data).toString('base64'),
        })),
      });
    } catch (err) {
      next(err);
    }
  });

  router.post('/restore', async (req, res, next) => {
    try {
      const body = req.body || {};
      if (!isPlainObject(body)) {
        return res.status(400).json({ error: 'invalid_request' });
      }
      if (body.state !== undefined) {
        const errMsg = validateState(body.state);
        if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      }
      if (body.messages !== undefined && !validateRestoreMessages(body.messages)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'messages invalid' });
      }
      // 先校验全部新表：任一非法即拒绝，不碰数据库。
      const sections = [
        { key: 'memories', fn: (r) => validateMemory(r, false) },
        { key: 'anniversaries', fn: (r) => validateAnniversary(r, false) },
        { key: 'wishlists', fn: (r) => validateWishlist(r, false) },
        { key: 'daily_surprises', fn: validateSurpriseRow },
        { key: 'surprise_history', fn: validateSurpriseRow },
        { key: 'preferences', fn: (r) => validatePreference(r, false) },
        { key: 'game_records', fn: validateGameRecordRow },
        { key: 'daily_reports', fn: validateDailyReportRow },
        { key: 'letters', fn: (r) => validateLetter(r, false) },
        { key: 'vault_items', fn: validateVault },
        { key: 'user_settings', fn: validateUserSettingRow },
        { key: 'events', fn: validateEventRow },
        { key: 'gift_favorites', fn: validateGiftFavoriteRow },
        { key: 'photos', fn: validatePhotoRow },
      ];
      for (const s of sections) {
        const errMsg = validateRows(body[s.key], s.fn, s.key);
        if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      }
      if (Array.isArray(body.photos) && body.photos.length > MAX_PHOTOS_PER_RESTORE) {
        return res.status(400).json({ error: 'invalid_request', detail: `photos 一次最多 ${MAX_PHOTOS_PER_RESTORE} 张` });
      }
      // 唯一键字段（daily_surprises / daily_reports 的 date、user_settings 的 key、photos 的 filename）不能重复。
      for (const u of [
        { key: 'daily_surprises', field: 'date' },
        { key: 'daily_reports', field: 'date' },
        { key: 'user_settings', field: 'key' },
        { key: 'photos', field: 'filename' },
      ]) {
        const rows = body[u.key];
        if (Array.isArray(rows)) {
          const seen = new Set();
          for (const r of rows) {
            if (seen.has(r[u.field])) {
              return res.status(400).json({ error: 'invalid_request', detail: `${u.key} 里 ${u.field} 重复` });
            }
            seen.add(r[u.field]);
          }
        }
      }
      await ensureUser(req.userToken);
      // 事务内替换该用户的数据：失败则整体回滚。
      const imported = await db.tx(async (t) => {
        await t.run('DELETE FROM user_state WHERE token = ?', req.userToken);
        if (body.state !== undefined) {
          const merged = Object.assign(emptyState(), body.state);
          const r = stateToRow(req.userToken, merged);
          await t.run(
            `INSERT INTO user_state
               (token, profile_json, affection, memories_json, first_met, last_visit, last_topic, recent_replies_json, daily_gift_date, coins, meters_json, hat, seen_faces_json, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            r.token,
            r.profile_json,
            r.affection,
            r.memories_json,
            r.first_met,
            r.last_visit,
            r.last_topic,
            r.recent_replies_json,
            r.daily_gift_date,
            r.coins,
            r.meters_json,
            r.hat,
            r.seen_faces_json,
            r.updated_at
          );
        }
        await t.run('DELETE FROM messages WHERE token = ?', req.userToken);
        const counts = { messages: 0 };
        if (Array.isArray(body.messages)) {
          for (const m of body.messages) {
            await t.run(
              'INSERT INTO messages (token, role, content, created_at) VALUES (?, ?, ?, ?)',
              req.userToken, m.role, m.content, m.created_at || Date.now()
            );
            counts.messages += 1;
          }
        }
        // 通用替换：删掉该 token 的旧行，再按备份逐条插入（不复用备份里的 id）。
        const put = async (table, rows, cols, map) => {
          await t.run(`DELETE FROM ${table} WHERE token = ?`, req.userToken);
          if (!Array.isArray(rows)) return 0;
          const sql =
            `INSERT INTO ${table} (token, ${cols.join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`;
          for (const r of rows) await t.run(sql, req.userToken, ...map(r));
          return rows.length;
        };
        const now = Date.now();
        counts.memories = await put('memories', body.memories,
          ['title', 'date', 'location', 'description', 'category', 'photo_url', 'favorite', 'created_at', 'updated_at'],
          (r) => [r.title, r.date, r.location || '', r.description || '', r.category || '', r.photo_url || '', r.favorite ? 1 : 0, now, now]);
        counts.anniversaries = await put('anniversaries', body.anniversaries,
          ['title', 'date', 'type', 'note', 'created_at', 'updated_at'],
          (r) => [r.title, r.date, r.type || 'custom', r.note || '', now, now]);
        counts.wishlists = await put('wishlists', body.wishlists,
          ['title', 'category', 'priority', 'note', 'photo_url', 'done', 'completed_at', 'created_at', 'updated_at'],
          (r) => [r.title, r.category || '', r.priority || 2, r.note || '', r.photo_url || '', r.done ? 1 : 0, r.completed_at || null, now, now]);
        counts.daily_surprises = await put('daily_surprises', body.daily_surprises,
          ['date', 'kind', 'title', 'content', 'source', 'favorite', 'created_at'],
          (r) => [r.date, r.kind, r.title, r.content, r.source || 'offline', r.favorite ? 1 : 0, now]);
        counts.surprise_history = await put('surprise_history', body.surprise_history,
          ['date', 'kind', 'title', 'content', 'source', 'favorite', 'created_at'],
          (r) => [r.date, r.kind, r.title, r.content, r.source || 'offline', r.favorite ? 1 : 0, now]);
        counts.preferences = await put('preferences', body.preferences,
          ['category', 'value', 'confirmed', 'source', 'created_at', 'updated_at'],
          (r) => [r.category, r.value, r.confirmed ? 1 : 0, r.source || 'manual', now, now]);
        counts.game_records = await put('game_records', body.game_records,
          ['game', 'score', 'coins', 'played_at', 'created_at'],
          (r) => [r.game, r.score, r.coins, r.played_at || now, now]);
        counts.daily_reports = await put('daily_reports', body.daily_reports,
          ['date', 'summary', 'data_json', 'created_at'],
          (r) => [r.date, r.summary || '', r.data_json || '{}', now]);
        counts.letters = await put('letters', body.letters,
          ['title', 'content', 'occasion_date', 'favorite', 'status', 'created_at', 'updated_at'],
          (r) => [r.title, r.content, r.occasion_date || '', r.favorite ? 1 : 0, r.status || 'draft', now, now]);
        counts.vault_items = await put('vault_items', body.vault_items,
          ['blob', 'iv', 'salt', 'created_at', 'updated_at'],
          (r) => [r.blob, r.iv, r.salt, now, now]);
        counts.user_settings = await put('user_settings', body.user_settings,
          ['key', 'value', 'created_at', 'updated_at'],
          (r) => [r.key, r.value || '', now, now]);
        counts.events = await put('events', body.events,
          ['type', 'detail', 'created_at'],
          (r) => [r.type, r.detail || '', r.created_at || now]);
        counts.gift_favorites = await put('gift_favorites', body.gift_favorites,
          ['name', 'reason', 'occasion', 'budget', 'created_at'],
          (r) => [r.name, r.reason || '', r.occasion || '', r.budget || '', now]);
        counts.photos = await put('photos', body.photos,
          ['filename', 'mime', 'data', 'size', 'created_at'],
          (r) => [r.filename, r.mime, Buffer.from(r.data, 'base64'), r.size, r.created_at || now]);
        return counts;
      });
      res.json({ ok: true, imported });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createStateRouter, validateState, emptyState, rowToState };
