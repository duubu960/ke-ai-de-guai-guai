'use strict';
// 回忆时光机：GET /api/memories（?month=YYYY-MM、?q=、?favorite=）
// POST / GET /:id / PUT /:id / DELETE /:id
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

function rowToMemory(r) {
  return {
    id: r.id,
    title: r.title,
    date: r.date,
    location: r.location || '',
    description: r.description || '',
    category: r.category || '',
    photoUrl: r.photo_url || '',
    favorite: r.favorite === 1,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

// 新建/更新的共用校验。isUpdate=true 时只校验出现的字段。
function validateMemory(body, isUpdate) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  const need = (field) => !isUpdate || body[field] !== undefined;
  if (need('title')) {
    if (!v.isNonEmptyStr(body.title, 100)) return 'title 不能为空且不超过 100 字';
  }
  if (need('date')) {
    if (!v.isDateStr(body.date)) return 'date 必须是 YYYY-MM-DD';
  }
  if (body.location !== undefined && !v.isOptStr(body.location, 100)) return 'location 不超过 100 字';
  if (body.description !== undefined && !v.isOptStr(body.description, 2000)) return 'description 不超过 2000 字';
  if (body.category !== undefined && !v.isOptStr(body.category, 20)) return 'category 不超过 20 字';
  if (body.photo_url !== undefined && !v.isOptStr(body.photo_url, 500)) return 'photo_url 不超过 500 字';
  if (body.photoUrl !== undefined && !v.isOptStr(body.photoUrl, 500)) return 'photoUrl 不超过 500 字';
  if (body.favorite !== undefined && v.toBool(body.favorite) === null) return 'favorite 必须是布尔值';
  return null;
}

function createMemoriesRouter(db) {
  const router = express.Router();

  router.get('/memories', async (req, res, next) => {
    try {
      const { month, q, favorite } = req.query;
      if (month !== undefined && !v.isMonthStr(month)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'month 必须是 YYYY-MM' });
      }
      if (favorite !== undefined && favorite !== '0' && favorite !== '1') {
        return res.status(400).json({ error: 'invalid_request', detail: 'favorite 必须是 0 或 1' });
      }
      if (q !== undefined && typeof q !== 'string') {
        return res.status(400).json({ error: 'invalid_request', detail: 'q 必须是字符串' });
      }
      let sql = 'SELECT * FROM memories WHERE token = ?';
      const params = [req.userToken];
      if (month) {
        sql += ' AND substr(date, 1, 7) = ?';
        params.push(month);
      }
      if (favorite !== undefined) {
        sql += ' AND favorite = ?';
        params.push(Number(favorite));
      }
      if (q) {
        // LOWER() 两边都包：SQLite 的 LIKE 对 ASCII 本来就不区分大小写，
        // PostgreSQL 的 LIKE 区分；这样写两种数据库行为一致。
        sql += ' AND (LOWER(title) LIKE LOWER(?) OR LOWER(description) LIKE LOWER(?) OR LOWER(location) LIKE LOWER(?))';
        const like = `%${q}%`;
        params.push(like, like, like);
      }
      sql += ' ORDER BY date DESC, id DESC';
      const rows = await db.all(sql, ...params);
      res.json({ memories: rows.map(rowToMemory) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/memories', async (req, res, next) => {
    try {
      const errMsg = validateMemory(req.body, false);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const b = req.body;
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO memories (token, title, date, location, description, category, photo_url, favorite, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken,
        b.title.trim(),
        b.date,
        b.location || '',
        b.description || '',
        b.category || '',
        b.photoUrl || b.photo_url || '',
        v.toBool(b.favorite) === 1 ? 1 : 0,
        now,
        now
      );
      const row = await db.get('SELECT * FROM memories WHERE id = ?', created.id);
      res.status(201).json(rowToMemory(row));
    } catch (err) {
      next(err);
    }
  });

  router.get('/memories/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get('SELECT * FROM memories WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      res.json(rowToMemory(row));
    } catch (err) {
      next(err);
    }
  });

  router.put('/memories/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validateMemory(req.body, true);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM memories WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      const b = req.body;
      const merged = {
        title: b.title !== undefined ? b.title.trim() : row.title,
        date: b.date !== undefined ? b.date : row.date,
        location: b.location !== undefined ? b.location : row.location,
        description: b.description !== undefined ? b.description : row.description,
        category: b.category !== undefined ? b.category : row.category,
        photo_url: b.photoUrl !== undefined ? b.photoUrl : b.photo_url !== undefined ? b.photo_url : row.photo_url,
        favorite: b.favorite !== undefined ? v.toBool(b.favorite) : row.favorite,
      };
      await db.run(
        `UPDATE memories SET title = ?, date = ?, location = ?, description = ?, category = ?, photo_url = ?, favorite = ?, updated_at = ? WHERE id = ? AND token = ?`,
        merged.title, merged.date, merged.location, merged.description, merged.category,
        merged.photo_url, merged.favorite, Date.now(), id, req.userToken
      );
      const updated = await db.get('SELECT * FROM memories WHERE id = ?', id);
      res.json(rowToMemory(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/memories/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM memories WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createMemoriesRouter, validateMemory, rowToMemory };
