'use strict';
// 每日情侣报告：GET /api/reports/today、GET /api/reports?date=YYYY-MM-DD
// 全部数字来自 messages / events / wishlists / daily_surprises 的真实数据，
// 无数据时返回 {hasData:false}，不编。AI 总结有 Key 时调 DeepSeek，
// 无 Key 时用模板并标注 source:"offline"。结果会缓存进 daily_reports。
const express = require('express');
const { chatWithDeepSeek } = require('../services/deepseek');
const { offlineReportSummary } = require('../services/content');
const v = require('./validate');

async function computeReport(db, token, date) {
  const [start, end] = v.dayRange(date);
  const chatRow = await db.get(
    "SELECT COUNT(*) AS n FROM messages WHERE token = ? AND role = 'user' AND created_at >= ? AND created_at < ?",
    token, start, end
  );
  const chatCount = chatRow.n || 0;
  const evRow = await db.get(
    'SELECT COUNT(*) AS n FROM events WHERE token = ? AND created_at >= ? AND created_at < ?',
    token, start, end
  );
  const interactionCount = evRow.n || 0;
  const doneWishes = await db.all(
    'SELECT id, title FROM wishlists WHERE token = ? AND done = 1 AND completed_at >= ? AND completed_at < ? ORDER BY completed_at ASC',
    token, start, end
  );
  const surprise = await db.get(
    'SELECT * FROM daily_surprises WHERE token = ? AND date = ?',
    token, date
  );
  const moodRow = await db.get(
    "SELECT detail FROM events WHERE token = ? AND type = 'mood' AND created_at >= ? AND created_at < ? ORDER BY created_at DESC LIMIT 1",
    token, start, end
  );
  const longest = await db.get(
    "SELECT content FROM messages WHERE token = ? AND role = 'assistant' AND created_at >= ? AND created_at < ? ORDER BY LENGTH(content) DESC LIMIT 1",
    token, start, end
  );

  const hasData =
    chatCount > 0 || interactionCount > 0 || doneWishes.length > 0 || !!surprise;
  const highlights = [];
  if (surprise) highlights.push({ type: 'surprise', text: `${surprise.title}：${surprise.content}` });
  for (const w of doneWishes) highlights.push({ type: 'wish', text: `完成了心愿「${w.title}」` });
  if (longest && longest.content) {
    highlights.push({ type: 'quote', text: String(longest.content).slice(0, 200) });
  }
  return {
    date,
    hasData,
    chatCount,
    interactionCount,
    wishesCompleted: doneWishes.length,
    completedWishes: doneWishes.map((w) => w.title),
    surprise: surprise
      ? { kind: surprise.kind, title: surprise.title, content: surprise.content, source: surprise.source }
      : null,
    mood: moodRow ? moodRow.detail || null : null,
    highlights,
  };
}

function createReportsRouter(db, config) {
  const router = express.Router();

  async function handleReport(req, res, next, date) {
    try {
      const stats = await computeReport(db, req.userToken, date);
      if (!stats.hasData) return res.json({ date, hasData: false });
      let summary;
      let source = 'offline';
      if (config.getApiKey()) {
        try {
          const result = await chatWithDeepSeek({
            apiKey: config.getApiKey(),
            model: config.model,
            messages: [
              {
                role: 'system',
                content:
                  '你是可爱的乖乖，一只粉色小猪，宝宝的 AI 小男友。用温柔、可爱、不肉麻的语气写一段 2-3 句的当日小结，可以带一句傲娇的关心，只能用下面给出的真实数字，不编造任何没有发生的事，不自称真人。',
              },
              {
                role: 'user',
                content:
                  `今天宝宝和乖乖说了 ${stats.chatCount} 句话，互动了 ${stats.interactionCount} 次，完成了 ${stats.wishesCompleted} 个心愿。` +
                  (stats.surprise ? `打开了盲盒「${stats.surprise.title}」。` : '没有开盲盒。') +
                  (stats.mood ? `今天的心情是「${stats.mood}」。` : ''),
              },
            ],
          });
          summary = String(result.reply || '').trim();
          if (summary) source = 'ai';
        } catch (e) {
          // 回落模板。
        }
      }
      if (!summary) {
        summary = offlineReportSummary({
          chatCount: stats.chatCount,
          interactionCount: stats.interactionCount,
          wishesCompleted: stats.wishesCompleted,
          surpriseTitle: stats.surprise ? stats.surprise.title : '',
          mood: stats.mood,
        });
        source = 'offline';
      }
      // 缓存进 daily_reports（同一天重复生成会覆盖）。
      await db.run(
        `INSERT INTO daily_reports (token, date, summary, data_json, created_at)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(token, date) DO UPDATE SET summary = excluded.summary, data_json = excluded.data_json`,
        req.userToken, date, summary, JSON.stringify(stats), Date.now()
      );
      res.json(Object.assign({}, stats, { summary, source }));
    } catch (err) {
      next(err);
    }
  }

  router.get('/reports/today', (req, res, next) => handleReport(req, res, next, v.todayStr()));

  router.get('/reports', (req, res, next) => {
    const date = req.query.date;
    if (typeof date !== 'string' || !v.isDateStr(date)) {
      return res.status(400).json({ error: 'invalid_request', detail: 'date 必须是 YYYY-MM-DD' });
    }
    handleReport(req, res, next, date);
  });

  return router;
}

module.exports = { createReportsRouter, computeReport };
