'use strict';
// 事件日志：POST /api/events {type, detail?}（前端日志，失败静默由前端处理）。
// type 枚举：chat / interact / game / surprise / wishlist_done / mood / sleep / voice / other。
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

const EVENT_TYPES = new Set([
  'chat',
  'interact',
  'game',
  'surprise',
  'wishlist_done',
  'mood',
  'sleep',
  'voice',
  'emotion_open',
  'emotion_select',
  'emotion_quiet',
  'emotion_vent',
  'gift_favorite',
  'letter_saved',
  'memory_saved',
  'other',
]);

function createEventsRouter(db) {
  const router = express.Router();

  router.post('/events', async (req, res, next) => {
    try {
      const b = req.body;
      if (!v.isPlainObject(b)) return res.status(400).json({ error: 'invalid_request', detail: 'body 必须是对象' });
      if (!EVENT_TYPES.has(b.type)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'type 必须是已知事件类型之一' });
      }
      if (b.detail !== undefined && !v.isStr(b.detail, 500)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'detail 不超过 500 字' });
      }
      await ensureUser(req.userToken);
      const now = Date.now();
      const created = await db.get(
        'INSERT INTO events (token, type, detail, created_at) VALUES (?, ?, ?, ?) RETURNING id',
        req.userToken, b.type, b.detail || '', now
      );
      res.status(201).json({ ok: true, id: Number(created.id) });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createEventsRouter, EVENT_TYPES };
