'use strict';
// GET /api/health：只报告 DeepSeek 是否已配置，绝不返回 Key。
const express = require('express');

function createHealthRouter(config) {
  const router = express.Router();

  router.get('/health', (req, res) => {
    res.json({
      ok: true,
      deepseek: config.getApiKey() ? 'configured' : 'missing',
      model: config.model,
      time: new Date().toISOString(),
    });
  });

  return router;
}

module.exports = { createHealthRouter };
