'use strict';
// 喜好档案：CRUD + 待确认列表 + 文本提取（只返回候选，不自动保存）。
// 手动添加的喜好默认 confirmed=1；AI 提取的候选需用户确认后才保存。
const express = require('express');
const { ensureUser } = require('../database/db');
const { chatWithDeepSeek } = require('../services/deepseek');
const { PREF_CATEGORIES, extractPreferences } = require('../services/content');
const v = require('./validate');

function rowToPreference(r) {
  return {
    id: r.id,
    category: r.category,
    value: r.value,
    confirmed: r.confirmed === 1,
    source: r.source,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function validatePreference(body, isUpdate) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  const need = (f) => !isUpdate || body[f] !== undefined;
  if (need('category') && !PREF_CATEGORIES.includes(body.category)) {
    return 'category 必须是 food/drink/color/animal/music/movie/gift/activity/dislike/date';
  }
  if (need('value') && !v.isNonEmptyStr(body.value, 20)) return 'value 不能为空且不超过 20 字';
  if (body.source !== undefined && body.source !== 'manual' && body.source !== 'ai') {
    return 'source 必须是 manual 或 ai';
  }
  if (body.confirmed !== undefined && v.toBool(body.confirmed) === null) {
    return 'confirmed 必须是布尔值';
  }
  return null;
}

function createPreferencesRouter(db, config) {
  const router = express.Router();

  router.get('/preferences/pending', async (req, res, next) => {
    try {
      const rows = await db.all(
        'SELECT * FROM preferences WHERE token = ? AND confirmed = 0 ORDER BY created_at DESC',
        req.userToken
      );
      res.json({ preferences: rows.map(rowToPreference) });
    } catch (err) {
      next(err);
    }
  });

  router.get('/preferences', async (req, res, next) => {
    try {
      const { category } = req.query;
      if (category !== undefined && !PREF_CATEGORIES.includes(category)) {
        return res.status(400).json({ error: 'invalid_request', detail: 'category 不合法' });
      }
      let sql = 'SELECT * FROM preferences WHERE token = ?';
      const params = [req.userToken];
      if (category) {
        sql += ' AND category = ?';
        params.push(category);
      }
      sql += ' ORDER BY category ASC, created_at ASC';
      const rows = await db.all(sql, ...params);
      res.json({ preferences: rows.map(rowToPreference) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/preferences', async (req, res, next) => {
    try {
      const errMsg = validatePreference(req.body, false);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const b = req.body;
      const source = b.source || 'manual';
      const confirmed = source === 'manual' ? 1 : v.toBool(b.confirmed) === 1 ? 1 : 0;
      const dup = await db.get(
        'SELECT * FROM preferences WHERE token = ? AND category = ? AND value = ?',
        req.userToken, b.category, b.value.trim()
      );
      if (dup) return res.status(200).json(rowToPreference(dup));
      const now = Date.now();
      const created = await db.get(
        `INSERT INTO preferences (token, category, value, confirmed, source, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING id`,
        req.userToken, b.category, b.value.trim(), confirmed, source, now, now
      );
      const row = await db.get('SELECT * FROM preferences WHERE id = ?', created.id);
      res.status(201).json(rowToPreference(row));
    } catch (err) {
      next(err);
    }
  });

  // 从聊天文本提取可能的喜好：只返回候选清单，不自动保存。
  // 规则提取为主；有 Key 时再用 DeepSeek 辅助提一遍（失败则只用规则结果）。
  router.post('/preferences/extract', async (req, res, next) => {
    try {
      const text = req.body && req.body.text;
      if (typeof text !== 'string' || text.trim().length < 1 || text.length > 4000) {
        return res.status(400).json({ error: 'invalid_request', detail: 'text 不能为空且不超过 4000 字' });
      }
      const candidates = extractPreferences(text);
      const seen = new Set(candidates.map((c) => `${c.category}:${c.value}`));
      if (config.getApiKey()) {
        try {
          const result = await chatWithDeepSeek({
            apiKey: config.getApiKey(),
            model: config.model,
            messages: [
              {
                role: 'system',
                content:
                  '从用户的话里提取她可能喜欢的东西，只输出 JSON 数组，格式 [{"category":"food|drink|color|animal|music|movie|gift|activity|dislike|date","value":"..."}]，每个 value 不超过 20 字，没有就输出 []。不要输出任何解释。',
              },
              { role: 'user', content: text },
            ],
          });
          const parsed = JSON.parse(String(result.reply || '').trim());
          if (Array.isArray(parsed)) {
            for (const item of parsed) {
              if (
                item &&
                PREF_CATEGORIES.includes(item.category) &&
                typeof item.value === 'string' &&
                item.value.trim().length > 0 &&
                item.value.trim().length <= 20
              ) {
                const key = `${item.category}:${item.value.trim()}`;
                if (!seen.has(key)) {
                  seen.add(key);
                  candidates.push({ category: item.category, value: item.value.trim(), source: 'ai' });
                }
              }
            }
          }
        } catch (e) {
          // DeepSeek 失败不影响规则提取结果。
        }
      }
      // 候选只是“待确认”，一律 confirmed:false——前端需用户确认后才保存。
      res.json({ candidates: candidates.slice(0, 10).map((c) => ({ ...c, confirmed: false })) });
    } catch (err) {
      next(err);
    }
  });

  router.put('/preferences/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validatePreference(req.body, true);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM preferences WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      const b = req.body;
      await db.run(
        `UPDATE preferences SET category = ?, value = ?, confirmed = ?, source = ?, updated_at = ? WHERE id = ? AND token = ?`,
        b.category !== undefined ? b.category : row.category,
        b.value !== undefined ? b.value.trim() : row.value,
        b.confirmed !== undefined ? v.toBool(b.confirmed) : row.confirmed,
        b.source !== undefined ? b.source : row.source,
        Date.now(),
        id,
        req.userToken
      );
      const updated = await db.get('SELECT * FROM preferences WHERE id = ?', id);
      res.json(rowToPreference(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/preferences/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM preferences WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createPreferencesRouter, validatePreference, rowToPreference };
