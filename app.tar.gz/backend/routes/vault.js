'use strict';
// 隐私保险箱：只存密文（blob / iv / salt），服务器永远不收密码，
// 不提供任何“找回密码”接口——忘密码=无法解密，需由前端如实提示。
// blob 是前端用 WebCrypto AES-GCM 加密后的 base64，iv/salt 同为 base64。
const express = require('express');
const { ensureUser } = require('../database/db');
const v = require('./validate');

function rowToVaultItem(r) {
  return {
    id: r.id,
    blob: r.blob,
    iv: r.iv,
    salt: r.salt,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

// 密文校验：三者都必须是字符串；blob 上限 200000 字符（约 150KB 明文），
// iv/salt 上限 200 字符。body 里出现 password/key 一律拒绝。
function validateVault(body) {
  if (!v.isPlainObject(body)) return 'body must be an object';
  if ('password' in body || 'key' in body) return '服务器不接收密码或密钥';
  if (!v.isNonEmptyStr(body.blob, 200000)) return 'blob 不能为空且不超过 200000 字符';
  if (!v.isNonEmptyStr(body.iv, 200)) return 'iv 不能为空且不超过 200 字符';
  if (!v.isNonEmptyStr(body.salt, 200)) return 'salt 不能为空且不超过 200 字符';
  return null;
}

function createVaultRouter(db) {
  const router = express.Router();

  router.get('/vault/items', async (req, res, next) => {
    try {
      const rows = await db.all(
        'SELECT * FROM vault_items WHERE token = ? ORDER BY created_at DESC, id DESC',
        req.userToken
      );
      res.json({ items: rows.map(rowToVaultItem) });
    } catch (err) {
      next(err);
    }
  });

  router.post('/vault/items', async (req, res, next) => {
    try {
      const errMsg = validateVault(req.body);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      await ensureUser(req.userToken);
      const now = Date.now();
      const created = await db.get(
        'INSERT INTO vault_items (token, blob, iv, salt, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?) RETURNING id',
        req.userToken, req.body.blob, req.body.iv, req.body.salt, now, now
      );
      const row = await db.get('SELECT * FROM vault_items WHERE id = ?', created.id);
      res.status(201).json(rowToVaultItem(row));
    } catch (err) {
      next(err);
    }
  });

  router.get('/vault/items/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const row = await db.get('SELECT * FROM vault_items WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      res.json(rowToVaultItem(row));
    } catch (err) {
      next(err);
    }
  });

  router.put('/vault/items/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const errMsg = validateVault(req.body);
      if (errMsg) return res.status(400).json({ error: 'invalid_request', detail: errMsg });
      const row = await db.get('SELECT * FROM vault_items WHERE id = ? AND token = ?', id, req.userToken);
      if (!row) return res.status(404).json({ error: 'not_found' });
      await db.run(
        'UPDATE vault_items SET blob = ?, iv = ?, salt = ?, updated_at = ? WHERE id = ? AND token = ?',
        req.body.blob, req.body.iv, req.body.salt, Date.now(), id, req.userToken
      );
      const updated = await db.get('SELECT * FROM vault_items WHERE id = ?', id);
      res.json(rowToVaultItem(updated));
    } catch (err) {
      next(err);
    }
  });

  router.delete('/vault/items/:id', async (req, res, next) => {
    try {
      const id = v.parseId(req.params.id);
      if (id === null) return res.status(400).json({ error: 'invalid_request', detail: 'id 必须是正整数' });
      const info = await db.run('DELETE FROM vault_items WHERE id = ? AND token = ?', id, req.userToken);
      if (info.changes === 0) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true });
    } catch (err) {
      next(err);
    }
  });

  return router;
}

module.exports = { createVaultRouter, validateVault, rowToVaultItem };
