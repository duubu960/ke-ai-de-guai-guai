# 可爱的乖乖 v3 — 测试报告（第三阶段）

- 测试日期：2026-11-11
- 测试环境：Node.js v24.22.1、npm 10.9.4、SQLite（Node 内置 `node:sqlite`）、curl、jsdom 31
- 测试范围：后端迁移与新接口、13 个前端模块、导航与桥接、联调、回归（原有功能）
- **结论：全部通过，共 31 + 63 + 31 + 20 + 46 + 32 = 223 项检查，0 失败。**
- **2026-11-11 更新（部署准备 v2.1.0 + 人设修正后重测）**：SQLite 全量 226/226，PostgreSQL 16 本地全量 225/225，0 失败。见 §12。

---

## 1. 后端自测 — `npm test`（scripts/test-backend.js）

31/31 通过，退出码 0。临时端口 + 临时数据库，跑完已清理。含第二阶段的 15 项 + 第三阶段新增 16 项。

新增的 16 项（Phase 3）：
- 迁移幂等：再跑一次不报错、14 张表齐、migrations 只有 1 条记录
- memories CRUD + 按月/搜索/收藏 + 跨 token 隔离
- anniversaries CRUD + summary（无日期时 daysTogether 为 null，不编）
- surprise 每天一次：两次 open 返回同一份（201→200，isNew true→false，同一 id）
- wishlists CRUD + complete + summary
- preferences CRUD + pending + extract 只返回候选、绝不自动保存
- gifts recommend 6 条且无价格/店铺/链接
- games 每日上限：10→再 25 得 409，另一游戏 30 正常，state coins 累计 40
- state 新字段（coins/meters/hat/seenFaces）与 meters 子字段合并
- vault 拒收密码（body 含密码直接 400）
- photos：合法 PNG 可取回、GIF 拒、>5MB 拒
- events 记录与校验（含情绪/礼物收藏/信件/回忆的事件类型）
- letters CRUD + 收藏 + 离线 ai-draft（无 Key 时模板 + source:offline）
- reports today：无数据 hasData:false，有数据时真实计算、缓存一致
- backup 含全部新表、restore 回滚与恢复
- **可选字段的 null 当作“没有”**（wishlists photo_url:null、memories/anniversaries 的 null 字段、letters occasion_date:null）——联调发现的真实问题，已修并加回归测试

## 2. 联调测试 — `bash scripts/test-integration.sh`（curl）

63/63 通过，退出码 0。原第二阶段 25 项（21 + 假 Key 4 项）全过；新增 Phase 3 冒烟 38 项（health、memories、anniversaries summary、surprise 两次同一 id、wishlists、preferences、gifts、games 上限 409、reports、letters、vault、photos、backup、DB 表与迁移记录）。测试用随机端口 + 临时库，跑完清理（DB、照片目录均已清）。

假 Key 验证（原始结果，`DEEPSEEK_API_KEY=sk-test-dummy-key`）：
- `POST /api/letters/ai-draft` → HTTP 200，`source:"offline"`，内容是模板信
- `POST /api/surprise/open {"kind":"ai"}` → HTTP 201，`source:"offline"`，内容是模板惊喜
- 两处均 fallback 到模板并标注 `source:"offline"`，无“AI 生成成功”
- 上游 401 本身在第二阶段的 `/api/chat` 已直接验证（同假 Key，约 1s，返回 401 `deepseek_unauthorized`，未写库）——证明代理确实打到了 DeepSeek 并被拒

## 3. 前端 DOM 冒烟 + 持久化恢复 — `npm run test:dom`（jsdom）

31/31 通过（12 + 12 + 7）。第二阶段的两组 12 项 + 恢复测试 7 项全部通过，Phase 3 的后端改动未影响原有前端。

## 4. 导航与桥接测试 — `scripts/test-shell.js`（jsdom）

20/20 通过。验证：window.GG 桥接存在、setEmotion 往返、5 个导航按钮 + 5 个页面、首页默认激活、称呼是宝宝（无“哥哥”）、导航双向切换、记住上次页面、切页不丢小猪 DOM、点小猪有反应、发消息有回话、零页面 JS 报错。

## 5. B+C 模块联调 — `scripts/test-integration-features.js`（jsdom + 真实服务器）

46/46 通过，退出码 0。真实服务器（随机端口、临时库），13 个模块中的 9 个（盲盒/心愿/喜好/礼物/哄睡/游戏/语音/报告/保险箱）走真实接口端到端，**没有桩**。

逐项（均走真实接口验证）：
- 盲盒：开盒有真实内容、history 只有 1 条、第二次开返回同一份（isNew false）
- 心愿：新建入列表、API 有该条、完成出庆祝、summary done=1
- 喜好：从真实聊天记录提取出候选（芒果、珍珠奶茶）、点确认后进入已确认、服务器 confirmed=true
- 礼物：推荐 6 条渲染、收藏进收藏夹、服务器 favorites 有 1 条
- 游戏：猜数字二分搜索赢下、记录落库、summary 有该局、金币 +10
- 保险箱：设密码→加密保存（服务器端只见密文，blob 里不含明文）→上锁→错密码拒绝→对密码解密出原文→删除
- 报告：渲染真实数字，与 API 的 chatCount 一致
- 哄睡：浮层打开（月亮/星星/小猪）、睡前故事发进首页聊天、退出关闭
- 语音：麦克风按钮存在，不支持时老实提示
- 全程零页面 JS 报错

## 6. A 模块联调 — `scripts/test-integration-features-a.js`（jsdom + 真实服务器）

32/32 通过，退出码 0。真实服务器（随机端口、临时库），回忆/情绪/纪念日/信件 4 个模块走真实接口端到端，**没有桩**。

逐项（均走真实接口验证）：
- 回忆：种子回忆在列表、新建入列表、API 有 2 条、搜索按关键词过滤、收藏落库、删除成功
- 纪念日：daysTogether 真实计算（第一次见面 2026-11-01 → 当天 10 天，与 API summary 一致）、新建入列表、删除成功
- 信件：新建入列表、API 有该条、AI 起草（无 Key）填入离线模板、ai-draft API 的 source 是 offline、收藏落库、删除成功
- 情绪：8 张情绪卡、选“难过”出现温柔开场白、倾诉发进首页聊天、安静陪伴屏出现、退出关闭
- 全程零页面 JS 报错

## 7. 代码与安全检查

- `node --check`：全部新增/修改的 JS 文件通过。
- **Key 已从前端彻底移除**：对 `frontend/` 全文 grep `api.deepseek.com`、`Authorization`、`Bearer `、`sk-`（16 位以上）——**0 处真实 Key**。测试里只用 `sk-test-dummy-key`。钥匙只存在于服务器的 `.env`（本项目没有 `.env`，也没有真实 Key）。
- **照片隔离**：照片存在 `backend/data/photos/<token>/<uuid>.jpg`，文件名是随机 UUID，不可枚举；但静态服务本身不校验 token，URL 本身就是隔离边界——不要把照片 URL 发给外人。
- **保险箱**：服务器只存密文（blob/iv/salt），发送的密文里不含任何明文（联调已验证）；无找回密码接口（设计如此）。
- 13 个模块只写自己的容器、只用 `GG.apiFetch`、只用现有 CSS 变量；无 TODO、无空实现。
- 项目里没有生成数据库文件（测试用的都是 `/tmp` 里的临时库，已删除）；首次真实启动时自动创建 `backend/database/app.sqlite`。

## 8. 联调中发现并修复的真实问题（7 个）

1. **礼物推荐永远空**（`gifts.js`）：模块的 `asList` 只认 `recommendations`，后端返回的是 `{gifts: [...]}`，导致推荐列表永远显示“没有合适的推荐”。已补 `gifts` 键；**心愿的 AI 建议也有同样问题**（它也调 `/api/gifts/recommend`），一并补了。
2. **无照片的心愿保存失败**（后端 `validateWishlist`）：模块发 `photo_url: null`，后端校验把 null 当非法值拒了（400）。已加 `isOptStr`（null/缺失都算“没有”），并把 memories、anniversaries 的可选字符串字段一并改掉；加回归测试。
3. **信件不填纪念日保存失败**（后端 `letters.js`）：模块发 `occasion_date: null`，后端校验只放过空字符串、不放过 null（400）。已放过 null；加回归测试。
4. **游戏 ID 对不上**（后端 `GAMES` 集 vs 前端）：后端用 `number/lucky/feeding`，前端 8 个游戏用 `guess/luck/feed`，记录成绩会 400「game 不合法」。已把后端集合改成前端的 ID（`strawberry/guess/memory/wheel/reaction/quiz/rps/luck/feed`），后端测试同步改掉。
5. **游戏成绩记上了却显示“没记上”**（`games.js`）：`recordGame` 只认 HTTP 200 为成功，后端新建返回 201，导致用户看到报错、成绩和金币也不刷新。已改为 200 或 201 都算成功。
6. **前端发的事件类型被后端拒了**（`events.js`）：情绪模块发 `emotion_open/emotion_select/...`、礼物发 `gift_favorite`、信件发 `letter_saved`、回忆发 `memory_saved`，后端的白名单没有这 7 种，全部 400（事件是 fire-and-forget，功能不受影响，但日报的互动数会漏）。已把 7 种加进白名单；加回归测试。
7. **联调测试自身的残留服务器问题**（测试脚本）：第一次联调崩溃后服务器进程没杀掉、一直占着 3140 端口，后面几次联调实际测的是旧代码的残留服务。已杀掉残留进程；联调脚本改为每次随机端口 + 崩溃也杀进程。
   - 另修 3 个测试脚本自身的问题：二分搜索读整张卡片文本会把副标题里的“猜中”误判为赢（改读结果行）、列表删除按钮要按容器限定（`[data-del]` 在回忆/纪念日/信件里都有）、信件列表检查要限定在列表区（容器标题本身就含“写给宝宝的信”）。

## 9. 对照用户要求的测试清单

| 要求 | 结果 |
|---|---|
| 14 个阶段是否都做了 | ✅ 全部实现，13 个模块 + 导航 + 桥接，联调 46 + 32 项通过 |
| 是否删了原有功能 | ✅ 原有功能回归全过（test:dom 31/31、test-shell 20/20） |
| 小猪形象、头像、紫粉风格是否没动 | ✅ 未动（只改了称呼与显示名，见 §11） |
| 三种人格是否保留 | ✅ 保留；情绪覆盖按 8 种情绪工作（联调验证） |
| Key 是否只放服务器 .env | ✅ 前端 0 处 Key 相关内容 |
| 新功能是否真正可操作 | ✅ 联调全部走真实接口点出来的（创建/收藏/删除/开盒/游戏/加密） |
| 新增数据是否数据库持久化 | ✅ 14 张新表 + 照片落盘 + backup/restore 覆盖全部表 |
| 是否用虚假数据冒充 | ✅ 无数据时老实显示空状态；离线模板标注 source:offline；报告 hasData:false |
| 每个阶段完成后是否自动测试并修复 | ✅ 见 §8（7 个真实问题） |
| 需要外部服务的是否先完成不依赖的部分并说明限制 | ✅ 见 §10 |

## 10. 未验证的事项（诚实清单）

- **真 Key 的 DeepSeek 成功回复**：手头没有真实 Key，按要求没有去找。用户按 README 第 2 节配置后，在页面发一条消息即可验证。假 Key 下 401 映射正确，证明代理通路没问题。
- **真实手机浏览器**：交互验证是在 jsdom 里做的，未在真实 Chrome/Safari/微信内置浏览器里点过。按 README 第 3 节用局域网地址在手机上验证一次。
- **局域网手机访问与公网部署**：未部署到任何服务器；README 第 3、4 节是标准做法，没有实测过用户的网络环境。
- **语音识别/朗读的真机效果**：jsdom 里没有 SpeechRecognition/speechSynthesis，只验证了“不支持时老实提示”和按钮存在；真实 Chrome 的 STT/TTS、手机触屏手感、摇篮曲实际听感需真机验证。
- **照片上传的真机流程**：canvas 压缩 + 上传的代码已写，jsdom 里 FileReader/Image 不可靠，未能实测，需真实浏览器验证。
- **多人同时访问**：未做并发测试；当前是单进程 + SQLite，两个人同时用没有问题依据缺失，量大了再测。
- **长期运行**：未做 24 小时连续运行测试；数据库文件增长、日志、pm2 保活按常规做法写进 README，未实测。

## 11. 已知限制与改动说明

- **人设改动（2026-11-11 修正版）**：AI 是送给女朋友的专属 AI 小男友（男性），核心性格外冷内热、傲娇、专一、特别偏爱宝宝；称呼「宝宝」，聊天显示名「可爱的乖乖」。旧的「上位者 / 朕 / 退下吧」口吻和「小女友式陪伴」描述已全部改掉（以契约 §1 为准）。三种人格、小猪形象、头像、紫粉风格、互动都没动。改动可逆（备份在 `ke-ai-de-guai-guai-v2-backup-2026-11-11-phase3-before/`）。
- **照片 URL 的隔离**：见 §7。不要把照片链接发给外人。
- **每日盲盒的“今天”按服务器本地日期算**：部署在哪个时区，就按哪个时区算。
- **游戏金币上限**：每个游戏每天最多 30 金币（服务器强制）。
- **数据隔离是按浏览器生成的 token**，不是账号密码登录；换设备、清浏览器数据会生成新 token，旧数据只能靠备份文件恢复。
- **保险箱密码忘了真的打不开**（设计如此，页面里写明了）。
- 在线聊天的上下文只取本次会话的最近 20 条（与原来一致）；跨设备续聊需靠服务器端的历史检索，后续再做。

---

## 12. 部署准备与人设修正后重测（2026-11-11，v2.1.0）

- **SQLite 全量（人设修正后）**：后端 32/32、联调 65/65、DOM 31/31（12+12+7）、test-shell 20/20、功能 A 32/32、功能 B+C 46/46，**合计 226/226，0 失败**。人设改动（系统提示词、离线脑子、后端提示词/模板、情绪提示词）没有破坏任何功能。
- **PostgreSQL 16 本地全量（Neon 兼容验证）**：本地装 PostgreSQL 16.15（Ubuntu 镜像源；注：apt 默认双镜像里的 cogentco 极慢，改用 azure-only 源后 9 秒完成更新），建库后用 `scripts/test-pg.js` 逐套跑：后端 32/32、DOM 31/31、联调 **64/64**、test-shell 20/20、功能 A 32/32、功能 B+C 46/46，**合计 225/225，0 失败**（联调 pg 模式是 64 项：sqlite 的两条迁移断言合并成一条）。
- **联调 pg 模式发现的真实问题（已修）**：`scripts/pg-query.js` 没给 int8（COUNT(*)）注册数字解析，`COUNT(*)` 返回 JSON 字符串 `"n":"2"`，导致 `db_count` 的 grep 拿不到数，两条断言报 `expected [2] got []` / `expected [0] got []`。已在 pg-query.js 里加上与 `backend/database/db.js` 相同的 int8 解析，重跑后 64/64。**产品代码本身没有问题**，是测试工具的 bug。
- **部署包验证（tarball 解压即部署）**：`app.tar.gz`（236 KB，82 个文件，不含 .env/node_modules/.sqlite，.env.example 只有空占位）解到空目录 → `npm install --omit=dev`（82 个包，0.7 秒）→ 启动服务器：`/healthz` 200（无 token）、首页 200、`/api/health` ok:true（无 Key 时 deepseek:missing）、无 Key 时 `/api/chat` 正确返回 503 `deepseek_key_missing`、迁移 002+003 正常应用。
- **未验证**：真实 Neon 数据库、真实 Render 部署（均未做，等用户注册账号后操作）；真 Key 的 DeepSeek 回复（仍需用户在 Render 填 Key 后实测）。

## 附：第二阶段测试结果（历史，2026-11-11）

- 后端自测 15/15、联调 25/25、DOM 冒烟 12+12、持久化恢复 7/7，合计 71 项，0 失败。
- 假 Key 直连验证：`/api/chat` 返回 401 `deepseek_unauthorized`，证明代理通路没问题。
- 第二阶段发现并修复的问题：每日礼物日期非零补格式（`2026-1-5`）导致后端 400，已改为补零。
