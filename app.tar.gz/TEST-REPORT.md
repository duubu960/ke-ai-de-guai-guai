# 可爱的乖乖 v3 — 测试报告（第三阶段）

- 测试日期：2026-11-11
- 测试环境：Node.js v24.22.1、npm 10.9.4、SQLite（Node 内置 `node:sqlite`）、curl、jsdom 31
- 测试范围：后端迁移与新接口、13 个前端模块、导航与桥接、联调、回归（原有功能）
- **结论：全部通过，共 31 + 63 + 31 + 20 + 46 + 32 = 223 项检查，0 失败。**
- **2026-11-11 更新（部署准备 v2.1.0 + 人设修正后重测）**：SQLite 全量 226/226，PostgreSQL 16 本地全量 225/225，0 失败。见 §12。

---

## 1. 后端自测 — `npm test`（scripts/test-backend.js）

31/31 通过，退出码 0。临时端口 + 临时数据库，跑完已清理。含第二阶段的 15 项 + 第三阶段新增 16 项。

新增的 16 项（Phase 3）：
- 迁移幂等：再跑一次不报错、14 张表齐、migrations 只有 1 条记录
- memories CRUD + 按月/搜索/收藏 + 跨 token 隔离
- anniversaries CRUD + summary（无日期时 daysTogether 为 null，不编）
- surprise 每天一次：两次 open 返回同一份（201→200，isNew true→false，同一 id）
- wishlists CRUD + complete + summary
- preferences CRUD + pending + extract 只返回候选、绝不自动保存
- gifts recommend 6 条且无价格/店铺/链接
- games 每日上限：10→再 25 得 409，另一游戏 30 正常，state coins 累计 40
- state 新字段（coins/meters/hat/seenFaces）与 meters 子字段合并
- vault 拒收密码（body 含密码直接 400）
- photos：合法 PNG 可取回、GIF 拒、>5MB 拒
- events 记录与校验（含情绪/礼物收藏/信件/回忆的事件类型）
- letters CRUD + 收藏 + 离线 ai-draft（无 Key 时模板 + source:offline）
- reports today：无数据 hasData:false，有数据时真实计算、缓存一致
- backup 含全部新表、restore 回滚与恢复
- **可选字段的 null 当作“没有”**（wishlists photo_url:null、memories/anniversaries 的 null 字段、letters occasion_date:null）——联调发现的真实问题，已修并加回归测试

## 2. 联调测试 — `bash scripts/test-integration.sh`（curl）

63/63 通过，退出码 0。原第二阶段 25 项（21 + 假 Key 4 项）全过；新增 Phase 3 冒烟 38 项（health、memories、anniversaries summary、surprise 两次同一 id、wishlists、preferences、gifts、games 上限 409、reports、letters、vault、photos、backup、DB 表与迁移记录）。测试用随机端口 + 临时库，跑完清理（DB、照片目录均已清）。

假 Key 验证（原始结果，`DEEPSEEK_API_KEY=sk-test-dummy-key`）：
- `POST /api/letters/ai-draft` → HTTP 200，`source:"offline"`，内容是模板信
- `POST /api/surprise/open {"kind":"ai"}` → HTTP 201，`source:"offline"`，内容是模板惊喜
- 两处均 fallback 到模板并标注 `source:"offline"`，无“AI 生成成功”
- 上游 401 本身在第二阶段的 `/api/chat` 已直接验证（同假 Key，约 1s，返回 401 `deepseek_unauthorized`，未写库）——证明代理确实打到了 DeepSeek 并被拒

## 3. 前端 DOM 冒烟 + 持久化恢复 — `npm run test:dom`（jsdom）

31/31 通过（12 + 12 + 7）。第二阶段的两组 12 项 + 恢复测试 7 项全部通过，Phase 3 的后端改动未影响原有前端。

## 4. 导航与桥接测试 — `scripts/test-shell.js`（jsdom）

20/20 通过。验证：window.GG 桥接存在、setEmotion 往返、5 个导航按钮 + 5 个页面、首页默认激活、称呼是宝宝（无“哥哥”）、导航双向切换、记住上次页面、切页不丢小猪 DOM、点小猪有反应、发消息有回话、零页面 JS 报错。

## 5. B+C 模块联调 — `scripts/test-integration-features.js`（jsdom + 真实服务器）

46/46 通过，退出码 0。真实服务器（随机端口、临时库），13 个模块中的 9 个（盲盒/心愿/喜好/礼物/哄睡/游戏/语音/报告/保险箱）走真实接口端到端，**没有桩**。

逐项（均走真实接口验证）：
- 盲盒：开盒有真实内容、history 只有 1 条、第二次开返回同一份（isNew false）
- 心愿：新建入列表、API 有该条、完成出庆祝、summary done=1
- 喜好：从真实聊天记录提取出候选（芒果、珍珠奶茶）、点确认后进入已确认、服务器 confirmed=true
- 礼物：推荐 6 条渲染、收藏进收藏夹、服务器 favorites 有 1 条
- 游戏：猜数字二分搜索赢下、记录落库、summary 有该局、金币 +10
- 保险箱：设密码→加密保存（服务器端只见密文，blob 里不含明文）→上锁→错密码拒绝→对密码解密出原文→删除
- 报告：渲染真实数字，与 API 的 chatCount 一致
- 哄睡：浮层打开（月亮/星星/小猪）、睡前故事发进首页聊天、退出关闭
- 语音：麦克风按钮存在，不支持时老实提示
- 全程零页面 JS 报错

## 6. A 模块联调 — `scripts/test-integration-features-a.js`（jsdom + 真实服务器）

32/32 通过，退出码 0。真实服务器（随机端口、临时库），回忆/情绪/纪念日/信件 4 个模块走真实接口端到端，**没有桩**。

逐项（均走真实接口验证）：
- 回忆：种子回忆在列表、新建入列表、API 有 2 条、搜索按关键词过滤、收藏落库、删除成功
- 纪念日：daysTogether 真实计算（第一次见面 2026-11-01 → 当天 10 天，与 API summary 一致）、新建入列表、删除成功
- 信件：新建入列表、API 有该条、AI 起草（无 Key）填入离线模板、ai-draft API 的 source 是 offline、收藏落库、删除成功
- 情绪：8 张情绪卡、选“难过”出现温柔开场白、倾诉发进首页聊天、安静陪伴屏出现、退出关闭
- 全程零页面 JS 报错

## 7. 代码与安全检查

- `node --check`：全部新增/修改的 JS 文件通过。
- **Key 已从前端彻底移除**：对 `frontend/` 全文 grep `api.deepseek.com`、`Authorization`、`Bearer `、`sk-`（16 位以上）——**0 处真实 Key**。测试里只用 `sk-test-dummy-key`。钥匙只存在于服务器的 `.env`（本项目没有 `.env`，也没有真实 Key）。
- **照片隔离**：照片存在 `backend/data/photos/<token>/<uuid>.jpg`，文件名是随机 UUID，不可枚举；但静态服务本身不校验 token，URL 本身就是隔离边界——不要把照片 URL 发给外人。
- **保险箱**：服务器只存密文（blob/iv/salt），发送的密文里不含任何明文（联调已验证）；无找回密码接口（设计如此）。
- 13 个模块只写自己的容器、只用 `GG.apiFetch`、只用现有 CSS 变量；无 TODO、无空实现。
- 项目里没有生成数据库文件（测试用的都是 `/tmp` 里的临时库，已删除）；首次真实启动时自动创建 `backend/database/app.sqlite`。

## 8. 联调中发现并修复的真实问题（7 个）

1. **礼物推荐永远空**（`gifts.js`）：模块的 `asList` 只认 `recommendations`，后端返回的是 `{gifts: [...]}`，导致推荐列表永远显示“没有合适的推荐”。已补 `gifts` 键；**心愿的 AI 建议也有同样问题**（它也调 `/api/gifts/recommend`），一并补了。
2. **无照片的心愿保存失败**（后端 `validateWishlist`）：模块发 `photo_url: null`，后端校验把 null 当非法值拒了（400）。已加 `isOptStr`（null/缺失都算“没有”），并把 memories、anniversaries 的可选字符串字段一并改掉；加回归测试。
3. **信件不填纪念日保存失败**（后端 `letters.js`）：模块发 `occasion_date: null`，后端校验只放过空字符串、不放过 null（400）。已放过 null；加回归测试。
4. **游戏 ID 对不上**（后端 `GAMES` 集 vs 前端）：后端用 `number/lucky/feeding`，前端 8 个游戏用 `guess/luck/feed`，记录成绩会 400「game 不合法」。已把后端集合改成前端的 ID（`strawberry/guess/memory/wheel/reaction/quiz/rps/luck/feed`），后端测试同步改掉。
5. **游戏成绩记上了却显示“没记上”**（`games.js`）：`recordGame` 只认 HTTP 200 为成功，后端新建返回 201，导致用户看到报错、成绩和金币也不刷新。已改为 200 或 201 都算成功。
6. **前端发的事件类型被后端拒了**（`events.js`）：情绪模块发 `emotion_open/emotion_select/...`、礼物发 `gift_favorite`、信件发 `letter_saved`、回忆发 `memory_saved`，后端的白名单没有这 7 种，全部 400（事件是 fire-and-forget，功能不受影响，但日报的互动数会漏）。已把 7 种加进白名单；加回归测试。
7. **联调测试自身的残留服务器问题**（测试脚本）：第一次联调崩溃后服务器进程没杀掉、一直占着 3140 端口，后面几次联调实际测的是旧代码的残留服务。已杀掉残留进程；联调脚本改为每次随机端口 + 崩溃也杀进程。
   - 另修 3 个测试脚本自身的问题：二分搜索读整张卡片文本会把副标题里的“猜中”误判为赢（改读结果行）、列表删除按钮要按容器限定（`[data-del]` 在回忆/纪念日/信件里都有）、信件列表检查要限定在列表区（容器标题本身就含“写给宝宝的信”）。

## 9. 对照用户要求的测试清单

| 要求 | 结果 |
|---|---|
| 14 个阶段是否都做了 | ✅ 全部实现，13 个模块 + 导航 + 桥接，联调 46 + 32 项通过 |
| 是否删了原有功能 | ✅ 原有功能回归全过（test:dom 31/31、test-shell 20/20） |
| 小猪形象、头像、紫粉风格是否没动 | ✅ 未动（只改了称呼与显示名，见 §11） |
| 三种人格是否保留 | ✅ 保留；情绪覆盖按 8 种情绪工作（联调验证） |
| Key 是否只放服务器 .env | ✅ 前端 0 处 Key 相关内容 |
| 新功能是否真正可操作 | ✅ 联调全部走真实接口点出来的（创建/收藏/删除/开盒/游戏/加密） |
| 新增数据是否数据库持久化 | ✅ 14 张新表 + 照片落盘 + backup/restore 覆盖全部表 |
| 是否用虚假数据冒充 | ✅ 无数据时老实显示空状态；离线模板标注 source:offline；报告 hasData:false |
| 每个阶段完成后是否自动测试并修复 | ✅ 见 §8（7 个真实问题） |
| 需要外部服务的是否先完成不依赖的部分并说明限制 | ✅ 见 §10 |

## 10. 未验证的事项（诚实清单）

- **真 Key 的 DeepSeek 成功回复**：手头没有真实 Key，按要求没有去找。用户按 README 第 2 节配置后，在页面发一条消息即可验证。假 Key 下 401 映射正确，证明代理通路没问题。
- **真实手机浏览器**：交互验证是在 jsdom 里做的，未在真实 Chrome/Safari/微信内置浏览器里点过。按 README 第 3 节用局域网地址在手机上验证一次。
- **局域网手机访问与公网部署**：未部署到任何服务器；README 第 3、4 节是标准做法，没有实测过用户的网络环境。
- **语音识别/朗读的真机效果**：jsdom 里没有 SpeechRecognition/speechSynthesis，只验证了“不支持时老实提示”和按钮存在；真实 Chrome 的 STT/TTS、手机触屏手感、摇篮曲实际听感需真机验证。
- **照片上传的真机流程**：canvas 压缩 + 上传的代码已写，jsdom 里 FileReader/Image 不可靠，未能实测，需真实浏览器验证。
- **多人同时访问**：未做并发测试；当前是单进程 + SQLite，两个人同时用没有问题依据缺失，量大了再测。
- **长期运行**：未做 24 小时连续运行测试；数据库文件增长、日志、pm2 保活按常规做法写进 README，未实测。

## 11. 已知限制与改动说明

- **人设改动（2026-11-11 修正版）**：AI 是送给女朋友的专属 AI 小男友（男性），核心性格外冷内热、傲娇、专一、特别偏爱宝宝；称呼「宝宝」，聊天显示名「可爱的乖乖」。旧的「上位者 / 朕 / 退下吧」口吻和「小女友式陪伴」描述已全部改掉（以契约 §1 为准）。三种人格、小猪形象、头像、紫粉风格、互动都没动。改动可逆（备份在 `ke-ai-de-guai-guai-v2-backup-2026-11-11-phase3-before/`）。
- **照片 URL 的隔离**：见 §7。不要把照片链接发给外人。
- **每日盲盒的“今天”按服务器本地日期算**：部署在哪个时区，就按哪个时区算。
- **游戏金币上限**：每个游戏每天最多 30 金币（服务器强制）。
- **数据隔离是按浏览器生成的 token**，不是账号密码登录；换设备、清浏览器数据会生成新 token，旧数据只能靠备份文件恢复。
- **保险箱密码忘了真的打不开**（设计如此，页面里写明了）。
- 在线聊天的上下文只取本次会话的最近 20 条（与原来一致）；跨设备续聊需靠服务器端的历史检索，后续再做。

---

## 12. 部署准备与人设修正后重测（2026-11-11，v2.1.0）

- **SQLite 全量（人设修正后）**：后端 32/32、联调 65/65、DOM 31/31（12+12+7）、test-shell 20/20、功能 A 32/32、功能 B+C 46/46，**合计 226/226，0 失败**。人设改动（系统提示词、离线脑子、后端提示词/模板、情绪提示词）没有破坏任何功能。
- **PostgreSQL 16 本地全量（Neon 兼容验证）**：本地装 PostgreSQL 16.15（Ubuntu 镜像源；注：apt 默认双镜像里的 cogentco 极慢，改用 azure-only 源后 9 秒完成更新），建库后用 `scripts/test-pg.js` 逐套跑：后端 32/32、DOM 31/31、联调 **64/64**、test-shell 20/20、功能 A 32/32、功能 B+C 46/46，**合计 225/225，0 失败**（联调 pg 模式是 64 项：sqlite 的两条迁移断言合并成一条）。
- **联调 pg 模式发现的真实问题（已修）**：`scripts/pg-query.js` 没给 int8（COUNT(*)）注册数字解析，`COUNT(*)` 返回 JSON 字符串 `"n":"2"`，导致 `db_count` 的 grep 拿不到数，两条断言报 `expected [2] got []` / `expected [0] got []`。已在 pg-query.js 里加上与 `backend/database/db.js` 相同的 int8 解析，重跑后 64/64。**产品代码本身没有问题**，是测试工具的 bug。
- **部署包验证（tarball 解压即部署）**：`app.tar.gz`（236 KB，82 个文件，不含 .env/node_modules/.sqlite，.env.example 只有空占位）解到空目录 → `npm install --omit=dev`（82 个包，0.7 秒）→ 启动服务器：`/healthz` 200（无 token）、首页 200、`/api/health` ok:true（无 Key 时 deepseek:missing）、无 Key 时 `/api/chat` 正确返回 503 `deepseek_key_missing`、迁移 002+003 正常应用。
- **未验证**：真实 Neon 数据库、真实 Render 部署（均未做，等用户注册账号后操作）；真 Key 的 DeepSeek 回复（仍需用户在 Render 填 Key 后实测）。

## 13. 上线后热修复（2026-11-11，v2.1.1）

- **真机发现的问题**：部署上线后，用户在手机上打开首页，情绪急救室浮层直接盖住首页，点「退出」和「我好了，回去吧」都关不掉，页面被强制卡住。
- **原因**：`frontend/js/features/emotion.js` 的浮层用 `hidden` 属性控制显隐，但注入的样式里 `.ft-emo-overlay` 写了 `display:flex`；按 CSS 规则，作者样式的 `display:flex` 会覆盖浏览器内置的 `[hidden]{display:none}`，所以 `hidden=true` 也藏不住浮层。jsdom 不算样式，所以自动化测试全过，真机才暴露。
- **同类问题**：`frontend/js/features/games.js` 的 `.gm-body` 也有 `display:flex` + `hidden` 混用，游戏卡片折叠不住；`letters.js` / `memories.js` 的浮层是关时直接 `remove()`，`sleep.js` 用 `.open` class 控制，均不受影响。
- **修复（只加两行 CSS，不动逻辑）**：emotion.js 加 `.ft-emo-overlay[hidden]{display:none}`；games.js 加 `.gm-body[hidden]{display:none}`。版本 2.1.0 → 2.1.1。
- **回归**：语法检查通过；DOM 套件重跑 31/31 通过。修复后 `app.tar.gz` 重新打包上传 GitHub，Render 自动重新部署。
- **上线验证（2026-11-11 02:50，真机浏览器）**：GitHub 上新版 app.tar.gz 同一次提交替换旧文件（仓库变为 2 个提交）；Render 推送后约 4 分钟未触发自动部署，改用控制台 Manual Deploy → Deploy latest commit 手动部署，新部署 cdaaaa7 构建 37.7 秒成功 Live。首页三步验证全过：打开时弹窗不再盖住页面；点「我需要抱抱」正常打开；点「退出」正常关闭，刷新后仍无遮挡；`/healthz` 返回 ok:true。此后部署流程注意：不要只等自动部署，5 分钟未触发就手动部署。

## 14. 夜间主题与头像兜底（2026-11-11，v2.1.2）

- **真机发现的问题（v2.1.1 上线后，用户 03:05 截图反馈）**：① 聊天卡片顶部标题「打字跟可爱的乖乖聊聊天」看不见（白字印在浅色卡片上）；② 聊天头像没加载出来，只显示破碎的 alt 文字「可..」。
- **原因①（真 bug）**：站内主题有两套机制：JS 按时间设 `data-theme="night"`（凌晨 3 点是 night，文字变白），但各组件的深色样式只写在 `prefers-color-scheme: dark` 媒体查询里；用户手机是浅色系统模式，媒体查询不生效，于是文字白了、卡片还是浅的。同类受影响的还有 `.food-pop`、`.act`、`.sheet`、`.chat-card`、底部导航等 13 处。
- **修复①**：style.css 末尾加一整块 `body[data-theme="night"]` 覆盖规则，把媒体查询里的深色样式原样镜像过来，夜间主题不再依赖手机系统模式。
- **原因②（当时）**：头像文件本身没问题（curl 直查线上 `assets/avatar.jpg` 返回 200 image/jpeg 16471 字节）；用户当时 VPN 网速只有 0.12 KB/s，16KB 的图还没拿到就先显示了 alt 兜底文字。
- **修复②（防呆）**：头像加载失败时用 🐷 emoji 圆章兜底（app.js 加 `avatarFallback`，动态消息和首页静态欢迎语都覆盖），以后慢网也不会只剩「可..」。
- **回归与验证**：待跑；部署后真机验证：夜间打开首页聊天标题应清晰可见、底部导航清晰；头像正常显示或显示猪猪兜底。

## 15. 聊天显示名改成「最喜欢的哥哥」（2026-11-11，v2.1.3）

- **用户要求（03:07）**：首页/聊天页里所有的「可爱的乖乖」都改成「最喜欢的哥哥」。名字按「最喜欢的哥哥」改（用户原话是「最喜好的哥哥」，应为笔误）；如用户实际想要「最喜欢你的哥哥」，再改一字即可。
- **改动范围（仅首页/聊天页）**：index.html 19 处（标题、徽章、气泡打招呼、操作按钮文案、聊天标题、消息署名、输入框提示、栏目小标题、页脚）、app.js 25 处（消息署名、回复小标题、问候语、自我介绍回答、DeepSeek 系统提示词、头像 alt、无障碍文案）。其他页面（信件落款、游戏问答）未动，属已知遗留。
- **回归**：node --check 通过；test:dom 31/31 通过（12+12+7）。部署后真机验证：聊天署名、标题、打招呼均为「最喜欢的哥哥」。
- **部署阻塞（03:09）**：v2.1.2 部署卡在 GitHub 登录——保存的登录信息用户名栏被填成了一串自动生成的字符（不是 duubu960），GitHub 返回 Incorrect username or password。处理：不重复提交，让浏览器改用账号邮箱重试登录；用户去休息，不要再索要密码。v2.1.3（夜主题 + 头像兜底 + 改名）打包已完成，待登录恢复后一次部署。
- **登录进展（03:11）**：改用账号邮箱 duubu960@gmail.com + 已保存密码后，密码这关通过了，GitHub 进入发验证码步骤；但 Muse 的 Gmail 未接通，读不到发到 duubu960@gmail.com 的验证码，部署停在验证码处，等用户早上在手机上输入验证码后再继续。
- **上传阻塞（03:12）**：用户发的验证码通过、登录成功（Welcome to GitHub, duubu960!），但上传 app.tar.gz 连续 5 次失败，均为 source_open_failed：原因是给浏览器的文件路径经过软链接（~/workspace/your_files/ 是软链接）。第一次重新授权用的还是软链接路径，被系统拒了；第二次给了真实路径 /home/hatch/workspace/goals/interactive-companion/files/ke-ai-de-guai-guai-v2-deploy/app.tar.gz，但任务在收到前已按指示停下。另试过把包传到 Muse 内置存储给浏览器下载，因需要用户在审批卡上批准、用户在睡觉，30 分钟后超时未传。03:12 后又新开了一次任务，直接用真实路径授权上传，待结果。
- **教训**：给浏览器任务授权文件必须用 readlink -f 解析后的真实路径；软链接路径会在上传时报 source_open_failed（已记入 AGENTS.md）。
- **大小不匹配的原因（04:29 查实）**：两次 input_grant_size_mismatch 并不是文件本身的问题——04:09 的巡检 run 在 04:20 重新打包了 app.tar.gz（239,728 → 242,194 字节，应是它做了一轮网上找来的小优化），我 03:10 发的授权声明的还是旧大小，所以浏览器校验失败。教训：巡检 run 和主聊天的人工部署不要同时动同一个包；等 run 的汇报来了再决定下一步，不要再并行开上传任务。部署现在由巡检 run 接手。

## 16. 过夜巡检 04:09 轮：聊天时间戳 + 添加到主屏幕（2026-11-11，v2.1.4）

- **本轮检查**：GitHub 仓库仍只有 2 次提交（最新 cdaaaa7 = v2.1.1），v2.1.3 仍未上线；03:42 新开的那次上传任务与 03:12 前后的另一次上传任务在运行时列表里仍显示 running，但都没有打开的浏览器窗口、且分别已 27 分钟 / 57 分钟无活动，疑似已卡住。线上 /healthz 用 browser.open 直取超时（Render 免费档 15 分钟无访问会休眠，首访需唤醒），待浏览器任务唤醒后复核。
- **学到的优点（本轮网上调研）**：AI 男友类产品（Nomi 等）以记忆连贯与持续对话见长；情侣 App（OurCouple / Love8 / Been in Love）普遍强调主页小部件、爱的天数 streak、虚拟宠物共同养成、每日一句。本轮只取两个与现有定位相符的小优点：① 聊天气泡带时间（同类产品标配，本站此前消息无时间）；② 加到手机主屏幕像个真 App（theme-color + mobile-web-app-capable 等 meta，本站此前缺这些）。
- **改动（小、可逆，改前已备份到 ke-ai-de-guai-guai-v2-backup-2026-11-11-v214-before.tar.gz）**：
  1. 聊天消息时间戳：`addMsg(who, text, when)` 新增可选时间参数，气泡底部显示 `HH:MM`（`.msg-time`，自己发的靠右）；历史恢复时传入后端 `/api/history` 已返回的 `created_at`（毫秒时间戳），新消息默认当前时间，无效时间回退到当前时间。
  2. 添加到主屏幕：index.html 增加 `theme-color #FFD6DE`（粉色，与配色一致）、`mobile-web-app-capable`、`apple-mobile-web-app-capable`、`apple-mobile-web-app-title 可爱的乖乖`、`apple-mobile-web-app-status-bar-style`。
  3. 版本号升到 2.1.4。
- **测试发现并修复（测试本身的过时断言，非产品 bug）**：test-shell.js 的 `no 哥哥 left in rendered page` 在 v2.1.3 改名后必然失败——显示名本身就是「最喜欢的哥哥」。断言已更新为：显示名存在，且去掉显示名后页面不再有其他「哥哥」。其余脚本无同类断言。
- **回归（本轮重跑）**：node --check 通过；后端 npm test 32/32；test:dom 31/31（12+12+7）；test-shell 21/21（断言更新后由 20 变 21）；特性集成 B+C 46/46、A 32/32；合计 162 项，0 失败。
- **部署**：v2.1.4（含 v2.1.3 全部内容）已重新打包，待浏览器任务一次上传部署并线上验证（夜间标题、署名、头像兜底、情绪弹窗、/healthz + 新增的时间戳与主屏幕 meta）。

## 17. 过夜巡检 05:09 轮：聊天日期分隔 + 真图标（2026-11-11，v2.1.5）

- **本轮检查**：线上仍是 v2.1.1（browser.open 首页实测：聊天卡片标题仍是「打字跟可爱的乖乖聊聊天」，欢迎语仍是「可爱的乖乖哼哼」；/healthz 返回 ok:true，服务本身是醒的）。04:09 轮派发的 v2.1.4 部署浏览器任务在 05:12 被取消、无结果；GitHub 仓库仍只有 2 次提交，app.tar.gz 未被替换。03:43 那次上传失败的原因已查实：授权记录的大小 239,728 字节是旧包，04:20 巡检重打包后实际文件已是 242,194 字节，属确定性 input_grant_size_mismatch，与账号无关；本轮部署须用最新包重新授权，且授权后不再重打包。
- **学到的优点（本轮网上调研）**：AI 男友类产品（X-Friend、Imate、Anima）共同强调记忆连贯、主动发消息、偶尔的小惊喜礼物；本站这些能力已有。本轮只取两个补齐型小优点：① 消息按日期分组（配合上轮加的时间戳，跨天聊天不再混在一起）；② 添加到主屏幕要有真图标（补齐上轮只加了 meta、没有图标的缺口）。
- **改动（小、可逆，改前已备份到 ke-ai-de-guai-guai-v2-backup-2026-11-11-v215-before.tar.gz）**：
  1. 聊天日期分隔：`addMsg` 按消息本地日期插入 `.msg-date` 分隔行（今天 / 昨天 / M月D日），同一天只出现一次；历史恢复跨天时自动分组；新消息跨零点自动出现新分隔。
  2. 真图标：favicon 由空 `data:,` 换成 🐷 emoji SVG（data URI）；新增 `apple-touch-icon` 指向 `assets/avatar.jpg`，iOS 添加到主屏幕时显示照片头像。
  3. 版本号升到 2.1.5。
- **回归（本轮重跑）**：node --check 通过；后端 npm test 32/32；test:dom 31/31（12+12+7）；test-shell 21/21；特性集成 B+C 46/46、A 32/32；合计 162 项，0 失败。
- **部署**：v2.1.5（含 v2.1.3 + v2.1.4 全部内容）已重新打包，待浏览器任务一次上传部署并线上验证（夜间标题、署名、头像兜底、情绪弹窗、/healthz + 新增的日期分隔与图标）。

## 18. 过夜巡检 06:09 轮：长按复制 + 回到底部（2026-11-11，v2.1.6）

- **本轮检查**：线上仍是 v2.1.1（curl 首页实测：0 处「最喜欢的哥哥」、19 处「可爱的乖乖」；线上 app.js 无 avatarFallback、无「最喜欢的哥哥」；线上 style.css 仅 1 处 `body[data-theme="night"]`，本地 15 处；/healthz 返回 ok:true、首页 200，服务本身正常）。05:09 轮派发的 v2.1.5 部署浏览器任务在 06:09 被取消、无结果；GitHub 仓库仍只有 2 次提交，app.tar.gz 未被替换。v2.1.3–v2.1.5 全部内容仍未上线。
- **学到的优点（本轮网上调研）**：AI 男友类产品（X-Friend、Nomi 等）共同强调记忆连贯、主动发消息——本站已有；Google Messages 2026 年 9–10 月刚全量推出的改动最值得学：长按消息出快捷菜单复制文字（用户最想要的功能之一）、左滑看时间戳、右滑回复。本轮只取两个与现有定位相符的小优点：① 长按消息复制文字（配「已复制」小提示）；② 聊天上翻看旧消息时出现「回到底部」按钮，新消息不再把正在翻旧记录的人硬拉到底部（仅自己刚发的消息仍自动到底）。
- **改动（小、可逆，改前已备份到 ke-ai-de-guai-guai-v2-backup-2026-11-11-v216-before.tar.gz）**：
  1. 长按复制：`addMsg` 给每个气泡绑长按（550ms）→ 复制气泡纯文字（去掉署名和时间），优先 navigator.clipboard，失败时用 textarea 兜底，成功显示「已复制」toast、气泡短暂描边；静态欢迎语同样可长按复制；气泡加 user-select:none，避免长按时弹出系统选字菜单。
  2. 回到底部：聊天记录区下方加 `↓ 回到底部` 按钮，平时隐藏，上翻超过 160px 时出现，点一下回到最新；新消息仅在已接近底部时才自动滚动，贴纸/联想词/正在输入同样处理；历史恢复结束仍一次滚到底。
  3. 版本号升到 2.1.6。
- **回归（本轮重跑）**：node --check 通过；后端 npm test 32/32；test:dom 31/31（12+12+7）；test-shell 21/21；特性集成 B+C 46/46、A 32/32；合计 162 项，0 失败。另写一次性 jsdom 探针验证新功能 13/13（静态/动态气泡长按复制出纯文字、toast、描边、回到底部显隐与点击滚动、全程零页面 JS 错误）。
- **部署**：v2.1.6（含 v2.1.3 + v2.1.4 + v2.1.5 全部内容）已重新打包，待浏览器任务一次上传部署并线上验证（夜间标题、署名、头像兜底、情绪弹窗、/healthz + 新增的长按复制与回到底部）。

## 19. 过夜巡检 07:09 轮：今日一问（2026-11-11，v2.1.7）

- **本轮检查**：线上仍是 v2.1.1（browser.open 首页实测：聊天卡片标题仍是「打字跟可爱的乖乖聊聊天」；/healthz 返回 ok:true，服务本身正常）。06:09 轮派发的 v2.1.6 部署浏览器任务在 07:19 被取消、无结果；GitHub 仓库仍只有 2 次提交，app.tar.gz 未被替换。v2.1.3–v2.1.6 全部内容仍未上线。
- **部署推进（本轮）**：07:2x 已重新派发云端浏览器任务部署 v2.1.6（245,302 字节，md5 2004e8e12108cc0aad98a81b33aad414，真实路径授权，授权后不再重打包）；任务要求：GitHub 若需登录用邮箱 duubu960@gmail.com + 已保存密码只提交一次，需验证码则停下汇报；上传后等 Render 自动部署、5 分钟未触发则手动 Deploy latest commit；随后线上验证 7 项（healthz、夜间标题、署名、头像兜底、情绪弹窗、长按复制、回到底部）。任务结果尚未返回。
- **学到的优点（本轮网上调研）**：情侣 App（Togetherly、Hunnybun、TwoNest，2026 年 10–11 月新上架/更新）共同的低门槛互动是「一键想你」小动作和「每日一问」——每天一个小问题引发对话，不用想话题；Amorno 的经验是纪念日提醒要提前 7 天 + 2 天两次。本轮只取「每日一问」这一个小优点（「一键想你」本站的「我想你了」chips 已有；纪念日提前提醒需跨模块取数，本轮不碰）。
- **改动（小、可逆，改前已备份到 ke-ai-de-guai-guai-v2-backup-2026-11-11-v217-before.tar.gz，245,368 字节）**：
  1. 今日一问：聊天记录区下方、快捷短语上方新增「💭 今日一问」条，14 条温和问题按年积日轮换、每天固定一条，点一下按快捷短语的同一发送通路发给最喜欢的哥哥；样式只用 CSS 变量（--card2/--ink/--line/--muted），夜间主题自动覆盖，无需额外镜像规则。
  2. 版本号升到 2.1.7。人设、后端、数据均未动。
- **回归（本轮重跑）**：node --check 通过；后端 npm test 32/32；test:dom 31/31（12+12+7）；test-shell 21/21；特性集成 B+C 46/46、A 32/32；合计 162 项，0 失败。另写一次性 jsdom 探针（/tmp/v217-probe.js）验证新功能 8/8（今日一问条存在、文案与当日轮换一致、点按真实发送且出现在已发消息里、全程零页面 JS 错误）。
- **部署**：v2.1.7 尚未打包——v2.1.6 的部署浏览器任务正在进行中，按 04:09 轮教训，授权期间不重打包 app.tar.gz。若 v2.1.6 部署成功，再打包 v2.1.7 派发下一轮部署；若失败，v2.1.7 随早上汇总一并说明。

## 20. 情侣绑定（2026-11-11，v2.2.0，后端）

- **背景**：网站靠每部手机浏览器里的随机 uuid token（X-User-Token）区分用户，没有登录，两个人各看各的数据。用户要求：一方生成绑定码，另一方输入，绑完回忆、信件、心愿、聊天记录双方都能看到。
- **改动**：
  1. 新迁移 004（SQLite 与 PG 两份）：`couples` 表，`id`（SQLite AUTOINCREMENT / PG SERIAL）、`code TEXT UNIQUE NOT NULL`（6 位数字）、`token_a TEXT NOT NULL`、`token_b TEXT`（可空）、`created_at`（毫秒时间戳）；token_a / token_b 各建索引。
  2. 新路由 `backend/routes/couple.js`（`createCoupleRouter(db)`，另导出 `resolveScope(db, token)`）：`POST /api/couple/create`（生成 6 位码，碰撞重试；已是 token_a 返回已有码；已是 token_b 返回 409）、`POST /api/couple/join {code}`（码不存在 404；加入自己发起的 400；已在别的绑定里 / 码已被占 409；成功时一个事务内把调用方在四张共享表里的旧行 token 改成 token_a，再设 token_b）、`GET /api/couple/status`（`{paired:false}` 或 `{paired:true, code, role:'a'|'b', joined}`）、`POST /api/couple/unbind`（任一方可解；返回 note 写明共享行留在发起方名下）。code 只接受 6 位数字串；全部接口走 `userToken` 中间件。
  3. 共享范围解析：`resolveScope` 查 couples 表，token 是任一方就返回 token_a，否则返回原 token。已用在 `chat.js`（POST 两次 INSERT、GET /api/history）、`memories.js`、`letters.js`、`wishlists.js` 全部共享表读写处；`chat.js` 的 `ensureUser` 仍用原始 token。
  4. `backend/server.js` 挂载新路由；`package.json` 版本号升到 2.2.0。`frontend/` 未动（前端是别的 agent 的活）。
- **共享与不共享**：共享 messages、memories、letters、wishlists；不共享 user_state（金币、meters、喜好）、vault（隐私保险箱）、photos、anniversaries、games、events、reports、preferences、gifts。两个有意的边界：`letters.js` 的 ai-draft 上下文（user_state 里的名字、preferences 里的喜好、相识天数）仍用原始 token；`wishlists.js` 的 complete 写入 events 的记录仍归操作者自己的 token。
- **解除后的数据归属**：共享行留在发起方（token_a）名下，不迁回；unbind 返回的 note 写明此行为，前端会展示。
- **回归**：node --check 全过；后端 `npm test` **39/39**（原 32 项 + 新增 7 个情侣绑定用例：创建取码/重复创建、错误码 404/400、加入前 B 的旧数据、加入成功后双方看到同一批聊天/回忆/信件/心愿、错误码 409、绑定期间 user_state 与 vault 仍隔离、解除后恢复隔离且共享行留在发起方名下）；`npm run test:dom` 31/31（12+12+7）全过。为配合新迁移，迁移幂等用例的期望列表已更新（004-couple 两份 + couples 表）。
- **test:pg 未跑**：本机没有 PostgreSQL 服务（无 psql/pg_ctl/集群进程、无 docker），且未设置 DATABASE_URL；不使用线上 Neon 连接串做测试。PG 版迁移只做了人工对照（仿照 003-photos.pg.sql 的写法、`?` 占位符经 `toPgParams` 翻译），上线后需在 Render 上验证迁移能正常应用。
- **已知限制**：备份/恢复仍按原始 token（state.js 未动）：B 绑定后自己的 `/api/backup` 不含已并入 token_a 的行，A 的备份包含全部共享行；解绑后 B 的备份同样不含这些行。

## 附：第二阶段测试结果（历史，2026-11-11）

- 后端自测 15/15、联调 25/25、DOM 冒烟 12+12、持久化恢复 7/7，合计 71 项，0 失败。
- 假 Key 直连验证：`/api/chat` 返回 401 `deepseek_unauthorized`，证明代理通路没问题。
- 第二阶段发现并修复的问题：每日礼物日期非零补格式（`2026-1-5`）导致后端 400，已改为补零。

## 21. 哄睡修复：音乐听不见 + 讲故事没能力（2026-11-11，v2.2.0 基础上）

- **用户现场证据（截图 + 口述）**：哄睡浮层里小夜曲听不到声音；点“讲个睡前故事”只在首页聊天回话，浮层里什么也不出现、也不出声。
- **Bug 1 音乐听不到的原因（代码确认）**：① 音量太小：`masterGain` 0.05 × 音符包络峰值 0.5 = 实际 0.025，手机扬声器上基本听不见；② `startMusic` 里 `audioCtx.resume()` 没等结果，上下文还处在 `suspended`（OPPO 手机内置浏览器很常见）时音符就排进去了，等于静音；③ 开关按钮初始文字就是“小夜曲：开”，状态还是操作分不清。
- **Bug 1 改法（只改 `frontend/js/features/sleep.js`）**：
  1. 音量：`masterGain` 0.05 → **0.22**，音符包络峰值 0.5 → **0.8**；每音符再加一个 triangle 波振荡器与 sine 混音（峰值 0.4，约 sine 的一半），声音暖一点，手机扬声器上能听见。
  2. `startMusic` 改成先 `ensureAudio()`，再等 `audioCtx.resume()` 的 Promise（`.then/.catch` 兼容写法，与文件现有风格一致），确认 `state === 'running'` 才开始排音符；resume 后仍是 `suspended` 时按钮文字回到“小夜曲：关”，并 `GG.showNotice('小夜曲还没醒，点一下屏幕再试一次')`。
  3. 按钮文字改成状态语义：未播放显示“小夜曲：关”，播放中显示“小夜曲：开”；`openSleep` 自动开音乐的行为保留。
  4. 加 `visibilitychange` 监听：页面重新可见时，若音乐在放且上下文是 `suspended`，再 resume 一次。
- **Bug 2 讲故事没能力的原因（代码确认）**：“讲个睡前故事”只是调 `GG.sendChat(...)`，回复只出现在首页聊天里，浮层里不显示也不出声；`sleep.js` 从没用过 `speechSynthesis`（朗读只在 `voice.js` 里有）。
- **Bug 2 改法（只改 `sleep.js`）**：
  1. 浮层里新增故事区（默认 `hidden`）：故事文字 + “🔊 朗读”/“⏹ 停止朗读”/“收起故事”按钮，样式写进原有 `injectStyle`（深紫底、粉白字，与浮层配色一致）。
  2. 点故事按钮后禁用并显示“正在想故事…”，直接用 `GG.apiFetch('/api/chat', {method:'POST', body: JSON.stringify({messages:[{role:'system', content: STORY_SYSTEM}, {role:'user', content: STORY_ASK}]})})` 拿回复（响应 `{reply}`，用法与 `app.js` 的 `callDeepSeek` 一致）。特别注意：后端 `/api/chat` 不自带人设 system prompt（`deepseek.js` 无 system 处理、`chat.js` 只透传），所以请求里自带一句 system 提示（男友哄睡口吻、150 字以内、暖的、不要套路情话、不要朕/本宫这类词），否则回的是通用 DeepSeek 口吻。
  3. 拿到 reply 就显示在故事区，并用 `speechSynthesis` 自动朗读（`zh-CN`，`rate 0.85`）；故事显示后按钮即恢复（朗读在后台继续，用“停止朗读”控制——若等朗读结束才恢复，无朗读支持的浏览器上按钮会一直卡住）。
  4. API 失败（网络错、503、401、402、空回复，任何非 200）时用本地故事库兜底，不弹报错。本地库 4 则、每则 ≤120 字：前两则直接复用 `app.js` 离线脑子“讲故事”档里的两则（草莓树、爬山），另写两则同风格（数星星、月亮盖被子）。
  5. 不支持 `speechSynthesis` 时只显示文字并在故事区提示一句；“🔊 朗读”可重新读当前故事；“⏹ 停止朗读”即 `cancel()`；关闭浮层时若在朗读就 `cancel()`，音乐按现有逻辑停掉。
  6. 注意：POST `/api/chat` 会把这次问答写进聊天记录，故事同时出现在首页聊天里，与原有行为一致，可以接受；不再另外调 `GG.sendChat` 发一次（避免重复）。
  7. “说句晚安情话”和“讲讲今天的回忆”两个按钮、呼吸、定时、动画全部保持原样不动。
- **测试改动**：`scripts/test-dom.js` 追加睡眠用例 10 项/模式（入口存在、浮层打开、开音乐后按钮文字翻成“小夜曲：开”、再点翻回“小夜曲：关”、故事按钮点后故事区出现且有文字、朗读/停止按钮存在、按钮恢复可用、浮层关闭）；另补了测试桩缺失的 `linearRampToValueAtTime`（真实 `playNote` 用它，桩里没有会导致 jsdom 抛错）。
- **回归**：`node --check`（sleep.js、test-dom.js）通过；`npm run test:dom` **51/51，0 失败**（no-key 22/22、dummy-key 22/22、restore 7/7；原来 12+12+7=31，新增睡眠用例 10+10=20 全部通过）。no-key 模式下故事走 503 兜底、dummy-key 模式下走 401 兜底，两路都验证了本地故事出现。
- **未做**：未升版本号（任务约束不改 `package.json`；当前版本号 2.2.0 是并行改动，本轮未动）。真机验证（OPPO 上实际音量、朗读是否出声）未做，需在部署后用真机点一次确认。
- **部署**：本轮只改了前端文件与测试，未打包；部署需家长代理按既有流程打包 v2.2.0（含本修复）→ GitHub 替换 app.tar.gz → Render 手动 Deploy latest commit → 线上验证（开哄睡听得到音乐、讲故事浮层出文字且朗读）。
