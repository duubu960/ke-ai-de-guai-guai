// Phase 3 bottom navigation: switches .page sections, never rebuilds the home DOM.
(function(){
  var nav = document.getElementById('bottomNav');
  if(!nav) return;
  var pages = ['home','memories','surprise','games','me'];
  function show(page){
    if(pages.indexOf(page) === -1) page = 'home';
    pages.forEach(function(p){
      var sec = document.getElementById('page-' + p);
      if(sec) sec.classList.toggle('active', p === page);
    });
    nav.querySelectorAll('button').forEach(function(b){
      b.classList.toggle('active', b.dataset.page === page);
    });
    try{ window.localStorage.setItem('gg_page_v1', page); }catch(e){}
    try{ document.documentElement.scrollTop = 0; document.body.scrollTop = 0; }catch(e){}
    document.dispatchEvent(new CustomEvent('gg:page', { detail: { page: page } }));
  }
  nav.addEventListener('click', function(e){
    var btn = e.target.closest ? e.target.closest('button[data-page]') : null;
    if(btn) show(btn.dataset.page);
  });
  var saved = 'home';
  try{ saved = window.localStorage.getItem('gg_page_v1') || 'home'; }catch(e){}
  show(saved);
  window.GGNav = { show: show };
})();
