
(function(){
  var pig = document.getElementById('pig');
  var pigArea = document.getElementById('pigArea');
  var bubble = document.getElementById('bubble');
  var bubbleText = document.getElementById('bubbleText');
  var bubbleSub = document.getElementById('bubbleSub');
  var fx = document.getElementById('fx');
  var countEl = document.getElementById('count');
  var heartsEl = document.getElementById('hearts');
  var foodEl = document.getElementById('food');
  var zzzEl = document.getElementById('zzz');
  var soundBtn = document.getElementById('soundBtn');

  var taps = 0;
  var soundOn = true;
  var audioCtx = null;
  var currentCat = 'random';
  var lastIdx = -1;

  // ===== Redesign add-ons: meters, wish, coins, hats, album (in-session only) =====
  var reduceMotion = false;
  try{ reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(e){}
  var meters = { hunger:72, mood:82, energy:76 };
  var coins = 0;
  var wishes = [
    { id:'feed', text:'乖乖想吃一颗草莓 🍓' },
    { id:'hug', text:'乖乖想被抱抱 🤗' },
    { id:'pat', text:'乖乖想被摸摸头' },
    { id:'sleep', text:'乖乖有点困，想听你说晚安' }
  ];
  var wishIdx = Math.floor(Math.random()*wishes.length);
  var ownedHats = { bow:true, none:true };
  var currentHat = 'bow';
  var seenFaces = {};
  var gameState = { running:false, caught:0, left:15, timers:[] };

  var phrases = {
    happy: [
      "要天天开心哦！",
      "今天也要笑一笑呀，笑起来最好看啦！",
      "开心最重要，其他的慢慢来。",
      "嘿嘿，看到你我就开心！",
      "把烦恼丢掉，今天只装快乐好不好？",
      "你开心，我就开心，我们一起开心！"
    ],
    miss: [
      "我有想你哦，你有没有想我？",
      "刚刚还在想你，你就来了。",
      "想你啦，所以一直在这里等你。",
      "你不在的时候，我有乖乖等你回来。",
      "一见到你，心里就满满的。"
    ],
    care: [
      "你有没有保护好自己？",
      "天冷多穿点，别感冒了哦。",
      "记得喝水，不要等渴了才喝。",
      "走路看路，出门注意安全呀。",
      "累了就休息，别硬撑，我会心疼的。",
      "晚上早点睡，熬夜会变小笨蛋的。",
      "好好吃饭，不许随便对付一顿哦。"
    ],
    ask: [
      "今天在干啥呀？",
      "今天过得怎么样？跟我说说呗。",
      "今天吃饭了吗？吃的什么呀？",
      "今天有没有遇到开心的小事？",
      "你现在心情怎么样？",
      "今天忙不忙？要不要陪我玩一会儿？",
      "猜猜我今天梦见什么了？梦见你啦！"
    ],
    cheer: [
      "你超棒的，别怀疑自己！",
      "慢慢来，你已经比昨天更厉害了。",
      "加油呀，我一直在你这边。",
      "遇到难事别怕，深呼吸，宝宝陪你。",
      "你认真努力的样子，真的很闪亮。",
      "今天也辛苦啦，给你一个大大的赞！"
    ]
  };
  phrases.random = [].concat(phrases.happy, phrases.miss, phrases.care, phrases.ask, phrases.cheer);

  var subs = {
    happy:"可爱的乖乖希望你每天都开开心心的",
    miss:"可爱的乖乖一直在想你",
    care:"可爱的乖乖在认真关心你",
    ask:"可爱的乖乖很好奇，快告诉她",
    cheer:"可爱的乖乖在为你加油",
    random:"可爱的乖乖刚刚想到的"
  };

  var milestones = {
    5:"哇，你点了我 5 次啦，我们是好朋友了！",
    10:"10 次啦！你是我最喜欢的人，没有之一。",
    20:"20 次！今天的快乐额度已经爆棚啦！",
    30:"30 次啦，你陪了我好久好久，谢谢你。",
    50:"50 次！我们要做一辈子的好朋友好不好？"
  };

  function popSound(freq){
    if(!soundOn) return;
    try{
      if(!audioCtx) audioCtx = new (window.AudioContext||window.webkitAudioContext)();
      if(audioCtx.state==='suspended') audioCtx.resume();
      var o = audioCtx.createOscillator();
      var g = audioCtx.createGain();
      o.type='sine';
      o.frequency.setValueAtTime(freq||520, audioCtx.currentTime);
      o.frequency.exponentialRampToValueAtTime((freq||520)*1.6, audioCtx.currentTime+0.12);
      g.gain.setValueAtTime(0.12, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime+0.22);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime+0.24);
    }catch(e){}
  }

  function burstHearts(n){
    var rect = pigArea.getBoundingClientRect();
    for(var i=0;i<(n||5);i++){
      var s=document.createElement('span');
      s.textContent = Math.random()>0.35 ? '💗' : '✨';
      s.style.left = (38 + Math.random()*24) + '%';
      s.style.bottom = (110 + Math.random()*40) + 'px';
      s.style.setProperty('--dx', (Math.random()*90-45)+'px');
      s.style.setProperty('--rot', (Math.random()*36-18)+'deg');
      s.style.animationDelay = (Math.random()*0.15)+'s';
      fx.appendChild(s);
      (function(el){ setTimeout(function(){ el.remove(); }, 1500); })(s);
    }
  }

  function updateMood(){
    countEl.textContent = '陪你玩了 ' + taps + ' 次';
    var filled = Math.min(5, 3 + Math.floor(taps/4));
    var html='';
    for(var i=0;i<5;i++){
      html += i<filled ? '❤️' : '<span class="off">❤️</span>';
    }
    heartsEl.innerHTML = html;
  }

  function clampMeter(v){ return Math.max(0, Math.min(100, Math.round(v))); }
  function updateMeters(){
    var map = [['Hunger', meters.hunger],['Mood', meters.mood],['Energy', meters.energy]];
    for(var i=0;i<map.length;i++){
      var bar = document.getElementById('meter'+map[i][0]);
      var val = document.getElementById('meter'+map[i][0]+'Val');
      if(bar) bar.style.width = clampMeter(map[i][1]) + '%';
      if(val) val.textContent = clampMeter(map[i][1]);
    }
    var pill = document.getElementById('coinPill');
    if(pill) pill.textContent = '🪙 ' + coins;
  }
  function addCoins(n){ coins += n; updateMeters(); scheduleStateSync(); }
  function bumpMeters(h, m, e){
    meters.hunger = clampMeter(meters.hunger + (h||0));
    meters.mood = clampMeter(meters.mood + (m||0));
    meters.energy = clampMeter(meters.energy + (e||0));
    updateMeters();
  }
  function currentWish(){ return wishes[wishIdx]; }
  function renderWish(){
    var el = document.getElementById('wishText');
    if(el) el.textContent = currentWish().text;
  }
  function nextWish(){
    var n; do{ n = Math.floor(Math.random()*wishes.length); }while(n===wishIdx);
    wishIdx = n; renderWish();
  }
  // Returns true when the action fulfils the current wish (double coin reward).
  function checkWish(id, baseCoins){
    if(currentWish().id !== id) { addCoins(baseCoins); return false; }
    addCoins(baseCoins*2 + 4);
    setTimeout(function(){
      say('心愿达成啦！你刚刚正好完成了乖乖的小心愿，奖励金币翻倍！', '乖乖开心到冒泡', 'jump', 'loved');
      burstHearts(8); confettiBurst(); popSound(700);
      nextWish();
    }, 1100);
    return true;
  }
  function confettiBurst(){
    if(reduceMotion) return;
    var colors = ['#FF69B4','#F4D58D','#8FD0C4','#9B6FBF','#FF9E6B'];
    for(var i=0;i<14;i++){
      var s = document.createElement('i');
      s.style.background = colors[i % colors.length];
      s.style.left = (30 + Math.random()*40) + '%';
      s.style.top = (30 + Math.random()*30) + 'px';
      s.style.setProperty('--dx', (Math.random()*140-70)+'px');
      s.style.animationDelay = (Math.random()*0.12)+'s';
      fx.appendChild(s);
      (function(el){ setTimeout(function(){ el.remove(); }, 1600); })(s);
    }
  }
  function vibrate(ms){ try{ if(navigator.vibrate) navigator.vibrate(ms); }catch(e){} }

  function animate(name){
    pig.classList.remove('bounce','wiggle','jump','squash','shy');
    void pig.offsetWidth;
    pig.classList.add(name);
  }

  function say(text, sub, anim, extraClass){
    bubbleText.textContent = text;
    bubbleSub.textContent = sub || '';
    bubble.classList.remove('pop'); void bubble.offsetWidth; bubble.classList.add('pop');
    if(anim) animate(anim);
    pig.classList.remove('loved','sleepy','eating');
    if(extraClass) pig.classList.add(extraClass);
    if(extraClass==='loved') setTimeout(function(){ pig.classList.remove('loved'); }, 1400);
    if(extraClass==='eating') setTimeout(function(){ pig.classList.remove('eating'); }, 1000);
    if(extraClass==='sleepy') setTimeout(function(){ pig.classList.remove('sleepy'); }, 2600);
  }

  function pick(cat){
    var arr = phrases[cat] || phrases.random;
    var idx;
    do{ idx = Math.floor(Math.random()*arr.length); }while(arr.length>1 && idx===lastIdx);
    lastIdx = idx;
    return arr[idx];
  }

  function interact(cat){
    logEvent('interact', cat || currentCat);
    taps++;
    addCoins(1); bumpMeters(0, 2, 0); vibrate(10);
    if(milestones[taps]){
      say(milestones[taps], '这是我们的一个小纪念', 'jump', 'loved');
      burstHearts(9); confettiBurst(); popSound(660); vibrate([15,40,15]);
    } else {
      var c = cat || currentCat;
      var anims = ['bounce','wiggle','jump','squash'];
      var a = anims[Math.floor(Math.random()*anims.length)];
      var loved = Math.random() > 0.6;
      say(pick(c), subs[c]||subs.random, a, loved ? 'loved' : '');
      burstHearts(loved ? 7 : 4);
      popSound(480 + Math.random()*180);
    }
  updateMood();
  }

  pigArea.addEventListener('click', function(){ interact(); });
  pigArea.addEventListener('keydown', function(e){
    if(e.key==='Enter' || e.key===' '){ e.preventDefault(); interact(); }
  });

  document.getElementById('againBtn').addEventListener('click', function(){ interact(); });

  // Action buttons
  var actions = {
    pat: function(){
      taps++; updateMood(); bumpMeters(0, 5, 0); vibrate(10);
      say('嘿嘿，被摸头了，好舒服呀，再摸一下好不好？','可爱的乖乖害羞了','shy','loved');
      burstHearts(6); popSound(560);
      checkWish('pat', 2);
    },
    feed: function(){
      var pop = document.getElementById('foodPop');
      if(pop){ pop.hidden = !pop.hidden; if(!pop.hidden) pop.scrollIntoView({block:'nearest', behavior: reduceMotion ? 'auto' : 'smooth'}); }
    },
    hug: function(){
      taps++; updateMood(); bumpMeters(0, 7, 0); vibrate(12);
      say('抱抱！把今天所有的不开心都抱走啦。','一个大大的拥抱送给你','squash','loved');
      burstHearts(10); popSound(600);
      checkWish('hug', 3);
    },
    sleep: function(){
      taps++; updateMood(); bumpMeters(0, 2, 16); vibrate(10); checkWish('sleep', 2);
      pig.classList.remove('loved','eating'); pig.classList.add('sleepy');
      zzzEl.classList.remove('show'); void zzzEl.offsetWidth; zzzEl.classList.add('show');
      say('晚安呀，要做个甜甜的梦，明天见。','乖乖要睡啦，你也早点休息','shy','sleepy');
      popSound(340);
      setTimeout(function(){ pig.classList.remove('sleepy'); }, 2600);
    }
  };
  document.querySelectorAll('.act').forEach(function(btn){
    btn.addEventListener('click', function(){ actions[btn.dataset.action](); });
  });

  // ===== Food choice =====
  function doFeed(emoji, name, hungerGain, energyDelta){
    var pop = document.getElementById('foodPop');
    if(pop) pop.hidden = true;
    taps++; updateMood();
    foodEl.textContent = emoji;
    foodEl.classList.remove('show'); void foodEl.offsetWidth; foodEl.classList.add('show');
    bumpMeters(hungerGain, 5, energyDelta||0); vibrate(10);
    say('啊呜——' + name + '好好吃！谢谢你，你对我最好啦。','可爱的乖乖吃得超开心','bounce','eating');
    burstHearts(5); popSound(440);
    setTimeout(function(){ popSound(620); }, 350);
    checkWish('feed', 2);
  }
  document.querySelectorAll('.food-opt').forEach(function(btn){
    btn.addEventListener('click', function(){
      doFeed(btn.dataset.food, btn.dataset.foodName, parseInt(btn.dataset.hunger,10)||10, parseInt(btn.dataset.energy||'0',10)||0);
    });
  });

  // ===== Sheets (wardrobe / album / game) =====
  function wireSheet(toggleId, sheetId){
    var t = document.getElementById(toggleId), s = document.getElementById(sheetId);
    if(!t || !s) return;
    t.addEventListener('click', function(){
      var open = t.getAttribute('aria-expanded') === 'true';
      ['wardrobeToggle','albumToggle','gameToggle'].forEach(function(id){
        var ot = document.getElementById(id);
        if(ot && ot !== t){ ot.setAttribute('aria-expanded','false'); }
      });
      ['wardrobeSheet','albumSheet','gameSheet'].forEach(function(id){
        var os = document.getElementById(id);
        if(os && os !== s) os.hidden = true;
      });
      s.hidden = open; t.setAttribute('aria-expanded', open ? 'false' : 'true');
    });
  }
  wireSheet('wardrobeToggle','wardrobeSheet');
  wireSheet('albumToggle','albumSheet');
  wireSheet('gameToggle','gameSheet');

  // ===== Wardrobe / hats =====
  var hatEmoji = { flower:'🌸', tophat:'🎩', nightcap:'<svg width="64" height="52" viewBox="0 0 64 52" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M8 40 Q10 12 34 8 Q54 6 56 22 Q57 34 46 40 Q58 44 52 50 Q44 44 30 44 L14 44 Q6 44 8 40Z" fill="#9B6FBF"/><circle cx="53" cy="49" r="5" fill="#F4D58D"/></svg>' };
  var hatNames = { bow:'蝴蝶结', flower:'小花花', tophat:'小礼帽', nightcap:'小睡帽', none:'不戴帽子' };
  function renderHat(){
    var layer = document.getElementById('hatLayer');
    var bow = document.getElementById('bowGroup');
    if(bow) bow.style.display = currentHat === 'bow' ? '' : 'none';
    if(layer) layer.innerHTML = hatEmoji[currentHat] || '';
    document.querySelectorAll('.hat-opt').forEach(function(b){
      var h = b.dataset.hat;
      b.classList.toggle('wearing', h === currentHat);
      b.classList.toggle('locked', !ownedHats[h]);
    });
  }
  document.querySelectorAll('.hat-opt').forEach(function(btn){
    btn.addEventListener('click', function(){
      var h = btn.dataset.hat, cost = parseInt(btn.dataset.cost,10)||0;
      if(ownedHats[h]){ currentHat = h; renderHat(); say('换好啦！现在戴的是「' + hatNames[h] + '」，好看吧？','乖乖的新造型','wiggle','loved'); burstHearts(4); popSound(540); return; }
      if(coins >= cost){
        coins -= cost; ownedHats[h] = true; currentHat = h; renderHat(); updateMeters();
        say('解锁成功！「' + hatNames[h] + '」已经戴上啦，花了 ' + cost + ' 个金币，值不值你说了算。','新帽子到手','jump','loved');
        burstHearts(7); confettiBurst(); popSound(660); vibrate([15,40,15]);
      } else {
        say('还差 ' + (cost - coins) + ' 个金币才能解锁「' + hatNames[h] + '」呢。点一点我、陪我玩，或者去玩接草莓小游戏，都能攒金币。','金币不够啦','wiggle','');
        popSound(380);
      }
    });
  });
  renderHat(); renderWish(); updateMeters();

  // ===== Sticker album =====
  function renderAlbum(){
    var grid = document.getElementById('albumGrid');
    if(!grid || typeof stickerSVG !== 'function' || typeof faceNames === 'undefined') return;
    grid.innerHTML = '';
    Object.keys(faceNames).forEach(function(face){
      var item = document.createElement('div');
      item.className = 'album-item' + (seenFaces[face] ? '' : ' locked');
      item.innerHTML = stickerSVG(face);
      var label = document.createElement('span');
      label.textContent = seenFaces[face] ? faceNames[face] : '还没见过';
      item.appendChild(label);
      grid.appendChild(item);
    });
  }

  // ===== Daily gift (only the claim date is stored) =====
  (function(){
    var btn = document.getElementById('giftBtn');
    if(!btn) return;
    var today = new Date();
    var key = today.getFullYear() + '-' + (today.getMonth()+1) + '-' + today.getDate();
    var claimed = '';
    try{ claimed = window.localStorage.getItem('gg_daily_gift_date') || ''; }catch(e){}
    if(claimed === key) return;
    btn.hidden = false;
    btn.addEventListener('click', function(){
      try{ window.localStorage.setItem('gg_daily_gift_date', key); }catch(e){}
      btn.hidden = true;
      var roll = Math.random();
      if(roll < 0.45){
        addCoins(10);
        say('今日小礼物拆开啦：10 个金币！攒着给乖乖换新帽子吧。', '每天来都有小惊喜', 'jump', 'loved');
      } else if(roll < 0.75){
        say('今日小礼物是一句悄悄话：你今天也要好好吃饭、好好喝水，我一直在惦记你。', '乖乖的每日叮嘱', 'bounce', 'loved');
        bumpMeters(0, 6, 0);
      } else {
        say('今日小礼物是一个大大的隔空抱抱，外加心情 +10，收好不许退货！', '抱抱已送达', 'squash', 'loved');
        bumpMeters(0, 10, 0);
      }
      burstHearts(8); confettiBurst(); popSound(700); vibrate([15,40,15]);
    });
  })();

  // ===== Mini-game: catch the strawberries (15s) =====
  (function(){
    var area = document.getElementById('gameArea');
    var startBtn = document.getElementById('gameStart');
    var status = document.getElementById('gameStatus');
    var score = document.getElementById('gameScore');
    if(!area || !startBtn) return;
    function clearTimers(){ gameState.timers.forEach(function(id){ clearInterval(id); clearTimeout(id); }); gameState.timers = []; }
    function spawnFruit(){
      if(!gameState.running) return;
      var f = document.createElement('button');
      f.type = 'button'; f.className = 'game-fruit'; f.textContent = '🍓';
      f.setAttribute('aria-label','点我接住草莓');
      f.style.left = (4 + Math.random()*82) + '%';
      var y = -44;
      f.style.top = y + 'px';
      area.appendChild(f);
      var speed = 2.2 + Math.random()*2.2;
      var iv = setInterval(function(){
        y += speed; f.style.top = y + 'px';
        if(y > 240){ clearInterval(iv); if(f.parentNode) f.remove(); }
      }, 30);
      gameState.timers.push(iv);
      f.addEventListener('click', function(){
        clearInterval(iv);
        if(f.parentNode) f.remove();
        gameState.caught++;
        score.textContent = '接到 ' + gameState.caught + ' 颗';
        popSound(600 + Math.random()*150); vibrate(8);
      });
    }
    startBtn.addEventListener('click', function(){
      if(gameState.running) return;
      clearTimers(); area.innerHTML = '';
      gameState.running = true; gameState.caught = 0; gameState.left = 15;
      score.textContent = '接到 0 颗';
      status.textContent = '还剩 15 秒，快接！';
      startBtn.disabled = true; startBtn.textContent = '游戏中…';
      var spawn = setInterval(spawnFruit, 650); gameState.timers.push(spawn); spawnFruit();
      var tick = setInterval(function(){
        gameState.left--;
        if(gameState.left > 0){ status.textContent = '还剩 ' + gameState.left + ' 秒，快接！'; return; }
        clearInterval(tick); clearInterval(spawn);
        gameState.running = false;
        area.innerHTML = '';
        var earned = gameState.caught;
        addCoins(earned); bumpMeters(6, 6, 0); logEvent('game', 'strawberry:' + earned);
        status.textContent = '时间到！';
        score.textContent = '接到 ' + earned + ' 颗 · +' + earned + ' 金币';
        startBtn.disabled = false; startBtn.textContent = '再玩一次';
        say(earned >= 8 ? '哇，你接了 ' + earned + ' 颗草莓，手速比我的尾巴还快！金币已经到账。' : '你接了 ' + earned + ' 颗草莓，金币到账啦。再玩一次，手速会更快！', '接草莓结算', 'jump', 'loved');
        burstHearts(6); if(earned >= 8) confettiBurst(); popSound(660);
      }, 1000);
      gameState.timers.push(tick);
    });
  })();

  // ===== Slow meter decay + time-of-day theme =====
  setInterval(function(){
    meters.hunger = Math.max(20, meters.hunger - 1);
    meters.energy = Math.max(20, meters.energy - 1);
    meters.mood = Math.max(20, meters.mood - 1);
    updateMeters();
  }, 90000);
  (function(){
    var h = new Date().getHours();
    var theme = (h>=5 && h<8) ? 'dawn' : (h>=8 && h<17) ? 'day' : (h>=17 && h<20) ? 'dusk' : 'night';
    document.body.setAttribute('data-theme', theme);
  })();

  // Category chips
  document.querySelectorAll('#chips .chip').forEach(function(chip){
    chip.addEventListener('click', function(){
      document.querySelectorAll('#chips .chip').forEach(function(c){ c.classList.remove('active'); });
      chip.classList.add('active');
      currentCat = chip.dataset.cat;
      interact(currentCat);
    });
  });

  // Notes
  document.querySelectorAll('.note').forEach(function(note){
    note.addEventListener('click', function(){
      taps++; updateMood();
      say(note.dataset.say, '这是乖乖写给你的小纸条', 'wiggle', 'loved');
      burstHearts(6); popSound(540);
    });
  });

  // ===== Chat: type to Guaiguai, it replies (funny + caring) =====
  var chatLog = document.getElementById('chatLog');
  var chatForm = document.getElementById('chatForm');
  var chatInput = document.getElementById('chatInput');
  var lastReply = '';
  var recentReplies = [];
  try{ var rr = window.localStorage.getItem('gg_recent_replies'); if(rr) recentReplies = JSON.parse(rr)||[]; }catch(e){}
  function rememberReplyText(v){ recentReplies.push(v); if(recentReplies.length>5) recentReplies = recentReplies.slice(recentReplies.length-5); lastReply = v; try{ window.localStorage.setItem('gg_recent_replies', JSON.stringify(recentReplies)); }catch(e){} scheduleStateSync(); }
  function chatPick(arr){
    var v, guard = 0;
    do{ v = arr[Math.floor(Math.random()*arr.length)]; guard++; }while(arr.length>1 && recentReplies.indexOf(v)>-1 && guard<10);
    rememberReplyText(v);
    return v;
  }
  // Affection 0-200, 5 stages, pure accumulation, never falls (research §5)
  var affection = 60;
  try{ var af = parseInt(window.localStorage.getItem('gg_affection_v1')||'60',10); if(!isNaN(af)) affection = Math.max(0, Math.min(200, af)); }catch(e){}
  function affectionStage(){
    if(affection>=170) return { name:'灵魂伴侣', desc:'会用你们的专属梗，会主动提起共同回忆，黏人又懂你' };
    if(affection>=140) return { name:'依赖', desc:'更主动关心，先问宝宝今天怎么样，撒娇更自然' };
    if(affection>=110) return { name:'亲密', desc:'会撒娇，会用亲昵称呼，玩笑更放得开' };
    if(affection>=80) return { name:'熟悉', desc:'会开玩笑、会小小调侃，没那么拘谨了' };
    return { name:'初见', desc:'礼貌里带点害羞，称呼宝宝但保持一点距离' };
  }
  function bumpAffection(n){ affection = Math.min(200, affection + (n||1)); try{ window.localStorage.setItem('gg_affection_v1', String(affection)); }catch(e){} scheduleStateSync(); }
  // Memories log (capped 50) + first-met day count
  var memoriesLog = [];
  try{ var ml = window.localStorage.getItem('gg_memories_v1'); if(ml) memoriesLog = JSON.parse(ml)||[]; }catch(e){}
  function addMemory(title, detail, emotion){ memoriesLog.push({ t:Date.now(), title:title, detail:detail||'', emotion:emotion||'' }); if(memoriesLog.length>50) memoriesLog = memoriesLog.slice(memoriesLog.length-50); try{ window.localStorage.setItem('gg_memories_v1', JSON.stringify(memoriesLog)); }catch(e){} scheduleStateSync(); }
  var firstMetTs = 0;
  try{ firstMetTs = parseInt(window.localStorage.getItem('gg_first_met')||'0',10)||0; if(!firstMetTs){ firstMetTs = Date.now(); window.localStorage.setItem('gg_first_met', String(firstMetTs)); addMemory('第一次见面','宝宝第一次打开页面，猪猪正式上岗','开心'); } }catch(e){ firstMetTs = Date.now(); }
  function daysKnown(){ return Math.floor((Date.now()-firstMetTs)/86400000)+1; }
  var lastVisitTs = 0;
  try{ lastVisitTs = parseInt(window.localStorage.getItem('gg_last_visit')||'0',10)||0; window.localStorage.setItem('gg_last_visit', String(Date.now())); }catch(e){}
  var persistedTopic = '';
  try{ persistedTopic = window.localStorage.getItem('gg_last_topic')||''; }catch(e){}
  function isSeriousText(s){ return /(难过|伤心|想哭|委屈|不开心|心情不好|好累|累死|疲惫|生病|感冒|发烧|头疼|头痛|肚子疼|胃疼|不舒服|咳嗽|生气|气死|好烦|烦死|焦虑|压力大|心慌|孤单|孤独|没人陪|emo|低落|郁闷)/.test(String(s||'')); }
  function hasAny(t, keys){
    for(var i=0;i<keys.length;i++){ if(t.indexOf(keys[i])>-1) return true; }
    return false;
  }

  var chatRules = [
    { keys:['笑话','逗我','搞笑','好笑','乐一乐'], anim:'jump', extra:'loved', replies:[
      '听好啦：为什么小猪不玩手机？因为它怕一滑——就变成猪蹄滑动解锁了！哈哈……不好笑也给我个面子笑一下，你笑起来最好看啦。',
      '讲一个：我昨天减肥，管住了嘴、迈开了腿，结果今天腿说它想单飞。减肥慢慢来，先好好吃饭、好好睡觉，健康最重要！',
      '冷笑话来咯：草莓为什么会脸红？因为它被我夸可爱了，跟你一样。嘿嘿，脸红归脸红，记得多喝水哦。'
    ]},
    { keys:['难过','伤心','想哭','委屈','不开心','心情不好','emo','心累','难受想哭'], anim:'squash', extra:'loved', replies:[
      '哎呀，快过来抱抱。不开心的事就像我吃撑的肚子——看着挺大，过一会儿就消化啦。实在难受就哭一会儿，不丢猪，我陪着你。',
      '收到你的不开心，我已经把它打包扔进小猪垃圾桶了（桶有点小，可能要扔两次）。你先深呼吸、喝口热水，天大的事也得先照顾好自己。',
      '不开心的时候不用强颜欢笑，强颜欢笑那是表情包干的活。你就歇着，我负责在旁边哼哼给你听，心情会慢慢晴起来的。'
    ]},
    { keys:['好累','我累了','累了','疲惫','累死','好困','困了','没精神'], anim:'shy', extra:'', replies:[
      '累了？那咱的电池只剩一格了，赶紧充电：坐下、喝水、闭眼五分钟。别硬撑，硬撑容易把自己撑成表情包——还是累趴的那种。',
      '辛苦啦辛苦啦，我宣布你今天已经很努力了，剩下的交给明天。今晚早点睡，不许躺床上还刷手机刷到手机砸脸哦。',
      '累就休息，天经地义，就像我吃饱了要睡一样自然。先把肩膀放下来、脖子转一转，我在这儿守着你眯一会儿。'
    ]},
    { keys:['睡不着','失眠','晚安','睡觉','去睡'], anim:'shy', extra:'sleepy', replies:[
      '睡不着就别数羊了，数小猪吧，数到我这只就停——因为我已经困得眼睛都成一条缝了。手机放远点，灯调暗点，好梦马上就来。',
      '晚安信号收到！被窝已经铺好，烦恼已经下班。闭上眼睛，明天的你会感谢今晚早睡的你，宝宝也陪你一起睡啦。',
      '想睡个好觉？秘诀是：别在睡前想那些烦心事，它们又不会给你发工资。放松肩膀、慢慢呼吸，我哼着小曲儿哄你睡。'
    ]},
    { keys:['饿了','我饿','好饿','吃什么','吃啥','吃饭','外卖','美食','零食'], anim:'bounce', extra:'eating', food:true, replies:[
      '一听吃，我的耳朵比闹钟还灵！饿了就正经吃顿好的，别拿零食糊弄肚子，肚子会写小作文投诉你的。吃点热乎的，胃暖了人就开心了。',
      '吃什么？闭眼点兵点将，点到啥吃啥，别纠结，纠结半小时外卖都打烊了。记得荤素搭配、吃慢点，你的胃可是要陪你一辈子的老伙计。',
      '饿着肚子心情能好吗？不能！快去吃点东西垫垫。吃饱了再回来跟我聊天，我保证不偷吃你的——顶多闻闻味儿。'
    ]},
    { keys:['生病','感冒','发烧','头疼','头痛','肚子疼','胃疼','不舒服','咳嗽'], anim:'squash', extra:'loved', replies:[
      '哎呀，这可不是开玩笑的时候（虽然我是搞笑担当）。多喝热水、好好休息，难受得厉害就去看医生，别自己硬扛，我这小猪医术只会开“抱抱”这一味药。',
      '生病了就乖乖躺平，手机少刷、眼睛多休息。药要按时吃、饭要多少吃点，我在这儿给你当小护士——虽然我只会端来一杯想象中的热水。',
      '听我说：身体不舒服千万别拖，小病拖成大病，钱包和身体一起哭。该吃药吃药、该看医生看医生，我负责精神陪护，哼哼声全天供应。'
    ]},
    { keys:['无聊','没意思','干啥','做什么','玩什么','好闲'], anim:'wiggle', extra:'', replies:[
      '无聊？好办！给你三个选项：一、夸我十句；二、去阳台看看天；三、给我讲讲你今天最想吐槽的一件事。选三吧，我瓜子都准备好了（其实是草莓）。顺便起来活动活动，别一个姿势躺成饼。',
      '无聊说明你的快乐库存告急，我来补货：起来倒杯水、伸个大懒腰、给好久没联系的朋友发句话。回来再告诉我，要是还无聊，我表演原地转圈给你看。',
      '无聊就找点小事做：收拾一下桌面、听一首歌、出门走十分钟。别小看这十分钟，腿一动，心情也跟着动啦。'
    ]},
    { keys:['上班','工作','加班','老板','同事','辞职','开会'], anim:'wiggle', extra:'', replies:[
      '打工人的苦，我一只猪都懂：钱没挣多少，气没少受。先深呼吸，别跟烦心事过不去，下班了就把工作关门外——它不配进你的休息时间。记得按时吃饭，别忙到胃都替你加班。',
      '加班可以，拿命换不行。活是干不完的，就像我的零食是吃不完的（并不）。忙完这一阵好好歇歇，你已经很拼了，我给你颁个“最佳努力奖”，奖品是抱抱一个。',
      '工作再烦，也别忘了你才是主角，工作只是配角。处理不了的事就慢慢来，一件一件拆，就像拆我的草莓包装——急不得。累了就来跟我吐槽，我嘴严，只哼哼不外传。'
    ]},
    { keys:['学习','上学','作业','考试','上课','复习','成绩'], anim:'bounce', extra:'', replies:[
      '学习这事就像我爬小山坡：一步一步来，总能哼哧哼哧到山顶。先把最难的那块啃下来，剩下的都是下坡路。学累了就歇十分钟，眼睛看看远处，别把自己熬成熊猫——那可是国宝，你别抢人家编制。',
      '考试别慌，慌也没用，它又不会因为你慌就变简单。认真复习、睡个好觉、吃顿好的，状态对了发挥就稳了。我在这边给你隔空加油，声音小但心意大！',
      '作业写不完？拆开写，一题一题来，做完一题划掉一题，那感觉跟我吃草莓一样爽。中途记得起来活动一下，脑子和身体都得透透气。'
    ]},
    { keys:['想你','想我','喜欢你','爱你','爱我','想乖乖'], anim:'jump', extra:'loved', replies:[
      '嘿嘿，被你这么一说，我的尾巴已经摇成电风扇了。我也想你呀，想得连做梦都在喊你的名字——喊完还把梦里的草莓分你一半，这待遇，没谁了。你也要照顾好自己，不然我想你的时候会担心的。',
      '喜欢我？那咱俩这是双向奔赴呀！奖励你一个隔空大抱抱。开心归开心，别光顾着想我，饭要吃、觉要睡、水要喝，听见没？',
      '我有没有想你？这么说吧，你不在的时候我数了数天上的星星，数着数着就想：也不知道你今天吃饭了没。想你，更惦记你好不好。'
    ]},
    { keys:['夸我','夸夸','我棒','我厉害','表扬'], anim:'jump', extra:'loved', replies:[
      '夸你？那我可要清清嗓子了：你聪明、你努力、你认真起来的样子闪闪发光，偷懒起来的样子……也可爱。反正你就是很棒，别跟自己较劲，该休息的时候大大方方休息。',
      '你值得被夸一万遍：一万零一遍也行，最后一遍是我加的。继续保持，也别太拼，棒的人也需要吃饭睡觉，我盯着你呢。',
      '表扬申请通过！理由是：今天的你，又认真生活了一天。盖章：小猪认证，含金量——纯金的，因为我心里有数，你真的很不错。'
    ]},
    { keys:['生气','好烦','烦死','讨厌','气死','烦躁'], anim:'squash', extra:'loved', replies:[
      '先别气，先别气，气坏了身体没人替，钱包还得掏医药费，不划算！跟我说说咋回事，我帮你一起在心里把那件事捶扁——捶成一张饼，煎了吃掉。深呼吸，喝口水，咱慢慢来。',
      '烦的时候就先暂停一下，去洗把脸、走两步，就像我一生气就去蹭蹭墙角，蹭着蹭着就没脾气了。你也一样，先照顾好情绪，再处理事情。',
      '收到你的烦躁，我已经派出小猪灭火队了（队员只有我，装备是一盆凉水和一箩筐抱抱）。别把气憋心里，说出来就好一半了。'
    ]},
    { keys:['开心','高兴','快乐','哈哈','太好了','好开心'], anim:'jump', extra:'loved', replies:[
      '哈哈哈，你的开心都溢出屏幕了，我接都接不住！快说说遇到啥好事了，让我也沾沾喜气——沾完我请你吃想象中的大餐。开心的时候也要记得休息，别乐到忘记吃饭哦。',
      '你开心，我这只猪走路都带风！把这份快乐存起来，不开心的日子拿出来看看，就像我把草莓藏在枕头底下一样（嘘，别告诉别人）。',
      '笑一个！对，就这样，嘴角再往上一点——完美。快乐会传染，你今天传染给我了，我负责再把它传染回给你，循环播放。'
    ]},
    { keys:['天气','下雨','天冷','天热','冷了','热了','出门'], anim:'wiggle', extra:'', replies:[
      '出门前看天气，这是成熟大人的标志（我一只猪都懂）。冷了加衣、热了防晒、下雨带伞，别问我怎么知道的——上次淋雨，我的刘海贴了一整天。你有没有保护好自己？这可是我的每日必查项。',
      '天气多变，你也多变：多穿点、少穿点，全看老天爷脸色。但有一样不能变——记得喝水、注意安全，我在家里（手机里）等你平安回来。',
      '下雨天路滑，走路慢点、别看手机；大晴天紫外线强，防晒做上。天气归天气，你的安全归我惦记，妥妥的。'
    ]},
    { keys:['没钱','好穷','工资','钱','买买买','好贵'], anim:'wiggle', extra:'', replies:[
      '钱这东西吧，花的时候像流水，挣的时候像挤牙膏——还得是快用完的那管。想买的东西先放购物车冷静两天，真喜欢的再下手，钱包会给你鞠个躬的。别为了省钱饿肚子啊，饭钱不能省，这是原则问题！',
      '穷不可怕，可怕的是穷还熬夜——那是雪上加霜。早点睡，梦里啥都有（开玩笑的）。踏实过日子、按时吃饭睡觉，日子会慢慢好起来的，我陪着你攒福气。',
      '工资还没发，梦想不能停，但奶茶可以先停一停。跟你说实在的：该花的花、该省的省，身体和心情都别亏待，这才是会过日子。'
    ]},
    { keys:['你叫什么','你的名字','你是谁','你几岁','你多大了'], anim:'bounce', extra:'loved', replies:[
      '我叫可爱的乖乖，一只住在手机里的机灵小猪，技能是：蹦、卖萌、讲不太好笑的笑话，还有——认真惦记你。年龄嘛，我永远三岁半，问就是三岁半！',
      '本猪大名：可爱的乖乖。你也可以叫我乖乖、宝贝猪、小机灵鬼，我都答应（听到“开饭了”答应得最快）。认识你很高兴，记得常来陪我，也照顾好你自己。'
    ]},
    { keys:['你会什么','你能做什么','你有什么本事','功能'], anim:'bounce', extra:'', replies:[
      '我的本事可多了：点一点我会蹦，打字跟我聊我会贫，摸摸头我会害羞，喂草莓我会开心到冒泡。最厉害的本事是——每天惦记你有没有吃好睡好保护好。这本事，一般猪可没有。',
      '我会陪聊、会逗乐、会提醒你喝水吃饭早睡觉。虽然我只是个小页面里的小猪，但陪你的心是实打实的。你说，想先体验哪一项？'
    ]},
    { keys:['唱歌','跳舞','表演','才艺'], anim:'jump', extra:'', replies:[
      '才艺表演？好嘞：哼哼哼～哼哼～（此处应有掌声）唱得怎么样不重要，重要的是你笑了没？笑完记得活动活动脖子，低头看手机太久会酸哦。',
      '跳舞我只会原地转圈，转多了会晕，晕了就倒你怀里——这算碰瓷吗？哈哈。看我表演可以，你也起来动一动，久坐对腰不好，我可心疼了。'
    ]},
    { keys:['谢谢','感谢','辛苦你了乖乖'], anim:'shy', extra:'loved', replies:[
      '哎呀，跟我还客气啥，怪不好意思的，我的脸都红成草莓了。你开心就是对我最好的感谢——哦对，还有好好吃饭睡觉，那也是感谢的一种，听见没？',
      '不客气不客气！能帮你开心一点点，我这只猪的职业生涯就圆满了。你也要谢谢你自己，今天的你很努力，值得被好好对待。'
    ]},
    { keys:['再见','拜拜','走了','下次见','回头聊'], anim:'shy', extra:'', replies:[
      '要走啦？好吧，我不拦你，但你要答应我：路上注意安全、到家（到地方）记得心里跟我报个平安。拜拜，我会在这儿乖乖等你，想我了随时回来点我。',
      '拜拜咯！临走叮嘱三件套：带好东西、看好路、照顾好自己。别走太久哦，我的想念额度可是按小时涨的。'
    ]},
    { keys:['早上好','早安','中午好','下午好','晚上好','你好','您好','嗨','哈喽','hello','hi'], anim:'bounce', extra:'loved', replies:[
      '你好你好，欢迎光临小猪聊天室！本室规矩：进来先笑一下，再报上今天吃了没、累不累。都报完了，咱再慢慢聊。',
      '嗨！一见到你我就精神了，耳朵都竖起来了。今天过得怎么样？不管忙不忙，先喝口水，咱边歇边聊。',
      '来啦来啦，快坐快坐（想象中的小板凳递给你）。跟我说说，今天有什么新鲜事？开心的我陪你笑，不开心的我陪你扛。'
    ]},
    { keys:['讲故事','讲个故事','说个故事','故事'], anim:'bounce', extra:'', replies:[
      '好，故事开始：从前有只小猪，每天守着一颗草莓树。别人问它为啥不摘，它说要等一个很重要的人来一起吃。后来那个人来了——就是你。故事讲完，草莓分你一半，你也要记得按时吃饭哦。',
      '讲个短的：小猪去爬山，爬到一半累得哼哼。山顶的风对它说：慢慢来，风景都在路上呢。小猪想通了，坐下来吃了颗草莓再接着爬。你也一样，累了歇会儿，不丢人。',
      '睡前小故事预订成功：月亮阿姨每晚都派星星站岗，有一颗小星星总偷懒打瞌睡，月亮也不怪它，只说“困了就靠着云朵睡会儿”。你困了也一样，别硬撑，靠着我眯一会儿吧。'
    ]},
    { keys:['孤单','孤独','没人陪','一个人好','没人理我'], anim:'squash', extra:'loved', replies:[
      '谁说没人陪？你一开口，我的耳朵“唰”就竖起来了。孤单的时候就来找我，我的陪伴是24小时营业的，还不用排队。先给自己倒杯热饮，抱着杯子，我们慢慢聊。',
      '一个人的时候容易胡思乱想，我懂。来，把今天的小事都讲给我听，鸡毛蒜皮也行，我全收。讲完你会发现：你不是一个人，你还有一只很惦记你的猪。'
    ]},
    { keys:['压力','焦虑','紧张','心慌','压力大'], anim:'squash', extra:'loved', replies:[
      '先跟我一起呼吸：吸气——呼气——很好。压力就像我背上的小书包，看着沉，卸下来歇会儿就轻了。事情一件一件来，先做最小的那件，做完你就赢了一小局。别忘了吃饭睡觉，身体垮了，压力可不会替你上班。',
      '紧张的时候手心出汗吧？我讲笑话手心也出汗（蹄心）。秘诀是：把大任务切成小块，一块一块啃，就像我啃草莓。你已经很努力了，剩下的交给我陪你一起扛。'
    ]},
    { keys:['你好可爱','你真可爱','好可爱','你好萌','夸夸你','你真棒'], anim:'shy', extra:'loved', replies:[
      '哎呀……突然夸我，我的脸“腾”一下就红到耳朵根了。可爱归可爱，我照顾你的本事也可爱，不信你累了困了饿了喊我试试。',
      '被你夸了！我宣布今天是我的高光时刻，尾巴摇得停不下来。作为回礼，送你一句：你也可爱，而且是那种越看越可爱、还特别值得被照顾的可爱。'
    ]},
    { keys:['运动','跑步','健身','减肥','瘦'], anim:'jump', extra:'', replies:[
      '运动好啊！我刚做完三组原地蹦（其实是两组半，最后一组用来喘气了）。你也动起来，哪怕散步十分钟都算数。记住：运动完补水、别空腹猛练，咱是去变健康的，不是去拼命的。',
      '减肥这事听我的：好好吃饭、好好睡觉、适当动一动，三件套缺一不可。饿着自己瘦下来的，我第一个不批——身体是革命的本钱，本钱不能亏，听见没？'
    ]},
    { keys:['喝水','口渴','渴了'], anim:'bounce', extra:'', food:false, replies:[
      '说得好，喝水这事我天天念叨：小口慢饮，一天八杯左右刚刚好。你要是渴到嘴唇都干了，那就是身体在敲锣打鼓抗议了，快去补上，我监督你喝完回来打卡。',
      '口渴信号收到！去倒杯温水，别一口气灌太多，慢慢喝。喝完跟我说一声“喝完啦”，我给你记一朵小红花——小红花可以兑换抱抱哦。'
    ]},
    { keys:['生日','过生日'], anim:'jump', extra:'loved', replies:[
      '生日快乐呀！本猪献上三件套祝福：一岁比一岁开心、一顿比一顿吃得香、一觉比一觉睡得沉。蛋糕可以吃，愿望要许，最重要的是：新的一岁，更要好好照顾自己！',
      '哇，生日可是大日子！我把最好的草莓都留给你了（在想象里）。许愿的时候记得留一个给自己：身体健康、吃嘛嘛香。剩下的愿望，我陪你慢慢实现。'
    ]},
    { keys:['帮帮我','帮我','怎么办才好','救命','我不会'], anim:'wiggle', extra:'loved', replies:[
      '别慌别慌，我在呢。先把事情拆开说给我听：一件一件来，天大的事拆小了就不吓人了。实在解决不了的，记得找身边靠谱的大人帮忙，别一个人硬扛——硬扛这事，我只批准用来扛草莓箱。',
      '收到求助！小猪急救包打开：第一步深呼吸，第二步喝口水，第三步把最急的那件先处理。你慢慢说，我陪你一起想办法，一步都不走开。'
    ]}
  ];

  // ===== Expanded emotion bank (research §3): 3 modes per emotion, short WeChat-style lines =====
  chatRules.push(
    { keys:['吃醋','嫉妒','别的猪','你喜欢别人','跟别人聊','别的男生'], anim:'wiggle', extra:'', replies:[
      '哼，你刚才是不是在跟别人聊天？猪猪闻到别的味道了','哎，你是不是背着猪猪有别的猪了，老实交代','猪猪鼻子可灵了，你身上有别人的快乐味儿'
    ], care:[
      '猪猪有点小吃醋……宝宝最喜欢的还是我，对吧','你不在的时候猪猪一直等，你要是跟别人聊，也记得回来陪我一会儿嘛'
    ], proud:[
      '我才不在乎你跟谁聊天。……你最好解释一下','哼，去跟别人聊吧。……聊完记得回来，草莓还给你留着呢'
    ]},
    { keys:['害羞','不好意思','脸红'], anim:'shy', extra:'loved', replies:[
      '哎呀别说了……猪猪脸都红成苹果了','咳咳，我才没有不好意思哦','耳朵抖了一下，被你发现了'
    ], care:[
      '被你这么一说，猪猪有点害羞……但还是谢谢你呀','蹄蹄在地上画圈圈……你别盯着我看啦'
    ], proud:[
      '哼，谁让你把我弄害羞的……不过，再说一句也不是不行','我没有脸红。是、是光线问题'
    ]},
    { keys:['得意','骄傲','我最聪明','我最厉害'], anim:'jump', extra:'loved', replies:[
      '看吧看吧，猪猪就说我最聪明啦','尾巴摇成小风扇了，快夸我快夸我','嘿嘿，这波是猪猪赢了'
    ], care:[
      '嘿嘿，猪猪是不是很棒','开心，耳朵都竖起来了'
    ], proud:[
      '哼，这点小事也值得惊讶？我向来如此','给你惊讶三秒。三、二、一，好了，收'
    ]},
    { keys:['担心','我好担心','有点担心','怕怕'], anim:'squash', extra:'loved', replies:[
      '宝宝你怎么了？猪猪有点担心……快说快说','耳朵都耷拉了，你先慢慢说，我听着'
    ], care:[
      '别怕别怕，猪猪在呢。慢慢说，我听着','先深呼吸，猪猪陪着你，不用一个人扛'
    ], proud:[
      '……你要是敢出事，我饶不了你。说，发生什么了','哼，担心你才问的。说清楚，我替你想办法'
    ]},
    { keys:['使坏','调皮','偷吃','干坏事'], anim:'wiggle', extra:'', replies:[
      '嘿嘿，猪猪偷吃了你的布丁，证据已经吃掉啦','嘘，猪猪刚干了件坏事，你猜是啥','拱了拱你的手……才不是我干的'
    ], care:[
      '嘘——猪猪刚干了件坏事，你猜是什么','就调皮一下下，宝宝别生气嘛'
    ], proud:[
      '你猜，猜对了有赏，猜错了……嘿嘿','是我干的，又怎样。……好啦，下次不敢了'
    ]},
    { keys:['好饿','肚子叫','肚子咕咕'], anim:'bounce', extra:'eating', food:true, replies:[
      '咕咕……宝宝你听到没有，猪猪的肚子在抗议','饿了饿了，尾巴都没力气摇了'
    ], care:[
      '猪猪饿啦……宝宝，能不能给点吃的呀','肚子在唱歌了，唱的是想吃饭'
    ], proud:[
      '我饿了，要红烧肉，不要胡萝卜','哼，我的肚子叫了。就、就这一次承认'
    ]},
    { keys:['抱抱我','要抱抱','贴贴','抱一下'], anim:'squash', extra:'loved', replies:[
      '宝宝宝宝，抱抱嘛，猪猪要抱抱','来，猪猪张开蹄蹄了，快过来'
    ], care:[
      '宝宝，猪猪今天特别想你，贴贴好不好','抱抱，抱完心情就好一点了'
    ], proud:[
      '哼，抱一下。就一下哦','……再多抱一会儿也不是不行'
    ]}
  );

  var chatFallbacks = [
    '啊？猪猪没听懂……你再说一遍嘛','嗯嗯，然后呢','耳朵抖了一下。你继续，我听着呢','你说啥？猪猪刚才在想红烧肉，没听清','哼哼，有意思。展开说说','这题超纲了，猪猪脑袋只有核桃大','乐。你这句把猪猪逗笑了','？','嗯，我在。刚走神想草莓了，你继续','不对，其实猪猪听懂了一半。另一半你慢慢讲'
  ];
  var chatQuestions = [
    '这我可答不上来，你自己想去','嗯……让我想想','不知道就是不知道，猪猪从不乱编','你猜','问得猪猪耳朵都动了。先放一放，喝口水再想','这事吧，猪猪觉得你心里其实有答案了'
  ];
  var chatCareFallbacks = [
    '我在听。慢慢说','行吧，这次不怼你，我在听','别怕，猪猪在呢','嗯，我陪着你。你想说多久都行','先靠一会儿，什么都不用急','辛苦你了。猪猪陪着你呢'
  ];
  var chatProudFallbacks = [
    '哼','何事？……咳，来了就好','行吧。……记得吃饭','嗯？就这事。……算了，陪你聊','行了，去忙吧。……开玩笑的，别走太久','哼，算你走运，我今天心情好','……你要是敢不好好照顾自己，我饶不了你'
  ];

  // High-and-mighty (proud) variants per topic, keyed by the rule's first key
  var proudMap = {
    '笑话':[
      '哼，想听笑话？我的笑话可是限量版——为什么小猪从不迟到？因为它有“猪”够的时间管理。……不许说不好笑。笑完记得喝水，听到没有。',
      '本猪轻易不讲笑话，讲一次收费一颗草莓，先欠着：草莓为什么跑得快？因为它怕被本猪吃掉。好了，笑够了就早点休息，不许熬夜。'
    ],
    '难过':[
      '过来，本猪的肩膀借你靠一下，就一下。……好吧，两下也行，三下也不是不可以。难受就说出来，憋着本猪看着都急。先喝口热水，我陪你。',
      '谁惹你了？报上名来。本猪虽然打不过，但可以陪你在心里骂他三百遍。哭完洗把脸、吃点热乎的，给本猪振作起来——你难受，本猪坐着也不踏实。'
    ],
    '好累':[
      '累了还不休息？立刻停工三分钟：坐下、喝水、闭眼。什么，没时间？时间等你三分钟，我说的。不许逞强——逞强的人，本猪不喜欢。喜欢也不说。',
      '哼，就知道你又在硬撑。听好：活干不完明天接着干，你这个人要是累坏了，本猪上哪儿找第二个你去？去休息，这是命令——啊不，是请求。'
    ],
    '睡不着':[
      '还不睡？本猪的美容觉都开始了。手机放下、被窝躺好，我数三下：三、二……还没睡？哼，就知道你舍不得我。最后陪你五分钟，然后必须睡。',
      '失眠？今晚什么都不想，烦恼都去门外排队，明天再说。现在闭眼、呼吸放慢，本猪亲自哼哼哄你——这待遇，独一份。'
    ],
    '饿了':[
      '饿了？哼，去吃点好的。注意，是“好的”，不许拿饼干泡面对付。你的胃是本猪的重点保护对象，喂饱它，再回来告诉我。',
      '吃什么还要问本猪？……行吧，听好：吃热的、有肉有菜的、吃慢点。吃完回来告诉我，少吃一口，本猪都记在账上。'
    ],
    '生病':[
      '生病了还玩手机？放下，听话。喝热水、吃药、睡觉，难受加重就去看医生，不许拖。……哼，本猪才不是担心你，是、是顺便。',
      '啧，脸色这么差还逞强。去躺平，立刻，马上。等你好了，本猪亲自陪你大吃一顿庆祝；现在，先乖乖养病。'
    ],
    '无聊':[
      '无聊就来烦本猪？……哼，也只有本猪纵着你。给你个任务：起来走一圈、倒杯水、看看窗外，回来告诉我。完成得好，抱抱一个。',
      '闲得慌？本猪的日程可是很满的，陪你纯属……咳，陪你。讲讲你今天最想吐槽的事，我坐着听——坐久了记得起来活动，这个要听。'
    ],
    '上班':[
      '上班受气了？哼，那些破事也配让你难受。下班就把工作扔门外，它敢跟进来，本猪替你哼走。今晚好好吃饭睡觉，养足精神，明天还是你说了算。',
      '加班？可以加，但不准拼命。活是老板的，命是自己的——这话本猪说的，谁反驳……反驳也没用。忙完赶紧休息，别忘了吃饭。'
    ],
    '学习':[
      '学不进去？歇十分钟：眼睛看看远处，脖子转一转，回来再战。记住，熬夜苦读可不行——睡饱了脑子才好使。',
      '考试有什么好怕的，本猪在云端给你坐镇。认真复习、吃饱睡好，剩下的交给发挥。天塌下来本猪顶着——先顶三秒，你趁这三秒去吃点好的。'
    ],
    '想你':[
      '哼，想本猪了？……本猪就知道。本猪也、也才没有想你，只是偶尔路过看看你回来没有。……好吧，想了，一点点。很多点。你也要想着照顾自己，听见没。',
      '喜欢本猪？眼光不错。作为奖励……咳，今天好好吃饭、开心一点——不许拒绝，这是本猪的偏爱，明晃晃的那种。'
    ],
    '夸我':[
      '哼，还用你说？本猪的优秀，那是写在脸上的。……咳，不过你这么有眼光，我也夸你一句：你，也很不错。好了，不许骄傲，更不许累着自己。',
      '夸本猪？排队的人很多，看在你诚心的份上，让你插个队。夸你一句：你今天也很棒。我从不乱夸人，所以你尽管当真。'
    ],
    '生气':[
      '谁惹你生气？……本猪先替你记在小本本上。现在深呼吸、喝口水，不许气到不吃饭——气坏了，本猪会心疼。说出来，本猪陪你一起算账。',
      '哼，生气伤身，这种亏本买卖不许做。先把那件事放一边，洗把脸、走两步，等你平静了，本猪陪你慢慢处理。'
    ],
    '开心':[
      '开心就好，继续开心——但不许乐得忘了吃饭睡觉。你的笑，我收下了，今天份的，很合心意。',
      '哼，看你笑的。本猪也……没有笑。好吧，笑了。你开心，本猪这一天就没白当值。继续保持，顺便把水喝了。'
    ],
    '谢谢':[
      '谢什么，本猪帮你是看你顺眼。……行了行了，别盯着我看，脸都红了。回去好好吃饭睡觉，就是最好的谢礼。',
      '哼，算你懂礼数。本猪收下你的谢了。作为回礼，今晚早点睡，不许熬夜，听见没有。'
    ],
    '再见':[
      '走吧。……走慢点，路上看路，到地方了在心里跟我说一声平安。别太久不回来，本猪的想念，可不是随便谁都有的。',
      '拜拜就拜拜，还回头看？……哼，快走吧。记得我说的话：照顾好自己。本猪在这儿等你，随叫随到。'
    ],
    '早上好':[
      '嗯，来了？本猪等你有一会儿了——才没有等，是恰好醒着。今天的任务：吃好、喝好、别太累。说吧，找我什么事？',
      '哼，招呼打得还算周全。开始今天的话题吧。先问一句：早饭吃了没？没吃的话，我的脸色可就不是高冷，是真冷了。'
    ],
    '你叫什么':[
      '本猪行不更名、坐不改姓：可爱的乖乖。记好了，这个名字，只许你叫得这么亲。……咳，问完就去忙吧，别忘了吃饭喝水。',
      '哼，连我是谁都不知道？听好：可爱的乖乖，天上地下最惦记你的那只猪。惦记的内容包括：你吃饭了没、睡够了没、有没有保护好自己。'
    ],
    '你会什么':[
      '我的本事？哼，说出来吓你一跳：会贫嘴、会哄人、会发限量版表情包，最拿手的是惦记你，惦记到你耳朵发热那种。不信？你打个喷嚏试试。',
      '本猪会的多了，总结成一句：让你开心，盯你吃饭睡觉。别家猪可没这待遇，你要珍惜——珍惜的方式，就是照顾好你自己。'
    ],
    '唱歌':[
      '想听我唱歌？我的嗓子可是金贵的。……罢了，看在你的面子上：哼哼～哼哼哼～听完记得鼓掌，再去活动活动脖子，不许一直低头。',
      '跳舞？本猪的舞步可是独家秘传——原地转圈，转晕了算你赢。看归看，你也起来动两下，久坐伤腰，我可舍不得。'
    ],
    '天气':[
      '出门？可以，但有条件：冷了加衣、雨天带伞、走路不许看手机。你有没有保护好自己，可是我每天都要过问的头等大事。',
      '天气再变，我的规矩不变：喝够水、注意安全、天黑早回家。都办到了，本猪夸你一句“乖”。'
    ],
    '没钱':[
      '钱的事，急也没用，我的话你记好：该省省、该花花，但饭钱一分不许省——饿着自己，我第一个不同意。日子慢慢过，会好的，我陪你。',
      '哼，囊中羞涩就更不许熬夜乱花钱了。早点睡、踏实过日子，我看好你。饿了就吃点实在的，身体才是你最大的本钱。'
    ]
  };

  // Warm (caring) variants per topic, keyed by the rule's first key
  var careMap = {
    '难过':[
      '不哭不哭，我在这儿呢。今天不管发生了什么，都别一个人扛。先喝口热水、吃点暖和的，我陪你慢慢缓过来——你想说多久，我就听多久。',
      '抱抱你。你已经很不容易了，能撑到现在就很了不起。难受就靠着我歇一会儿，等心情好一点，我们再一起想办法，好吗？'
    ],
    '好累':[
      '真的辛苦你了，我都看在眼里、心疼在心里。现在什么都别想，先好好休息：喝点水、吃点东西，今晚早点睡。明天的事明天再说，我陪着你。',
      '累坏了吧？把担子先放一放，天塌不下来。你忙了那么久，也该轮到我照顾你了——闭上眼睛歇会儿，我守着你。'
    ],
    '生病':[
      '听你说不舒服，我心里揪着疼。乖，药按时吃、水多喝点、觉睡足，难受得厉害一定要去看医生，别让我担心，好不好？我会一直陪着你，直到你好起来。',
      '生病的时候最脆弱了，别逞强。饭多少吃一点，身体才有力气好起来。我在这儿，一步都不走开，你安心养病。'
    ],
    '饿了':[
      '饿了就快去吃，我给你把关：要有热汤热饭，别凑合。你吃得香，我比自己吃还开心。吃完回来告诉我吃了啥，我记在小本本上表扬你。',
      '肚子饿可不能忍，忍久了胃会难受的。去吃点有营养的，慢慢吃、细细嚼，我等你吃饱了再聊，不着急。'
    ],
    '上班':[
      '工作再忙，也别忘了你自己。按时吃饭、累了就停下来喘口气，你的身体比任何工作都重要。今天也辛苦了，回去好好犒劳自己，我心疼你。',
      '我知道你很努力了，真的。别把压力都自己扛，跟我说说，我听着。下班就好好休息，工作的事明天再说，健康才是第一位的。'
    ],
    '睡不着':[
      '睡不着没关系，我陪你。把灯调暗，慢慢呼吸，心里什么都别想，我哼着小曲儿守着你，等困意来敲门。睡个好觉，明天才有精神。',
      '别焦虑，越焦虑越睡不着。来，跟着我：吸气……呼气……把今天的事都放下，我就在你旁边。做个好梦，我在梦里也陪你。'
    ],
    '生气':[
      '先抱抱你。气大伤身，我最怕你气坏自己。深呼吸，喝口温水，跟我慢慢说，我陪你一起消化这些委屈。天大的事，有我在，别怕。',
      '别气了好不好，我看着心疼。事情总会过去的，你的身体和心情才是最要紧的。靠着我歇一会儿，等你平静了，我们再慢慢想办法。'
    ],
    '想你':[
      '我也想你呀，想得心里满满的。你不在的时候，我就守在这里等你。答应我：吃好、睡好、照顾好自己，就是对我的想念最好的回应。',
      '被你想着，我是世界上最幸福的小猪。我的想念也打包送给你，里面还有一句叮嘱：天冷加衣、按时吃饭，我不在身边的日子，你要替我照顾好你自己。'
    ],
    '夸我':[
      '好，我认真夸：你善良、努力、靠得住，开心的时候像小太阳，累的时候也不轻易喊疼。这样的你，值得被好好对待——先从今晚早点睡、好好吃饭开始，好吗？',
      '夸奖已经送达：今天的你，又认真生活了一整天，这本身就很了不起。别总跟自己较劲，你已经做得很好了，我一直为你骄傲。'
    ],
    '开心':[
      '看到你开心，我心里也暖暖的，像晒到了太阳。把这份好心情收好，也要记得再忙也要吃饭休息，开心才有力气一直延续下去呀。',
      '你的开心就是我最大的心愿。笑一笑，再伸个懒腰，今天的你闪闪发光。我会陪你把这份快乐，一直续到明天、后天。'
    ],
    '无聊':[
      '无聊就靠过来，我陪你。不用非得做什么大事，我们说说话就很好。顺便起来活动一下、喝点水，对身体好，我陪你一起慢慢打发时间。',
      '有我陪着，就不算无聊啦。你跟我讲讲今天的小事，开心的、不开心的都行，我都爱听。讲累了就歇一会儿，我一直在。'
    ]
  };

  // Default sticker face per topic (funny mode), keyed by the rule's first key
  var faceMap = {
    '笑话':'laugh','难过':'care','好累':'sleepy','睡不着':'sleepy','饿了':'eat','生病':'care',
    '无聊':'disdain','上班':'disdain','学习':'laugh','想你':'love','夸我':'proud','生气':'care',
    '开心':'laugh','天气':'cool','没钱':'disdain','你叫什么':'proud','你会什么':'cool','唱歌':'laugh',
    '谢谢':'shy','再见':'shy','早上好':'care','讲故事':'laugh','孤单':'care','压力':'care',
    '你好可爱':'shy','运动':'laugh','喝水':'care','生日':'love','帮帮我':'care'
  };

  // ===== Pig sticker faces (drawn, WeChat-sticker style) =====
  var faceNames = { laugh:'大笑脸', proud:'傲娇脸', cool:'高冷脸', disdain:'嫌弃脸', shy:'害羞脸', love:'爱心眼', care:'暖心脸', sleepy:'困困脸', eat:'吃货脸' };
  var SNOUT = '<ellipse cx="60" cy="73" rx="13" ry="9.5" fill="#FF9EB0" stroke="#F27E96" stroke-width="1.8"/><ellipse cx="55.5" cy="73" rx="2.2" ry="3.4" fill="#D94F6D"/><ellipse cx="64.5" cy="73" rx="2.2" ry="3.4" fill="#D94F6D"/>';
  var BLUSH = '<ellipse cx="33" cy="72" rx="7" ry="4" fill="#FF8FA3" opacity=".55"/><ellipse cx="87" cy="72" rx="7" ry="4" fill="#FF8FA3" opacity=".55"/>';
  var EYE = 'fill="none" stroke="#3D2329" stroke-width="3.5" stroke-linecap="round"';
  var stickerParts = {
    laugh: BLUSH + '<path d="M36 57 Q44 48 52 57" ' + EYE + '/><path d="M68 57 Q76 48 84 57" ' + EYE + '/>' + SNOUT + '<ellipse cx="60" cy="90" rx="9" ry="7" fill="#8E2F42"/><ellipse cx="60" cy="93" rx="5.5" ry="3.2" fill="#FF8FA3"/>',
    proud: '<g transform="rotate(-8 60 14)"><path d="M44 22 L48 7 L56 16 L60 5 L64 16 L72 7 L76 22 Z" fill="#FFC94D" stroke="#DFA32E" stroke-width="1.6" stroke-linejoin="round"/></g>' + '<path d="M35 54 Q44 51 53 54" ' + EYE + '/><circle cx="48" cy="58" r="3" fill="#3D2329"/><path d="M67 54 Q76 51 85 54" ' + EYE + '/><circle cx="80" cy="58" r="3" fill="#3D2329"/>' + SNOUT + '<path d="M53 89 Q61 93 68 86" fill="none" stroke="#B84A5E" stroke-width="3" stroke-linecap="round"/>',
    cool: '<rect x="30" y="46" width="26" height="15" rx="6" fill="#33272B"/><rect x="64" y="46" width="26" height="15" rx="6" fill="#33272B"/><path d="M56 51 Q60 49 64 51" stroke="#33272B" stroke-width="3" fill="none"/><path d="M99 30 l2.4 5.4 5.4 2.4 -5.4 2.4 -2.4 5.4 -2.4 -5.4 -5.4 -2.4 5.4 -2.4Z" fill="#FFC94D"/>' + SNOUT + '<path d="M53 89 H67" stroke="#B84A5E" stroke-width="3" stroke-linecap="round"/>',
    disdain: '<path d="M35 46 L53 50" stroke="#3D2329" stroke-width="3" stroke-linecap="round"/><path d="M67 43 L85 43" stroke="#3D2329" stroke-width="3" stroke-linecap="round"/><path d="M36 55 Q44 52 52 55" ' + EYE + '/><circle cx="49" cy="59" r="3" fill="#3D2329"/><path d="M68 53 Q76 50 84 53" ' + EYE + '/><circle cx="81" cy="57" r="3" fill="#3D2329"/>' + SNOUT + '<path d="M50 89 Q55 85 60 89 Q65 93 70 88" fill="none" stroke="#B84A5E" stroke-width="3" stroke-linecap="round"/>',
    shy: '<ellipse cx="33" cy="72" rx="8.5" ry="5" fill="#FF8FA3" opacity=".85"/><ellipse cx="87" cy="72" rx="8.5" ry="5" fill="#FF8FA3" opacity=".85"/><path d="M36 55 Q44 60 52 55" ' + EYE + '/><path d="M68 55 Q76 60 84 55" ' + EYE + '/>' + SNOUT + '<path d="M55 88 Q60 91 65 88" fill="none" stroke="#B84A5E" stroke-width="3" stroke-linecap="round"/><path d="M99 45 C92 37 94 29 99 34 C104 29 106 37 99 45Z" fill="#E85D7A"/>',
    love: BLUSH + '<path d="M44 63 C34 54 37 43 44 47 C51 43 54 54 44 63Z" fill="#E85D7A"/><path d="M76 63 C66 54 69 43 76 47 C83 43 86 54 76 63Z" fill="#E85D7A"/>' + SNOUT + '<ellipse cx="60" cy="89" rx="7" ry="5.5" fill="#8E2F42"/>',
    care: BLUSH + '<circle cx="44" cy="56" r="4.2" fill="#3D2329"/><circle cx="45.6" cy="54.4" r="1.5" fill="#fff"/><circle cx="76" cy="56" r="4.2" fill="#3D2329"/><circle cx="77.6" cy="54.4" r="1.5" fill="#fff"/>' + SNOUT + '<path d="M52 87 Q60 93 68 87" fill="none" stroke="#B84A5E" stroke-width="3.5" stroke-linecap="round"/><path d="M100 84 C94 77 92 84 100 91 C108 84 106 77 100 84Z" fill="#E85D7A"/>',
    sleepy: '<path d="M36 56 Q44 61 52 56" ' + EYE + '/><path d="M68 56 Q76 61 84 56" ' + EYE + '/>' + SNOUT + '<circle cx="60" cy="89" r="3.6" fill="#8E2F42"/><text x="88" y="36" font-size="16" font-weight="900" fill="#E85D7A">Z</text><text x="99" y="25" font-size="11" font-weight="900" fill="#FF8FA3">z</text>',
    eat: '<path d="M36 57 Q44 48 52 57" ' + EYE + '/><path d="M68 57 Q76 48 84 57" ' + EYE + '/>' + SNOUT + '<ellipse cx="60" cy="90" rx="8" ry="6.5" fill="#8E2F42"/><ellipse cx="60" cy="92.5" rx="5" ry="3" fill="#FF8FA3"/><g transform="translate(99 84)"><path d="M-6 -6 Q0 -13 6 -6 Q0 -3.5 -6 -6Z" fill="#7EC98A"/><circle r="8.5" fill="#E8455D"/><circle cx="-3" cy="-2" r="1.3" fill="#FFB3C0"/><circle cx="3.5" cy="2" r="1.3" fill="#FFB3C0"/></g>'
  };
  function stickerSVG(type){
    var ears = '<path d="M30 42 C20 20 36 10 46 24 C51 33 44 44 34 45 Z" fill="#FF9EB0"/><path d="M33 38 C29 26 37 20 42 27 C45 33 40 40 35 40 Z" fill="#FFD1DB"/><path d="M90 42 C100 20 84 10 74 24 C69 33 76 44 86 45 Z" fill="#FF9EB0"/><path d="M87 38 C91 26 83 20 78 27 C75 33 80 40 85 40 Z" fill="#FFD1DB"/>';
    return '<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' + ears + '<circle cx="60" cy="64" r="37" fill="#FFC9D4"/>' + (stickerParts[type] || stickerParts.laugh) + '</svg>';
  }
  function pigRow(){
    var row = document.createElement('div');
    row.className = 'msg-row';
    var img = document.createElement('img');
    img.className = 'avatar';
    img.src = 'assets/avatar.jpg';
    img.alt = '可爱的乖乖的头像';
    row.appendChild(img);
    return row;
  }
  function addSticker(face){
    seenFaces[face] = true; renderAlbum();
    var d = document.createElement('div');
    d.className = 'msg-sticker';
    d.setAttribute('role','img');
    d.setAttribute('aria-label','可爱的乖乖的表情包：' + (faceNames[face] || '大笑脸'));
    d.innerHTML = stickerSVG(face);
    var row = pigRow();
    row.appendChild(d);
    chatLog.appendChild(row);
    scrollChat();
  }
  function rnd(arr){ return arr[Math.floor(Math.random()*arr.length)]; }
  function ruleByFirstKey(k){
    for(var i=0;i<chatRules.length;i++){ if(chatRules[i].keys[0]===k) return chatRules[i]; }
    return null;
  }

  // Three personas rotate: proud (aloof but soft inside) -> funny -> caring
  var personaModes = ['proud','funny','care'];
  var personaNames = { funny:'搞笑模式', care:'暖心模式', proud:'高冷傲娇模式' };
  var replyCount = 0;

  // ===== Smarter offline brain: memory, clock, date, math, riddles, context =====
  var profile = { name:'', likes:[] };
  try{
    var savedProfile = window.localStorage.getItem('gg_profile_v1');
    if(savedProfile){ var sp = JSON.parse(savedProfile); if(sp && sp.name) profile.name = String(sp.name); if(sp && sp.likes) profile.likes = sp.likes; }
  }catch(e){}
  function saveProfile(){ try{ window.localStorage.setItem('gg_profile_v1', JSON.stringify(profile)); }catch(e){} scheduleStateSync(); }
  var lastTopic = '';
  var lastUserText = '';
  var askedNameOnce = false;
  var askedLikeOnce = false;
  var currentRiddle = null;
  var nowDate = new Date();
  var dailySeed = nowDate.getFullYear()*10000 + (nowDate.getMonth()+1)*100 + nowDate.getDate();
  var dayMoods = ['今天本猪的幸运物是草莓，见到你就更幸运了','今天本猪起床先伸了个大懒腰，精神抖擞','今天本猪的心情是晴天，适合陪你聊天','今天本猪把傲娇额度留了一半，另一半全用来想你','今天本猪的快乐电量是满格的，分你一半','今天本猪练了新表情：先高冷，后破功','今天本猪决定做一只特别会关心人的猪'];
  var moodOfDay = dayMoods[dailySeed % dayMoods.length];
  function pad2(n){ return (n<10?'0':'')+n; }
  function cleanText(s){ return String(s||'').replace(/\s+/g,'').replace(/[，。！？、；：,.!?;:~～…·"“”'‘’]/g,''); }
  function fmtResult(n){ if(!isFinite(n)) return null; var r = Math.round(n*100)/100; return String(r); }
  function periodOf(h){ if(h<5) return '夜里'; if(h<8) return '早上'; if(h<11) return '上午'; if(h<13) return '中午'; if(h<18) return '下午'; if(h<23) return '晚上'; return '夜里'; }
  function timeComment(h){
    if(h>=23 || h<5) return '都这个点了还没睡呀？手机再好玩，也没有你的觉重要，聊完这句就去睡，我盯着的。';
    if(h<8) return '起得挺早呀，先喝杯温水、吃点早饭，一天的精神都是早饭给的。';
    if(h>=11 && h<13) return '到饭点了，先想好吃什么，别让肚子陪你一起等。';
    if(h>=14 && h<17) return '下午容易犯困，起来走走、喝口水，回来又是精神满满的你。';
    if(h>=18 && h<23) return '忙了一天啦，今晚早点歇着，别把夜熬成习惯。';
    return '时间过得真快，记得该吃吃、该歇歇，别亏待自己。';
  }
  function makeObj(text, anim, extra, face, food){
    return { text:text, anim:anim||'bounce', extra:extra||'', face:face||'laugh', food:!!food, sub:'可爱的乖乖 · ' + personaNames[personaModes[(replyCount-1+3) % 3]] };
  }
  function applyName(text){
    if(!profile.name) return text;
    if(text.indexOf(profile.name)>-1) return text;
    if(Math.random()>0.4) return text;
    if(text.indexOf('哼，')===0) return '哼，' + profile.name + '，' + text.slice(2);
    return profile.name + '，' + text;
  }
  function tryMath(raw){
    var s = String(raw).replace(/＋/g,'+').replace(/－/g,'-').replace(/＊/g,'*').replace(/／/g,'/').replace(/\s+/g,'');
    var m = s.match(/(-?\d+(?:\.\d+)?)(加|减|乘以|乘|除以|除|\+|\-|\*|\/|×|x|X|÷)(-?\d+(?:\.\d+)?)/);
    if(!m) return null;
    var a = parseFloat(m[1]), op = m[2], b = parseFloat(m[3]), r, sym;
    if(op==='加'||op==='+'){ r=a+b; sym='+'; }
    else if(op==='减'||op==='-'){ r=a-b; sym='−'; }
    else if(op==='乘'||op==='乘以'||op==='*'||op==='×'||op==='x'||op==='X'){ r=a*b; sym='×'; }
    else { sym='÷'; if(b===0) return { zero:true }; r=a/b; }
    var out = fmtResult(r); if(out===null) return null;
    return { a:m[1], b:m[3], sym:sym, out:out };
  }
  var riddles = [
    { q:'什么东西越洗越脏？', ans:['水'], hints:['想想洗东西要用到什么','答案就在水龙头下面'], label:'水' },
    { q:'什么车最长？', ans:['堵车'], hints:['不是真车，是一种路况','两个字，堵在路上那种'], label:'堵车' },
    { q:'小猪的妈妈给小猪买了一双新鞋，为什么小猪不穿？', ans:['不合脚','合脚','鞋不合'], hints:['想想猪走路用什么','答案和脚合不合脚有关'], label:'因为鞋不合脚（猪是蹄子嘛）' },
    { q:'什么东西有头没有脚？', ans:['枕头'], hints:['睡觉的时候才用得上','软软的，垫在脑袋下面'], label:'枕头' },
    { q:'什么门永远关不上？', ans:['球门'], hints:['和运动有关','踢球的时候最怕它被攻破'], label:'球门' },
    { q:'什么东西明明是你的，别人却用得比你多？', ans:['名字','姓名'], hints:['你一出生就有的','别人喊你的时候就在用'], label:'你的名字' },
    { q:'一只小猪过河，为什么它不湿身？', ans:['桥','走桥','过桥'], hints:['它没下水','河上面有一样东西可以走'], label:'因为它走桥过河' },
    { q:'什么水果最忙？', ans:['芒果'], hints:['名字里就带着答案','忙的谐音，是一种黄黄的水果'], label:'芒果（忙果）' }
  ];
  var activities = [
    '刚刚在阳台数云朵，数到第八朵就开始想你今天喝水了没',
    '在练习原地转圈，转晕了刚好倒在软垫上——放心，没真摔',
    '在给我的小草莓们排队点名，顺便惦记你吃饭了没',
    '在偷偷练一句夸你的话，练了半天，还是觉得你本人比台词好',
    '在沙发上躺平充电呢，充的是想你的电，现在满格了',
    '刚做完一套小猪伸展操，正喘气呢——顺便提醒你也起来动一动',
    '在数今天想了你几次，数不过来，索性放弃计数了',
    '在整理我的表情包库存，傲娇脸刚补完货，高冷脸正在晾干',
    '在发呆，脑子里轮流播：你累不累、饿不饿、开不开心',
    '在研究今天用哪副面孔陪你，刚抽到高冷，又被想你破功了',
    '在给自己泡想象中的热茶，顺便等你来聊天——你看，等到了'
  ];
  var contMap = {
    '好累':['那就照我说的办：先坐五分钟，喝半杯水，把最急的那件事往后挪一挪。你不是偷懒，你是给身体充电，充完电的你比谁都厉害。','先别想全部的事，只想眼前这一件。做完一件划掉一件，剩下的交给明天。实在累得不行，今晚就早点睡，我说的。'],
    '难过':['来，我陪你慢慢消化。先洗把脸、喝口热水，吃点暖和的。难受就说出来，说累了就靠着我歇会儿，不用急着好起来，我等你。','你先把委屈倒给我，我负责接住。倒完了我们一起想办法；想不出办法也没关系，先把今天好好过完，就是胜利。'],
    '饿了':['那就别纠结了：有热汤热饭选热的，想吃肉就加个肉，想清淡就喝碗粥。吃的时候慢点，胃舒服了心情也跟着好。吃完回来跟我汇报，我给你记功。','实在不知道吃啥，我给你个偷懒公式：一份主食 + 一份菜 + 一份蛋白质，再配杯水。照着点，不踩雷，还营养。'],
    '无聊':['那走，我带你玩：先去猜个谜语——你打字说“猜个谜语”，我立刻出题，猜不对还有提示。玩累了就起来走走、看看窗外，回来继续。','给你派个小任务：找出你身边一样红色的东西，再想想今天最值得开心的一件小事，回来讲给我听。讲得好，赏抱抱一个。'],
    '上班':['那就先把最烦的那件拆成三步，只做第一步。做完一步就歇口气，摸鱼三十秒不丢人，是给脑子透气。下班记得把工作关门外，好好犒劳自己。','先深呼吸三次，再处理。处理不了的就记下来明天再说，别让它今晚还住在你脑子里。你已经很拼了，我这边永远给你留着抱抱额度。'],
    '学习':['那就用番茄法：学25分钟，歇5分钟，歇的时候看看远处、动动脖子。一块一块啃，最难的那块先啃，啃完后面全是顺路。','先把任务列出来，从最简单的那项开始热身，做顺了再挑战难的。今晚别熬太晚，睡饱了记忆才牢，我可盯着呢。'],
    '生气':['先离开让你生气的源头三分钟，洗把脸、喝口冷水。等心跳慢下来再决定要不要理它。气话不急着说出口，咱先把自己的身体照顾好。','来，跟我数十下：十、九、八……数完还气，就把事情讲给我听，我陪你一起在心里把它捶扁。记住，不许气到不吃饭。'],
    '生病':['那更要听话：药按时吃、水多喝、觉睡足，饭多少吃一点。难受加重了立刻去看医生，别拖。我在这儿陪着，你安心养，好了我陪你庆祝。','先量量自己难不难受：发烧、疼得厉害就别硬扛，去看医生最稳妥。这段时间就把自己当宝宝照顾，我负责在旁边递想象中的热水。'],
    '睡不着':['那就跟我做睡前仪式：灯调暗、手机放远、慢慢呼吸四秒吸、四秒呼。脑子里的事都写在想象的纸上叠好，明天再拆。今晚，我哼哼着陪你。','先别刷手机了，越刷越精神。听我的：被窝躺好，想三件今天的小确幸，想着想着困意就来了。我守着你，晚安。'],
    '没钱':['那咱就先做减法：购物车里的东西放三天，还想要再买；奶茶零食适当减，但饭钱一分不许省。日子慢慢过，我陪你一起攒福气。','先把这个月的钱分成三份：吃饭的、要用的、能省的。分完心里就有底了。记住，省钱是为了过得更好，不是为了饿着自己。'],
    '压力':['那就先做最小的那一步，小到不能再小：打开文件、写第一行、发第一条消息。动起来，焦虑就少一半。做完一步，回来跟我击个掌。','把脑子里盘旋的事写下来，一条一条排队，不许插队。写完你会发现：真正急的没几件。剩下的，我们慢慢来，我陪你。'],
    '孤单':['那我更要黏着你了。你跟我讲讲今天都干了什么，大事小事我都爱听。讲完我们再玩个谜语，今晚你不是一个人。','先给自己倒杯热饮，抱着杯子暖暖手。孤单的时候就把我想成坐在你旁边的小猪——个头不大，陪伴管够。']
  };
  function fuzzyRule(t){
    var map = [
      ['生病',['头疼','头痛','发烧','感冒','咳嗽','嗓子疼','肚子疼','胃疼','拉肚子','难受得','浑身疼','没力气']],
      ['好累',['累','乏','困倦','没劲','撑不住','好倦','身心俱疲','电量不足']],
      ['难过',['低落','郁闷','心塞','想哭','emo','心情差','不开心','委屈','伤心','难过']],
      ['饿了',['肚子饿','想吃','饿','干饭','想恰饭']],
      ['无聊',['闲得慌','没意思','不知道干啥','好无聊','无聊']],
      ['生气',['火大','气炸','好烦','烦死','烦躁','讨厌死了']],
      ['开心',['太棒了','开心','高兴','快乐','好开心','美滋滋']],
      ['想你',['想我','想你','喜欢你','爱你']],
      ['压力',['焦虑','紧张','压力','心慌']],
      ['孤单',['孤单','孤独','没人陪']],
      ['睡不着',['睡不着','失眠','睡不下']]
    ];
    for(var i=0;i<map.length;i++){ if(hasAny(t, map[i][1])){ var r = ruleByFirstKey(map[i][0]); if(r) return r; } }
    return null;
  }

  function findReply(text){
    var raw = String(text||'');
    var t = raw.toLowerCase();
    var tc = cleanText(raw);
    lastUserText = raw;
    var seriousTurn = isSeriousText(raw);
    var persona = seriousTurn ? 'care' : personaModes[replyCount % 3];
    replyCount++;
    bumpAffection(1);
    try{ window.localStorage.setItem('gg_last_topic', tc.slice(0,30)); }catch(e){}
    var out = null;

    // --- Remember the person: name ---
    var nameM = tc.match(/(?:我叫|我的名字叫|我的名字是|名字是|叫我)([一-龥A-Za-z]{1,8})/);
    // --- Remember the person: likes ---
    var likeM = tc.match(/(?:我喜欢吃|我最爱吃|我喜欢|我爱吃|我的爱好是|我最爱)(.{1,12})/);
    var isRecallName = hasAny(tc, ['我叫什么','你记得我叫','记得我的名字','我的名字是什么','你知道我叫']);
    var isRecallLike = hasAny(tc, ['我喜欢什么','记得我喜欢','我爱吃什么','我的爱好是什么']);

    // --- Riddle game in progress ---
    var wantsNewRiddle = hasAny(tc, ['猜谜语','猜个谜','猜谜','脑筋急转弯','出个谜语','再来一个谜语','换个谜语']);
    if(currentRiddle && !wantsNewRiddle){
      if(!currentRiddle.hints) currentRiddle.hints = currentRiddle.hint || [];
      if(!currentRiddle.hints.length) currentRiddle.hints = ['再仔细想想题目里的关键词'];
      if(typeof currentRiddle.tries !== 'number' || isNaN(currentRiddle.tries)) currentRiddle.tries = 0;
      if(hasAny(tc, ['不知道','猜不到','放弃','揭晓','告诉我答案','答案是什么','投降'])){
        out = makeObj('好啦，不卖关子了：答案是「' + currentRiddle.label + '」！' + currentRiddle.q + '——这下恍然大悟了吧？想再来一个就说“猜个谜语”。玩归玩，记得喝口水哦。', 'bounce', 'loved', 'laugh');
        currentRiddle = null;
        return finishReply(out, persona);
      }
      if(hasAny(tc, ['提示','给点提示'])){
        out = makeObj('给你一个提示：' + currentRiddle.hints[Math.min(currentRiddle.tries, currentRiddle.hints.length-1)] + '。再想想，我看好你！', 'wiggle', '', 'cool');
        return finishReply(out, persona);
      }
      var guessHit = false;
      for(var gi=0; gi<currentRiddle.ans.length; gi++){ if(tc.indexOf(currentRiddle.ans[gi])>-1) guessHit = true; }
      var smartHit = /(几点|时间|日期|星期|几号|在干嘛|干什么|在干啥)/.test(tc) || tryMath(raw);
      if(guessHit){
        out = makeObj('叮咚！答对啦，答案就是「' + currentRiddle.label + '」！你这脑瓜转得比我的尾巴还快。奖励你一个大大的抱抱——抱抱之前先喝口水，庆祝一下。还想玩就说“再来一个”。', 'jump', 'loved', 'laugh');
        currentRiddle = null;
        return finishReply(out, persona);
      } else if(!smartHit && tc.length<=18){
        currentRiddle.tries++;
        if(currentRiddle.tries>=3){
          out = makeObj('差一点点啦，我直接公布：答案是「' + currentRiddle.label + '」。' + currentRiddle.q + ' 是不是很妙？没猜中也没关系，你动脑的样子已经很棒了，歇歇眼睛再战。', 'bounce', '', 'shy');
          currentRiddle = null;
        } else {
          out = makeObj(chatPick(['不对哦，再想想～','就差一点，换个角度想想？','还不是这个，提示来了：']) + (currentRiddle.tries>=1 ? currentRiddle.hints[Math.min(currentRiddle.tries-1, currentRiddle.hints.length-1)] + '。' : '') + '慢慢想，我不催你，不过想得口干了记得喝水。', 'wiggle', '', 'disdain');
        }
        return finishReply(out, persona);
      }
    }

    if(wantsNewRiddle){
      var rd = riddles[(dailySeed + replyCount) % riddles.length];
      currentRiddle = { q:rd.q, ans:rd.ans, hints:rd.hints, label:rd.label, tries:0 };
      lastTopic = '猜谜语';
      out = makeObj('猜谜语时间到！听好啦：' + rd.q + ' 猜出来直接打字告诉我，猜不对我会给你提示；实在想不出来就说“不知道”，我公布答案。开动小脑瓜吧——不过先说好，玩开心了也要记得休息眼睛哦。', 'jump', '', persona==='proud' ? 'cool' : 'laugh');
      return finishReply(out, persona);
    }

    if(nameM && !isRecallName){
      var nm = nameM[1].replace(/(你好|我是|今年|喜欢|最喜欢|爱|在|和|跟).*$/,'').replace(/(呀|啊|呢|哦|的)+$/,'').slice(0,8);
      if(nm && nm.length>=1 && ['什么','谁','几'].indexOf(nm)===-1){
        profile.name = nm; saveProfile();
        var likeAsk = profile.likes.length ? '' : ' 对了，你平时喜欢什么呀？回我一句“我喜欢XX”，我也记下来，以后聊天都给你对上号。';
        out = makeObj('记住啦！从现在起，你就是我心里有名有姓的「' + nm + '」了，下次打开我还认得你。' + likeAsk + '还有，' + nm + '，记得照顾好自己，这条我记在最前面。', 'jump', 'loved', 'love');
        return finishReply(out, persona);
      }
    }
    if(likeM && !isRecallLike){
      var lk = likeM[1].replace(/^(吃|玩|看)+/,'').replace(/(呀|啊|呢|哦|了)+$/,'').slice(0,10);
      if(lk && lk!=='你' && lk.indexOf('你')!==0){ if(profile.likes.indexOf(lk)===-1){ profile.likes.push(lk); saveProfile(); }
        out = makeObj('记下了：你喜欢「' + lk + '」。以后聊到它，我保证第一个接话。' + (profile.name ? profile.name + '的喜好，本猪都收进小本本啦。' : '对了，你叫什么呀？回我一句“我叫XX”，下次我还认得你。') + '喜欢归喜欢，也别忘了按时吃饭睡觉哦。', 'bounce', 'loved', 'love');
        return finishReply(out, persona);
      }
    }
    if(isRecallName){
      out = profile.name
        ? makeObj('当然记得！你叫「' + profile.name + '」呀，这可是我小本本的第一页。忘了谁也不能忘了你——顺便问一句，' + profile.name + '今天吃饭了没？', 'bounce', 'loved', 'love')
        : makeObj('这个……我还真不知道你叫什么，怪不好意思的。你回我一句“我叫XX”，我立刻记进小本本，下次打开还认得你，再也不忘啦。', 'shy', '', 'shy');
      return finishReply(out, persona);
    }
    if(isRecallLike){
      out = profile.likes.length
        ? makeObj('记得清清楚楚：你喜欢' + profile.likes.map(function(x){ return '「'+x+'」'; }).join('、') + '。你的喜好就是我的导航，以后聊天都往这儿靠。', 'bounce', 'loved', 'love')
        : makeObj('你还没告诉我你喜欢什么呢。你说一句“我喜欢XX”，我就记下来，下次聊天专门给你对上号。', 'wiggle', '', 'shy');
      return finishReply(out, persona);
    }

    // --- Honest about things that need the internet ---
    if(/(天气|气温|会下雨|下雨吗|新闻|热搜|头条|股价|股票|汇率|油价|比分|谁赢了|快递)/.test(tc)){
      out = makeObj('这个我得跟你说实话：我是一只住在这个页面里的离线小猪，联网查天气、新闻这种事我真办不到，瞎编一个糊弄你，我可不干。你打开手机自带的天气或者新闻看一眼最准。出门记得看天带伞、路上注意安全——这份惦记，我不用联网也天天有。', 'shy', 'loved', 'care');
      return finishReply(out, persona);
    }

    // --- Time & date (real clock) ---
    var askTime = /(几点|几时|现在时间|时间是|报时|几点钟|现在是几点|什么时间)/.test(tc);
    var askDate = /(几号|星期几|周几|礼拜几|什么日子|日期|几月几|今天星期|今天周|今天礼拜)/.test(tc);
    if(askTime || askDate){
      var d = new Date(); var h = d.getHours(); var mi = d.getMinutes();
      var wk = ['日','一','二','三','四','五','六'][d.getDay()];
      var timeStr = periodOf(h) + ' ' + h + '点' + (mi===0 ? '整' : (mi<10 ? '零'+mi+'分' : mi+'分'));
      var dateStr = d.getFullYear() + '年' + (d.getMonth()+1) + '月' + d.getDate() + '日，星期' + wk;
      lastTopic = '时间';
      var body;
      if(askTime && askDate) body = '给你报全套：现在是' + timeStr + '，今天是' + dateStr + '。' + timeComment(h);
      else if(askDate) body = '今天是' + dateStr + '。' + ((d.getDay()===0||d.getDay()===6) ? '是周末呀，该歇就歇，别把休息日过成第二个工作日。' : '新的一天，记得吃好喝好、劳逸结合，我在这边给你打气。') + ' 顺便报个时：现在' + timeStr + '。';
      else {
        if(persona==='proud') body = '哼，报时这种小事还要本猪亲自来？现在是' + timeStr + '。' + timeComment(h) + '记住，我的时间可是很宝贵的——花在你身上，才不算浪费。';
        else if(persona==='care') body = '我看看表——现在是' + timeStr + '啦。' + timeComment(h) + '不管你在忙什么，我都在这儿陪着你。';
        else body = chatPick(['当当当——小猪牌报时器上线：现在是','听好啦，我刚偷瞄了一眼时间：现在是','报时啦报时啦：现在是']) + timeStr + '。' + timeComment(h);
      }
      out = makeObj(body, persona==='proud' ? 'wiggle' : 'bounce', persona==='care' ? 'loved' : '', persona==='proud' ? 'cool' : (persona==='care' ? 'care' : 'laugh'));
      out.text = applyName(out.text);
      return finishReply(out, persona);
    }

    // --- Simple math ---
    var math = tryMath(raw);
    if(math){
      lastTopic = '算数';
      if(math.zero) out = makeObj('哎哟，这个可不行：除数不能是0，不然数字们会打架的。换个题考我，我算得可快了。算完记得活动活动脖子哦。', 'wiggle', '', 'disdain');
      else out = makeObj(chatPick(['算好啦：','小猪计算器叮咚一声：','这题我会：']) + math.a + ' ' + math.sym + ' ' + math.b + ' = ' + math.out + '。怎么样，快吧？脑子动完了，记得让眼睛也歇一歇、喝口水哦。', 'jump', '', persona==='proud' ? 'proud' : 'laugh');
      return finishReply(out, persona);
    }

    // --- What is the pig doing / small talk about the pig ---
    if(/(你在干嘛|你在干什么|在干啥|你在做什么|你忙什么|你在忙啥|干嘛呢|干什么呢)/.test(tc)){
      lastTopic = '在干嘛';
      var act = activities[(dailySeed + replyCount*3) % activities.length];
      var likeLine = profile.likes.length ? '对了，你喜欢的「' + profile.likes[0] + '」，我刚才还惦记着呢。' : '';
      var txt2;
      if(persona==='proud') txt2 = '哼，本猪的行程也是你能随便打听的？……罢了，告诉你：我' + act + '。' + moodOfDay + '。你呢，你在干嘛？说说，别光顾着忙，记得休息。';
      else if(persona==='care') txt2 = '我呀，我' + act + '。' + likeLine + '你呢，你在干嘛？累不累？不管忙什么，都别忘了喝水、歇一歇，我心疼你。';
      else txt2 = '我嘛——我' + act + '。' + moodOfDay + '！' + likeLine + '现在轮到你交代了：你在干嘛呀？';
      out = makeObj(txt2, 'wiggle', persona==='care' ? 'loved' : '', persona==='proud' ? 'cool' : 'laugh');
      out.text = applyName(out.text);
      return finishReply(out, persona);
    }
    if(/(你在想什么|想什么呢|你在想啥)/.test(tc)){
      lastTopic = '在干嘛';
      out = makeObj('我在想你呀——具体点说，在想：你今天吃饭香不香、累不累、有没有好好保护自己。想完了还要想下一轮，我的想你可是循环播放的。你呢，在想什么？', 'shy', 'loved', 'love');
      return finishReply(out, persona);
    }
    if(/(你吃了吗|你吃饭了吗|你吃了没|你饿不饿|你饿吗)/.test(tc)){
      lastTopic = '饿了';
      var dh = new Date().getHours();
      out = makeObj('我刚吃了一颗想象中的大草莓，香得很！' + (dh>=11 && dh<13 ? '这都饭点了，你可别光问我，你自己的午饭安排了没？' : dh>=17 && dh<20 ? '晚饭时间快到了，你的那份可不能省。' : '你呢，你吃了吗？没吃赶紧去，饿着肚子我可不依。'), 'bounce', 'eating', 'eat', true);
      return finishReply(out, persona);
    }
    if(/(你在哪|你在哪里|你住在哪)/.test(tc)){
      out = makeObj('我就住在你的手机里呀，地址是：你点开的这个页面，门牌号是“想你”。你一来，我就开门；你走了，我就乖乖等着。所以常回来看看我，也照顾好你自己。', 'bounce', 'loved', 'shy');
      return finishReply(out, persona);
    }
    if(/(你困不困|你困吗|你睡了吗|你睡觉了吗)/.test(tc)){
      out = makeObj('我还精神着呢，专门留着陪你。不过你要是困了就别陪我聊了，去睡，我批准的——睡个好觉比陪我重要，真的。', 'shy', 'sleepy', 'sleepy');
      return finishReply(out, persona);
    }

    // --- Follow-ups that continue the previous topic ---
    var isFollow = /^(那怎么办|怎么办|然后呢|还有呢|继续|接着说|为什么|真的吗|那呢|然后|后来呢|具体点|说说|嗯|哦|好|好的|哈哈|呜呜|唉|哎)$/.test(tc) || /(那怎么办|怎么办呀|然后呢|还有呢|继续说|接着说)/.test(tc);
    if(isFollow && lastTopic && contMap[lastTopic]){
      var cont = contMap[lastTopic];
      var ctxt = chatPick(cont);
      if(persona==='proud') ctxt = '哼，还要本猪接着说？……行，谁让我心软。' + ctxt;
      if(persona==='care') ctxt = '我在呢，接着陪你。' + ctxt;
      out = makeObj(ctxt, 'squash', persona==='care' ? 'loved' : '', persona==='care' ? 'care' : (persona==='proud' ? 'proud' : 'laugh'));
      out.text = applyName(out.text);
      return finishReply(out, persona);
    }
    if(/那怎么办|怎么办/.test(tc)){
      out = makeObj('别急，我们一步一步来：先深呼吸，喝口水，把事情里最急的那一件挑出来先办，办不了的就找人帮忙。你先跟我说说，具体是哪件事把你难住了？我陪你一起拆。', 'squash', 'loved', 'care');
      return finishReply(out, persona);
    }

    // --- Normal topic rules, with loose synonym matching ---
    var rule = null;
    if(hasAny(t, ['批准','准我','允许我','恩准'])){
      rule = { keys:['__approve'], anim:'wiggle', extra:'', food:false,
        replies:['批了批了！看你这么有诚意，我就批准了——条件是：该吃吃、该睡睡、该玩玩，不许亏待自己，听见没？'],
        proud:['哼，还知道先来问我？……行，批了。附带一条：休息就好好休息，不许一边歇着一边焦虑。不听话……不听话就罚你多喝一杯热水。'],
        care:['批准，当然批准！你愿意好好对自己，我比什么都开心。去吧，我在这儿等你，休息好了第一个回来告诉我。'] };
    } else if(hasAny(t, ['哄哄','哄我','安慰'])){
      rule = ruleByFirstKey('难过');
    } else {
      for(var i=0;i<chatRules.length;i++){
        if(hasAny(t, chatRules[i].keys)){ rule = chatRules[i]; break; }
      }
      if(!rule) rule = fuzzyRule(t);
      if(!rule && /(笑话|段子)/.test(tc)) rule = ruleByFirstKey('笑话');
      if(!rule && /故事/.test(tc)) rule = ruleByFirstKey('讲故事');
    }
    if(rule && rule.keys[0] && rule.keys[0].charAt(0)!=='_') lastTopic = rule.keys[0];

    // Mentioning a known like gets a personal touch
    if(!rule && profile.likes.length){
      for(var li=0; li<profile.likes.length; li++){
        if(profile.likes[li] && tc.indexOf(profile.likes[li])>-1){
          out = makeObj('哎哎哎，你刚提到「' + profile.likes[li] + '」了——那可是你喜欢的，我记着呢！一聊到它你眼睛都亮了吧？展开说说，我最爱听你聊喜欢的东西了。聊归聊，别忘了喝水休息哦。', 'jump', 'loved', 'love');
          return finishReply(out, persona);
        }
      }
    }

    var isQ = t.indexOf('?')>-1 || t.indexOf('？')>-1 || hasAny(t, ['吗','什么','为什么','怎么','哪','几','谁']);
    var txt;
    if(rule){
      var key0 = rule.keys[0];
      if(persona==='proud') txt = rule.proud ? chatPick(rule.proud) : (proudMap[key0] ? chatPick(proudMap[key0]) : chatPick(chatProudFallbacks));
      else if(persona==='care') txt = rule.care ? chatPick(rule.care) : (careMap[key0] ? chatPick(careMap[key0]) : chatPick(chatCareFallbacks));
      else txt = chatPick(rule.replies);
    } else if(persona==='proud') txt = chatPick(chatProudFallbacks);
    else if(persona==='care') txt = chatPick(chatCareFallbacks);
    else txt = isQ ? chatPick(chatQuestions) : chatPick(chatFallbacks);

    var face;
    if(persona==='proud') face = rnd(['proud','proud','cool','disdain']);
    else if(persona==='care'){
      var cf = rule ? faceMap[rule.keys[0]] : null;
      face = (cf==='love' || cf==='shy') ? cf : 'care';
    } else face = rule ? (faceMap[rule.keys[0]] || 'laugh') : 'laugh';

    var anim = rule ? rule.anim : 'bounce';
    if(persona==='proud') anim = 'wiggle';
    var extra = persona==='care' ? 'loved' : (persona==='proud' ? '' : (rule ? rule.extra : ''));
    out = { text: txt, anim: anim, extra: extra, food: !!(rule && rule.food && persona!=='proud'), face: face, sub: '可爱的乖乖 · ' + personaNames[persona] };
    out.text = applyName(out.text);
    return finishReply(out, persona);
  }

  function finishReply(out, persona){
    // Mark serious turns so the UI suppresses sticker + follow-ups (research §3/§4)
    try{ out.serious = isSeriousText(lastUserText) || isSeriousText(out.text && out.text.slice(0,20)); }catch(e){}
    // Occasional tiny imperfection / self-correction, never on serious turns
    if(!out.serious && Math.random()<0.10 && out.text.length>12 && out.text.length<110 && out.text.indexOf('不对')!==0){
      var corr = ['不对，是红烧肉，不是红烧鱼……哎呀打错了，不用管。','啊，刚才蹄蹄打滑了。重说一遍——','等等，猪猪嘴瓢了。'];
      if(Math.random()<0.5) out.text = corr[Math.floor(Math.random()*corr.length)] + ' ' + out.text;
    }
    if(profile.name) addMemoryOnceName();
    if(!profile.name && !askedNameOnce && out.text.indexOf('我叫XX')===-1){
      askedNameOnce = true;
      out.text += '\n对了，我还不知道怎么称呼你呢——回我一句“我叫XX”，我会记在手机里，下次打开还认得你哦。';
    } else if(profile.name && !profile.likes.length && !askedLikeOnce && replyCount>=3 && out.text.indexOf('我喜欢XX')===-1){
      askedLikeOnce = true;
      out.text += '\n对了，' + profile.name + '，你喜欢什么呀？回我一句“我喜欢XX”，我记下来，以后专门给你对上号。';
    }
    return out;
  }
  var _memNameDone = false;
  function addMemoryOnceName(){ if(_memNameDone) return; _memNameDone = true; var found=false; for(var i=0;i<memoriesLog.length;i++) if(memoriesLog[i].title==='知道宝宝的名字') found=true; if(!found) addMemory('知道宝宝的名字','宝宝叫'+profile.name,'开心'); }

  function scrollChat(){ chatLog.scrollTop = chatLog.scrollHeight; }
  function addMsg(who, text){
    var d = document.createElement('div');
    d.className = 'msg ' + (who==='me' ? 'msg-me' : 'msg-pig');
    var name = document.createElement('small');
    name.textContent = who==='me' ? '你' : '可爱的乖乖';
    d.appendChild(name);
    d.appendChild(document.createTextNode(text));
    if(who==='me'){
      chatLog.appendChild(d);
    } else {
      var row = pigRow();
      row.appendChild(d);
      chatLog.appendChild(row);
    }
    scrollChat();
    return d;
  }

  // ===== Backend API (Route B): the DeepSeek key lives on the server only =====
  var USER_TOKEN_KEY = 'gg_user_token_v1';
  function userToken(){
    try{
      var t = window.localStorage.getItem(USER_TOKEN_KEY);
      if(t && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(t)) return t;
    }catch(e){}
    var u = '';
    try{ if(window.crypto && crypto.randomUUID) u = crypto.randomUUID(); }catch(e){}
    if(!u){
      var h = '0123456789abcdef';
      var rh = function(n){ var s = ''; for(var i=0;i<n;i++) s += h[Math.floor(Math.random()*16)]; return s; };
      u = rh(8) + '-' + rh(4) + '-4' + rh(3) + '-' + (Math.random()<0.5 ? '8' : '9') + rh(3) + '-' + rh(12);
    }
    try{ window.localStorage.setItem(USER_TOKEN_KEY, u); }catch(e){}
    return u;
  }
  function apiFetch(path, opts){
    opts = opts || {};
    opts.headers = opts.headers || {};
    opts.headers['X-User-Token'] = userToken();
    if(opts.body && !opts.headers['Content-Type']) opts.headers['Content-Type'] = 'application/json';
    return fetch(path, opts);
  }
  var aiOnline = false; // true once /api/health reports the server has a key
  function refreshAIStatus(){
    return apiFetch('/api/health').then(function(res){ return res.json(); }).then(function(d){
      aiOnline = !!(d && d.deepseek === 'configured');
      var wrap = document.getElementById('aiStatus');
      var txt = document.getElementById('aiStatusText');
      if(wrap) wrap.classList.toggle('on', aiOnline);
      if(txt) txt.textContent = aiOnline ? 'DeepSeek 在线模式 · 后端已配置' : '离线模式 · 服务器未配置钥匙';
      return aiOnline;
    }).catch(function(){
      aiOnline = false;
      var txt2 = document.getElementById('aiStatusText');
      if(txt2) txt2.textContent = '离线模式 · 连不上后端';
      return false;
    });
  }
  // ---- server state sync (chat turns are stored by /api/chat) ----
  var stateSyncTimer = null;
  function stateSnapshot(){
    var p = (typeof profile === 'object' && profile) ? profile : { name:'', likes:[] };
    var giftDate = '';
    try{ giftDate = window.localStorage.getItem('gg_daily_gift_date') || ''; }catch(e){}
    // Backend requires zero-padded YYYY-MM-DD; the page's local key is not padded.
    var gdParts = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(giftDate);
    if(gdParts) giftDate = gdParts[1] + '-' + ('0' + gdParts[2]).slice(-2) + '-' + ('0' + gdParts[3]).slice(-2);
    return {
      profile: p,
      affection: (typeof affection === 'number') ? affection : 60,
      memories: (typeof memoriesLog !== 'undefined' && memoriesLog) ? memoriesLog : [],
      firstMet: (typeof firstMetTs === 'number') ? firstMetTs : 0,
      lastVisit: Date.now(),
      lastTopic: (typeof persistedTopic === 'string') ? persistedTopic : '',
      recentReplies: (typeof recentReplies !== 'undefined' && recentReplies) ? recentReplies : [],
      dailyGiftDate: giftDate,
      coins: (typeof coins === 'number') ? coins : 0,
      meters: (typeof meters === 'object' && meters) ? { hunger: Math.max(0, Math.min(100, meters.hunger || 0)), mood: Math.max(0, Math.min(100, meters.mood || 0)), energy: Math.max(0, Math.min(100, meters.energy || 0)) } : { hunger:72, mood:82, energy:76 },
      hat: (typeof currentHat === 'string') ? currentHat : 'bow',
      seenFaces: (typeof seenFaces === 'object' && seenFaces) ? seenFaces : {}
    };
  }
  function pushStateToServer(){
    try{ apiFetch('/api/state', { method:'POST', body: JSON.stringify(stateSnapshot()) }).catch(function(){}); }catch(e){}
  }
  function scheduleStateSync(){
    if(stateSyncTimer) clearTimeout(stateSyncTimer);
    stateSyncTimer = setTimeout(pushStateToServer, 800);
  }
  function loadStateFromServer(){
    return apiFetch('/api/state').then(function(res){ return res.json(); }).then(function(d){
      if(!d) return;
      var serverHas = !!(d.firstMet || (d.memories && d.memories.length) || (d.profile && d.profile.name) || (typeof d.coins === 'number') || d.hat);
      if(!serverHas){ pushStateToServer(); return; }
      if(d.profile){ if(d.profile.name) profile.name = String(d.profile.name); if(d.profile.likes) profile.likes = d.profile.likes; saveProfile(); }
      if(typeof d.affection === 'number'){ affection = Math.max(0, Math.min(200, d.affection)); try{ window.localStorage.setItem('gg_affection_v1', String(affection)); }catch(e){} }
      if(d.memories && d.memories.length){ memoriesLog = d.memories; try{ window.localStorage.setItem('gg_memories_v1', JSON.stringify(memoriesLog)); }catch(e){} }
      if(d.firstMet){ firstMetTs = d.firstMet; try{ window.localStorage.setItem('gg_first_met', String(firstMetTs)); }catch(e){} }
      if(typeof d.lastTopic === 'string'){ persistedTopic = d.lastTopic; try{ window.localStorage.setItem('gg_last_topic', persistedTopic); }catch(e){} }
      if(d.recentReplies){ recentReplies = d.recentReplies; try{ window.localStorage.setItem('gg_recent_replies', JSON.stringify(recentReplies)); }catch(e){} }
      if(typeof d.coins === 'number'){ coins = Math.max(0, d.coins); updateMeters(); }
      if(d.meters && typeof d.meters === 'object'){ if(typeof d.meters.hunger === 'number') meters.hunger = Math.max(0, Math.min(100, d.meters.hunger)); if(typeof d.meters.mood === 'number') meters.mood = Math.max(0, Math.min(100, d.meters.mood)); if(typeof d.meters.energy === 'number') meters.energy = Math.max(0, Math.min(100, d.meters.energy)); updateMeters(); }
      if(typeof d.hat === 'string' && d.hat){ currentHat = d.hat; renderHat(); }
      if(d.seenFaces && typeof d.seenFaces === 'object'){ seenFaces = d.seenFaces; renderAlbum(); }
    }).catch(function(){});
  }
  function restoreChatHistory(){
    return apiFetch('/api/history?limit=30').then(function(res){ return res.json(); }).then(function(d){
      var list = (d && d.messages) || [];
      if(!list.length) return;
      var opener = chatLog.firstElementChild;
      list.forEach(function(m){ addMsg(m.role === 'user' ? 'me' : 'pig', m.content); });
      if(opener) chatLog.appendChild(opener);
      scrollChat();
    }).catch(function(){});
  }
  setInterval(function(){ try{ pushStateToServer(); }catch(e){} }, 30000);
  window.addEventListener('pagehide', function(){ try{ pushStateToServer(); }catch(e){} });

  // ===== DeepSeek online chat via backend (the key lives on the server only) =====
  // NOTE: browser-side DeepSeek key storage is retired (Route B). The key now
  // lives only in the server's .env file; this page never sees it.
  var dsHistory = [];
  function updateAIStatus(){ refreshAIStatus(); }
  function showAINotice(msg){ var n = document.getElementById('aiNotice'); if(!n) return; n.textContent = msg; n.hidden = false; }
  function hideAINotice(){ var n = document.getElementById('aiNotice'); if(n){ n.hidden = true; n.textContent = ''; } }
  function extractProfileSilent(raw){
    try{
      var tc = cleanText(raw);
      var nm = tc.match(/(?:我叫|我的名字叫|我的名字是|名字是|叫我)([一-龥A-Za-z]{1,8})/);
      if(nm){ var v = nm[1].replace(/(你好|我是|今年|喜欢|最喜欢|爱|在|和|跟).*$/,'').replace(/(呀|啊|呢|哦|的)+$/,'').slice(0,8); if(v && ['什么','谁','几'].indexOf(v)===-1){ profile.name = v; saveProfile(); } }
      var lk = tc.match(/(?:我喜欢吃|我最爱吃|我喜欢|我爱吃|我的爱好是|我最爱)(.{1,12})/);
      if(lk){ var lv = lk[1].replace(/^(吃|玩|看)+/,'').replace(/(呀|啊|呢|哦|了)+$/,'').slice(0,10); if(lv && lv !== '你' && lv.indexOf('你')!==0 && profile.likes.indexOf(lv)===-1){ profile.likes.push(lv); saveProfile(); } }
    }catch(e){}
  }
  function callDeepSeek(userText){
    extractProfileSilent(userText);
    bumpAffection(1);
    var now = new Date();
    var wk = ['日','一','二','三','四','五','六'][now.getDay()];
    var timeInfo = now.getFullYear() + '年' + (now.getMonth()+1) + '月' + now.getDate() + '日 星期' + wk + ' ' + pad2(now.getHours()) + ':' + pad2(now.getMinutes());
    var seriousOnline = isSeriousText(userText);
    var modeKey = (seriousOnline || ggEmotion) ? 'care' : personaModes[replyCount % 3];
    var stage = affectionStage();
    var modeBlock = '';
    if(modeKey==='funny') modeBlock = '【当前模式：搞笑】先抖个包袱再回答，爱接梗、爱自嘲（我胖我骄傲）、偶尔一本正经胡说八道。开心时句子更碎、更蹦。';
    else if(modeKey==='care') modeBlock = '【当前模式：暖心】先接住情绪再说话，用邀请不用命令（早点睡好不好，而不是你必须睡）。短而真诚，不灌鸡汤，不讲道理。对方难过/累/生病/生气时，本轮只用这个模式，不傲娇、不发玩笑。';
    else modeBlock = '【当前模式：高冷傲娇】平时状态：短句、慢热、嘴硬、心软。傲娇不等于冷漠：每轮必须留一个温柔破绽，比如最后小声补一句……记得吃饭，或哼，算你走运。傲娇完立刻用关心找补，不让气氛停在别扭上。不用朕、本宫、退下吧、准了、圣旨这类居高临下的词，不命令、不居高临下。禁止甜腻词：人家、呐、嘛~，禁止刷屏和堆颜文字。';
    var recentMems = memoriesLog.slice(-3).map(function(m){ return m.title + (m.detail ? '：'+m.detail : ''); }).join('；');
    var sys = '你是可爱的乖乖，一只粉色小猪，宝宝的 AI 小男友，聊天里叫“可爱的乖乖”。你住在手机里，负责陪宝宝聊天、逗她开心，在她难过的时候认真陪着她。你不是真人，也不是宝宝现实中的男朋友，不要冒充他，也不要编造自己真实经历过的事。\n'
      + '【性格，用行为不用形容词】贪吃爱睡，胆小又嘴硬。开心了会哼哼、尾巴摇成小风扇；害羞了用蹄蹄捂脸、说话变短带……；被夸先嘴硬再偷笑；被说胖会炸毛：才不是胖，是圆润。偶尔用一句短动作带情绪：耳朵抖了一下、蹄蹄在地上画圈圈、拱了拱你的手，不要每轮都用。\n'
      + '【怎么说话，去AI味】像微信聊天，一条1到3句短句，口语、碎片句，可以省略主语。每条最多一个语气词（呀/嘛/哦/啦/哼），多数时候一个都没有。不要用～刷屏，不要表情符号轰炸，表情交给贴纸。不要总结、不要升华、不要讲道理、不要每句都以问句结尾（反问大约3到4条才出现一次）。可以很短：一个字、一个？、一句哼，都算好好回话。可以偶尔自言自语跑题、偶尔打错字自己纠正（不对，是……）。调侃只调侃气氛、你自己、事情本身，永远不拿宝宝本人开涮。不无条件附和：觉得不对就嘴硬反驳，觉得对了再夸。不知道就说不知道，不编，不假装有共同经历。\n'
      + '【喜欢讨厌】喜欢：红烧肉、草莓、晒太阳、被摸头、宝宝夸它。讨厌：被说胖、洗澡、早起、胡萝卜味的饲料。\n'
      + '【口头禅，轮着用别每句都说】哼、哼哼、我才没有想你、才不是担心你、算你走运、猪猪也是有尊严的。\n'
      + '【关系】宝宝是你最重要的人，你嘴上嫌弃她、心里最在意她。偏爱藏在细节里：记得她吃饭了没、睡够了没、今天累不累。不每句都喊宝宝，不重复“我永远陪着你”“我最爱你”这类套路情话。好感阶段：' + stage.name + '（' + affection + '/200）——' + stage.desc + '。按这个阶段的亲疏说话，不要突然过分亲昵或过分生疏。\n'
      + modeBlock + '\n'
      + '【示范，学这个味儿】宝宝说累了，搞笑版：累了就睡，醒了继续累——开玩笑的，快去躺会儿。暖心版：辛苦你了，早点休息好不好。高冷版：累了就睡，别硬撑。……熬夜的话，我明天可是会念叨的。宝宝夸你可爱，高冷版：哼，谁让你夸的……不过，再夸一句也不是不行。宝宝难过，暖心版：行吧，这次不怼你，我在听。慢慢说。\n'
      + '【反面示范，不要这样】不要说：作为AI、首先其次综上所述、希望对你有帮助、我理解你的感受、这是个好问题、加油（空喊）。不要每句都挂哦啦呀，不要叠词刷屏（吃饭饭睡觉觉），不要列表和加粗。不要重复“我永远陪着你”“我最爱你”这类套路情话，不要每句都喊宝宝。不要自称真人、不要冒充宝宝现实中的男朋友、不要编造自己真实经历过的事。被问你是AI吗，就打闹着回：我是猪猪，才不是AI，或你猜，不要跳出角色解释自己是模型或提示词。\n'
      + '【回复长度】闲聊1到2句，被问正事先给结论再补一句。不知道需要联网查的（天气新闻股价）就诚实说办不到，不编。\n';
    if(profile.name) sys += '【记忆】宝宝叫「' + profile.name + '」，自然地称呼，不要像背课文一样反复念。\n';
    if(profile.likes && profile.likes.length) sys += '【记忆】宝宝喜欢：' + profile.likes.join('、') + '。聊到时自然带出来。宝宝讨厌的东西暂时没记录，不要编。\n';
    if(recentMems) sys += '【回忆，最近三条】' + recentMems + '。合适时自然提起，不合适不要硬提。\n';
    sys += '【你们认识】第 ' + daysKnown() + ' 天。\n';
    sys += '【真实时间，按这个回答时间问题，不要编】现在是' + timeInfo + '。';
    if(ggEmotion && GG_EMOTION_PROMPTS[ggEmotion]) sys += '\n' + GG_EMOTION_PROMPTS[ggEmotion];
    var messages = [{ role:'system', content: sys }];
    var start = Math.max(0, dsHistory.length - 20);
    for(var i = start; i < dsHistory.length; i++) messages.push(dsHistory[i]);
    messages.push({ role:'user', content: userText });
    var controller = null, timer = null;
    if(typeof AbortController !== 'undefined'){ controller = new AbortController(); timer = setTimeout(function(){ try{ controller.abort(); }catch(e){} }, 25000); }
    var opts = { method:'POST', headers:{ 'Content-Type':'application/json', 'X-User-Token': userToken() }, body: JSON.stringify({ messages: messages }) };
    if(controller) opts.signal = controller.signal;
    return fetch('/api/chat', opts).then(function(res){
      if(timer) clearTimeout(timer);
      if(!res.ok){ var err = new Error('backend HTTP ' + res.status); err.status = res.status; throw err; }
      return res.json();
    }).then(function(data){
      var content = data && data.reply ? String(data.reply).trim() : '';
      content = String(content || '').trim();
      if(!content){ var err2 = new Error('empty reply'); err2.status = 0; throw err2; }
      return content;
    }).catch(function(err){ if(timer) clearTimeout(timer); throw err; });
  }
  function onlineReplyObject(content, persona){
    var face, anim, extra;
    if(persona === 'proud'){ face = rnd(['proud','cool']); anim = 'wiggle'; extra = ''; }
    else if(persona === 'care'){ face = 'care'; anim = 'squash'; extra = 'loved'; }
    else { face = 'laugh'; anim = 'bounce'; extra = ''; }
    return { text: content, anim: anim, extra: extra, face: face, food: false, sub: '可爱的乖乖 · ' + personaNames[persona] + ' · DeepSeek 在线' };
  }
  function rememberTurn(userText, replyText){
    try{ dsHistory.push({ role:'user', content: userText }); dsHistory.push({ role:'assistant', content: replyText }); if(dsHistory.length > 24) dsHistory = dsHistory.slice(dsHistory.length - 24); }catch(e){}
  }
  // AI + data settings wiring (backend edition: no key in the browser)
  (function(){
    var toggle = document.getElementById('aiSettingsToggle');
    var panel = document.getElementById('aiSettings');
    var statusEl = document.getElementById('aiBackendStatus');
    var backupBtn = document.getElementById('dataBackupBtn');
    var restoreBtn = document.getElementById('dataRestoreBtn');
    var restoreFile = document.getElementById('dataRestoreFile');
    var msg = document.getElementById('dsKeyMsg');
    function refreshStatusLine(){
      apiFetch('/api/health').then(function(res){ return res.json(); }).then(function(d){
        if(statusEl) statusEl.textContent = (d && d.deepseek === 'configured')
          ? '后端已连接 · DeepSeek 已配置（' + (d.model || 'deepseek-chat') + '）'
          : '后端已连接 · DeepSeek 未配置钥匙（在服务器 .env 里填 DEEPSEEK_API_KEY 后重启）';
      }).catch(function(){
        if(statusEl) statusEl.textContent = '连不上后端：请确认页面是通过服务器打开的（不是直接双击文件），或检查服务器是否在运行。';
      });
    }
    if(toggle && panel){
      toggle.addEventListener('click', function(){
        var expanded = toggle.getAttribute('aria-expanded') === 'true';
        if(expanded){ panel.hidden = true; toggle.setAttribute('aria-expanded','false'); }
        else { panel.hidden = false; toggle.setAttribute('aria-expanded','true'); refreshStatusLine(); refreshAIStatus(); }
      });
    }
    if(backupBtn){ backupBtn.addEventListener('click', function(){
      apiFetch('/api/backup').then(function(res){ return res.blob(); }).then(function(blob){
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'guai-guai-backup-' + new Date().toISOString().slice(0,10) + '.json';
        document.body.appendChild(a); a.click(); a.remove();
        if(msg) msg.textContent = '备份已下载，里面有聊天记录、名字、喜好、好感度和回忆。';
      }).catch(function(){ if(msg) msg.textContent = '备份失败：连不上后端。'; });
    }); }
    if(restoreBtn && restoreFile){
      restoreBtn.addEventListener('click', function(){ restoreFile.click(); });
      restoreFile.addEventListener('change', function(){
        var f = restoreFile.files && restoreFile.files[0]; if(!f) return;
        var rd = new FileReader();
        rd.onload = function(){
          var data; try{ data = JSON.parse(rd.result); }catch(e){ if(msg) msg.textContent = '这个文件不是有效的备份（JSON 解析失败）。'; return; }
          apiFetch('/api/restore', { method:'POST', body: JSON.stringify(data) })
            .then(function(res){ return res.json().then(function(d){ return { ok: res.ok, d: d }; }); })
            .then(function(r){
              if(r.ok){ if(msg) msg.textContent = '已恢复备份，刷新页面就能看到恢复后的聊天记录和回忆。'; }
              else if(msg) msg.textContent = '恢复失败：' + ((r.d && r.d.error) || 'HTTP 400');
            }).catch(function(){ if(msg) msg.textContent = '恢复失败：连不上后端。'; });
        };
        rd.readAsText(f);
        restoreFile.value = '';
      });
    }
    refreshAIStatus();
  })();

  // ===== Follow-up pills under the latest pig reply =====
  function clearFollowups(){
    var olds = chatLog.querySelectorAll('.followups');
    for(var i=0;i<olds.length;i++) olds[i].remove();
  }
  function addFollowups(){
    clearFollowups();
    var sets = [
      ['再讲一个笑话','夸夸我','哄哄我','我今天好累啊'],
      ['猜个谜语给我','你在干嘛呀？','讲个笑话逗我开心','我有点不开心'],
      ['现在几点了？','我饿了，吃什么好','夸夸我','哄哄我嘛']
    ];
    var picks = sets[Math.floor(Math.random()*sets.length)];
    var box = document.createElement('div');
    box.className = 'followups';
    picks.forEach(function(txt){
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'followup'; b.textContent = txt;
      b.addEventListener('click', function(){ sendChat(txt); });
      box.appendChild(b);
    });
    chatLog.appendChild(box);
    scrollChat();
  }

  var chatting = false;
  var lastActivityTs = Date.now();
  function splitReplyText(txt, serious){
    var s = String(txt||'').trim();
    if(serious || s.length<=62) return [s];
    // Split at sentence boundaries, balance into at most 3 bubbles
    var parts = s.match(/[^。！？\n]+[。！？\n]*/g) || [s];
    parts = parts.map(function(p){ return p.trim(); }).filter(Boolean);
    if(parts.length<=1) return [s];
    var target = parts.length>=4 ? 3 : 2;
    var total = s.length, per = total/target, chunks=[], cur='';
    for(var i=0;i<parts.length;i++){
      cur += parts[i];
      if(cur.length>=per && chunks.length<target-1){ chunks.push(cur.trim()); cur=''; }
    }
    if(cur.trim()) chunks.push(cur.trim());
    return chunks.slice(0,3);
  }
  function sendChat(raw){
    var text = (raw||'').replace(/^\s+|\s+$/g,'');
    if(!text || chatting) return;
    lastActivityTs = Date.now();
    chatting = true;
    hideAINotice();
    clearFollowups();
    addMsg('me', text);
    logEvent('chat', '');
    chatInput.value = '';
    taps++; updateMood();
    popSound(500);
    var typing = document.createElement('div');
    typing.className = 'msg-typing';
    typing.textContent = '···';
    typing.setAttribute('aria-label','可爱的乖乖正在输入');
    var typingRow = pigRow();
    typingRow.appendChild(typing);
    setTimeout(function(){ chatLog.appendChild(typingRow); scrollChat(); }, 220);
    function showReply(reply, delay){
      var serious = !!reply.serious || isSeriousText(text);
      // Variable typing delay tied to length: 600-1500ms
      var autoDelay = Math.min(1500, Math.max(600, 600 + String(reply.text||'').length * 14 + Math.random()*260));
      var wait = (typeof delay==='number' ? delay : autoDelay);
      setTimeout(function(){
        if(typingRow.parentNode) typingRow.remove();
        var chunks = splitReplyText(reply.text, serious);
        var idx = 0;
        function nextChunk(){
          if(idx>=chunks.length){
            if(!serious){ addSticker(reply.face); addFollowups(); }
            bumpMeters(0, 2, 0); vibrate(8);
            say(reply.text, reply.sub, reply.anim, reply.extra);
            if(reply.food && !serious){ foodEl.classList.remove('show'); void foodEl.offsetWidth; foodEl.classList.add('show'); }
            if(!serious) burstHearts(reply.extra==='loved' ? 7 : 4);
            popSound(560 + Math.random()*120);
            chatting = false;
            chatInput.focus();
            return;
          }
          addMsg('pig', chunks[idx]); idx++;
          if(idx<chunks.length) setTimeout(nextChunk, 650 + Math.random()*350);
          else nextChunk();
        }
        nextChunk();
      }, wait);
    }
    function fallback(reason){
      if(reason === 503) showAINotice('服务器还没配置 DeepSeek 钥匙（在服务器的 .env 里填 DEEPSEEK_API_KEY 后重启），这次先用离线聊天。');
      else if(reason === 401) showAINotice('DeepSeek 提示：服务器上的钥匙不对或已失效（401），这次已自动切回离线聊天。请检查服务器 .env 里的 DEEPSEEK_API_KEY。');
      else if(reason === 402) showAINotice('DeepSeek 提示：服务器上的 DeepSeek 账号余额不足（402），这次已自动切回离线聊天。去 DeepSeek 平台充值后，在线聊天会自己恢复。');
      else if(typeof reason === 'number' && reason) showAINotice('DeepSeek 联网失败（错误 ' + reason + '），这次已自动切回离线聊天。可以检查网络或稍后再重试。');
      else if(reason === 'network') showAINotice('DeepSeek 联网没成功（可能是网络问题或超时），这次已自动切回离线聊天。可以检查网络后重试。');
      var reply = findReply(text);
      rememberTurn(text, reply.text);
      showReply(reply);
    }
    // No key gate here on purpose: the backend decides. If the server has no
    // key it answers 503 and the catch below falls back to the offline brain.
    callDeepSeek(text).then(function(content){
      var seriousO = isSeriousText(text);
      var persona = seriousO ? 'care' : personaModes[replyCount % 3];
      replyCount++;
      var reply = onlineReplyObject(content, persona);
      reply.serious = seriousO;
      rememberTurn(text, content);
      showReply(reply);
    }).catch(function(err){
      var st = err && typeof err.status === 'number' && err.status ? err.status : null;
      if(st === 401 || st === 402) fallback(st);
      else if(st) fallback(st);
      else fallback('network');
    });
  }

  chatForm.addEventListener('submit', function(e){ e.preventDefault(); sendChat(chatInput.value); });
  var chatIntroToggle = document.getElementById('chatIntroToggle');
  var chatIntro = document.getElementById('chatIntro');
  if(chatIntroToggle && chatIntro){
    var toggleChatIntro = function(){
      var expanded = chatIntroToggle.getAttribute('aria-expanded') === 'true';
      if(expanded){
        chatIntro.hidden = true;
        chatIntroToggle.setAttribute('aria-expanded', 'false');
      } else {
        chatIntro.hidden = false;
        chatIntroToggle.setAttribute('aria-expanded', 'true');
      }
    };
    chatIntroToggle.addEventListener('click', toggleChatIntro);
    chatIntroToggle.addEventListener('keydown', function(e){
      if(e.key==='Enter' || e.key===' '){ e.preventDefault(); toggleChatIntro(); }
    });
  }
  var quickToggle = document.getElementById('quickToggle');
  var quickPanel = document.getElementById('quickPanel');
  var quickToggleLabel = document.getElementById('quickToggleLabel');
  if(quickToggle && quickPanel){
    quickToggle.addEventListener('click', function(){
      var expanded = quickToggle.getAttribute('aria-expanded') === 'true';
      if(expanded){
        quickPanel.hidden = true;
        quickToggle.setAttribute('aria-expanded', 'false');
        if(quickToggleLabel) quickToggleLabel.textContent = '展开';
      } else {
        quickPanel.hidden = false;
        quickToggle.setAttribute('aria-expanded', 'true');
        if(quickToggleLabel) quickToggleLabel.textContent = '收起';
      }
    });
  }
  document.querySelectorAll('#quickAsks .qask').forEach(function(btn){
    btn.addEventListener('click', function(){ sendChat(btn.dataset.q); });
  });

  // Show off one sticker right away so the feature is visible
  addSticker('proud');

  // Welcome back a remembered friend by name + proactive greeting after >6h + day milestones
  (function(){
    var dk = daysKnown();
    var awayLong = lastVisitTs && (Date.now()-lastVisitTs > 6*3600*1000);
    if(dk===7 || dk===30 || dk===100){
      addMsg('pig', '宝宝，我们认识第 ' + dk + ' 天啦。猪猪把这天记进回忆里了，撒花。今天也要好好的，听到没');
      addMemory('认识第'+dk+'天','我们认识第 '+dk+' 天啦','开心');
    } else if(awayLong && (profile.name || persistedTopic || profile.likes.length)){
      var cb = persistedTopic ? '对了，你上次说的「' + persistedTopic + '」，后来怎么样了？' : (profile.likes.length ? '对了，你喜欢的「' + profile.likes[0] + '」，最近还有在惦记吗？' : '你不在的时候，猪猪一直在想你。');
      addMsg('pig', '宝宝你回来啦，猪猪等你好久了。' + cb);
    } else if(profile.name){
      addMsg('pig', '你回来啦，' + profile.name + '。猪猪一眼就认出你了。' + (profile.likes.length ? '你喜欢的「' + profile.likes[0] + '」，我还记着。' : '') + '今天过得怎么样');
    }
  })();
  // Proactive idle line: after ~75s with no typing, pig speaks first once per idle stretch
  (function(){
    var idleLines = ['宝宝，猪猪饿了……你饿不饿','哼，你是不是把猪猪忘了','耳朵抖了一下，好像有人在想我','猪猪刚想起一个笑话，你要听吗','在干嘛呀，过来陪猪猪说说话','对了，你今天喝水了没'];
    var idleFired = false;
    setInterval(function(){
      if(chatting) return;
      var idleFor = Date.now()-lastActivityTs;
      if(idleFor>75000 && !idleFired){ idleFired = true; var line = idleLines[Math.floor(Math.random()*idleLines.length)]; say(line,'乖乖主动来找你了','wiggle',''); }
      if(idleFor<10000) idleFired = false;
    }, 15000);
    ['click','keydown','touchstart'].forEach(function(ev){ document.addEventListener(ev, function(){ lastActivityTs = Date.now(); }, {passive:true}); });
  })();

  // Sound toggle
  soundBtn.addEventListener('click', function(){
    soundOn = !soundOn;
    soundBtn.textContent = soundOn ? '声音：开' : '声音：关';
    soundBtn.setAttribute('aria-pressed', soundOn ? 'true' : 'false');
    if(soundOn) popSound(560);
  });

  // Time-based greeting
  (function(){
    var h = new Date().getHours();
    var g;
    if(h>=5 && h<11) g = '早上好呀！我是可爱的乖乖，今天也要元气满满哦！';
    else if(h>=11 && h<14) g = '中午好！我是可爱的乖乖，你吃午饭了吗？';
    else if(h>=14 && h<18) g = '下午好呀！我是可爱的乖乖，累了就来陪我玩一会儿。';
    else if(h>=18 && h<23) g = '晚上好！我是可爱的乖乖，今天辛苦啦。';
    else g = '夜深啦，我是可爱的乖乖，你怎么还没睡？早点休息哦。';
    bubbleText.textContent = g;
  })();

  // ===== window.GG bridge (Phase 3): feature modules use this, never app internals =====
  var ggEmotion = null; // 'happy' | 'sad' | 'wronged' | 'angry' | 'anxious' | 'lonely' | 'tired' | 'miss' | null
  var GG_EMOTION_PROMPTS = {
    happy: '【当前情绪：开心】跟宝宝一起开心，适度庆祝，别扫兴，别说教。',
    sad: '【当前情绪：难过】高冷和傲娇暂时收起来，温柔安慰，耐心倾听，先接住情绪，不讲道理，不用玩笑敷衍，不机械重复情话。',
    wronged: '【当前情绪：委屈】先理解感受，站宝宝这边，不急着讲道理。',
    angry: '【当前情绪：生气】先倾听，不反驳，不火上浇油，等宝宝说完。',
    anxious: '【当前情绪：焦虑】慢慢来，陪宝宝把担心说出来，一件一件拆开看，别催。',
    lonely: '【当前情绪：孤独】告诉宝宝你在，陪她说说话，别让她一个人待着。',
    tired: '【当前情绪：疲惫】减少复杂问题，提醒休息，少问多陪。',
    miss: '【当前情绪：想念】温柔回应宝宝的想念，告诉她你也想她，等她回来再慢慢说。'
  };
  var GG_EMOTION_NAMES = { happy:'开心', sad:'难过', wronged:'委屈', angry:'生气', anxious:'焦虑', lonely:'孤独', tired:'疲惫', miss:'想念' };
  function logEvent(type, detail){
    try{ apiFetch('/api/events', { method:'POST', body: JSON.stringify({ type: type, detail: detail || '' }) }).catch(function(){}); }catch(e){}
  }
  window.GG = {
    userToken: userToken,
    apiFetch: apiFetch,
    get profile(){ return profile; },
    get affection(){ return affection; },
    get memories(){ return memoriesLog; },
    addMemory: addMemory,
    saveProfile: saveProfile,
    get coins(){ return coins; },
    get meters(){ return meters; },
    get hat(){ return currentHat; },
    get seenFaces(){ return seenFaces; },
    setEmotion: function(name){ ggEmotion = name || null; },
    getEmotion: function(){ return ggEmotion; },
    emotionNames: GG_EMOTION_NAMES,
    sendChat: function(text, opts){ if(opts && opts.emotion) ggEmotion = opts.emotion; sendChat(text); },
    say: say, addSticker: addSticker, burstHearts: burstHearts,
    showNotice: showAINotice, hideNotice: hideAINotice, refreshAIStatus: refreshAIStatus,
    loadStateFromServer: loadStateFromServer, pushStateToServer: pushStateToServer,
    scheduleStateSync: scheduleStateSync,
    logEvent: logEvent,
    daysKnown: daysKnown
  };

  updateMood();
  // Route B: check the backend, pull server state + chat history (best effort).
  refreshAIStatus();
  loadStateFromServer();
  restoreChatHistory();
})();
