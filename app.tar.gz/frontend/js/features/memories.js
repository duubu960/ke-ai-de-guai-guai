// 回忆时光机 — 渲染到 #mem-timeline（Phase 3 前端模块 A）
// 数据全部走 GG.apiFetch 调后端；没有回忆时如实显示空状态，不编示例。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var box = document.getElementById('mem-timeline');
    if(!box) return;

    injectStyle();

    var CATS = { date:'📅 约会', travel:'✈️ 旅行', daily:'🌸 日常', festival:'🎉 节日', first:'💗 第一次', other:'✨ 其他' };
    var state = { list: [], month: '', q: '', fav: false, day: '', editingId: null, pendingPhoto: null, loading: false };

    // ---------- 小工具 ----------
    function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function fmtDate(d){ var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? m[1] + '年' + (+m[2]) + '月' + (+m[3]) + '日' : (d || ''); }
    function monthLabel(d){ var m = /^(\d{4})-(\d{2})-/.exec(d || ''); return m ? m[1] + '年' + (+m[2]) + '月' : '未标日期'; }
    function todayISO(){ var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
    function api(path, opts){
      return window.GG.apiFetch(path, opts).then(function(res){
        return res.json().catch(function(){ return {}; }).then(function(d){
          if(!res.ok){ var e = new Error((d && (d.detail || d.error)) || ('请求失败（' + res.status + '）')); e.status = res.status; throw e; }
          return d;
        });
      });
    }
    function normList(d){ var arr = []; if(Array.isArray(d)) arr = d; else if(d && Array.isArray(d.memories)) arr = d.memories; else if(d && Array.isArray(d.items)) arr = d.items; return arr.map(normMem); }
    // 后端返回驼峰字段（photoUrl/createdAt），与请求体的下划线字段都兼容
    function normMem(m){
      if(!m) return m;
      if(m.photoUrl !== undefined && m.photo_url === undefined) m.photo_url = m.photoUrl;
      if(m.createdAt !== undefined && m.created_at === undefined) m.created_at = m.createdAt;
      if(m.updatedAt !== undefined && m.updated_at === undefined) m.updated_at = m.updatedAt;
      return m;
    }

    // ---------- 骨架 ----------
    box.innerHTML =
      '<div class="ft-mem">' +
        '<div class="ft-mem-head"><h3>回忆时光机</h3>' +
        '<button type="button" class="btn-main ft-mem-new">＋ 写新回忆</button></div>' +
        '<div class="ft-mem-tools">' +
          '<input type="search" class="ft-mem-q" placeholder="搜索标题或文字…" aria-label="搜索回忆">' +
          '<input type="month" class="ft-mem-month" aria-label="按月份筛选">' +
          '<button type="button" class="chip ft-mem-fav">⭐ 只看收藏</button>' +
        '</div>' +
        '<div class="ft-mem-daychip" hidden>正在看 <b class="ft-mem-day"></b> 的回忆 <button type="button" class="ft-mem-day-x" aria-label="取消按日期查看">✕</button></div>' +
        '<div class="ft-mem-err" hidden></div>' +
        '<div class="ft-mem-form" hidden></div>' +
        '<div class="ft-mem-list"></div>' +
      '</div>';

    var elQ = box.querySelector('.ft-mem-q');
    var elMonth = box.querySelector('.ft-mem-month');
    var elFav = box.querySelector('.ft-mem-fav');
    var elDayChip = box.querySelector('.ft-mem-daychip');
    var elErr = box.querySelector('.ft-mem-err');
    var elForm = box.querySelector('.ft-mem-form');
    var elList = box.querySelector('.ft-mem-list');
    var qTimer = null;

    function showErr(msg){ elErr.hidden = !msg; elErr.textContent = msg || ''; }
    function buildQuery(){
      var p = [];
      if(state.month) p.push('month=' + encodeURIComponent(state.month));
      if(state.q) p.push('q=' + encodeURIComponent(state.q));
      if(state.fav) p.push('favorite=1');
      return p.length ? '?' + p.join('&') : '';
    }

    function load(){
      if(state.loading) return;
      state.loading = true;
      showErr('');
      api('/api/memories' + buildQuery()).then(function(d){
        state.list = normList(d);
        renderList();
      }).catch(function(e){
        showErr('回忆加载失败：' + e.message + '，请稍后再试。');
      }).then(function(){ state.loading = false; });
    }

    // ---------- 列表渲染 ----------
    function renderList(){
      var list = state.list;
      if(state.day) list = list.filter(function(m){ return m.date === state.day; });
      elDayChip.hidden = !state.day;
      if(state.day) box.querySelector('.ft-mem-day').textContent = fmtDate(state.day);
      if(!list.length){
        elList.innerHTML = '<div class="ft-mem-empty">还没有回忆，写下你们的第一条吧 💗<br>' +
          '<button type="button" class="btn-main ft-mem-empty-new">写第一条回忆</button></div>';
        var b = elList.querySelector('.ft-mem-empty-new');
        if(b) b.addEventListener('click', function(){ openForm(null); });
        return;
      }
      // 按月份分组（已按日期倒序返回）
      var groups = {}, order = [];
      list.forEach(function(m){
        var k = monthLabel(m.date);
        if(!groups[k]){ groups[k] = []; order.push(k); }
        groups[k].push(m);
      });
      var html = '';
      order.forEach(function(k){
        html += '<div class="ft-mem-month-h">' + esc(k) + '</div><div class="ft-mem-tl">';
        groups[k].forEach(function(m){
          html += '<article class="ft-mem-item" data-id="' + m.id + '">' +
            (m.photo_url ? '<img class="ft-mem-photo" src="' + esc(m.photo_url) + '" alt="" loading="lazy">' : '') +
            '<div class="ft-mem-body">' +
              '<div class="ft-mem-date">' + esc(fmtDate(m.date)) + (m.location ? ' · ' + esc(m.location) : '') + '</div>' +
              '<h4>' + esc(m.title) + '</h4>' +
              (m.category && CATS[m.category] ? '<span class="ft-mem-cat">' + esc(CATS[m.category]) + '</span>' : '') +
              (m.description ? '<p class="ft-mem-desc">' + esc(m.description) + '</p>' : '') +
              '<div class="ft-mem-ops">' +
                '<button type="button" class="chip ft-mem-favb" data-id="' + m.id + '" aria-label="收藏">' + (m.favorite ? '★ 已收藏' : '☆ 收藏') + '</button>' +
                '<button type="button" class="chip" data-edit="' + m.id + '">编辑</button>' +
                '<button type="button" class="chip" data-del="' + m.id + '">删除</button>' +
              '</div>' +
            '</div></article>';
        });
        html += '</div>';
      });
      elList.innerHTML = html;
    }

    // ---------- 详情弹窗 ----------
    var modal = null;
    function openDetail(id){
      var m = null;
      state.list.forEach(function(x){ if(String(x.id) === String(id)) m = x; });
      if(!m) return;
      var sameDay = state.list.filter(function(x){ return x.date === m.date && String(x.id) !== String(id); });
      closeModal();
      modal = document.createElement('div');
      modal.className = 'ft-mem-modal';
      modal.innerHTML = '<div class="ft-mem-modal-card">' +
        '<button type="button" class="ft-mem-modal-x" aria-label="关闭">✕</button>' +
        (m.photo_url ? '<img class="ft-mem-modal-photo" src="' + esc(m.photo_url) + '" alt="">' : '') +
        '<div class="ft-mem-modal-date">' + esc(fmtDate(m.date)) + (m.location ? ' · ' + esc(m.location) : '') + '</div>' +
        '<h3>' + esc(m.title) + '</h3>' +
        (m.category && CATS[m.category] ? '<span class="ft-mem-cat">' + esc(CATS[m.category]) + '</span>' : '') +
        (m.description ? '<p class="ft-mem-modal-desc">' + esc(m.description) + '</p>' : '') +
        (sameDay.length ? '<div class="ft-mem-sameday"><div class="ft-mem-sameday-h">这一天还有</div>' +
          sameDay.map(function(x){ return '<button type="button" class="chip ft-mem-sameday-item" data-id="' + x.id + '">' + esc(x.title) + '</button>'; }).join('') + '</div>' : '') +
        '<div class="ft-mem-modal-ops">' +
          '<button type="button" class="btn-main ft-mem-goday">带我回到那一天</button>' +
          '<button type="button" class="btn-ghost ft-mem-modal-edit">编辑这条</button>' +
        '</div></div>';
      document.body.appendChild(modal);
      modal.addEventListener('click', function(e){
        if(e.target === modal || e.target.classList.contains('ft-mem-modal-x')) closeModal();
        var sd = e.target.closest ? e.target.closest('.ft-mem-sameday-item') : null;
        if(sd){ openDetail(sd.getAttribute('data-id')); return; }
        if(e.target.classList.contains('ft-mem-goday')){
          state.day = m.date; state.month = ''; elMonth.value = ''; state.q = ''; elQ.value = '';
          closeModal(); renderList();
          if(box.scrollIntoView) box.scrollIntoView({ behavior: 'smooth', block: 'start' });
          return;
        }
        if(e.target.classList.contains('ft-mem-modal-edit')){ closeModal(); openForm(m); }
      });
    }
    function closeModal(){ if(modal){ modal.remove(); modal = null; } }

    // ---------- 表单 ----------
    function openForm(m){
      state.editingId = m ? m.id : null;
      state.pendingPhoto = null;
      elForm.hidden = false;
      elForm.innerHTML =
        '<h4>' + (m ? '编辑回忆' : '写一条新回忆') + '</h4>' +
        '<label>标题<input type="text" class="ft-mem-f-title" maxlength="80" value="' + esc(m ? m.title : '') + '" placeholder="给这段回忆起个名字"></label>' +
        '<label>日期<input type="date" class="ft-mem-f-date" value="' + esc(m ? m.date : todayISO()) + '"></label>' +
        '<label>分类<select class="ft-mem-f-cat">' +
          Object.keys(CATS).map(function(k){ return '<option value="' + k + '"' + (m && m.category === k ? ' selected' : '') + '>' + esc(CATS[k]) + '</option>'; }).join('') +
        '</select></label>' +
        '<label>地点<input type="text" class="ft-mem-f-loc" maxlength="60" value="' + esc(m ? m.location : '') + '" placeholder="在哪里发生的（可不填）"></label>' +
        '<label>文字<textarea class="ft-mem-f-desc" rows="4" maxlength="2000" placeholder="那天发生了什么，想记住什么……">' + esc(m ? m.description : '') + '</textarea></label>' +
        '<label>照片<span class="ft-mem-f-photo-hint">可选，上传后会自动压缩再保存</span>' +
          '<input type="file" class="ft-mem-f-photo" accept="image/jpeg,image/png,image/webp"></label>' +
        (m && m.photo_url ? '<img class="ft-mem-f-preview" src="' + esc(m.photo_url) + '" alt="已有照片">' : '<img class="ft-mem-f-preview" hidden alt="照片预览">') +
        '<div class="ft-mem-f-err" hidden></div>' +
        '<div class="ft-mem-f-ops"><button type="button" class="btn-main ft-mem-f-save">保存</button>' +
        '<button type="button" class="btn-ghost ft-mem-f-cancel">取消</button></div>';
      if(elForm.scrollIntoView) elForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
      wireForm(m);
    }
    function wireForm(m){
      var fPhoto = elForm.querySelector('.ft-mem-f-photo');
      var preview = elForm.querySelector('.ft-mem-f-preview');
      var fErr = elForm.querySelector('.ft-mem-f-err');
      if(fPhoto) fPhoto.addEventListener('change', function(){
        var f = fPhoto.files && fPhoto.files[0];
        if(!f) return;
        if(f.size > 10 * 1024 * 1024){ fErr.hidden = false; fErr.textContent = '这张照片太大了（超过 10MB），换一张小一点的吧。'; fPhoto.value = ''; return; }
        compressImage(f, function(err, dataUrl){
          if(err){ fErr.hidden = false; fErr.textContent = err.message; fPhoto.value = ''; return; }
          fErr.hidden = true;
          state.pendingPhoto = { dataUrl: dataUrl, name: f.name };
          preview.src = dataUrl; preview.hidden = false;
        });
      });
      elForm.querySelector('.ft-mem-f-cancel').addEventListener('click', function(){ elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null; });
      elForm.querySelector('.ft-mem-f-save').addEventListener('click', function(){
        var title = elForm.querySelector('.ft-mem-f-title').value.trim();
        var date = elForm.querySelector('.ft-mem-f-date').value;
        if(!title){ fErr.hidden = false; fErr.textContent = '先给这条回忆起个标题吧。'; return; }
        if(!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)){ fErr.hidden = false; fErr.textContent = '选一个正确的日期。'; return; }
        var body = {
          title: title, date: date,
          category: elForm.querySelector('.ft-mem-f-cat').value,
          location: elForm.querySelector('.ft-mem-f-loc').value.trim(),
          description: elForm.querySelector('.ft-mem-f-desc').value.trim(),
          photo_url: (m && m.photo_url) || ''
        };
        var saveBtn = elForm.querySelector('.ft-mem-f-save');
        saveBtn.disabled = true; saveBtn.textContent = '保存中…';
        var chain = Promise.resolve();
        if(state.pendingPhoto){
          chain = chain.then(function(){
            return api('/api/photos', { method: 'POST', body: JSON.stringify({ dataUrl: state.pendingPhoto.dataUrl, name: state.pendingPhoto.name }) });
          }).then(function(d){
            if(!d || !d.url) throw new Error('照片上传失败了，回忆还没保存，请再试一次。');
            body.photo_url = d.url;
          });
        }
        chain.then(function(){
          var path = state.editingId ? '/api/memories/' + state.editingId : '/api/memories';
          return api(path, { method: state.editingId ? 'PUT' : 'POST', body: JSON.stringify(body) });
        }).then(function(){
          var wasEdit = !!state.editingId;
          elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null; state.pendingPhoto = null;
          if(window.GG && window.GG.logEvent) window.GG.logEvent('memory_saved', wasEdit ? 'edit' : 'new');
          load();
        }).catch(function(e){
          fErr.hidden = false; fErr.textContent = '保存失败：' + e.message;
          saveBtn.disabled = false; saveBtn.textContent = '保存';
        });
      });
    }

    // ---------- 照片压缩（最长边 ≤1200，JPEG 0.8） ----------
    function compressImage(file, cb){
      var reader;
      try{ reader = new FileReader(); }catch(e){ cb(new Error('浏览器不支持读照片')); return; }
      reader.onerror = function(){ cb(new Error('读不到这张照片，换一张试试')); };
      reader.onload = function(){
        var img = new Image();
        img.onerror = function(){ cb(new Error('这张照片打不开，换一张试试')); };
        img.onload = function(){
          var max = 1200, w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
          if(!w || !h){ cb(new Error('这张照片读不到尺寸，换一张试试')); return; }
          var scale = Math.min(1, max / Math.max(w, h));
          var cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
          var canvas = document.createElement('canvas');
          canvas.width = cw; canvas.height = ch;
          var ctx = canvas.getContext && canvas.getContext('2d');
          if(!ctx){ cb(new Error('浏览器不支持图片压缩')); return; }
          ctx.drawImage(img, 0, 0, cw, ch);
          cb(null, canvas.toDataURL('image/jpeg', 0.8));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    }

    // ---------- 事件 ----------
    box.querySelector('.ft-mem-new').addEventListener('click', function(){ openForm(null); });
    elQ.addEventListener('input', function(){
      clearTimeout(qTimer);
      qTimer = setTimeout(function(){ state.q = elQ.value.trim(); load(); }, 400);
    });
    elMonth.addEventListener('change', function(){ state.month = elMonth.value; state.day = ''; load(); });
    elFav.addEventListener('click', function(){
      state.fav = !state.fav;
      elFav.classList.toggle('active', state.fav);
      load();
    });
    box.querySelector('.ft-mem-day-x').addEventListener('click', function(){ state.day = ''; renderList(); });
    elList.addEventListener('click', function(e){
      var fav = e.target.closest ? e.target.closest('.ft-mem-favb') : null;
      var ed = e.target.closest ? e.target.closest('[data-edit]') : null;
      var del = e.target.closest ? e.target.closest('[data-del]') : null;
      var item = e.target.closest ? e.target.closest('.ft-mem-item') : null;
      if(fav){
        var id = fav.getAttribute('data-id'), cur = null;
        state.list.forEach(function(x){ if(String(x.id) === String(id)) cur = x; });
        if(!cur) return;
        var body = { title: cur.title, date: cur.date, location: cur.location || '', description: cur.description || '', category: cur.category || 'other', photo_url: cur.photo_url || '', favorite: cur.favorite ? 0 : 1 };
        api('/api/memories/' + id, { method: 'PUT', body: JSON.stringify(body) }).then(load).catch(function(err){ showErr('收藏失败：' + err.message); });
        return;
      }
      if(ed){
        var m = null;
        state.list.forEach(function(x){ if(String(x.id) === String(ed.getAttribute('data-edit'))) m = x; });
        if(m) openForm(m);
        return;
      }
      if(del){
        var did = del.getAttribute('data-del');
        if(!window.confirm('确定要删除这条回忆吗？删除后就找不回来啦。')) return;
        api('/api/memories/' + did, { method: 'DELETE' }).then(load).catch(function(err){ showErr('删除失败：' + err.message); });
        return;
      }
      if(item) openDetail(item.getAttribute('data-id'));
    });
    document.addEventListener('gg:page', function(e){
      if(e && e.detail && e.detail.page === 'memories') load();
    });

    function injectStyle(){
      if(document.querySelector('style[data-feature="memories"]')) return;
      var s = document.createElement('style');
      s.setAttribute('data-feature', 'memories');
      s.textContent =
        '.ft-mem h3{font-size:19px;margin:0}' +
        '.ft-mem-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:18px 2px 10px}' +
        '.ft-mem-head .btn-main{flex:0 0 auto;padding:10px 18px;min-height:44px;font-size:14.5px}' +
        '.ft-mem-tools{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}' +
        '.ft-mem-tools input[type=search]{flex:1 1 160px;min-height:44px;border:1px solid var(--line);border-radius:999px;padding:10px 16px;font-size:14.5px;font-family:inherit;background:var(--card);color:var(--ink)}' +
        '.ft-mem-tools input[type=month]{min-height:44px;border:1px solid var(--line);border-radius:999px;padding:8px 12px;font-size:14px;font-family:inherit;background:var(--card);color:var(--ink)}' +
        '.ft-mem-daychip{margin:0 2px 10px;font-size:13.5px;color:var(--muted)}' +
        '.ft-mem-daychip button{border:none;background:none;color:var(--accent-deep);font-size:15px;cursor:pointer;min-height:44px}' +
        '.ft-mem-err{background:var(--pink-pale);border:1px solid var(--line);color:var(--ink);border-radius:14px;padding:10px 14px;font-size:13.5px;margin-bottom:10px}' +
        '.ft-mem-month-h{font-size:14px;font-weight:800;color:var(--muted);margin:16px 4px 8px}' +
        '.ft-mem-tl{position:relative;margin-left:8px;padding-left:18px;border-left:2px solid var(--pink-soft)}' +
        '.ft-mem-item{position:relative;background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);margin-bottom:12px;overflow:hidden;cursor:pointer}' +
        '.ft-mem-item::before{content:"";position:absolute;left:-23px;top:20px;width:10px;height:10px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 4px var(--pink-soft)}' +
        '.ft-mem-photo{width:100%;max-height:220px;object-fit:cover;display:block}' +
        '.ft-mem-body{padding:14px 16px}' +
        '.ft-mem-date{font-size:12.5px;color:var(--muted);margin-bottom:4px}' +
        '.ft-mem-body h4{margin:0 0 6px;font-size:16.5px}' +
        '.ft-mem-cat{display:inline-block;background:var(--pink-pale);color:var(--accent-deep);border-radius:999px;padding:3px 10px;font-size:12.5px;font-weight:700}' +
        '.ft-mem-desc{margin:8px 0 0;font-size:14px;line-height:1.7;color:var(--ink);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}' +
        '.ft-mem-ops{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}' +
        '.ft-mem-ops .chip{min-height:40px;padding:8px 14px;font-size:13px}' +
        '.ft-mem-empty{background:var(--card);border:1px dashed var(--line);border-radius:20px;padding:32px 18px;text-align:center;color:var(--muted);font-size:14.5px;line-height:1.8}' +
        '.ft-mem-empty .btn-main{margin-top:14px;padding:10px 22px;min-height:44px;font-size:14.5px}' +
        '.ft-mem-form{background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:16px;margin-bottom:14px}' +
        '.ft-mem-form h4{margin:0 0 12px;font-size:16.5px}' +
        '.ft-mem-form label{display:block;font-size:13.5px;font-weight:700;color:var(--muted);margin-bottom:10px}' +
        '.ft-mem-form input[type=text],.ft-mem-form input[type=date],.ft-mem-form select,.ft-mem-form textarea{width:100%;min-height:44px;border:1px solid var(--line);border-radius:12px;padding:10px 12px;font-size:14.5px;font-family:inherit;background:var(--surface);color:var(--ink);margin-top:4px}' +
        '.ft-mem-form textarea{resize:vertical;line-height:1.6}' +
        '.ft-mem-f-photo-hint{font-weight:400;font-size:12.5px;margin-left:6px}' +
        '.ft-mem-f-preview{width:100%;max-height:240px;object-fit:cover;border-radius:14px;margin:4px 0 10px}' +
        '.ft-mem-f-err{color:var(--accent-deep);font-size:13.5px;margin-bottom:8px}' +
        '.ft-mem-f-ops{display:flex;gap:10px}' +
        '.ft-mem-f-ops .btn-main{flex:1}' +
        '.ft-mem-modal{position:fixed;inset:0;background:rgba(42,24,54,.55);z-index:200;display:flex;align-items:flex-end;justify-content:center}' +
        '.ft-mem-modal-card{position:relative;background:var(--card);border-radius:26px 26px 0 0;max-width:480px;width:100%;max-height:88vh;overflow:auto;padding:20px 20px 28px}' +
        '.ft-mem-modal-x{position:absolute;top:12px;right:12px;width:40px;height:40px;min-height:40px;border-radius:50%;border:1px solid var(--line);background:var(--card);color:var(--ink);font-size:15px;cursor:pointer}' +
        '.ft-mem-modal-photo{width:100%;max-height:260px;object-fit:cover;border-radius:16px}' +
        '.ft-mem-modal-date{font-size:12.5px;color:var(--muted);margin:10px 0 4px}' +
        '.ft-mem-modal-card h3{margin:0 0 8px;font-size:20px}' +
        '.ft-mem-modal-desc{font-size:15px;line-height:1.9;white-space:pre-wrap;margin:12px 0 0}' +
        '.ft-mem-sameday{margin-top:16px;border-top:1px dashed var(--line);padding-top:12px}' +
        '.ft-mem-sameday-h{font-size:13px;font-weight:700;color:var(--muted);margin-bottom:8px}' +
        '.ft-mem-sameday-item{margin:0 6px 6px 0}' +
        '.ft-mem-modal-ops{display:flex;gap:10px;margin-top:18px}' +
        '.ft-mem-modal-ops .btn-main{flex:1}';
      document.head.appendChild(s);
    }

    load();
  });
})();
