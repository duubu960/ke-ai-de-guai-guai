// 纪念日与倒计时 — 渲染到 #mem-anniversaries（Phase 3 前端模块 A）
// 日期全部由用户输入；没有日期时如实提示不编天数；刷新后数据从服务器来。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var box = document.getElementById('mem-anniversaries');
    if(!box) return;

    injectStyle();

    var TYPES = { first_meet:'💗 第一次见面', anniversary:'💍 恋爱纪念日', birthday:'🎂 生日', custom:'✨ 重要日子' };
    var state = { list: [], summary: null, editingId: null, celebratedToday: false };

    function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function fmtDate(d){ var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? m[1] + '年' + (+m[2]) + '月' + (+m[3]) + '日' : (d || ''); }
    function todayISO(){ var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
    function api(path, opts){
      return window.GG.apiFetch(path, opts).then(function(res){
        return res.json().catch(function(){ return {}; }).then(function(d){
          if(!res.ok){ var e = new Error((d && (d.detail || d.error)) || ('请求失败（' + res.status + '）')); e.status = res.status; throw e; }
          return d;
        });
      });
    }
    function normList(d){ if(Array.isArray(d)) return d; if(d && Array.isArray(d.anniversaries)) return d.anniversaries; if(d && Array.isArray(d.items)) return d.items; return []; }

    box.innerHTML =
      '<div class="ft-ann">' +
        '<div class="ft-ann-err" hidden></div>' +
        '<div class="ft-ann-hero"></div>' +
        '<div class="ft-ann-next"></div>' +
        '<div class="ft-ann-head"><h3>纪念日</h3>' +
        '<button type="button" class="btn-main ft-ann-new">＋ 记一个日子</button></div>' +
        '<div class="ft-ann-form" hidden></div>' +
        '<div class="ft-ann-list"></div>' +
      '</div>';

    var elErr = box.querySelector('.ft-ann-err');
    var elHero = box.querySelector('.ft-ann-hero');
    var elNext = box.querySelector('.ft-ann-next');
    var elForm = box.querySelector('.ft-ann-form');
    var elList = box.querySelector('.ft-ann-list');

    function showErr(msg){ elErr.hidden = !msg; elErr.textContent = msg || ''; }

    function load(){
      showErr('');
      var p1 = api('/api/anniversaries/summary').then(function(d){ state.summary = d; }).catch(function(e){ state.summary = null; showErr('倒计时加载失败：' + e.message); });
      var p2 = api('/api/anniversaries').then(function(d){ state.list = normList(d); }).catch(function(e){ state.list = []; showErr('纪念日加载失败：' + e.message); });
      Promise.all([p1, p2]).then(render);
    }

    function render(){
      // --- 在一起天数 ---
      var s = state.summary;
      if(s && typeof s.daysTogether === 'number'){
        elHero.innerHTML = '<div class="ft-ann-days"><span class="ft-ann-days-l">我们在一起</span>' +
          '<span class="ft-ann-days-n">' + s.daysTogether + '</span><span class="ft-ann-days-l">天啦 💗</span></div>';
      } else {
        elHero.innerHTML = '<div class="ft-ann-days ft-ann-days-empty">先记下你们第一次见面的日子吧 💗' +
          '<br><button type="button" class="btn-main ft-ann-first">记下第一次见面</button></div>';
        var b = elHero.querySelector('.ft-ann-first');
        if(b) b.addEventListener('click', function(){ openForm(null, 'first_meet'); });
      }
      // --- 最近倒计时 ---
      var next = (s && Array.isArray(s.next)) ? s.next : [];
      if(next.length){
        var n = next[0];
        var daysLeft = n.daysLeft;
        var isToday = daysLeft === 0;
        elNext.innerHTML = '<div class="ft-ann-count">' +
          '<div class="ft-ann-count-l">最近的日子</div>' +
          '<div class="ft-ann-count-t">' + esc(n.title) + '</div>' +
          '<div class="ft-ann-count-d">' + esc(fmtDate(n.date)) + '</div>' +
          (isToday ? '<div class="ft-ann-count-n">就是今天 🎉</div>' : '<div class="ft-ann-count-n">还剩 <b>' + daysLeft + '</b> 天</div>') +
          (next.length > 1 ? '<div class="ft-ann-count-more">接下来还有：' + next.slice(1, 3).map(function(x){ return esc(x.title) + '（' + x.daysLeft + '天）'; }).join('、') + '</div>' : '') +
          '</div>';
        if(isToday && !state.celebratedToday){
          state.celebratedToday = true;
          if(window.GG.burstHearts) window.GG.burstHearts(8);
          if(window.GG.say) window.GG.say('宝宝，今天是「' + n.title + '」！要开开心心地过哦，乖乖陪你一起庆祝。', '今天是个好日子', 'wiggle', 'loved');
        }
      } else {
        elNext.innerHTML = '';
      }
      // --- 管理列表 ---
      if(!state.list.length){
        elList.innerHTML = '<div class="ft-ann-empty">还没有记任何日子，上面先记一个吧。</div>';
        return;
      }
      var sorted = state.list.slice().sort(function(a, b){ return String(a.date).localeCompare(String(b.date)); });
      elList.innerHTML = sorted.map(function(a){
        return '<div class="ft-ann-item">' +
          '<div class="ft-ann-item-b"><div class="ft-ann-item-t">' + esc(TYPES[a.type] || '✨ 重要日子') + ' · ' + esc(a.title) + '</div>' +
          '<div class="ft-ann-item-d">' + esc(fmtDate(a.date)) + (a.note ? ' · ' + esc(a.note) : '') + '</div></div>' +
          '<div class="ft-ann-item-ops">' +
            '<button type="button" class="chip" data-edit="' + a.id + '">编辑</button>' +
            '<button type="button" class="chip" data-del="' + a.id + '">删除</button>' +
          '</div></div>';
      }).join('');
    }

    function openForm(a, presetType){
      state.editingId = a ? a.id : null;
      elForm.hidden = false;
      elForm.innerHTML =
        '<h4>' + (a ? '编辑纪念日' : '记一个日子') + '</h4>' +
        '<label>标题<input type="text" class="ft-ann-f-title" maxlength="60" value="' + esc(a ? a.title : '') + '" placeholder="例如：第一次见面、在一起一周年"></label>' +
        '<label>日期<input type="date" class="ft-ann-f-date" value="' + esc(a ? a.date : todayISO()) + '"></label>' +
        '<label>类型<select class="ft-ann-f-type">' +
          Object.keys(TYPES).map(function(k){ return '<option value="' + k + '"' + (((a && a.type === k) || (!a && presetType === k)) ? ' selected' : '') + '>' + esc(TYPES[k]) + '</option>'; }).join('') +
        '</select></label>' +
        '<label>备注<input type="text" class="ft-ann-f-note" maxlength="120" value="' + esc(a ? a.note : '') + '" placeholder="想对这个日子说点什么（可不填）"></label>' +
        '<div class="ft-ann-f-err" hidden></div>' +
        '<div class="ft-ann-f-ops"><button type="button" class="btn-main ft-ann-f-save">保存</button>' +
        '<button type="button" class="btn-ghost ft-ann-f-cancel">取消</button></div>';
      if(elForm.scrollIntoView) elForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
      var fErr = elForm.querySelector('.ft-ann-f-err');
      elForm.querySelector('.ft-ann-f-cancel').addEventListener('click', function(){ elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null; });
      elForm.querySelector('.ft-ann-f-save').addEventListener('click', function(){
        var title = elForm.querySelector('.ft-ann-f-title').value.trim();
        var date = elForm.querySelector('.ft-ann-f-date').value;
        if(!title){ fErr.hidden = false; fErr.textContent = '先给这个日子起个名字吧。'; return; }
        if(!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)){ fErr.hidden = false; fErr.textContent = '选一个正确的日期。'; return; }
        var body = { title: title, date: date, type: elForm.querySelector('.ft-ann-f-type').value, note: elForm.querySelector('.ft-ann-f-note').value.trim() };
        var saveBtn = elForm.querySelector('.ft-ann-f-save');
        saveBtn.disabled = true; saveBtn.textContent = '保存中…';
        var path = state.editingId ? '/api/anniversaries/' + state.editingId : '/api/anniversaries';
        api(path, { method: state.editingId ? 'PUT' : 'POST', body: JSON.stringify(body) }).then(function(){
          elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null;
          load();
        }).catch(function(e){
          fErr.hidden = false; fErr.textContent = '保存失败：' + e.message;
          saveBtn.disabled = false; saveBtn.textContent = '保存';
        });
      });
    }

    box.querySelector('.ft-ann-new').addEventListener('click', function(){ openForm(null); });
    elList.addEventListener('click', function(e){
      var ed = e.target.closest ? e.target.closest('[data-edit]') : null;
      var del = e.target.closest ? e.target.closest('[data-del]') : null;
      if(ed){
        var a = null;
        state.list.forEach(function(x){ if(String(x.id) === String(ed.getAttribute('data-edit'))) a = x; });
        if(a) openForm(a);
        return;
      }
      if(del){
        var id = del.getAttribute('data-del');
        if(!window.confirm('确定要删除这个纪念日吗？')) return;
        api('/api/anniversaries/' + id, { method: 'DELETE' }).then(load).catch(function(err){ showErr('删除失败：' + err.message); });
      }
    });
    document.addEventListener('gg:page', function(e){
      if(e && e.detail && e.detail.page === 'memories') load();
    });

    function injectStyle(){
      if(document.querySelector('style[data-feature="anniversaries"]')) return;
      var s = document.createElement('style');
      s.setAttribute('data-feature', 'anniversaries');
      s.textContent =
        '.ft-ann-err{background:var(--pink-pale);border:1px solid var(--line);color:var(--ink);border-radius:14px;padding:10px 14px;font-size:13.5px;margin:14px 0 0}' +
        '.ft-ann-hero{margin-top:14px}' +
        '.ft-ann-days{background:linear-gradient(135deg,var(--pink-soft),var(--pink-pale));border:1px solid var(--line);border-radius:24px;box-shadow:var(--shadow);padding:22px 18px;text-align:center}' +
        '.ft-ann-days-l{display:block;font-size:14px;color:var(--muted);font-weight:700}' +
        '.ft-ann-days-n{display:block;font-size:52px;line-height:1.2;font-weight:800;color:var(--accent-deep)}' +
        '.ft-ann-days-empty{font-size:15px;line-height:1.8;color:var(--ink)}' +
        '.ft-ann-days-empty .btn-main{margin-top:12px;padding:10px 22px;min-height:44px;font-size:14.5px}' +
        '.ft-ann-count{background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:16px;margin-top:12px;text-align:center}' +
        '.ft-ann-count-l{font-size:12.5px;color:var(--muted);font-weight:700}' +
        '.ft-ann-count-t{font-size:18px;font-weight:800;margin-top:4px}' +
        '.ft-ann-count-d{font-size:13.5px;color:var(--muted);margin-top:2px}' +
        '.ft-ann-count-n{font-size:15px;font-weight:800;color:var(--accent-deep);margin-top:8px}' +
        '.ft-ann-count-n b{font-size:26px}' +
        '.ft-ann-count-more{font-size:12.5px;color:var(--muted);margin-top:8px;line-height:1.6}' +
        '.ft-ann-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:20px 2px 10px}' +
        '.ft-ann-head h3{font-size:19px;margin:0}' +
        '.ft-ann-head .btn-main{flex:0 0 auto;padding:10px 18px;min-height:44px;font-size:14.5px}' +
        '.ft-ann-empty{background:var(--card);border:1px dashed var(--line);border-radius:20px;padding:22px 16px;text-align:center;color:var(--muted);font-size:14px;line-height:1.7}' +
        '.ft-ann-item{display:flex;justify-content:space-between;align-items:center;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:12px 14px;margin-bottom:8px}' +
        '.ft-ann-item-t{font-size:14.5px;font-weight:700;line-height:1.5}' +
        '.ft-ann-item-d{font-size:12.5px;color:var(--muted);margin-top:2px;line-height:1.5}' +
        '.ft-ann-item-ops{display:flex;gap:6px;flex:0 0 auto}' +
        '.ft-ann-item-ops .chip{min-height:40px;padding:8px 12px;font-size:13px}' +
        '.ft-ann-form{background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:16px;margin-bottom:12px}' +
        '.ft-ann-form h4{margin:0 0 12px;font-size:16.5px}' +
        '.ft-ann-form label{display:block;font-size:13.5px;font-weight:700;color:var(--muted);margin-bottom:10px}' +
        '.ft-ann-form input[type=text],.ft-ann-form input[type=date],.ft-ann-form select{width:100%;min-height:44px;border:1px solid var(--line);border-radius:12px;padding:10px 12px;font-size:14.5px;font-family:inherit;background:var(--surface);color:var(--ink);margin-top:4px}' +
        '.ft-ann-f-err{color:var(--accent-deep);font-size:13.5px;margin-bottom:8px}' +
        '.ft-ann-f-ops{display:flex;gap:10px}' +
        '.ft-ann-f-ops .btn-main{flex:1}';
      document.head.appendChild(s);
    }

    load();
  });
})();
