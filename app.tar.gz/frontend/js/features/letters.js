// 专属信件 — 渲染到 #mem-letters（Phase 3 前端模块 A）
// 信件可保存草稿/收藏/阅读/复制/下载；AI 起草只放进编辑框让用户自己改，不包装成真人写的。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var box = document.getElementById('mem-letters');
    if(!box) return;

    injectStyle();

    var state = { list: [], editingId: null };
    var modal = null;

    function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
    function fmtDate(d){ var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? m[1] + '年' + (+m[2]) + '月' + (+m[3]) + '日' : (d || ''); }
    function fmtTs(ts){ if(!ts) return ''; var t = new Date(ts); if(isNaN(t.getTime())) return ''; return t.getFullYear() + '年' + (t.getMonth() + 1) + '月' + t.getDate() + '日'; }
    function todayISO(){ var t = new Date(); return t.getFullYear() + '-' + ('0' + (t.getMonth() + 1)).slice(-2) + '-' + ('0' + t.getDate()).slice(-2); }
    function api(path, opts){
      return window.GG.apiFetch(path, opts).then(function(res){
        return res.json().catch(function(){ return {}; }).then(function(d){
          if(!res.ok){ var e = new Error((d && (d.detail || d.error)) || ('请求失败（' + res.status + '）')); e.status = res.status; throw e; }
          return d;
        });
      });
    }
    function normList(d){ var arr = []; if(Array.isArray(d)) arr = d; else if(d && Array.isArray(d.letters)) arr = d.letters; else if(d && Array.isArray(d.items)) arr = d.items; return arr.map(normLet); }
    // 后端返回驼峰字段（occasionDate/updatedAt），与请求体的下划线字段都兼容
    function normLet(l){
      if(!l) return l;
      if(l.occasionDate !== undefined && l.occasion_date === undefined) l.occasion_date = l.occasionDate;
      if(l.updatedAt !== undefined && l.updated_at === undefined) l.updated_at = l.updatedAt;
      if(l.createdAt !== undefined && l.created_at === undefined) l.created_at = l.createdAt;
      return l;
    }

    box.innerHTML =
      '<div class="ft-let">' +
        '<div class="ft-let-head"><h3>写给宝宝的信 💌</h3>' +
        '<button type="button" class="btn-main ft-let-new">＋ 写一封信</button></div>' +
        '<div class="ft-let-err" hidden></div>' +
        '<div class="ft-let-form" hidden></div>' +
        '<div class="ft-let-list"></div>' +
      '</div>';

    var elErr = box.querySelector('.ft-let-err');
    var elForm = box.querySelector('.ft-let-form');
    var elList = box.querySelector('.ft-let-list');

    function showErr(msg){ elErr.hidden = !msg; elErr.textContent = msg || ''; }

    function load(){
      showErr('');
      api('/api/letters').then(function(d){
        state.list = normList(d);
        renderList();
      }).catch(function(e){ showErr('信件加载失败：' + e.message + '，请稍后再试。'); });
    }

    function renderList(){
      if(!state.list.length){
        elList.innerHTML = '<div class="ft-let-empty">还没有写过信，写第一封给宝宝吧 💌<br>' +
          '<button type="button" class="btn-main ft-let-empty-new">写第一封信</button></div>';
        var b = elList.querySelector('.ft-let-empty-new');
        if(b) b.addEventListener('click', function(){ openForm(null); });
        return;
      }
      var sorted = state.list.slice().sort(function(a, b){ return (b.updated_at || 0) - (a.updated_at || 0); });
      elList.innerHTML = sorted.map(function(l){
        var date = l.occasion_date ? fmtDate(l.occasion_date) : fmtTs(l.updated_at);
        return '<article class="ft-let-item" data-id="' + l.id + '">' +
          '<div class="ft-let-item-t">' + esc(l.title || '没有标题的信') + '</div>' +
          '<div class="ft-let-item-m">' + esc(date) + ' · ' + (l.status === 'sent' ? '已送出' : '草稿') + (l.favorite ? ' · ★ 已收藏' : '') + '</div>' +
          '<div class="ft-let-item-p">' + esc((l.content || '').slice(0, 60)) + ((l.content || '').length > 60 ? '…' : '') + '</div>' +
          '<div class="ft-let-item-ops">' +
            '<button type="button" class="chip" data-open="' + l.id + '">读信</button>' +
            '<button type="button" class="chip" data-edit="' + l.id + '">编辑</button>' +
            '<button type="button" class="chip ft-let-favb" data-fav="' + l.id + '">' + (l.favorite ? '★ 已收藏' : '☆ 收藏') + '</button>' +
            '<button type="button" class="chip" data-del="' + l.id + '">删除</button>' +
          '</div></article>';
      }).join('');
    }

    // ---------- 编辑表单 ----------
    function openForm(l, presetContent){
      state.editingId = l ? l.id : null;
      elForm.hidden = false;
      elForm.innerHTML =
        '<h4>' + (l ? '编辑信件' : '写一封信') + '</h4>' +
        '<label>标题<input type="text" class="ft-let-f-title" maxlength="80" value="' + esc(l ? l.title : '') + '" placeholder="给这封信起个名字"></label>' +
        '<label>纪念日（可选）<input type="date" class="ft-let-f-date" value="' + esc(l && l.occasion_date ? l.occasion_date : '') + '"></label>' +
        '<label>状态<select class="ft-let-f-status">' +
          '<option value="draft"' + (!l || l.status !== 'sent' ? ' selected' : '') + '>草稿</option>' +
          '<option value="sent"' + (l && l.status === 'sent' ? ' selected' : '') + '>已送出</option>' +
        '</select></label>' +
        '<label>信的内容<textarea class="ft-let-f-content" rows="9" maxlength="6000" placeholder="宝宝：\n\n想对她说的话，都写在这里……">' + esc(presetContent != null ? presetContent : (l ? l.content : '')) + '</textarea></label>' +
        '<div class="ft-let-ai">' +
          '<div class="ft-let-ai-row"><input type="text" class="ft-let-f-occasion" maxlength="40" placeholder="场合（可选，如：纪念日、想你的时候）">' +
          '<select class="ft-let-f-tone"><option value="温柔">温柔</option><option value="俏皮">俏皮</option><option value="想念">想念</option><option value="郑重">郑重</option></select></div>' +
          '<button type="button" class="btn-ghost ft-let-f-ai">✨ AI 帮我写一封</button>' +
          '<p class="ft-let-ai-note" hidden></p>' +
        '</div>' +
        '<div class="ft-let-f-err" hidden></div>' +
        '<div class="ft-let-f-ops"><button type="button" class="btn-main ft-let-f-save">保存</button>' +
        '<button type="button" class="btn-ghost ft-let-f-cancel">取消</button></div>';
      if(elForm.scrollIntoView) elForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
      wireForm(l);
    }
    function wireForm(l){
      var fErr = elForm.querySelector('.ft-let-f-err');
      var aiNote = elForm.querySelector('.ft-let-ai-note');
      elForm.querySelector('.ft-let-f-cancel').addEventListener('click', function(){ elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null; });
      elForm.querySelector('.ft-let-f-ai').addEventListener('click', function(){
        var aiBtn = elForm.querySelector('.ft-let-f-ai');
        aiBtn.disabled = true; aiBtn.textContent = '正在想怎么写…';
        api('/api/letters/ai-draft', { method: 'POST', body: JSON.stringify({ occasion: elForm.querySelector('.ft-let-f-occasion').value.trim(), tone: elForm.querySelector('.ft-let-f-tone').value }) }).then(function(d){
          var draft = (d && (d.draft || d.content)) || '';
          var source = (d && d.source) || '';
          if(!draft) throw new Error('这次没有拿到草稿，请自己写几句吧。');
          var ta = elForm.querySelector('.ft-let-f-content');
          ta.value = (ta.value.trim() ? ta.value + '\n\n' : '') + draft;
          aiNote.hidden = false;
          aiNote.textContent = (source === 'ai'
            ? '这封草稿是 AI 帮你起的头，里面的话请你改成自己的语气再送出。'
            : '这是本地模板生成的基础草稿，不是真人写的，也不是 AI 在线写的，请你确认内容后再用。') +
            '如果草稿里提到了具体的事，请核对一下是不是真的发生过哦。';
        }).catch(function(e){
          aiNote.hidden = false;
          aiNote.textContent = 'AI 起草失败了：' + e.message + '。先自己写几句也没关系。';
        }).then(function(){ aiBtn.disabled = false; aiBtn.textContent = '✨ AI 帮我写一封'; });
      });
      elForm.querySelector('.ft-let-f-save').addEventListener('click', function(){
        var title = elForm.querySelector('.ft-let-f-title').value.trim();
        var content = elForm.querySelector('.ft-let-f-content').value.trim();
        if(!title){ fErr.hidden = false; fErr.textContent = '先给这封信起个标题吧。'; return; }
        if(!content){ fErr.hidden = false; fErr.textContent = '信的内容还是空的，写几句再保存吧。'; return; }
        var body = { title: title, content: content, occasion_date: elForm.querySelector('.ft-let-f-date').value || null, status: elForm.querySelector('.ft-let-f-status').value };
        var saveBtn = elForm.querySelector('.ft-let-f-save');
        saveBtn.disabled = true; saveBtn.textContent = '保存中…';
        var path = state.editingId ? '/api/letters/' + state.editingId : '/api/letters';
        api(path, { method: state.editingId ? 'PUT' : 'POST', body: JSON.stringify(body) }).then(function(){
          elForm.hidden = true; elForm.innerHTML = ''; state.editingId = null;
          if(window.GG && window.GG.logEvent) window.GG.logEvent('letter_saved', '');
          load();
        }).catch(function(e){
          fErr.hidden = false; fErr.textContent = '保存失败：' + e.message;
          saveBtn.disabled = false; saveBtn.textContent = '保存';
        });
      });
    }

    // ---------- 阅读页 ----------
    function openReader(id){
      var l = null;
      state.list.forEach(function(x){ if(String(x.id) === String(id)) l = x; });
      if(!l) return;
      closeModal();
      var date = l.occasion_date ? fmtDate(l.occasion_date) : fmtTs(l.updated_at);
      var paras = String(l.content || '').split(/\n+/).map(function(p){ return '<p>' + esc(p) + '</p>'; }).join('');
      modal = document.createElement('div');
      modal.className = 'ft-let-modal';
      modal.innerHTML = '<div class="ft-let-paper">' +
        '<button type="button" class="ft-let-modal-x" aria-label="关闭">✕</button>' +
        '<div class="ft-let-paper-date">' + esc(date) + '</div>' +
        '<h3 class="ft-let-paper-t">' + esc(l.title || '没有标题的信') + '</h3>' +
        '<div class="ft-let-paper-body">' + paras + '</div>' +
        '<div class="ft-let-paper-sign">—— 可爱的乖乖</div>' +
        '<div class="ft-let-paper-ops">' +
          '<button type="button" class="btn-main ft-let-copy">复制信件</button>' +
          '<button type="button" class="btn-ghost ft-let-dl">下载 .txt</button>' +
        '</div>' +
        '<div class="ft-let-paper-tip" hidden></div>' +
        '</div>';
      document.body.appendChild(modal);
      var fullText = (l.title ? l.title + '\n' : '') + (date ? date + '\n\n' : '') + (l.content || '') + '\n\n—— 可爱的乖乖';
      var tip = modal.querySelector('.ft-let-paper-tip');
      modal.addEventListener('click', function(e){
        if(e.target === modal || e.target.classList.contains('ft-let-modal-x')){ closeModal(); return; }
        if(e.target.classList.contains('ft-let-copy')){
          copyText(fullText, tip);
          return;
        }
        if(e.target.classList.contains('ft-let-dl')){
          try{
            var blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = ((l.title || '给宝宝的信').replace(/[\\/:*?"<>|]/g, '') || '给宝宝的信') + '.txt';
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1000);
            tip.hidden = false; tip.textContent = '已经开始下载啦。';
          }catch(err){
            tip.hidden = false; tip.textContent = '下载失败了，换个浏览器再试试。';
          }
        }
      });
    }
    function copyText(text, tip){
      function done(ok){
        tip.hidden = false;
        tip.textContent = ok ? '已经复制到剪贴板啦。' : '复制失败，请手动选中信的内容复制。';
      }
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(function(){ done(true); }, function(){
          fallbackCopy(text, done);
        });
      } else {
        fallbackCopy(text, done);
      }
    }
    function fallbackCopy(text, done){
      try{
        var ta = document.createElement('textarea');
        ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select();
        var ok = document.execCommand('copy');
        ta.remove(); done(!!ok);
      }catch(e){ done(false); }
    }
    function closeModal(){ if(modal){ modal.remove(); modal = null; } }

    // ---------- 事件 ----------
    box.querySelector('.ft-let-new').addEventListener('click', function(){ openForm(null); });
    elList.addEventListener('click', function(e){
      var open = e.target.closest ? e.target.closest('[data-open]') : null;
      var ed = e.target.closest ? e.target.closest('[data-edit]') : null;
      var fav = e.target.closest ? e.target.closest('[data-fav]') : null;
      var del = e.target.closest ? e.target.closest('[data-del]') : null;
      var item = e.target.closest ? e.target.closest('.ft-let-item') : null;
      if(open){ openReader(open.getAttribute('data-open')); return; }
      if(ed){
        var l = null;
        state.list.forEach(function(x){ if(String(x.id) === String(ed.getAttribute('data-edit'))) l = x; });
        if(l) openForm(l);
        return;
      }
      if(fav){
        api('/api/letters/' + fav.getAttribute('data-fav') + '/favorite', { method: 'POST' }).then(load).catch(function(err){ showErr('收藏失败：' + err.message); });
        return;
      }
      if(del){
        if(!window.confirm('确定要删除这封信吗？删除后就找不回来啦。')) return;
        api('/api/letters/' + del.getAttribute('data-del'), { method: 'DELETE' }).then(load).catch(function(err){ showErr('删除失败：' + err.message); });
        return;
      }
      if(item) openReader(item.getAttribute('data-id'));
    });
    document.addEventListener('gg:page', function(e){
      if(e && e.detail && e.detail.page === 'memories') load();
    });

    function injectStyle(){
      if(document.querySelector('style[data-feature="letters"]')) return;
      var s = document.createElement('style');
      s.setAttribute('data-feature', 'letters');
      s.textContent =
        '.ft-let-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin:20px 2px 10px}' +
        '.ft-let-head h3{font-size:19px;margin:0}' +
        '.ft-let-head .btn-main{flex:0 0 auto;padding:10px 18px;min-height:44px;font-size:14.5px}' +
        '.ft-let-err{background:var(--pink-pale);border:1px solid var(--line);color:var(--ink);border-radius:14px;padding:10px 14px;font-size:13.5px;margin-bottom:10px}' +
        '.ft-let-empty{background:var(--card);border:1px dashed var(--line);border-radius:20px;padding:32px 18px;text-align:center;color:var(--muted);font-size:14.5px;line-height:1.8}' +
        '.ft-let-empty .btn-main{margin-top:14px;padding:10px 22px;min-height:44px;font-size:14.5px}' +
        '.ft-let-item{background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:16px;margin-bottom:12px;cursor:pointer}' +
        '.ft-let-item-t{font-size:16.5px;font-weight:800}' +
        '.ft-let-item-m{font-size:12.5px;color:var(--muted);margin-top:4px}' +
        '.ft-let-item-p{font-size:14px;line-height:1.7;color:var(--ink);margin-top:8px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}' +
        '.ft-let-item-ops{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}' +
        '.ft-let-item-ops .chip{min-height:40px;padding:8px 14px;font-size:13px}' +
        '.ft-let-form{background:var(--card);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);padding:16px;margin-bottom:14px}' +
        '.ft-let-form h4{margin:0 0 12px;font-size:16.5px}' +
        '.ft-let-form label{display:block;font-size:13.5px;font-weight:700;color:var(--muted);margin-bottom:10px}' +
        '.ft-let-form input[type=text],.ft-let-form input[type=date],.ft-let-form select,.ft-let-form textarea{width:100%;min-height:44px;border:1px solid var(--line);border-radius:12px;padding:10px 12px;font-size:14.5px;font-family:inherit;background:var(--surface);color:var(--ink);margin-top:4px}' +
        '.ft-let-form textarea{resize:vertical;line-height:1.8}' +
        '.ft-let-ai{border-top:1px dashed var(--line);padding-top:12px;margin-bottom:10px}' +
        '.ft-let-ai-row{display:flex;gap:8px}' +
        '.ft-let-ai-row input{flex:1}' +
        '.ft-let-ai-row select{flex:0 0 96px}' +
        '.ft-let-ai .btn-ghost{margin-top:8px;width:100%}' +
        '.ft-let-ai-note{font-size:13px;line-height:1.7;color:var(--muted);margin:8px 0 0}' +
        '.ft-let-f-err{color:var(--accent-deep);font-size:13.5px;margin-bottom:8px}' +
        '.ft-let-f-ops{display:flex;gap:10px}' +
        '.ft-let-f-ops .btn-main{flex:1}' +
        '.ft-let-modal{position:fixed;inset:0;background:rgba(42,24,54,.55);z-index:200;display:flex;align-items:flex-end;justify-content:center}' +
        '.ft-let-paper{position:relative;background:linear-gradient(180deg,#FFF9FB,#FFF3F8);border-radius:26px 26px 0 0;max-width:480px;width:100%;max-height:88vh;overflow:auto;padding:26px 24px 30px}' +
        '.ft-let-modal-x{position:absolute;top:12px;right:12px;width:40px;height:40px;min-height:40px;border-radius:50%;border:1px solid var(--line);background:var(--card);color:var(--ink);font-size:15px;cursor:pointer}' +
        '.ft-let-paper-date{text-align:center;font-size:13px;color:var(--muted);letter-spacing:.1em}' +
        '.ft-let-paper-t{text-align:center;font-size:21px;margin:10px 0 18px}' +
        '.ft-let-paper-body p{font-size:15.5px;line-height:2.1;letter-spacing:.04em;text-indent:2em;margin:0 0 6px;white-space:pre-wrap}' +
        '.ft-let-paper-sign{text-align:right;font-size:15px;font-weight:700;color:var(--accent-deep);margin-top:20px}' +
        '.ft-let-paper-ops{display:flex;gap:10px;margin-top:22px}' +
        '.ft-let-paper-ops .btn-main{flex:1}' +
        '.ft-let-paper-tip{text-align:center;font-size:13.5px;color:var(--muted);margin-top:10px}';
      document.head.appendChild(s);
    }

    load();
  });
})();
