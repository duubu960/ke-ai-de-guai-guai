// 隐私保险箱（Phase 3）：渲染到 #me-vault。
// 真加密：WebCrypto AES-GCM + PBKDF2（随机 16 字节 salt、10 万次迭代、SHA-256）。
// 密码只在内存里，绝不发给服务器；服务器只存密文。
// 忘记密码 = 打不开，没有任何找回接口，不要找客服，也不要问乖乖。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var root = document.getElementById('me-vault');
    if(!root) return;
    injectStyle();

    var cryptoObj = window.crypto || window.msCrypto || null;
    var password = null;      // 只在内存里，上锁即清除
    var items = [];           // 解密后的条目 [{id, title, content, updated_at}]
    var unlocked = false;

    root.innerHTML =
      '<div class="card vt-card">' +
        '<h3 class="vt-h">🔐 隐私保险箱</h3>' +
        '<p class="vt-sub">只有你知道密码的小抽屉。里面的字先在你的手机上加密，再发给服务器，服务器看到的只是一串谁也读不懂的密文。</p>' +
        '<p class="vt-warn">页面备份导出的是密文，没有密码也打不开。</p>' +
        '<div class="vt-body" data-vault-body aria-live="polite"><p class="vt-empty">正在看看保险箱里有什么…</p></div>' +
      '</div>';
    var bodyEl = root.querySelector('[data-vault-body]');

    if(!cryptoObj || !cryptoObj.subtle){
      bodyEl.innerHTML = '<p class="vt-empty">这个浏览器没有加密功能（需要 WebCrypto），换个新一点的浏览器再来用保险箱。</p>';
      return;
    }

    loadVault();

    // ---- base64 工具 ----
    function bufToB64(buf){
      var bytes = new Uint8Array(buf);
      var bin = '';
      for(var i = 0; i < bytes.length; i += 8192){
        bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
      }
      return window.btoa(bin);
    }
    function b64ToBuf(b64){
      var bin = window.atob(b64);
      var bytes = new Uint8Array(bin.length);
      for(var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return bytes.buffer;
    }

    // ---- 加密 / 解密 ----
    function deriveKey(pw, saltBuf){
      return cryptoObj.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey'])
        .then(function(base){
          return cryptoObj.subtle.deriveKey(
            { name: 'PBKDF2', salt: saltBuf, iterations: 100000, hash: 'SHA-256' },
            base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
        });
    }
    function encryptText(pw, plain){
      var salt = cryptoObj.getRandomValues(new Uint8Array(16));
      var iv = cryptoObj.getRandomValues(new Uint8Array(12));
      return deriveKey(pw, salt.buffer).then(function(key){
        return cryptoObj.subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, new TextEncoder().encode(plain));
      }).then(function(ct){
        return { blob: bufToB64(ct), iv: bufToB64(iv.buffer), salt: bufToB64(salt.buffer) };
      });
    }
    function decryptItem(pw, item){
      return deriveKey(pw, b64ToBuf(item.salt)).then(function(key){
        return cryptoObj.subtle.decrypt(
          { name: 'AES-GCM', iv: new Uint8Array(b64ToBuf(item.iv)) },
          key, b64ToBuf(item.blob));
      }).then(function(pt){
        return JSON.parse(new TextDecoder().decode(pt));
      });
    }

    // ---- 后端取回 ----
    function fetchItems(){
      return window.GG.apiFetch('/api/vault/items').then(function(res){
        if(!res.ok) throw new Error('http ' + res.status);
        return res.json();
      }).then(function(d){
        if(Array.isArray(d)) return d;
        return d.items || d || [];
      });
    }

    function loadVault(){
      fetchItems().then(function(list){
        if(!list.length){
          renderSetup();
        }else{
          renderUnlock(list);
        }
      }).catch(function(){
        bodyEl.innerHTML = '<p class="vt-empty">保险箱暂时打不开，检查一下后端连接，稍后再来。</p>' +
          '<button type="button" class="play-btn" data-vault-retry>再试一次</button>';
        var btn = bodyEl.querySelector('[data-vault-retry]');
        if(btn) btn.addEventListener('click', loadVault);
      });
    }

    // ---- 首次使用：设密码 ----
    function renderSetup(){
      bodyEl.innerHTML =
        '<p class="vt-empty">保险箱还是空的，先设一个只有你知道的密码吧（至少 6 位）。</p>' +
        '<label class="vt-label">密码<input type="password" class="vt-input" data-vt-pw1 autocomplete="new-password" placeholder="至少 6 位" /></label>' +
        '<label class="vt-label">再输一遍<input type="password" class="vt-input" data-vt-pw2 autocomplete="new-password" placeholder="确认密码" /></label>' +
        '<p class="vt-err" data-vt-err hidden></p>' +
        '<button type="button" class="play-btn vt-wide" data-vt-setup>设好密码</button>' +
        '<p class="vt-forget">忘记密码怎么办：密码只存在你脑子里，忘了就打不开了，真的没办法。所以请一定记牢，写在只有你能看到的地方。</p>';
      bodyEl.querySelector('[data-vt-setup]').addEventListener('click', function(){
        var pw1 = bodyEl.querySelector('[data-vt-pw1]').value || '';
        var pw2 = bodyEl.querySelector('[data-vt-pw2]').value || '';
        var err = bodyEl.querySelector('[data-vt-err]');
        if(pw1.length < 6){ err.hidden = false; err.textContent = '密码至少 6 位，太短了不安全。'; return; }
        if(pw1 !== pw2){ err.hidden = false; err.textContent = '两次输入的密码不一样，再对一下。'; return; }
        err.hidden = true;
        password = pw1;
        unlocked = true;
        items = [];
        renderList();
      });
    }

    // ---- 已有密文：解锁 ----
    var lockedList = [];
    function renderUnlock(list){
      lockedList = list;
      bodyEl.innerHTML =
        '<p class="vt-empty">保险箱里有 ' + list.length + ' 条秘密，输密码打开它。</p>' +
        '<label class="vt-label">密码<input type="password" class="vt-input" data-vt-pw autocomplete="current-password" placeholder="输入保险箱密码" /></label>' +
        '<p class="vt-err" data-vt-err hidden></p>' +
        '<button type="button" class="play-btn vt-wide" data-vt-unlock>打开保险箱</button>' +
        '<p class="vt-forget">忘记密码怎么办：密码只存在你脑子里，忘了就打不开了，真的没办法。没有找回入口，也没有备用钥匙。</p>';
      var pwInput = bodyEl.querySelector('[data-vt-pw]');
      function doUnlock(){
        var pw = pwInput.value || '';
        var err = bodyEl.querySelector('[data-vt-err]');
        if(!pw){ err.hidden = false; err.textContent = '先输入密码。'; return; }
        err.hidden = true;
        bodyEl.querySelector('[data-vt-unlock]').textContent = '正在开锁…';
        // 逐条解密：只要有一条解开就说明密码对
        var tries = lockedList.map(function(it){
          return decryptItem(pw, it).then(function(data){
            return { id: it.id, title: data.title || '', content: data.content || '', updated_at: it.updated_at };
          }).catch(function(){ return null; });
        });
        Promise.all(tries).then(function(results){
          var ok = results.filter(function(r){ return r !== null; });
          if(!ok.length){
            err.hidden = false;
            err.textContent = '密码不对，再想想。提示：密码只在你脑子里，输错了打不开是正常的。';
            bodyEl.querySelector('[data-vt-unlock]').textContent = '打开保险箱';
            return;
          }
          password = pw;
          unlocked = true;
          items = ok;
          renderList();
        });
      }
      bodyEl.querySelector('[data-vt-unlock]').addEventListener('click', doUnlock);
      pwInput.addEventListener('keydown', function(e){ if(e.key === 'Enter'){ e.preventDefault(); doUnlock(); } });
    }

    // ---- 已解锁：列表 + 新增/编辑/删除 ----
    function renderList(){
      var html = '<p class="vt-empty">保险箱打开着，离开前记得点「上锁」。一共有 ' + items.length + ' 条秘密。</p>';
      if(!items.length){
        html += '<p class="vt-empty">还没有秘密，写第一条吧。</p>';
      }else{
        html += '<div class="vt-list">';
        for(var i = 0; i < items.length; i++){
          var it = items[i];
          html += '<div class="vt-item" data-vt-id="' + esc(it.id) + '">' +
            '<div class="vt-item-head"><b>' + esc(it.title || '没有标题') + '</b>' +
            '<span class="vt-item-btns"><button type="button" class="vt-mini" data-vt-edit>编辑</button>' +
            '<button type="button" class="vt-mini vt-mini-del" data-vt-del>删除</button></span></div>' +
            '<p class="vt-item-content">' + esc(it.content || '') + '</p></div>';
        }
        html += '</div>';
      }
      html += '<div class="vt-form">' +
        '<label class="vt-label">标题<input type="text" class="vt-input" data-vt-title maxlength="100" placeholder="给这条秘密起个名字" /></label>' +
        '<label class="vt-label">内容<textarea class="vt-input vt-area" data-vt-content rows="3" maxlength="5000" placeholder="写下来，只有你能打开…"></textarea></label>' +
        '<p class="vt-err" data-vt-err hidden></p>' +
        '<button type="button" class="play-btn vt-wide" data-vt-add>加密保存</button>' +
        '<button type="button" class="btn-ghost vt-wide" data-vt-lock>🔒 上锁</button>' +
        '</div>';
      bodyEl.innerHTML = html;

      var itemEls = bodyEl.querySelectorAll('[data-vt-id]');
      for(var k = 0; k < itemEls.length; k++){
        (function(el){
          var id = el.getAttribute('data-vt-id');
          el.querySelector('[data-vt-del]').addEventListener('click', function(){
            if(!window.confirm('真的要删掉这条秘密吗？删了就找不回来。')) return;
            window.GG.apiFetch('/api/vault/items/' + encodeURIComponent(id), { method: 'DELETE' })
              .then(function(res){
                if(!res.ok) throw new Error('http ' + res.status);
                items = items.filter(function(x){ return String(x.id) !== String(id); });
                renderList();
              }).catch(function(){
                var err = bodyEl.querySelector('[data-vt-err]');
                err.hidden = false; err.textContent = '没删掉，检查一下后端连接再试。';
              });
          });
          el.querySelector('[data-vt-edit]').addEventListener('click', function(){
            var it = null;
            for(var j = 0; j < items.length; j++){ if(String(items[j].id) === String(id)) it = items[j]; }
            if(!it) return;
            bodyEl.querySelector('[data-vt-title]').value = it.title || '';
            bodyEl.querySelector('[data-vt-content]').value = it.content || '';
            bodyEl.querySelector('[data-vt-add]').textContent = '加密保存修改';
            bodyEl.querySelector('[data-vt-add]').setAttribute('data-edit-id', id);
            bodyEl.querySelector('[data-vt-content]').focus();
          });
        })(itemEls[k]);
      }

      bodyEl.querySelector('[data-vt-add]').addEventListener('click', function(){
        var btn = this;
        var title = (bodyEl.querySelector('[data-vt-title]').value || '').replace(/^\s+|\s+$/g, '');
        var content = (bodyEl.querySelector('[data-vt-content]').value || '').replace(/^\s+|\s+$/g, '');
        var err = bodyEl.querySelector('[data-vt-err]');
        if(!content){ err.hidden = false; err.textContent = '内容是空的，写点什么再保存。'; return; }
        err.hidden = true;
        btn.textContent = '正在加密…';
        var editId = btn.getAttribute('data-edit-id');
        encryptText(password, JSON.stringify({ title: title, content: content })).then(function(enc){
          var url = editId ? '/api/vault/items/' + encodeURIComponent(editId) : '/api/vault/items';
          var method = editId ? 'PUT' : 'POST';
          return window.GG.apiFetch(url, { method: method, body: JSON.stringify(enc) }).then(function(res){
            if(!res.ok) throw new Error('http ' + res.status);
            return res.json().catch(function(){ return {}; });
          }).then(function(d){
            var id = (d && d.id != null) ? d.id : editId;
            if(editId){
              for(var j = 0; j < items.length; j++){
                if(String(items[j].id) === String(editId)){ items[j].title = title; items[j].content = content; }
              }
            }else{
              items.push({ id: id, title: title, content: content, updated_at: Date.now() });
            }
            renderList();
          });
        }).catch(function(){
          err.hidden = false; err.textContent = '没保存上，检查一下后端连接再试。';
          btn.textContent = editId ? '加密保存修改' : '加密保存';
        });
      });

      bodyEl.querySelector('[data-vt-lock]').addEventListener('click', function(){
        password = null;
        unlocked = false;
        items = [];
        loadVault();
      });
    }

    function esc(s){
      return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="vault"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'vault');
      st.textContent =
        '.vt-card{display:flex;flex-direction:column;gap:10px;}' +
        '.vt-h{margin:0;font-size:17px;}' +
        '.vt-sub{margin:0;color:var(--muted);font-size:13.5px;line-height:1.6;}' +
        '.vt-warn{margin:0;background:var(--pink-pale);border:1px solid var(--pink);border-radius:12px;padding:9px 12px;font-size:13px;line-height:1.5;color:var(--ink);}' +
        '.vt-empty{color:var(--muted);font-size:14px;line-height:1.6;margin:0;}' +
        '.vt-forget{margin:0;font-size:12.5px;line-height:1.6;color:var(--muted);background:var(--card2);border:1px dashed var(--line);border-radius:12px;padding:9px 12px;}' +
        '.vt-label{display:flex;flex-direction:column;gap:6px;font-size:13.5px;font-weight:700;color:var(--ink);margin:0 0 10px;}' +
        '.vt-input{border:1.5px solid var(--line);border-radius:12px;background:var(--card);color:var(--ink);padding:11px 14px;font-size:15px;min-height:48px;}' +
        '.vt-area{resize:vertical;line-height:1.6;}' +
        '.vt-err{margin:0 0 10px;color:#B04040;font-size:13.5px;font-weight:700;}' +
        '.vt-wide{width:100%;}' +
        '.vt-list{display:flex;flex-direction:column;gap:10px;}' +
        '.vt-item{background:var(--card2);border:1px solid var(--line);border-radius:16px;padding:12px 14px;}' +
        '.vt-item-head{display:flex;justify-content:space-between;align-items:center;gap:10px;}' +
        '.vt-item-head b{font-size:15px;}' +
        '.vt-item-btns{display:flex;gap:6px;flex:0 0 auto;}' +
        '.vt-mini{min-height:44px;border-radius:999px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);font-size:13px;font-weight:700;padding:6px 12px;cursor:pointer;}' +
        '.vt-mini-del{color:#B04040;border-color:#F2A0A0;}' +
        '.vt-item-content{margin:8px 0 0;font-size:14px;line-height:1.7;white-space:pre-wrap;word-break:break-word;}' +
        '.vt-form{border-top:1px solid var(--line);padding-top:12px;display:flex;flex-direction:column;gap:10px;}' +
        '.vt-form .vt-label{margin:0;}';
      document.head.appendChild(st);
    }
  });
})();
