/* 可爱的乖乖 — 每日惊喜盲盒（Phase 3）
 * 渲染到 #surprise-box。每天只能开一次（服务器靠 (token, date) 唯一键保证）；
 * 今天已开过就展示已有的那份，绝不重新生成。source:"offline" 时如实标注
 * 「乖乖自己写的小惊喜」，不包装成 AI 生成。数据一律走 GG.apiFetch。 */
(function () {
  'use strict';

  function boot() {
    if (!window.GG || !window.GG.apiFetch) return;
    var root = document.getElementById('surprise-box');
    if (!root) return;
    init(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  var KINDS = {
    love_note: { icon: '💌', label: 'AI 专属情话', hint: '乖乖想对宝宝说' },
    note:      { icon: '📝', label: '温柔小纸条', hint: '今天的小纸条' },
    blessing:  { icon: '✨', label: '今日专属祝福', hint: '送给宝宝的祝福' },
    story:     { icon: '📖', label: '随机小故事', hint: '乖乖讲的小故事' },
    question:  { icon: '❓', label: '趣味问题', hint: '想一想，慢慢答' },
    task:      { icon: '🤝', label: '情侣互动任务', hint: '今天和乖乖一起做' },
    memory:    { icon: '💗', label: '专属回忆', hint: '翻出来的小回忆' },
    ai:        { icon: '🤖', label: 'AI 小惊喜', hint: '乖乖用 AI 给你变的小惊喜' }
  };

  function injectStyle() {
    if (document.querySelector('style[data-feature="surprise"]')) return;
    var st = document.createElement('style');
    st.setAttribute('data-feature', 'surprise');
    st.textContent =
      '.sp-card{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:0 8px 24px rgba(255,105,180,.12);padding:16px 14px;margin-bottom:12px}' +
      '.sp-card h3{margin:0 0 4px;font-size:17px;color:var(--ink)}' +
      '.sp-sub{margin:0 0 12px;font-size:12.5px;color:var(--muted);line-height:1.5}' +
      '.sp-open-btn{width:100%;min-height:52px;border:none;border-radius:999px;background:var(--accent);color:#fff;font-weight:800;font-size:16px;cursor:pointer;box-shadow:inset 0 2px 0 rgba(255,255,255,.55),0 8px 18px rgba(255,105,180,.30)}' +
      '.sp-open-btn:disabled{background:var(--pink-soft);color:var(--muted);box-shadow:none;cursor:default}' +
      '.sp-open-btn:active:not(:disabled){transform:scale(.98)}' +
      '.sp-kind{display:inline-flex;align-items:center;gap:6px;background:var(--pink-pale);color:var(--accent-deep);border-radius:999px;padding:4px 10px;font-size:12.5px;font-weight:800;margin-bottom:10px}' +
      '.sp-title{font-size:16px;font-weight:800;color:var(--ink);margin:0 0 8px;line-height:1.4}' +
      '.sp-content{font-size:14.5px;line-height:1.75;color:var(--ink);white-space:pre-wrap;margin:0 0 10px}' +
      '.sp-src{font-size:12px;color:var(--muted);margin:0}' +
      '.sp-task-done{margin-top:10px;width:100%;min-height:44px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;font-size:14px;font-weight:800;cursor:pointer}' +
      '.sp-task-done.done{background:var(--pink-pale);border-color:var(--pink);color:var(--accent-deep)}' +
      '.sp-hist-title{font-size:15px;font-weight:800;color:var(--ink);margin:14px 0 8px}' +
      '.sp-hist-item{display:flex;align-items:flex-start;gap:10px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:10px 12px;margin-bottom:8px}' +
      '.sp-hist-ico{font-size:20px;line-height:1.2;flex:0 0 auto}' +
      '.sp-hist-body{flex:1;min-width:0}' +
      '.sp-hist-t{font-size:14px;font-weight:800;color:var(--ink);line-height:1.35}' +
      '.sp-hist-c{font-size:13px;color:var(--muted);line-height:1.55;margin-top:2px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}' +
      '.sp-hist-d{font-size:11.5px;color:var(--muted);margin-top:4px}' +
      '.sp-fav{flex:0 0 auto;border:none;background:transparent;font-size:20px;cursor:pointer;min-width:44px;min-height:44px;line-height:1}' +
      '.sp-err{font-size:13px;color:var(--muted);line-height:1.6}' +
      '.sp-err button{margin-top:8px}' +
      '.sp-empty{font-size:13.5px;color:var(--muted);line-height:1.6}';
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function todayStr() {
    var d = new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' + m : m) + '-' + (day < 10 ? '0' + day : day);
  }

  function asList(d) {
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.items)) return d.items;
    if (d && Array.isArray(d.surprises)) return d.surprises;
    if (d && Array.isArray(d.history)) return d.history;
    return [];
  }

  function init(root) {
    injectStyle();
    var state = { today: null, history: [], opening: false };

    root.innerHTML =
      '<div class="sp-card" id="spTodayCard">' +
        '<h3>🎁 今天的专属惊喜</h3>' +
        '<p class="sp-sub">每天只能开一次哦，开出来的就是今天独一份的惊喜。</p>' +
        '<div id="spTodayBody"><p class="sp-empty">正在看看今天的惊喜开过了没有…</p></div>' +
      '</div>' +
      '<div id="spHistoryWrap"><h3 class="sp-hist-title">以前的惊喜</h3><div id="spHistoryBody"><p class="sp-empty">正在翻以前的惊喜…</p></div></div>';

    var todayBody = root.querySelector('#spTodayBody');
    var historyBody = root.querySelector('#spHistoryBody');

    function apiErr(res, fallback) {
      return res.json().catch(function () { return {}; }).then(function (d) {
        throw new Error((d && d.detail) || (d && d.error) || fallback);
      });
    }

    function renderToday() {
      if (state.today) {
        var k = KINDS[state.today.kind] || { icon: '🎁', label: '小惊喜', hint: '今天的惊喜' };
        var srcLine = state.today.source === 'offline'
          ? '乖乖自己写的小惊喜'
          : '乖乖用 AI 给宝宝准备的惊喜';
        var taskBtn = state.today.kind === 'task'
          ? '<button type="button" class="sp-task-done" id="spTaskDone">我完成啦 ✓</button>'
          : '';
        todayBody.innerHTML =
          '<p class="sp-sub" style="margin-bottom:8px">今天的惊喜已经开过啦，留在这里慢慢看～</p>' +
          '<div class="sp-kind"><span>' + k.icon + '</span><span>' + esc(k.label) + '</span></div>' +
          '<p class="sp-title">' + esc(state.today.title || k.hint) + '</p>' +
          '<p class="sp-content">' + esc(state.today.content || '') + '</p>' +
          '<p class="sp-src">' + (state.today.source === 'offline' ? '💗 ' : '✨ ') + esc(srcLine) + '</p>' +
          taskBtn;
        var doneBtn = todayBody.querySelector('#spTaskDone');
        if (doneBtn) {
          doneBtn.addEventListener('click', function () {
            doneBtn.classList.add('done');
            doneBtn.textContent = '完成啦，宝宝最棒了 💗';
            doneBtn.disabled = true;
            window.GG.burstHearts(8);
            window.GG.say('宝宝完成任务啦！乖乖给你一个大大的拥抱，今天也超厉害的～', '', 'happy');
            window.GG.logEvent('surprise_task_done', state.today.kind || '');
          });
        }
      } else {
        todayBody.innerHTML =
          '<button type="button" class="sp-open-btn" id="spOpenBtn">🎁 开今天的惊喜</button>';
        var btn = todayBody.querySelector('#spOpenBtn');
        btn.addEventListener('click', openToday);
      }
    }

    function renderHistory() {
      if (!state.history.length) {
        historyBody.innerHTML = '<p class="sp-empty">还没有开过的惊喜。开一个今天的，历史就从这里开始啦。</p>';
        return;
      }
      historyBody.innerHTML = '';
      state.history.forEach(function (item) {
        var k = KINDS[item.kind] || { icon: '🎁', label: '小惊喜' };
        var row = document.createElement('div');
        row.className = 'sp-hist-item';
        row.innerHTML =
          '<span class="sp-hist-ico">' + k.icon + '</span>' +
          '<div class="sp-hist-body">' +
            '<div class="sp-hist-t">' + esc(item.title || k.label) + '</div>' +
            '<div class="sp-hist-c">' + esc(item.content || '') + '</div>' +
            '<div class="sp-hist-d">' + esc(item.date || '') + (item.source === 'offline' ? ' · 乖乖自己写的' : '') + '</div>' +
          '</div>' +
          '<button type="button" class="sp-fav" aria-label="收藏这份惊喜">' + (item.favorite ? '⭐' : '☆') + '</button>';
        var favBtn = row.querySelector('.sp-fav');
        favBtn.addEventListener('click', function () {
          favBtn.disabled = true;
          window.GG.apiFetch('/api/surprises/' + item.id + '/favorite', { method: 'POST' })
            .then(function (res) {
              if (!res.ok) return apiErr(res, '收藏失败');
              return res.json().catch(function () { return {}; });
            })
            .then(function (d) {
              item.favorite = (d && d.favorite != null) ? d.favorite : (item.favorite ? 0 : 1);
              favBtn.textContent = item.favorite ? '⭐' : '☆';
              favBtn.disabled = false;
              if (item.favorite) window.GG.say('这份惊喜收好啦，宝宝想看的时候随时翻出来～', '', 'happy');
            })
            .catch(function (err) {
              favBtn.disabled = false;
              window.GG.showNotice('收藏失败了：' + err.message + '，再点一次试试。');
            });
        });
        historyBody.appendChild(row);
      });
    }

    function openToday() {
      if (state.opening || state.today) return;
      state.opening = true;
      var btn = todayBody.querySelector('#spOpenBtn');
      if (btn) { btn.disabled = true; btn.textContent = '正在开盒…'; }
      window.GG.apiFetch('/api/surprise/open', { method: 'POST' })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '今天的惊喜打不开');
          return res.json();
        })
        .then(function (d) {
          var s = (d && d.surprise) || d;
          state.today = s;
          if (!state.history.some(function (h) { return h.date === s.date; })) state.history.unshift(s);
          state.opening = false;
          window.GG.burstHearts(10);
          window.GG.say('锵锵！今天的惊喜来啦，宝宝快拆开看看～', '', 'happy');
          window.GG.logEvent('surprise_open', s.kind || '');
          renderToday();
          renderHistory();
        })
        .catch(function (err) {
          state.opening = false;
          todayBody.innerHTML =
            '<p class="sp-err">哎呀，惊喜盒子打不开：' + esc(err.message) + '。检查一下网络，再试一次吧。</p>' +
            '<button type="button" class="sp-open-btn" id="spOpenBtnRetry">再试一次</button>';
          todayBody.querySelector('#spOpenBtnRetry').addEventListener('click', function () {
            renderToday();
          });
        });
    }

    function load() {
      window.GG.apiFetch('/api/surprises/history?limit=30')
        .then(function (res) {
          if (!res.ok) return apiErr(res, '惊喜历史拉不到');
          return res.json();
        })
        .then(function (d) {
          state.history = asList(d);
          var t = todayStr();
          state.today = null;
          for (var i = 0; i < state.history.length; i++) {
            if (state.history[i].date === t) { state.today = state.history[i]; break; }
          }
          renderToday();
          renderHistory();
        })
        .catch(function (err) {
          todayBody.innerHTML =
            '<p class="sp-err">今天的惊喜暂时看不到：' + esc(err.message) + '。检查一下网络，再试一次吧。</p>' +
            '<button type="button" class="sp-open-btn" id="spOpenBtnRetry2">再试一次</button>';
          todayBody.querySelector('#spOpenBtnRetry2').addEventListener('click', function () {
            todayBody.innerHTML = '<p class="sp-empty">正在看看今天的惊喜开过了没有…</p>';
            load();
          });
          historyBody.innerHTML = '<p class="sp-empty">历史也暂时拉不到，等网络好一点再来翻吧。</p>';
        });
    }

    load();
  }
})();
