// 哄睡模式（Phase 3）：全屏夜晚浮层 + 首页入口。
// 音乐是 WebAudio 本地生成的轻摇篮曲，不引用任何音乐文件。
// 睡前聊天走原有 GG.sendChat（回话出现在首页聊天里）。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var actions = document.querySelector('#page-home .actions');
    if(!actions) return;
    if(document.querySelector('[data-sleep-entry]')) return;

    injectStyle();

    // ---- 首页入口按钮（与现有 .act 按钮同款） ----
    var entry = document.createElement('button');
    entry.className = 'act';
    entry.type = 'button';
    entry.setAttribute('data-sleep-entry', '1');
    entry.innerHTML = '<span class="ico ico-pink">💤</span><span><strong>陪我睡觉</strong><span>夜晚模式，哄你慢慢入睡</span></span>';
    entry.addEventListener('click', openSleep);
    actions.appendChild(entry);

    // ---- 浮层（创建一次，重复使用） ----
    var overlay = null, pigClone = null;
    var musicOn = false, audioCtx = null, masterGain = null, noteTimer = null, noteIdx = 0;
    var timerId = null, timerEnd = 0, timerTick = null;
    var breathOn = false, breathTimer = null, breathPhase = 'in';
    var animOn = true;

    // 摇篮曲：小星星旋律，放得很慢很轻（正弦波单音）。
    var MELODY = [
      [261.63, 1], [261.63, 1], [392.00, 1], [392.00, 1], [440.00, 1], [440.00, 1], [392.00, 2],
      [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 1], [293.66, 1], [261.63, 2],
      [392.00, 1], [392.00, 1], [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 2],
      [392.00, 1], [392.00, 1], [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 2],
      [261.63, 1], [261.63, 1], [392.00, 1], [392.00, 1], [440.00, 1], [440.00, 1], [392.00, 2],
      [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 1], [293.66, 1], [261.63, 2]
    ];
    var BEAT = 0.62; // 秒/拍，很慢

    function buildOverlay(){
      overlay = document.createElement('div');
      overlay.className = 'sleep-overlay';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-label', '哄睡模式');
      overlay.innerHTML =
        '<div class="sleep-stars" aria-hidden="true"></div>' +
        '<div class="sleep-moon" aria-hidden="true"></div>' +
        '<button type="button" class="sleep-close" data-sleep-close aria-label="退出哄睡模式">✕</button>' +
        '<div class="sleep-inner">' +
          '<div class="sleep-pig-wrap" aria-hidden="true"></div>' +
          '<h2 class="sleep-title">晚安，宝宝</h2>' +
          '<p class="sleep-sub">乖乖穿上睡衣陪你，慢慢来，不着急睡觉。</p>' +
          '<div class="sleep-breath-wrap">' +
            '<div class="sleep-breath-circle" data-breath-circle><span data-breath-text>吸气…</span></div>' +
            '<button type="button" class="sleep-btn" data-breath-toggle>开始呼吸放松</button>' +
          '</div>' +
          '<div class="sleep-chat">' +
            '<input type="text" class="sleep-input" data-sleep-input placeholder="跟乖乖说句睡前悄悄话…" maxlength="200" />' +
            '<button type="button" class="sleep-btn sleep-btn-main" data-sleep-send>发送</button>' +
          '</div>' +
          '<p class="sleep-hint">说的话会发到首页聊天里，乖乖在那边回你。</p>' +
          '<div class="sleep-quick">' +
            '<button type="button" class="sleep-chip" data-sleep-quick="story">📖 讲个睡前故事</button>' +
            '<button type="button" class="sleep-chip" data-sleep-quick="night">🌙 说句晚安情话</button>' +
            '<button type="button" class="sleep-chip" data-sleep-quick="memory">💗 讲讲今天的回忆</button>' +
          '</div>' +
          '<div class="sleep-music">' +
            '<span class="sleep-music-label">🎵 乖乖哼的小夜曲（本地生成）</span>' +
            '<button type="button" class="sleep-btn" data-music-toggle>小夜曲：开</button>' +
          '</div>' +
          '<div class="sleep-timer">' +
            '<label>定时停止' +
              '<select data-timer-select>' +
                '<option value="0">不定时</option>' +
                '<option value="15">15 分钟</option>' +
                '<option value="30" selected>30 分钟</option>' +
                '<option value="60">60 分钟</option>' +
              '</select>' +
            '</label>' +
            '<span class="sleep-timer-left" data-timer-left></span>' +
          '</div>' +
          '<button type="button" class="sleep-btn sleep-btn-wide" data-anim-toggle>动画：开</button>' +
          '<p class="sleep-goodnight" data-goodnight hidden>晚安，好梦 💤 乖乖在旁边陪着你。</p>' +
        '</div>';

      // 星星
      var stars = overlay.querySelector('.sleep-stars');
      for(var i = 0; i < 26; i++){
        var s = document.createElement('i');
        s.style.left = (Math.random() * 100).toFixed(1) + '%';
        s.style.top = (Math.random() * 55).toFixed(1) + '%';
        s.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
        s.style.animationDuration = (2 + Math.random() * 3).toFixed(2) + 's';
        stars.appendChild(s);
      }
      // 克隆首页小猪 SVG，加上睡衣感的柔和呼吸动画
      var pig = document.getElementById('pig');
      if(pig){
        pigClone = pig.cloneNode(true);
        pigClone.removeAttribute('id');
        pigClone.setAttribute('class', 'sleep-pig');
        overlay.querySelector('.sleep-pig-wrap').appendChild(pigClone);
      }

      overlay.querySelector('[data-sleep-close]').addEventListener('click', closeSleep);
      overlay.querySelector('[data-sleep-send]').addEventListener('click', sendSleepChat);
      var input = overlay.querySelector('[data-sleep-input]');
      input.addEventListener('keydown', function(e){ if(e.key === 'Enter'){ e.preventDefault(); sendSleepChat(); } });
      var quicks = overlay.querySelectorAll('[data-sleep-quick]');
      for(var q = 0; q < quicks.length; q++){
        quicks[q].addEventListener('click', function(){
          var kind = this.getAttribute('data-sleep-quick');
          if(kind === 'story'){
            window.GG.sendChat('宝宝想听一个睡前故事，讲一个短短的、暖暖的故事哄我睡觉');
          }else if(kind === 'night'){
            window.GG.sendChat('跟我说一句晚安，要温柔一点的');
          }else{
            var mems = window.GG.memories || [];
            var recent = mems.length ? mems[mems.length - 1] : null;
            if(recent && recent.title){
              window.GG.sendChat('讲讲我们「' + recent.title + '」的回忆，温柔一点');
            }else{
              window.GG.sendChat('讲讲我们今天的回忆，温柔一点');
            }
          }
          window.GG.showNotice('乖乖在首页聊天里回你啦，点右上角 ✕ 回去看看');
        });
      }
      overlay.querySelector('[data-music-toggle]').addEventListener('click', toggleMusic);
      overlay.querySelector('[data-breath-toggle]').addEventListener('click', toggleBreath);
      overlay.querySelector('[data-anim-toggle]').addEventListener('click', toggleAnim);
      overlay.querySelector('[data-timer-select]').addEventListener('change', function(){
        startTimer(parseInt(this.value, 10) || 0);
      });
      document.body.appendChild(overlay);
    }

    function sendSleepChat(){
      var input = overlay.querySelector('[data-sleep-input]');
      var text = (input.value || '').replace(/^\s+|\s+$/g, '');
      if(!text) return;
      input.value = '';
      window.GG.sendChat(text);
      window.GG.showNotice('乖乖在首页聊天里回你啦，点右上角 ✕ 回去看看');
    }

    // ---- 摇篮曲（WebAudio 本地生成） ----
    function ensureAudio(){
      if(audioCtx) return true;
      try{
        var AC = window.AudioContext || window.webkitAudioContext;
        if(!AC) return false;
        audioCtx = new AC();
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.05; // 很轻
        masterGain.connect(audioCtx.destination);
        return true;
      }catch(e){ return false; }
    }
    function playNote(freq, dur){
      if(!audioCtx || !masterGain) return;
      var t = audioCtx.currentTime;
      var osc = audioCtx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      var g = audioCtx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.5, t + 0.08);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc.connect(g); g.connect(masterGain);
      osc.start(t); osc.stop(t + dur + 0.05);
    }
    function scheduleNext(){
      if(!musicOn || !audioCtx) return;
      var note = MELODY[noteIdx % MELODY.length];
      noteIdx++;
      playNote(note[0], note[1] * BEAT * 1.15);
      noteTimer = setTimeout(scheduleNext, note[1] * BEAT * 1000);
    }
    function startMusic(){
      if(!ensureAudio()){
        setMusicLabel(false);
        window.GG.showNotice('这个浏览器放不出本地小夜曲，呼吸放松和聊天还能用');
        return;
      }
      if(audioCtx.state === 'suspended') audioCtx.resume();
      noteIdx = 0;
      musicOn = true;
      scheduleNext();
      setMusicLabel(true);
    }
    function stopMusic(){
      musicOn = false;
      if(noteTimer){ clearTimeout(noteTimer); noteTimer = null; }
      setMusicLabel(false);
    }
    function setMusicLabel(on){
      var btn = overlay && overlay.querySelector('[data-music-toggle]');
      if(btn) btn.textContent = on ? '小夜曲：开' : '小夜曲：关';
    }
    function toggleMusic(){
      if(musicOn) stopMusic(); else startMusic();
    }

    // ---- 呼吸放松（4 秒吸气 / 4 秒呼气） ----
    function toggleBreath(){
      var circle = overlay.querySelector('[data-breath-circle]');
      var text = overlay.querySelector('[data-breath-text]');
      var btn = overlay.querySelector('[data-breath-toggle]');
      if(breathOn){
        breathOn = false;
        if(breathTimer){ clearInterval(breathTimer); breathTimer = null; }
        circle.classList.remove('breath-in', 'breath-out');
        text.textContent = '吸气…';
        btn.textContent = '开始呼吸放松';
        return;
      }
      breathOn = true;
      breathPhase = 'in';
      circle.classList.add('breath-in');
      text.textContent = '吸气… 1 2 3 4';
      btn.textContent = '停止呼吸放松';
      breathTimer = setInterval(function(){
        if(breathPhase === 'in'){
          breathPhase = 'out';
          circle.classList.remove('breath-in');
          circle.classList.add('breath-out');
          text.textContent = '呼气… 1 2 3 4';
        }else{
          breathPhase = 'in';
          circle.classList.remove('breath-out');
          circle.classList.add('breath-in');
          text.textContent = '吸气… 1 2 3 4';
        }
      }, 4000);
    }

    // ---- 定时停止 ----
    function startTimer(minutes){
      if(timerTick){ clearInterval(timerTick); timerTick = null; }
      if(timerId){ clearTimeout(timerId); timerId = null; }
      var left = overlay.querySelector('[data-timer-left]');
      if(!minutes){
        left.textContent = '';
        return;
      }
      timerEnd = Date.now() + minutes * 60 * 1000;
      var updateLeft = function(){
        var ms = Math.max(0, timerEnd - Date.now());
        var m = Math.floor(ms / 60000);
        var s = Math.floor((ms % 60000) / 1000);
        left.textContent = '还剩 ' + m + ' 分 ' + ('0' + s).slice(-2) + ' 秒';
      };
      updateLeft();
      timerTick = setInterval(updateLeft, 1000);
      timerId = setTimeout(function(){
        stopMusic();
        if(breathOn) toggleBreath();
        left.textContent = '';
        overlay.querySelector('[data-goodnight]').hidden = false;
        try{ window.GG.logEvent('sleep', 'timer_done'); }catch(e){}
      }, minutes * 60 * 1000);
    }
    function toggleAnim(){
      animOn = !animOn;
      overlay.classList.toggle('sleep-noanim', !animOn);
      overlay.querySelector('[data-anim-toggle]').textContent = animOn ? '动画：开' : '动画：关';
    }

    function openSleep(){
      if(!overlay) buildOverlay();
      overlay.classList.add('open');
      overlay.querySelector('[data-goodnight]').hidden = true;
      document.body.style.overflow = 'hidden';
      try{ window.GG.logEvent('sleep', 'open'); }catch(e){}
      // 一打开就轻轻哼起小夜曲，默认 30 分钟定时
      if(!musicOn) startMusic();
      startTimer(30);
      overlay.querySelector('[data-timer-select]').value = '30';
    }
    function closeSleep(){
      stopMusic();
      if(breathOn) toggleBreath();
      if(timerTick){ clearInterval(timerTick); timerTick = null; }
      if(timerId){ clearTimeout(timerId); timerId = null; }
      if(overlay) overlay.classList.remove('open');
      document.body.style.overflow = '';
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="sleep"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'sleep');
      st.textContent =
        '.sleep-overlay{position:fixed;inset:0;z-index:200;display:none;flex-direction:column;overflow-y:auto;' +
        'background:linear-gradient(180deg,#241B33 0%,#32244A 55%,#3D2A52 100%);color:#F3EAF7;}' +
        '.sleep-overlay.open{display:flex;}' +
        '.sleep-overlay.sleep-noanim *{animation:none !important;transition:none !important;}' +
        '.sleep-stars{position:absolute;inset:0;pointer-events:none;overflow:hidden;}' +
        '.sleep-stars i{position:absolute;width:3px;height:3px;border-radius:50%;background:#FFE9A8;opacity:.7;animation:sleepTwinkle 3s ease-in-out infinite;}' +
        '@keyframes sleepTwinkle{0%,100%{opacity:.25;transform:scale(.8);}50%{opacity:.95;transform:scale(1.15);}}' +
        '.sleep-moon{position:absolute;top:34px;right:30px;width:64px;height:64px;border-radius:50%;' +
        'background:radial-gradient(circle at 35% 35%,#FFF8DC,#F7E08B 70%);box-shadow:0 0 42px 10px rgba(247,224,139,.35);}' +
        '.sleep-close{position:absolute;top:16px;left:16px;z-index:5;width:44px;height:44px;border-radius:50%;' +
        'border:1px solid rgba(243,234,247,.35);background:rgba(255,255,255,.08);color:#F3EAF7;font-size:18px;cursor:pointer;}' +
        '.sleep-inner{position:relative;z-index:2;max-width:480px;width:100%;margin:0 auto;padding:74px 20px 44px;text-align:center;}' +
        '.sleep-pig-wrap svg{width:150px;height:150px;filter:drop-shadow(0 10px 22px rgba(0,0,0,.35));animation:sleepBreathe 6s ease-in-out infinite;}' +
        '@keyframes sleepBreathe{0%,100%{transform:scale(1) translateY(0);}50%{transform:scale(1.03) translateY(-4px);}}' +
        '.sleep-title{font-size:26px;margin:14px 0 6px;color:#FFE9F3;}' +
        '.sleep-sub{color:#CDBFD8;font-size:14.5px;line-height:1.6;margin:0 0 18px;}' +
        '.sleep-breath-wrap{margin:0 0 18px;}' +
        '.sleep-breath-circle{width:118px;height:118px;margin:0 auto 12px;border-radius:50%;display:flex;align-items:center;justify-content:center;' +
        'background:radial-gradient(circle,rgba(255,143,163,.35),rgba(255,143,163,.12));border:1.5px solid rgba(255,143,163,.5);' +
        'color:#FFE9F3;font-size:14px;font-weight:700;transition:transform 4s ease-in-out;}' +
        '.sleep-breath-circle.breath-in{transform:scale(1.28);}' +
        '.sleep-breath-circle.breath-out{transform:scale(1);}' +
        '.sleep-chat{display:flex;gap:8px;margin:0 0 6px;}' +
        '.sleep-input{flex:1;min-height:48px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.10);' +
        'color:#F3EAF7;padding:10px 16px;font-size:15px;outline:none;}' +
        '.sleep-input::placeholder{color:#B7A6C6;}' +
        '.sleep-hint{color:#9A8CA8;font-size:12.5px;margin:0 0 14px;}' +
        '.sleep-btn{min-height:48px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.10);' +
        'color:#F3EAF7;font-size:14px;font-weight:700;padding:10px 16px;cursor:pointer;}' +
        '.sleep-btn-main{background:#E14E96;border-color:#E14E96;color:#fff;}' +
        '.sleep-btn-wide{width:100%;margin-top:12px;}' +
        '.sleep-quick{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:0 0 18px;}' +
        '.sleep-chip{min-height:44px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.08);' +
        'color:#FFE9F3;font-size:13.5px;font-weight:700;padding:9px 14px;cursor:pointer;}' +
        '.sleep-music{display:flex;align-items:center;justify-content:space-between;gap:10px;background:rgba(255,255,255,.06);' +
        'border:1px solid rgba(243,234,247,.18);border-radius:18px;padding:12px 14px;margin:0 0 12px;text-align:left;}' +
        '.sleep-music-label{font-size:13.5px;color:#EADCF2;line-height:1.5;}' +
        '.sleep-timer{display:flex;align-items:center;justify-content:space-between;gap:10px;background:rgba(255,255,255,.06);' +
        'border:1px solid rgba(243,234,247,.18);border-radius:18px;padding:12px 14px;font-size:14px;color:#EADCF2;}' +
        '.sleep-timer select{background:#2A2142;color:#F3EAF7;border:1px solid rgba(243,234,247,.3);border-radius:10px;padding:8px;min-height:44px;font-size:14px;}' +
        '.sleep-timer-left{font-size:13px;color:#CDBFD8;}' +
        '.sleep-goodnight{margin:18px 0 0;font-size:16px;line-height:1.7;color:#FFE9F3;font-weight:700;}';
      document.head.appendChild(st);
    }
  });
})();
