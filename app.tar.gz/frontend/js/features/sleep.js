// 哄睡模式（Phase 3）：全屏夜晚浮层 + 首页入口。
// 音乐是 WebAudio 本地生成的轻摇篮曲，不引用任何音乐文件。
// 睡前聊天走原有 GG.sendChat（回话出现在首页聊天里）；
// 睡前故事直接调 /api/chat，显示在浮层里并用 speechSynthesis 朗读（失败走本地故事库）。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var actions = document.querySelector('#page-home .actions');
    if(!actions) return;
    if(document.querySelector('[data-sleep-entry]')) return;

    injectStyle();

    // ---- 首页入口按钮（与现有 .act 按钮同款） ----
    var entry = document.createElement('button');
    entry.className = 'act';
    entry.type = 'button';
    entry.setAttribute('data-sleep-entry', '1');
    entry.innerHTML = '<span class="ico ico-pink">💤</span><span><strong>陪我睡觉</strong><span>夜晚模式，哄你慢慢入睡</span></span>';
    entry.addEventListener('click', openSleep);
    actions.appendChild(entry);

    // ---- 浮层（创建一次，重复使用） ----
    var overlay = null, pigClone = null;
    var musicOn = false, audioCtx = null, masterGain = null, noteTimer = null, noteIdx = 0;
    var timerId = null, timerEnd = 0, timerTick = null;
    var breathOn = false, breathTimer = null, breathPhase = 'in';
    var animOn = true;
    var storySpeaking = false;
    // 本地兜底睡前故事（每则 ≤120 字）：前两则复用 app.js 离线脑子里的，后两则同风格新写
    var LOCAL_STORIES = [
      '好，故事开始：从前有只小猪，每天守着一颗草莓树。别人问它为啥不摘，它说要等一个很重要的人来一起吃。后来那个人来了——就是你。故事讲完，草莓分你一半，你也要记得按时吃饭哦。',
      '讲个短的：小猪去爬山，爬到一半累得哼哼。山顶的风对它说：慢慢来，风景都在路上呢。小猪想通了，坐下来吃了颗草莓再接着爬。你也一样，累了歇会儿，不丢人。',
      '今晚的故事很短：有一只小猪每天晚上都要数星星，数到第九十九颗就睡着了。它说星星数不完没关系，反正明天晚上还能接着数。你也别数羊了，闭上眼睛，我在这儿守着，数到困了就睡。',
      '再讲一个：月亮每天晚上都要给小动物们盖被子，盖到最后一只小猪时，月亮打了个哈欠说，今晚你自己盖吧，我也要睡了。小猪就扯了一片云当被子，睡得可香了。你也盖好被子，晚安，梦里见。'
    ];
    // 后端 /api/chat 不自带人设，故事请求要自己带一句 system 提示
    var STORY_SYSTEM = '你是最喜欢的哥哥，一只粉色小猪，宝宝的 AI 小男友。现在是深夜哄睡时间：给宝宝讲睡前故事，一次一个，150字以内，故事要完整，暖暖的，像男朋友哄女朋友睡觉那样温柔。不要套路情话，不要用朕、本宫这类词，不要讲道理，不要总结。';
    var STORY_ASK = '宝宝要睡了，讲一个短短的、暖暖的睡前故事哄宝宝睡觉。';
    // 页面切回来时如果音乐在放但上下文又被挂起，再唤醒一次
    document.addEventListener('visibilitychange', function(){
      if(!document.hidden && musicOn && audioCtx && audioCtx.state === 'suspended'){
        try{ audioCtx.resume(); }catch(e){}
      }
    });

    // 摇篮曲：小星星旋律，放得很慢很轻（正弦波单音）。
    var MELODY = [
      [261.63, 1], [261.63, 1], [392.00, 1], [392.00, 1], [440.00, 1], [440.00, 1], [392.00, 2],
      [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 1], [293.66, 1], [261.63, 2],
      [392.00, 1], [392.00, 1], [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 2],
      [392.00, 1], [392.00, 1], [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 2],
      [261.63, 1], [261.63, 1], [392.00, 1], [392.00, 1], [440.00, 1], [440.00, 1], [392.00, 2],
      [349.23, 1], [349.23, 1], [329.63, 1], [329.63, 1], [293.66, 1], [293.66, 1], [261.63, 2]
    ];
    var BEAT = 0.62; // 秒/拍，很慢

    function buildOverlay(){
      overlay = document.createElement('div');
      overlay.className = 'sleep-overlay';
      overlay.setAttribute('role', 'dialog');
      overlay.setAttribute('aria-label', '哄睡模式');
      overlay.innerHTML =
        '<div class="sleep-stars" aria-hidden="true"></div>' +
        '<div class="sleep-moon" aria-hidden="true"></div>' +
        '<button type="button" class="sleep-close" data-sleep-close aria-label="退出哄睡模式">✕</button>' +
        '<div class="sleep-inner">' +
          '<div class="sleep-pig-wrap" aria-hidden="true"></div>' +
          '<h2 class="sleep-title">晚安，宝宝</h2>' +
          '<p class="sleep-sub">乖乖穿上睡衣陪你，慢慢来，不着急睡觉。</p>' +
          '<div class="sleep-breath-wrap">' +
            '<div class="sleep-breath-circle" data-breath-circle><span data-breath-text>吸气…</span></div>' +
            '<button type="button" class="sleep-btn" data-breath-toggle>开始呼吸放松</button>' +
          '</div>' +
          '<div class="sleep-chat">' +
            '<input type="text" class="sleep-input" data-sleep-input placeholder="跟乖乖说句睡前悄悄话…" maxlength="200" />' +
            '<button type="button" class="sleep-btn sleep-btn-main" data-sleep-send>发送</button>' +
          '</div>' +
          '<p class="sleep-hint">说的话会发到首页聊天里，乖乖在那边回你。</p>' +
          '<div class="sleep-quick">' +
            '<button type="button" class="sleep-chip" data-sleep-quick="story">📖 讲个睡前故事</button>' +
            '<button type="button" class="sleep-chip" data-sleep-quick="night">🌙 说句晚安情话</button>' +
            '<button type="button" class="sleep-chip" data-sleep-quick="memory">💗 讲讲今天的回忆</button>' +
          '</div>' +
          '<div class="sleep-story" data-story hidden>' +
            '<p class="sleep-story-text" data-story-text></p>' +
            '<p class="sleep-story-hint" data-story-hint hidden></p>' +
            '<div class="sleep-story-actions">' +
              '<button type="button" class="sleep-btn" data-story-read>🔊 朗读</button>' +
              '<button type="button" class="sleep-btn" data-story-stop>⏹ 停止朗读</button>' +
              '<button type="button" class="sleep-btn" data-story-close>收起故事</button>' +
            '</div>' +
          '</div>' +
          '<div class="sleep-music">' +
            '<span class="sleep-music-label">🎵 乖乖哼的小夜曲（本地生成）</span>' +
            '<button type="button" class="sleep-btn" data-music-toggle>小夜曲：关</button>' +
          '</div>' +
          '<div class="sleep-timer">' +
            '<label>定时停止' +
              '<select data-timer-select>' +
                '<option value="0">不定时</option>' +
                '<option value="15">15 分钟</option>' +
                '<option value="30" selected>30 分钟</option>' +
                '<option value="60">60 分钟</option>' +
              '</select>' +
            '</label>' +
            '<span class="sleep-timer-left" data-timer-left></span>' +
          '</div>' +
          '<button type="button" class="sleep-btn sleep-btn-wide" data-anim-toggle>动画：开</button>' +
          '<p class="sleep-goodnight" data-goodnight hidden>晚安，好梦 💤 乖乖在旁边陪着你。</p>' +
        '</div>';

      // 星星
      var stars = overlay.querySelector('.sleep-stars');
      for(var i = 0; i < 26; i++){
        var s = document.createElement('i');
        s.style.left = (Math.random() * 100).toFixed(1) + '%';
        s.style.top = (Math.random() * 55).toFixed(1) + '%';
        s.style.animationDelay = (Math.random() * 3).toFixed(2) + 's';
        s.style.animationDuration = (2 + Math.random() * 3).toFixed(2) + 's';
        stars.appendChild(s);
      }
      // 克隆首页小猪 SVG，加上睡衣感的柔和呼吸动画
      var pig = document.getElementById('pig');
      if(pig){
        pigClone = pig.cloneNode(true);
        pigClone.removeAttribute('id');
        pigClone.setAttribute('class', 'sleep-pig');
        overlay.querySelector('.sleep-pig-wrap').appendChild(pigClone);
      }

      overlay.querySelector('[data-sleep-close]').addEventListener('click', closeSleep);
      overlay.querySelector('[data-sleep-send]').addEventListener('click', sendSleepChat);
      var input = overlay.querySelector('[data-sleep-input]');
      input.addEventListener('keydown', function(e){ if(e.key === 'Enter'){ e.preventDefault(); sendSleepChat(); } });
      var quicks = overlay.querySelectorAll('[data-sleep-quick]');
      for(var q = 0; q < quicks.length; q++){
        quicks[q].addEventListener('click', function(){
          var kind = this.getAttribute('data-sleep-quick');
          if(kind === 'story'){
            tellStory(this);
            return;
          }else if(kind === 'night'){
            window.GG.sendChat('跟我说一句晚安，要温柔一点的');
          }else{
            var mems = window.GG.memories || [];
            var recent = mems.length ? mems[mems.length - 1] : null;
            if(recent && recent.title){
              window.GG.sendChat('讲讲我们「' + recent.title + '」的回忆，温柔一点');
            }else{
              window.GG.sendChat('讲讲我们今天的回忆，温柔一点');
            }
          }
          window.GG.showNotice('乖乖在首页聊天里回你啦，点右上角 ✕ 回去看看');
        });
      }
      overlay.querySelector('[data-music-toggle]').addEventListener('click', toggleMusic);
      overlay.querySelector('[data-story-read]').addEventListener('click', function(){ var t = storyText(); if(t) speakStory(t); });
      overlay.querySelector('[data-story-stop]').addEventListener('click', stopReading);
      overlay.querySelector('[data-story-close]').addEventListener('click', function(){
        stopReading();
        var box = overlay.querySelector('[data-story]');
        if(box) box.hidden = true;
      });
      overlay.querySelector('[data-breath-toggle]').addEventListener('click', toggleBreath);
      overlay.querySelector('[data-anim-toggle]').addEventListener('click', toggleAnim);
      overlay.querySelector('[data-timer-select]').addEventListener('change', function(){
        startTimer(parseInt(this.value, 10) || 0);
      });
      document.body.appendChild(overlay);
    }

    function sendSleepChat(){
      var input = overlay.querySelector('[data-sleep-input]');
      var text = (input.value || '').replace(/^\s+|\s+$/g, '');
      if(!text) return;
      input.value = '';
      window.GG.sendChat(text);
      window.GG.showNotice('乖乖在首页聊天里回你啦，点右上角 ✕ 回去看看');
    }

    // ---- 睡前故事（显示在浮层里 + 朗读；不经过 GG.sendChat，避免重复发一次） ----
    function storyText(){
      var el = overlay && overlay.querySelector('[data-story-text]');
      return el ? el.textContent : '';
    }
    function ttsOK(){
      return ('speechSynthesis' in window) && !!window.speechSynthesis;
    }
    function stopReading(){
      storySpeaking = false;
      try{ if(ttsOK()) window.speechSynthesis.cancel(); }catch(e){}
    }
    function speakStory(text){
      stopReading();
      if(!ttsOK()) return false;
      try{
        var u = new SpeechSynthesisUtterance(text);
        u.lang = 'zh-CN';
        u.rate = 0.85;
        u.onend = function(){ storySpeaking = false; };
        u.onerror = function(){ storySpeaking = false; };
        storySpeaking = true;
        window.speechSynthesis.speak(u);
        return true;
      }catch(e){ storySpeaking = false; return false; }
    }
    function showStory(text){
      var box = overlay.querySelector('[data-story]');
      var el = overlay.querySelector('[data-story-text]');
      var hint = overlay.querySelector('[data-story-hint]');
      if(!box || !el) return;
      el.textContent = text;
      box.hidden = false;
      if(hint){
        if(ttsOK()){ hint.hidden = true; hint.textContent = ''; }
        else{ hint.hidden = false; hint.textContent = '这个浏览器不支持朗读，只显示文字哦'; }
      }
      speakStory(text);
    }
    function localStory(){
      return LOCAL_STORIES[Math.floor(Math.random() * LOCAL_STORIES.length)];
    }
    function tellStory(btn){
      stopReading();
      var origText = btn.textContent;
      btn.disabled = true;
      btn.textContent = '正在想故事…';
      var done = function(){
        btn.disabled = false;
        btn.textContent = origText;
      };
      // 注意：POST /api/chat 会把这次问答写进聊天记录，故事同时出现在首页聊天里，
      // 与原有行为一致，可以接受；不再另外调 GG.sendChat（避免重复发一次）。
      var messages = [
        { role: 'system', content: STORY_SYSTEM },
        { role: 'user', content: STORY_ASK }
      ];
      window.GG.apiFetch('/api/chat', { method: 'POST', body: JSON.stringify({ messages: messages }) })
        .then(function(res){
          if(!res.ok) throw new Error('backend HTTP ' + res.status);
          return res.json();
        })
        .then(function(data){
          var reply = data && data.reply ? String(data.reply).trim() : '';
          if(!reply) throw new Error('empty reply');
          showStory(reply);
          done();
        })
        .catch(function(){
          // 任何失败（没 key、401/402、断网、空回复）都用本地故事兜底，不弹报错
          showStory(localStory());
          done();
        });
    }

    // ---- 摇篮曲（WebAudio 本地生成） ----
    function ensureAudio(){
      if(audioCtx) return true;
      try{
        var AC = window.AudioContext || window.webkitAudioContext;
        if(!AC) return false;
        audioCtx = new AC();
        masterGain = audioCtx.createGain();
        masterGain.gain.value = 0.22; // 够手机扬声器听见，仍比系统音量轻
        masterGain.connect(audioCtx.destination);
        return true;
      }catch(e){ return false; }
    }
    function playNote(freq, dur){
      if(!audioCtx || !masterGain) return;
      var t = audioCtx.currentTime;
      var osc = audioCtx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      var g = audioCtx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.8, t + 0.08);
      g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc.connect(g); g.connect(masterGain);
      osc.start(t); osc.stop(t + dur + 0.05);
      // 再加一个 triangle 波混音（约一半音量），声音暖一点
      var osc2 = audioCtx.createOscillator();
      osc2.type = 'triangle';
      osc2.frequency.value = freq;
      var g2 = audioCtx.createGain();
      g2.gain.setValueAtTime(0.0001, t);
      g2.gain.linearRampToValueAtTime(0.4, t + 0.08);
      g2.gain.exponentialRampToValueAtTime(0.0001, t + dur);
      osc2.connect(g2); g2.connect(masterGain);
      osc2.start(t); osc2.stop(t + dur + 0.05);
    }
    function scheduleNext(){
      if(!musicOn || !audioCtx) return;
      var note = MELODY[noteIdx % MELODY.length];
      noteIdx++;
      playNote(note[0], note[1] * BEAT * 1.15);
      noteTimer = setTimeout(scheduleNext, note[1] * BEAT * 1000);
    }
    function startMusic(){
      if(!ensureAudio()){
        setMusicLabel(false);
        window.GG.showNotice('这个浏览器放不出本地小夜曲，呼吸放松和聊天还能用');
        return;
      }
      // 先等上下文真正醒过来再排音符：OPPO 内置浏览器常见 suspended，
      // 不等就排等于往静音里放。
      var proceed = function(){
        if(audioCtx.state === 'suspended'){
          setMusicLabel(false);
          window.GG.showNotice('小夜曲还没醒，点一下屏幕再试一次');
          return;
        }
        noteIdx = 0;
        musicOn = true;
        scheduleNext();
        setMusicLabel(true);
      };
      try{
        var p = audioCtx.resume();
        if(p && typeof p.then === 'function') p.then(proceed, proceed);
        else proceed();
      }catch(e){ proceed(); }
    }
    function stopMusic(){
      musicOn = false;
      if(noteTimer){ clearTimeout(noteTimer); noteTimer = null; }
      setMusicLabel(false);
    }
    function setMusicLabel(on){
      var btn = overlay && overlay.querySelector('[data-music-toggle]');
      if(btn) btn.textContent = on ? '小夜曲：开' : '小夜曲：关';
    }
    function toggleMusic(){
      if(musicOn) stopMusic(); else startMusic();
    }

    // ---- 呼吸放松（4 秒吸气 / 4 秒呼气） ----
    function toggleBreath(){
      var circle = overlay.querySelector('[data-breath-circle]');
      var text = overlay.querySelector('[data-breath-text]');
      var btn = overlay.querySelector('[data-breath-toggle]');
      if(breathOn){
        breathOn = false;
        if(breathTimer){ clearInterval(breathTimer); breathTimer = null; }
        circle.classList.remove('breath-in', 'breath-out');
        text.textContent = '吸气…';
        btn.textContent = '开始呼吸放松';
        return;
      }
      breathOn = true;
      breathPhase = 'in';
      circle.classList.add('breath-in');
      text.textContent = '吸气… 1 2 3 4';
      btn.textContent = '停止呼吸放松';
      breathTimer = setInterval(function(){
        if(breathPhase === 'in'){
          breathPhase = 'out';
          circle.classList.remove('breath-in');
          circle.classList.add('breath-out');
          text.textContent = '呼气… 1 2 3 4';
        }else{
          breathPhase = 'in';
          circle.classList.remove('breath-out');
          circle.classList.add('breath-in');
          text.textContent = '吸气… 1 2 3 4';
        }
      }, 4000);
    }

    // ---- 定时停止 ----
    function startTimer(minutes){
      if(timerTick){ clearInterval(timerTick); timerTick = null; }
      if(timerId){ clearTimeout(timerId); timerId = null; }
      var left = overlay.querySelector('[data-timer-left]');
      if(!minutes){
        left.textContent = '';
        return;
      }
      timerEnd = Date.now() + minutes * 60 * 1000;
      var updateLeft = function(){
        var ms = Math.max(0, timerEnd - Date.now());
        var m = Math.floor(ms / 60000);
        var s = Math.floor((ms % 60000) / 1000);
        left.textContent = '还剩 ' + m + ' 分 ' + ('0' + s).slice(-2) + ' 秒';
      };
      updateLeft();
      timerTick = setInterval(updateLeft, 1000);
      timerId = setTimeout(function(){
        stopMusic();
        if(breathOn) toggleBreath();
        left.textContent = '';
        overlay.querySelector('[data-goodnight]').hidden = false;
        try{ window.GG.logEvent('sleep', 'timer_done'); }catch(e){}
      }, minutes * 60 * 1000);
    }
    function toggleAnim(){
      animOn = !animOn;
      overlay.classList.toggle('sleep-noanim', !animOn);
      overlay.querySelector('[data-anim-toggle]').textContent = animOn ? '动画：开' : '动画：关';
    }

    function openSleep(){
      if(!overlay) buildOverlay();
      overlay.classList.add('open');
      overlay.querySelector('[data-goodnight]').hidden = true;
      document.body.style.overflow = 'hidden';
      try{ window.GG.logEvent('sleep', 'open'); }catch(e){}
      // 一打开就轻轻哼起小夜曲，默认 30 分钟定时
      if(!musicOn) startMusic();
      startTimer(30);
      overlay.querySelector('[data-timer-select]').value = '30';
    }
    function closeSleep(){
      stopReading();
      stopMusic();
      if(breathOn) toggleBreath();
      if(timerTick){ clearInterval(timerTick); timerTick = null; }
      if(timerId){ clearTimeout(timerId); timerId = null; }
      if(overlay) overlay.classList.remove('open');
      document.body.style.overflow = '';
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="sleep"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'sleep');
      st.textContent =
        '.sleep-overlay{position:fixed;inset:0;z-index:200;display:none;flex-direction:column;overflow-y:auto;' +
        'background:linear-gradient(180deg,#241B33 0%,#32244A 55%,#3D2A52 100%);color:#F3EAF7;}' +
        '.sleep-overlay.open{display:flex;}' +
        '.sleep-overlay.sleep-noanim *{animation:none !important;transition:none !important;}' +
        '.sleep-stars{position:absolute;inset:0;pointer-events:none;overflow:hidden;}' +
        '.sleep-stars i{position:absolute;width:3px;height:3px;border-radius:50%;background:#FFE9A8;opacity:.7;animation:sleepTwinkle 3s ease-in-out infinite;}' +
        '@keyframes sleepTwinkle{0%,100%{opacity:.25;transform:scale(.8);}50%{opacity:.95;transform:scale(1.15);}}' +
        '.sleep-moon{position:absolute;top:34px;right:30px;width:64px;height:64px;border-radius:50%;' +
        'background:radial-gradient(circle at 35% 35%,#FFF8DC,#F7E08B 70%);box-shadow:0 0 42px 10px rgba(247,224,139,.35);}' +
        '.sleep-close{position:absolute;top:16px;left:16px;z-index:5;width:44px;height:44px;border-radius:50%;' +
        'border:1px solid rgba(243,234,247,.35);background:rgba(255,255,255,.08);color:#F3EAF7;font-size:18px;cursor:pointer;}' +
        '.sleep-inner{position:relative;z-index:2;max-width:480px;width:100%;margin:0 auto;padding:74px 20px 44px;text-align:center;}' +
        '.sleep-pig-wrap svg{width:150px;height:150px;filter:drop-shadow(0 10px 22px rgba(0,0,0,.35));animation:sleepBreathe 6s ease-in-out infinite;}' +
        '@keyframes sleepBreathe{0%,100%{transform:scale(1) translateY(0);}50%{transform:scale(1.03) translateY(-4px);}}' +
        '.sleep-title{font-size:26px;margin:14px 0 6px;color:#FFE9F3;}' +
        '.sleep-sub{color:#CDBFD8;font-size:14.5px;line-height:1.6;margin:0 0 18px;}' +
        '.sleep-breath-wrap{margin:0 0 18px;}' +
        '.sleep-breath-circle{width:118px;height:118px;margin:0 auto 12px;border-radius:50%;display:flex;align-items:center;justify-content:center;' +
        'background:radial-gradient(circle,rgba(255,143,163,.35),rgba(255,143,163,.12));border:1.5px solid rgba(255,143,163,.5);' +
        'color:#FFE9F3;font-size:14px;font-weight:700;transition:transform 4s ease-in-out;}' +
        '.sleep-breath-circle.breath-in{transform:scale(1.28);}' +
        '.sleep-breath-circle.breath-out{transform:scale(1);}' +
        '.sleep-chat{display:flex;gap:8px;margin:0 0 6px;}' +
        '.sleep-input{flex:1;min-height:48px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.10);' +
        'color:#F3EAF7;padding:10px 16px;font-size:15px;outline:none;}' +
        '.sleep-input::placeholder{color:#B7A6C6;}' +
        '.sleep-hint{color:#9A8CA8;font-size:12.5px;margin:0 0 14px;}' +
        '.sleep-btn{min-height:48px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.10);' +
        'color:#F3EAF7;font-size:14px;font-weight:700;padding:10px 16px;cursor:pointer;}' +
        '.sleep-btn-main{background:#E14E96;border-color:#E14E96;color:#fff;}' +
        '.sleep-btn-wide{width:100%;margin-top:12px;}' +
        '.sleep-quick{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:0 0 18px;}' +
        '.sleep-chip{min-height:44px;border-radius:999px;border:1px solid rgba(243,234,247,.3);background:rgba(255,255,255,.08);' +
        'color:#FFE9F3;font-size:13.5px;font-weight:700;padding:9px 14px;cursor:pointer;}' +
        '.sleep-music{display:flex;align-items:center;justify-content:space-between;gap:10px;background:rgba(255,255,255,.06);' +
        'border:1px solid rgba(243,234,247,.18);border-radius:18px;padding:12px 14px;margin:0 0 12px;text-align:left;}' +
        '.sleep-music-label{font-size:13.5px;color:#EADCF2;line-height:1.5;}' +
        '.sleep-timer{display:flex;align-items:center;justify-content:space-between;gap:10px;background:rgba(255,255,255,.06);' +
        'border:1px solid rgba(243,234,247,.18);border-radius:18px;padding:12px 14px;font-size:14px;color:#EADCF2;}' +
        '.sleep-timer select{background:#2A2142;color:#F3EAF7;border:1px solid rgba(243,234,247,.3);border-radius:10px;padding:8px;min-height:44px;font-size:14px;}' +
        '.sleep-timer-left{font-size:13px;color:#CDBFD8;}' +
        '.sleep-goodnight{margin:18px 0 0;font-size:16px;line-height:1.7;color:#FFE9F3;font-weight:700;}' +
        '.sleep-story{margin:0 0 18px;background:rgba(255,255,255,.08);border:1px solid rgba(255,143,163,.4);border-radius:18px;padding:16px;text-align:left;}' +
        '.sleep-story-text{margin:0 0 12px;font-size:15px;line-height:1.9;color:#FFE9F3;}' +
        '.sleep-story-hint{margin:0 0 12px;font-size:12.5px;color:#CDBFD8;}' +
        '.sleep-story-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;}' +
        '.sleep-story-actions .sleep-btn{min-height:44px;font-size:13.5px;}';
      document.head.appendChild(st);
    }
  });
})();
