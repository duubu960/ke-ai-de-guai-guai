// 语音陪伴（Phase 3）：集成到首页聊天卡片。
// 语音输入用浏览器 SpeechRecognition；朗读用 speechSynthesis，语速可调。
// 不支持的浏览器如实提示，不假装可用。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var form = document.getElementById('chatForm');
    var input = document.getElementById('chatInput');
    var sendBtn = document.getElementById('chatSend');
    var chatLog = document.getElementById('chatLog');
    if(!form || !input || !sendBtn || !chatLog) return;
    if(document.getElementById('voiceMicBtn')) return;
    injectStyle();

    var SR = window.SpeechRecognition || window.webkitSpeechRecognition || null;
    var synthOK = ('speechSynthesis' in window) && !!window.speechSynthesis;

    // ---- 麦克风按钮（放在发送按钮旁边） ----
    var micBtn = document.createElement('button');
    micBtn.type = 'button';
    micBtn.id = 'voiceMicBtn';
    micBtn.className = 'voice-mic';
    micBtn.textContent = '🎤';
    micBtn.title = '语音输入';
    micBtn.setAttribute('aria-label', '语音输入');
    form.insertBefore(micBtn, sendBtn);

    // ---- 朗读工具条（表单下方） ----
    var bar = document.createElement('div');
    bar.className = 'voice-bar';
    bar.innerHTML =
      '<button type="button" class="voice-toggle" data-voice-read>🔊 朗读：关</button>' +
      '<button type="button" class="voice-toggle" data-voice-pause hidden>⏸ 暂停</button>' +
      '<label class="voice-rate">语速 <select data-voice-rate>' +
        '<option value="0.6">0.6</option>' +
        '<option value="0.8">0.8</option>' +
        '<option value="1.0" selected>1.0</option>' +
        '<option value="1.2">1.2</option>' +
        '<option value="1.4">1.4</option>' +
      '</select></label>';
    form.parentNode.insertBefore(bar, form.nextSibling);

    var readBtn = bar.querySelector('[data-voice-read]');
    var pauseBtn = bar.querySelector('[data-voice-pause]');
    var rateSel = bar.querySelector('[data-voice-rate]');

    var readOn = false, paused = false, speaking = false;
    try{
      readOn = window.localStorage.getItem('gg_tts_v1') === 'on';
      var savedRate = window.localStorage.getItem('gg_tts_rate_v1');
      if(savedRate && rateSel.querySelector('option[value="' + savedRate + '"]')) rateSel.value = savedRate;
    }catch(e){}
    if(!synthOK) readOn = false;
    syncReadBtn();

    rateSel.addEventListener('change', function(){
      try{ window.localStorage.setItem('gg_tts_rate_v1', rateSel.value); }catch(e){}
    });

    // ---- 语音输入 ----
    var recog = null, listening = false;
    micBtn.addEventListener('click', function(){
      if(listening){ stopListening(); return; }
      if(!SR){
        window.GG.showNotice('当前浏览器不支持语音输入，换 Chrome 试试，或直接打字跟乖乖说');
        return;
      }
      try{
        recog = new SR();
        recog.lang = 'zh-CN';
        recog.interimResults = false;
        recog.maxAlternatives = 1;
        recog.onresult = function(e){
          var text = '';
          try{
            var r = e.results[e.results.length - 1];
            if(r && r[0]) text = r[0].transcript || '';
          }catch(err){}
          text = (text || '').replace(/^\s+|\s+$/g, '');
          stopListening();
          if(text){
            input.value = text;
            window.GG.sendChat(text);
          }else{
            window.GG.showNotice('没听清，再说一遍吧');
          }
        };
        recog.onerror = function(e){
          stopListening();
          if(e && e.error === 'not-allowed'){
            window.GG.showNotice('没有拿到麦克风权限，在浏览器设置里允许后再试试');
          }else if(e && e.error === 'no-speech'){
            window.GG.showNotice('没听到声音，再说一遍吧');
          }else{
            window.GG.showNotice('语音输入出了点问题（' + (e && e.error ? e.error : '未知错误') + '），直接打字也行');
          }
        };
        recog.onend = function(){ stopListening(); };
        recog.start();
        listening = true;
        micBtn.classList.add('listening');
        micBtn.textContent = '正在听…';
        micBtn.setAttribute('aria-label', '正在听，点击停止');
      }catch(err){
        stopListening();
        window.GG.showNotice('语音输入启动失败，换个浏览器或直接打字吧');
      }
    });
    function stopListening(){
      listening = false;
      micBtn.classList.remove('listening');
      micBtn.textContent = '🎤';
      micBtn.setAttribute('aria-label', '语音输入');
      if(recog){
        try{ recog.stop(); }catch(e){}
        recog = null;
      }
    }

    // ---- 语音朗读 ----
    function latestPigText(){
      var msgs = chatLog.querySelectorAll('.msg-pig');
      if(!msgs.length) return '';
      var clone = msgs[msgs.length - 1].cloneNode(true);
      var smalls = clone.querySelectorAll('small, img, .sticker');
      for(var i = 0; i < smalls.length; i++) smalls[i].remove();
      var text = (clone.textContent || '').replace(/\s+/g, ' ').replace(/^\s+|\s+$/g, '');
      return text.slice(0, 200);
    }
    function speak(text){
      if(!synthOK || !text) return;
      try{
        window.speechSynthesis.cancel();
        var u = new SpeechSynthesisUtterance(text);
        u.lang = 'zh-CN';
        u.rate = parseFloat(rateSel.value) || 1;
        u.onstart = function(){ speaking = true; paused = false; syncPauseBtn(); };
        u.onend = function(){ speaking = false; paused = false; syncPauseBtn(); };
        u.onerror = function(){ speaking = false; paused = false; syncPauseBtn(); };
        window.speechSynthesis.speak(u);
      }catch(e){
        speaking = false;
        syncPauseBtn();
      }
    }
    function stopSpeaking(){
      speaking = false; paused = false;
      try{ window.speechSynthesis.cancel(); }catch(e){}
      syncPauseBtn();
    }
    function syncReadBtn(){
      readBtn.textContent = readOn ? '🔊 朗读：开' : '🔊 朗读：关';
    }
    function syncPauseBtn(){
      pauseBtn.hidden = !speaking;
      if(speaking) pauseBtn.textContent = paused ? '▶ 继续' : '⏸ 暂停';
    }
    readBtn.addEventListener('click', function(){
      if(!synthOK){
        window.GG.showNotice('当前浏览器不支持语音朗读，换个浏览器试试');
        return;
      }
      readOn = !readOn;
      try{ window.localStorage.setItem('gg_tts_v1', readOn ? 'on' : 'off'); }catch(e){}
      syncReadBtn();
      if(readOn){
        var text = latestPigText();
        if(text) speak(text);
      }else{
        stopSpeaking();
      }
    });
    pauseBtn.addEventListener('click', function(){
      if(!synthOK || !speaking) return;
      try{
        if(paused){ window.speechSynthesis.resume(); paused = false; }
        else{ window.speechSynthesis.pause(); paused = true; }
      }catch(e){}
      syncPauseBtn();
    });

    // 乖乖新回话出现时，如果朗读开着就读出来
    if(window.MutationObserver){
      var observer = new MutationObserver(function(){
        if(!readOn || !synthOK || paused) return;
        var text = latestPigText();
        if(text) speak(text);
      });
      observer.observe(chatLog, { childList: true, subtree: true });
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="voice"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'voice');
      st.textContent =
        '.voice-mic{flex:0 0 auto;min-width:52px;min-height:52px;border-radius:999px;border:1.5px solid var(--line);' +
        'background:var(--card);font-size:19px;cursor:pointer;line-height:1;}' +
        '.voice-mic.listening{background:var(--pink-pale);border-color:var(--accent-deep);color:var(--accent-deep);' +
        'font-size:13px;font-weight:800;min-width:78px;animation:voicePulse 1s ease-in-out infinite;}' +
        '@keyframes voicePulse{0%,100%{transform:scale(1);}50%{transform:scale(1.05);}}' +
        '.voice-bar{display:flex;align-items:center;gap:8px;margin-top:8px;flex-wrap:wrap;}' +
        '.voice-toggle{min-height:44px;border-radius:999px;border:1.5px solid var(--line);background:var(--card);' +
        'color:var(--ink);font-size:13.5px;font-weight:700;padding:8px 14px;cursor:pointer;}' +
        '.voice-rate{display:flex;align-items:center;gap:6px;font-size:13.5px;color:var(--muted);font-weight:700;}' +
        '.voice-rate select{border:1.5px solid var(--line);border-radius:10px;background:var(--card);color:var(--ink);' +
        'padding:8px;min-height:44px;font-size:14px;}';
      document.head.appendChild(st);
    }
  });
})();
