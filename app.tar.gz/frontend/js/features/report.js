// 每日情侣报告（Phase 3）：渲染到 #me-report。
// 数字全部来自后端真实统计，没有数据时如实显示，不编数字。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var root = document.getElementById('me-report');
    if(!root) return;
    injectStyle();

    var todayKey = dateKey(new Date());
    root.innerHTML =
      '<div class="card rp-card">' +
        '<h3 class="rp-h">📊 今日情侣报告</h3>' +
        '<p class="rp-sub">聊天、互动、心愿、惊喜，都是今天真实发生过的，乖乖帮你记下来。</p>' +
        '<div class="rp-controls">' +
          '<label class="rp-date-label">看哪一天 <input type="date" class="rp-date" data-report-date value="' + todayKey + '" max="' + todayKey + '" /></label>' +
          '<button type="button" class="play-btn" data-report-view>查看这天</button>' +
          '<button type="button" class="btn-ghost" data-report-refresh>生成今日报告</button>' +
        '</div>' +
        '<div class="rp-body" data-report-body aria-live="polite"><p class="rp-empty">正在整理今天的回忆…</p></div>' +
      '</div>';

    var dateInput = root.querySelector('[data-report-date]');
    var bodyEl = root.querySelector('[data-report-body]');

    root.querySelector('[data-report-view]').addEventListener('click', function(){
      loadReport(dateInput.value || todayKey);
    });
    root.querySelector('[data-report-refresh]').addEventListener('click', function(){
      dateInput.value = todayKey;
      loadReport(todayKey);
    });
    dateInput.addEventListener('change', function(){
      loadReport(dateInput.value || todayKey);
    });

    loadReport(todayKey);

    function dateKey(d){
      return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
    }

    function loadReport(date){
      bodyEl.innerHTML = '<p class="rp-empty">正在整理 ' + esc(date) + ' 的回忆…</p>';
      var path = (date === todayKey) ? '/api/reports/today' : '/api/reports?date=' + encodeURIComponent(date);
      window.GG.apiFetch(path).then(function(res){
        if(!res.ok) throw new Error('http ' + res.status);
        return res.json();
      }).then(function(d){
        renderReport(d, date);
      }).catch(function(){
        bodyEl.innerHTML = '<p class="rp-empty">报告暂时取不到，检查一下后端连接，稍后再来看看。</p>';
      });
    }

    function renderReport(d, date){
      if(!d || d.hasData === false){
        bodyEl.innerHTML = '<p class="rp-empty">今天还没有足够的回忆' +
          (date === todayKey ? '，跟乖乖聊聊天、玩玩游戏，晚上再来看。' : '，那天还没有留下什么记录。') + '</p>';
        return;
      }
      var html = '<p class="rp-date-line">' + esc(date) + ' 的小结</p>';
      var stats = [];
      if(d.chats != null) stats.push(['💬 聊天', d.chats + ' 次']);
      if(d.interactions != null) stats.push(['🤲 互动', d.interactions + ' 次']);
      if(d.moods != null) stats.push(['💗 心情', Array.isArray(d.moods) ? (d.moods.join('、') || '没有记录') : d.moods]);
      if(d.wishesDone != null) stats.push(['✅ 心愿', '完成了 ' + d.wishesDone + ' 个']);
      if(d.surprise) stats.push(['🎁 惊喜', typeof d.surprise === 'string' ? d.surprise : (d.surprise.title || '开过盲盒啦')]);
      if(stats.length){
        html += '<div class="rp-stats">';
        for(var i = 0; i < stats.length; i++){
          html += '<div class="rp-stat"><span class="rp-stat-k">' + esc(stats[i][0]) + '</span><span class="rp-stat-v">' + esc(stats[i][1]) + '</span></div>';
        }
        html += '</div>';
      }
      var quotes = d.quotes || d.favoriteQuotes || [];
      if(Array.isArray(quotes) && quotes.length){
        html += '<h4 class="rp-sec">💌 值得收藏的话</h4><ul class="rp-quotes">';
        for(var q = 0; q < quotes.length; q++){
          html += '<li>“' + esc(typeof quotes[q] === 'string' ? quotes[q] : (quotes[q].text || quotes[q])) + '”</li>';
        }
        html += '</ul>';
      }
      if(d.summary){
        html += '<h4 class="rp-sec">🌙 乖乖的小结</h4><p class="rp-summary">' + esc(d.summary) + '</p>';
        html += '<p class="rp-source">来源：' + esc(d.summarySource === 'ai' ? 'AI 生成' : '本地模板') + '</p>';
      }
      if(!stats.length && !quotes.length && !d.summary){
        html += '<p class="rp-empty">今天还没有足够的回忆，跟乖乖聊聊天、玩玩游戏，晚上再来看。</p>';
      }
      bodyEl.innerHTML = html;
    }

    function esc(s){
      return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="report"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'report');
      st.textContent =
        '.rp-card{display:flex;flex-direction:column;gap:10px;}' +
        '.rp-h{margin:0;font-size:17px;}' +
        '.rp-sub{margin:0;color:var(--muted);font-size:13.5px;line-height:1.6;}' +
        '.rp-controls{display:flex;gap:8px;flex-wrap:wrap;align-items:center;}' +
        '.rp-date-label{display:flex;align-items:center;gap:8px;font-size:13.5px;font-weight:700;color:var(--ink);}' +
        '.rp-date{border:1.5px solid var(--line);border-radius:12px;background:var(--card);color:var(--ink);padding:10px;min-height:48px;font-size:14px;}' +
        '.rp-controls .play-btn,.rp-controls .btn-ghost{flex:1;white-space:nowrap;}' +
        '.rp-body{display:flex;flex-direction:column;gap:10px;}' +
        '.rp-empty{color:var(--muted);font-size:14px;line-height:1.6;margin:0;}' +
        '.rp-date-line{margin:0;font-size:13px;color:var(--muted);font-weight:700;}' +
        '.rp-stats{display:grid;grid-template-columns:1fr 1fr;gap:8px;}' +
        '.rp-stat{background:var(--card2);border:1px solid var(--line);border-radius:14px;padding:10px 12px;display:flex;flex-direction:column;gap:4px;}' +
        '.rp-stat-k{font-size:12.5px;color:var(--muted);}' +
        '.rp-stat-v{font-size:15px;font-weight:800;color:var(--ink);line-height:1.4;}' +
        '.rp-sec{margin:4px 0 0;font-size:15px;}' +
        '.rp-quotes{margin:0;padding-left:18px;font-size:14px;line-height:1.7;color:var(--ink);}' +
        '.rp-summary{margin:0;font-size:14.5px;line-height:1.8;color:var(--ink);}' +
        '.rp-source{margin:0;font-size:12px;color:var(--muted);}';
      document.head.appendChild(st);
    }
  });
})();
