/* 可爱的乖乖 — 心愿清单（Phase 3）
 * 渲染到 #surprise-wishlist。新建/编辑/删除/标记完成/优先级/备注/照片；
 * 完成时有纪念动画（GG.burstHearts + GG.say + 庆祝卡片）。
 * 「AI 帮我想一个」只给建议，点了「加入心愿」才新建，绝不自动添加。
 * 照片先在客户端 canvas 压缩（最长边 ≤1200、JPEG 0.8）再 POST /api/photos。 */
(function () {
  'use strict';

  function boot() {
    if (!window.GG || !window.GG.apiFetch) return;
    var root = document.getElementById('surprise-wishlist');
    if (!root) return;
    init(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  var CATEGORIES = ['礼物', '美食', '旅行', '活动', '学习', '其他'];

  function injectStyle() {
    if (document.querySelector('style[data-feature="wishlist"]')) return;
    var st = document.createElement('style');
    st.setAttribute('data-feature', 'wishlist');
    st.textContent =
      '.wl-card{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:0 8px 24px rgba(255,105,180,.12);padding:16px 14px;margin-bottom:12px}' +
      '.wl-card h3{margin:0 0 4px;font-size:17px;color:var(--ink)}' +
      '.wl-sub{margin:0 0 12px;font-size:12.5px;color:var(--muted);line-height:1.5}' +
      '.wl-summary{display:flex;gap:8px;align-items:center;background:var(--pink-pale);border-radius:16px;padding:10px 12px;font-size:14px;font-weight:800;color:var(--accent-deep);margin-bottom:12px}' +
      '.wl-row{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}' +
      '.wl-btn{flex:1;min-height:44px;border:none;border-radius:999px;background:var(--accent);color:#fff;font-weight:800;font-size:14px;cursor:pointer;box-shadow:0 6px 14px rgba(255,105,180,.28);padding:8px 12px}' +
      '.wl-btn.ghost{flex:0 0 auto;background:var(--card);border:1.5px solid var(--line);color:var(--ink);box-shadow:none}' +
      '.wl-btn:disabled{opacity:.6;cursor:default}' +
      '.wl-item{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:12px;margin-bottom:8px}' +
      '.wl-item.done{opacity:.75}' +
      '.wl-item.done .wl-title{text-decoration:line-through}' +
      '.wl-top{display:flex;align-items:flex-start;gap:8px}' +
      '.wl-title{flex:1;font-size:15px;font-weight:800;color:var(--ink);line-height:1.4}' +
      '.wl-prio{color:var(--accent-deep);font-size:13px;white-space:nowrap}' +
      '.wl-meta{font-size:12px;color:var(--muted);margin-top:4px;line-height:1.5}' +
      '.wl-note{font-size:13.5px;color:var(--ink);line-height:1.6;margin-top:6px}' +
      '.wl-photo{width:100%;border-radius:14px;margin-top:8px;display:block}' +
      '.wl-actions{display:flex;gap:8px;margin-top:10px;flex-wrap:wrap}' +
      '.wl-mini{flex:1;min-height:44px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;font-size:13.5px;font-weight:800;cursor:pointer;padding:6px 8px}' +
      '.wl-mini.primary{background:var(--pink-pale);border-color:var(--pink);color:var(--accent-deep)}' +
      '.wl-mini.danger{color:#C0392B}' +
      '.wl-form{background:var(--card2);border:1px dashed var(--pink);border-radius:18px;padding:12px;margin-bottom:12px}' +
      '.wl-form label{display:block;font-size:12.5px;font-weight:800;color:var(--muted);margin:10px 0 4px}' +
      '.wl-form input,.wl-form select,.wl-form textarea{width:100%;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;padding:10px;font-size:14px;background:var(--card);color:var(--ink);font-family:inherit}' +
      '.wl-form textarea{resize:vertical;min-height:64px}' +
      '.wl-form .wl-file{border-style:dashed}' +
      '.wl-cele{background:linear-gradient(135deg,var(--pink-pale),#FFF3C4);border-radius:18px;padding:14px;text-align:center;font-size:15px;font-weight:800;color:var(--accent-deep);line-height:1.6;margin-bottom:12px}' +
      '.wl-suggest{background:var(--card2);border:1px solid var(--line);border-radius:18px;padding:12px;margin-bottom:12px}' +
      '.wl-suggest p{margin:0 0 8px;font-size:14px;line-height:1.6;color:var(--ink)}' +
      '.wl-empty{font-size:13.5px;color:var(--muted);line-height:1.6}' +
      '.wl-err{font-size:13px;color:var(--muted);line-height:1.6}';
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function asList(d) {
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.items)) return d.items;
    if (d && Array.isArray(d.wishlists)) return d.wishlists;
    if (d && Array.isArray(d.gifts)) return d.gifts;
    if (d && Array.isArray(d.recommendations)) return d.recommendations;
    return [];
  }

  /* 客户端压缩照片：最长边 ≤1200、JPEG 0.8，返回 dataUrl（交给 /api/photos）。 */
  function compressPhoto(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error('读不到这张照片')); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('这张照片打不开')); };
        img.onload = function () {
          var max = 1200, w = img.width, h = img.height;
          if (Math.max(w, h) > max) {
            var scale = max / Math.max(w, h);
            w = Math.round(w * scale); h = Math.round(h * scale);
          }
          var canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d').drawImage(img, 0, 0, w, h);
          try { resolve(canvas.toDataURL('image/jpeg', 0.8)); }
          catch (e) { reject(new Error('照片压缩失败')); }
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function init(root) {
    injectStyle();
    var state = { items: [], summary: null, editingId: null, suggest: null };

    root.innerHTML =
      '<div class="wl-card">' +
        '<h3>💭 宝宝的小心愿</h3>' +
        '<p class="wl-sub">想做的、想要的、想去的地方，都写下来，一个一个实现。</p>' +
        '<div class="wl-summary" id="wlSummary">正在数心愿…</div>' +
        '<div class="wl-row">' +
          '<button type="button" class="wl-btn" id="wlAddBtn">＋ 写一个小心愿</button>' +
          '<button type="button" class="wl-btn ghost" id="wlAiBtn">✨ AI 帮我想一个</button>' +
        '</div>' +
        '<div id="wlCele"></div>' +
        '<div id="wlSuggest"></div>' +
        '<div id="wlFormWrap"></div>' +
        '<div id="wlList"><p class="wl-empty">正在翻心愿清单…</p></div>' +
      '</div>';

    var summaryEl = root.querySelector('#wlSummary');
    var celeEl = root.querySelector('#wlCele');
    var suggestEl = root.querySelector('#wlSuggest');
    var formWrap = root.querySelector('#wlFormWrap');
    var listEl = root.querySelector('#wlList');

    function apiErr(res, fallback) {
      return res.json().catch(function () { return {}; }).then(function (d) {
        throw new Error((d && d.detail) || (d && d.error) || fallback);
      });
    }

    function renderSummary() {
      if (!state.summary) { summaryEl.textContent = '心愿数不出来，刷新试试。'; return; }
      summaryEl.textContent = '已完成 ' + (state.summary.done || 0) + ' 个 / 共 ' + (state.summary.total || 0) + ' 个';
    }

    function renderList() {
      if (!state.items.length) {
        listEl.innerHTML = '<p class="wl-empty">还没有心愿。写下第一个吧，乖乖陪宝宝一起实现它。</p>';
        return;
      }
      listEl.innerHTML = '';
      var sorted = state.items.slice().sort(function (a, b) {
        if ((a.done || 0) !== (b.done || 0)) return (a.done || 0) - (b.done || 0);
        return (a.priority || 2) - (b.priority || 2);
      });
      sorted.forEach(function (item) {
        var stars = '★'.repeat(item.priority || 2) + '☆'.repeat(3 - (item.priority || 2));
        var el = document.createElement('div');
        el.className = 'wl-item' + (item.done ? ' done' : '');
        el.innerHTML =
          '<div class="wl-top"><div class="wl-title">' + esc(item.title) + '</div>' +
          '<span class="wl-prio">' + stars + '</span></div>' +
          '<div class="wl-meta">' + esc(item.category || '其他') +
            (item.completed_at ? ' · 完成于 ' + esc(new Date(item.completed_at).toLocaleDateString()) : '') + '</div>' +
          (item.note ? '<div class="wl-note">' + esc(item.note) + '</div>' : '') +
          (item.photo_url ? '<img class="wl-photo" src="' + esc(item.photo_url) + '" alt="心愿照片" loading="lazy" />' : '') +
          '<div class="wl-actions">' +
            (item.done
              ? '<button type="button" class="wl-mini" data-act="uncomplete">↩ 还没完成</button>'
              : '<button type="button" class="wl-mini primary" data-act="complete">✓ 完成啦</button>') +
            '<button type="button" class="wl-mini" data-act="edit">编辑</button>' +
            '<button type="button" class="wl-mini danger" data-act="del">删除</button>' +
          '</div>';
        el.querySelector('[data-act="complete"], [data-act="uncomplete"]').addEventListener('click', function () {
          toggleComplete(item);
        });
        el.querySelector('[data-act="edit"]').addEventListener('click', function () { openForm(item); });
        el.querySelector('[data-act="del"]').addEventListener('click', function () { removeItem(item); });
        listEl.appendChild(el);
      });
    }

    function toggleComplete(item) {
      window.GG.apiFetch('/api/wishlists/' + item.id + '/complete', { method: 'POST' })
        .then(function (res) {
          if (!res.ok) return apiErr(res, item.done ? '取消完成失败' : '标记完成失败');
          return res.json().catch(function () { return {}; });
        })
        .then(function () {
          item.done = item.done ? 0 : 1;
          item.completed_at = item.done ? Date.now() : null;
          if (item.done) {
            window.GG.burstHearts(12);
            window.GG.say('宝宝太棒啦！「' + item.title + '」完成啦，乖乖替你开心，今天也要奖励自己一下～', '', 'happy');
            window.GG.logEvent('wishlist_complete', item.title);
            celeEl.innerHTML = '<div class="wl-cele">🎉 恭喜宝宝！<br>「' + esc(item.title) + '」完成啦<br><small>乖乖记下了这一刻，开心要加倍～</small></div>';
            setTimeout(function () { celeEl.innerHTML = ''; }, 8000);
          }
          refreshSummary();
          renderList();
        })
        .catch(function (err) {
          window.GG.showNotice(err.message + '，再点一次试试。');
        });
    }

    function removeItem(item) {
      if (!window.confirm('确定删掉心愿「' + item.title + '」吗？删了就找不回来啦。')) return;
      window.GG.apiFetch('/api/wishlists/' + item.id, { method: 'DELETE' })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '删除失败');
          return res.json().catch(function () { return {}; });
        })
        .then(function () {
          state.items = state.items.filter(function (w) { return w.id !== item.id; });
          refreshSummary();
          renderList();
        })
        .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
    }

    function openForm(item) {
      state.editingId = item ? item.id : null;
      formWrap.innerHTML =
        '<form class="wl-form" id="wlForm">' +
          '<label for="wlFTitle">心愿标题</label>' +
          '<input id="wlFTitle" maxlength="60" required placeholder="比如：一起去看海" value="' + esc(item ? item.title : '') + '" />' +
          '<label for="wlFCat">分类</label>' +
          '<select id="wlFCat">' + CATEGORIES.map(function (c) {
            return '<option value="' + c + '"' + ((item ? item.category : '礼物') === c ? ' selected' : '') + '>' + c + '</option>';
          }).join('') + '</select>' +
          '<label for="wlFPrio">优先级</label>' +
          '<select id="wlFPrio">' +
            '<option value="1"' + (item && item.priority === 1 ? ' selected' : '') + '>★ 很想要</option>' +
            '<option value="2"' + (!item || item.priority === 2 ? ' selected' : '') + '>★★ 想实现</option>' +
            '<option value="3"' + (item && item.priority === 3 ? ' selected' : '') + '>★★★ 最重要</option>' +
          '</select>' +
          '<label for="wlFNote">备注</label>' +
          '<textarea id="wlFNote" maxlength="500" placeholder="写一点关于这个心愿的小想法…">' + esc(item ? item.note || '' : '') + '</textarea>' +
          '<label for="wlFPhoto">照片（可选）</label>' +
          '<input id="wlFPhoto" class="wl-file" type="file" accept="image/jpeg,image/png,image/webp" />' +
          (item && item.photo_url ? '<p class="wl-empty" style="margin-top:6px">已有照片一张；不选新照片就保留原来的。</p>' : '') +
          '<div class="wl-row" style="margin-top:12px">' +
            '<button type="submit" class="wl-btn" id="wlSaveBtn">' + (item ? '保存修改' : '加入心愿清单') + '</button>' +
            '<button type="button" class="wl-btn ghost" id="wlCancelBtn">取消</button>' +
          '</div>' +
        '</form>';
      formWrap.querySelector('#wlCancelBtn').addEventListener('click', function () {
        formWrap.innerHTML = '';
        state.editingId = null;
      });
      formWrap.querySelector('#wlForm').addEventListener('submit', function (e) {
        e.preventDefault();
        saveForm(item);
      });
    }

    function saveForm(item) {
      var title = formWrap.querySelector('#wlFTitle').value.trim();
      if (!title) { window.GG.showNotice('先给心愿起个名字吧。'); return; }
      var saveBtn = formWrap.querySelector('#wlSaveBtn');
      saveBtn.disabled = true;
      saveBtn.textContent = '正在保存…';
      var file = formWrap.querySelector('#wlFPhoto').files[0];
      var photoPromise = Promise.resolve(item ? item.photo_url || null : null);
      if (file) {
        photoPromise = compressPhoto(file)
          .then(function (dataUrl) {
            return window.GG.apiFetch('/api/photos', { method: 'POST', body: JSON.stringify({ dataUrl: dataUrl, name: file.name }) });
          })
          .then(function (res) {
            if (!res.ok) return apiErr(res, '照片上传失败');
            return res.json();
          })
          .then(function (d) { return d.url || null; });
      }
      photoPromise
        .then(function (photoUrl) {
          var body = {
            title: title,
            category: formWrap.querySelector('#wlFCat').value,
            priority: parseInt(formWrap.querySelector('#wlFPrio').value, 10),
            note: formWrap.querySelector('#wlFNote').value.trim(),
            photo_url: photoUrl
          };
          var url = state.editingId ? '/api/wishlists/' + state.editingId : '/api/wishlists';
          var method = state.editingId ? 'PUT' : 'POST';
          return window.GG.apiFetch(url, { method: method, body: JSON.stringify(body) });
        })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '保存失败');
          return res.json();
        })
        .then(function (d) {
          var saved = (d && d.wishlist) || d;
          if (state.editingId) {
            var idx = state.items.findIndex(function (w) { return w.id === state.editingId; });
            if (idx >= 0 && saved && saved.id) state.items[idx] = saved;
          } else if (saved && saved.id) {
            state.items.unshift(saved);
          }
          formWrap.innerHTML = '';
          state.editingId = null;
          window.GG.logEvent('wishlist_save', title);
          load();
        })
        .catch(function (err) {
          saveBtn.disabled = false;
          saveBtn.textContent = state.editingId ? '保存修改' : '加入心愿清单';
          window.GG.showNotice(err.message + '，再试一次吧。');
        });
    }

    /* AI 建议：只用已确认的喜好 + 推荐接口给一条建议，点了「加入心愿」才新建。 */
    function aiSuggest() {
      var btn = root.querySelector('#wlAiBtn');
      btn.disabled = true;
      btn.textContent = '乖乖正在想…';
      suggestEl.innerHTML = '<p class="wl-empty">乖乖正在翻宝宝的喜好，想一个合适的小心愿…</p>';
      var prefsP = window.GG.apiFetch('/api/preferences').then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; });
      var giftsP = window.GG.apiFetch('/api/gifts/recommend').then(function (r) { return r.ok ? r.json() : []; }).catch(function () { return []; });
      Promise.all([prefsP, giftsP]).then(function (results) {
        btn.disabled = false;
        btn.textContent = '✨ AI 帮我想一个';
        var prefs = asList(results[0]).filter(function (p) { return p.confirmed; });
        var gifts = asList(results[1]);
        var existingTitles = state.items.map(function (w) { return w.title; });
        var gift = null;
        for (var i = 0; i < gifts.length; i++) {
          if (existingTitles.indexOf(gifts[i].name) === -1) { gift = gifts[i]; break; }
        }
        if (!gift) {
          if (!prefs.length && !gifts.length) {
            suggestEl.innerHTML = '<div class="wl-suggest"><p>乖乖还不太了解宝宝的喜好，先去「我的」里告诉我喜欢什么，我再帮你想一个合适的小心愿～</p></div>';
          } else {
            suggestEl.innerHTML = '<div class="wl-suggest"><p>乖乖翻了一圈，合适的推荐都被宝宝写进清单啦。等有了新喜好，我再帮你想新的～</p></div>';
          }
          return;
        }
        var likeLine = prefs.length
          ? '宝宝喜欢' + prefs.slice(0, 3).map(function (p) { return p.value; }).join('、') + '，'
          : '';
        state.suggest = gift;
        suggestEl.innerHTML =
          '<div class="wl-suggest">' +
            '<p>💡 ' + esc(likeLine) + '乖乖觉得这个不错：<b>「' + esc(gift.name) + '」</b><br>' +
            esc(gift.reason || '') + '（适合：' + esc(gift.occasion || '日常') + '）</p>' +
            '<div class="wl-row" style="margin-bottom:0">' +
              '<button type="button" class="wl-btn" id="wlSuggestAdd">加入心愿</button>' +
              '<button type="button" class="wl-btn ghost" id="wlSuggestNo">不要这个</button>' +
            '</div>' +
          '</div>';
        suggestEl.querySelector('#wlSuggestAdd').addEventListener('click', function () {
          var g = state.suggest;
          suggestEl.querySelector('#wlSuggestAdd').disabled = true;
          window.GG.apiFetch('/api/wishlists', {
            method: 'POST',
            body: JSON.stringify({ title: g.name, category: '礼物', priority: 2, note: g.reason || '', photo_url: null })
          })
            .then(function (res) {
              if (!res.ok) return apiErr(res, '加入失败');
              return res.json();
            })
            .then(function (d) {
              var saved = (d && d.wishlist) || d;
              if (saved && saved.id) state.items.unshift(saved);
              suggestEl.innerHTML = '';
              state.suggest = null;
              window.GG.say('「' + g.name + '」已经写进心愿清单啦，宝宝真有眼光～', '', 'happy');
              window.GG.logEvent('wishlist_ai_add', g.name);
              refreshSummary();
              renderList();
            })
            .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
        });
        suggestEl.querySelector('#wlSuggestNo').addEventListener('click', function () {
          suggestEl.innerHTML = '';
          state.suggest = null;
        });
      });
    }

    function refreshSummary() {
      window.GG.apiFetch('/api/wishlists/summary')
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (d) { if (d) { state.summary = d; renderSummary(); } })
        .catch(function () {});
    }

    function load() {
      window.GG.apiFetch('/api/wishlists')
        .then(function (res) {
          if (!res.ok) return apiErr(res, '心愿清单拉不到');
          return res.json();
        })
        .then(function (d) {
          state.items = asList(d);
          renderList();
        })
        .catch(function (err) {
          listEl.innerHTML = '<p class="wl-err">心愿清单暂时拉不到：' + esc(err.message) + '。检查一下网络，刷新页面再试吧。</p>';
        });
      refreshSummary();
    }

    root.querySelector('#wlAddBtn').addEventListener('click', function () { openForm(null); });
    root.querySelector('#wlAiBtn').addEventListener('click', aiSuggest);
    load();
  }
})();
