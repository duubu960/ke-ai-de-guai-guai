// 情绪急救室 — 在首页 .actions 插入「我需要抱抱」按钮 + 全屏情绪陪伴浮层（Phase 3 前端模块 A）
// 情绪走 GG.setEmotion / GG.sendChat 走原有聊天；难过/委屈/生气时不玩笑、不说教。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function(){
    if(!window.GG) return;
    var actions = document.querySelector('#page-home .actions');
    if(!actions) return;
    if(actions.querySelector('[data-feature-emotion-btn]')) return;

    var NAMES = window.GG.emotionNames || { happy:'开心', sad:'难过', wronged:'委屈', angry:'生气', anxious:'焦虑', lonely:'孤独', tired:'疲惫', miss:'想念' };
    var EMOJIS = { happy:'😊', sad:'😢', wronged:'🥺', angry:'😤', anxious:'😟', lonely:'🌙', tired:'😴', miss:'💭' };
    var OPENINGS = {
      happy: '宝宝今天开心得冒泡啦！快跟乖乖说说，是什么好事呀？',
      sad: '乖，难过的时候不用一个人扛。乖乖在这里，慢慢说，我认真听着。',
      wronged: '委屈了对不对？先靠过来，乖乖站你这边，慢慢说给我听。',
      angry: '气坏了吧？先深呼吸一下，乖乖不反驳、不催你，你想说什么都行。',
      anxious: '别急，我们一件一件来。你心里的担心，都可以慢慢说给我听。',
      lonely: '你不是一个人。乖乖一直都在，陪你说会儿话，好不好？',
      tired: '累了就靠一靠，不用逞强。今晚不聊难的事，乖乖陪你歇一会儿。',
      miss: '想念的时候，乖乖也想你。我们把想说的话都存下来，下次见面再一起说。'
    };

    injectStyle();

    // ---------- 首页按钮 ----------
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'act';
    btn.setAttribute('data-feature-emotion-btn', '1');
    btn.innerHTML = '<span class="ico ico-pink">🫂</span><span><strong>我需要抱抱</strong><span>心里有话想说，先抱抱你</span></span>';
    actions.appendChild(btn);

    // ---------- 浮层 ----------
    var overlay = document.createElement('div');
    overlay.className = 'ft-emo-overlay';
    overlay.hidden = true;
    var gridHtml = Object.keys(NAMES).map(function(k){
      return '<button type="button" class="ft-emo-card" data-emotion="' + k + '">' +
        '<span class="ft-emo-emoji">' + EMOJIS[k] + '</span><span class="ft-emo-name">' + NAMES[k] + '</span></button>';
    }).join('');
    overlay.innerHTML =
      '<div class="ft-emo-panel" role="dialog" aria-label="情绪陪伴">' +
        '<div class="ft-emo-top"><h3>我在这里，宝宝 💗</h3>' +
        '<button type="button" class="btn-ghost ft-emo-exit">退出</button></div>' +
        '<p class="ft-emo-sub">先选一个最贴近现在心情的，乖乖陪你。</p>' +
        '<div class="ft-emo-grid">' + gridHtml + '</div>' +
        '<div class="ft-emo-talk" hidden>' +
          '<p class="ft-emo-open"></p>' +
          '<textarea class="ft-emo-text" rows="4" maxlength="1000" placeholder="想说什么都可以，乖乖认真听着……"></textarea>' +
          '<div class="ft-emo-err" hidden></div>' +
          '<div class="ft-emo-row"><button type="button" class="btn-main ft-emo-send">告诉乖乖</button>' +
          '<button type="button" class="btn-ghost ft-emo-quiet-btn">现在不想说话</button></div>' +
        '</div>' +
        '<div class="ft-emo-quiet" hidden>' +
          '<div class="ft-emo-pig">🐷</div>' +
          '<p class="ft-emo-quiet-t">我就在这里陪着你</p>' +
          '<p class="ft-emo-quiet-s">不用说话也没关系，乖乖安安静静陪你待一会儿。</p>' +
          '<button type="button" class="btn-ghost ft-emo-back">我好了，回去吧</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    var current = null;
    var talk = overlay.querySelector('.ft-emo-talk');
    var quiet = overlay.querySelector('.ft-emo-quiet');
    var openLine = overlay.querySelector('.ft-emo-open');
    var text = overlay.querySelector('.ft-emo-text');
    var err = overlay.querySelector('.ft-emo-err');

    function open(){
      current = null;
      talk.hidden = true; quiet.hidden = true;
      text.value = ''; err.hidden = true;
      overlay.querySelectorAll('.ft-emo-card').forEach(function(c){ c.classList.remove('active'); });
      overlay.hidden = false;
      if(window.GG.logEvent) window.GG.logEvent('emotion_open', '');
    }
    function close(){
      overlay.hidden = true;
      current = null;
      if(window.GG && window.GG.setEmotion) window.GG.setEmotion(null);
    }
    function select(key){
      current = key;
      if(window.GG.setEmotion) window.GG.setEmotion(key);
      overlay.querySelectorAll('.ft-emo-card').forEach(function(c){ c.classList.toggle('active', c.getAttribute('data-emotion') === key); });
      openLine.textContent = OPENINGS[key] || '';
      talk.hidden = false; quiet.hidden = true;
      err.hidden = true;
      text.focus();
      if(window.GG.logEvent) window.GG.logEvent('emotion_select', key);
    }

    btn.addEventListener('click', open);
    overlay.addEventListener('click', function(e){
      if(e.target === overlay){ close(); return; }
      var card = e.target.closest ? e.target.closest('.ft-emo-card') : null;
      if(card){ select(card.getAttribute('data-emotion')); return; }
      if(e.target.classList.contains('ft-emo-exit')){ close(); return; }
      if(e.target.classList.contains('ft-emo-quiet-btn')){
        talk.hidden = true; quiet.hidden = false;
        if(window.GG.logEvent) window.GG.logEvent('emotion_quiet', current || '');
        return;
      }
      if(e.target.classList.contains('ft-emo-back')){ close(); return; }
      if(e.target.classList.contains('ft-emo-send')){
        var t = text.value.trim();
        if(!t){ err.hidden = false; err.textContent = '先写一点点也可以，不写也没关系——点「现在不想说话」，乖乖就安静陪你。'; return; }
        var em = current;
        close();
        if(window.GG.logEvent) window.GG.logEvent('emotion_vent', em || '');
        if(window.GGNav) window.GGNav.show('home');
        window.GG.sendChat(t, { emotion: em });
      }
    });

    function injectStyle(){
      if(document.querySelector('style[data-feature="emotion"]')) return;
      var s = document.createElement('style');
      s.setAttribute('data-feature', 'emotion');
      s.textContent =
        '.ft-emo-overlay{position:fixed;inset:0;background:rgba(42,24,54,.55);z-index:200;display:flex;align-items:flex-end;justify-content:center}' +
        '.ft-emo-overlay[hidden]{display:none}' +
        '.ft-emo-panel{background:var(--card);border-radius:26px 26px 0 0;max-width:480px;width:100%;max-height:92vh;overflow:auto;padding:20px 18px 30px}' +
        '.ft-emo-top{display:flex;justify-content:space-between;align-items:center;gap:10px}' +
        '.ft-emo-top h3{margin:0;font-size:19px}' +
        '.ft-emo-top .btn-ghost{min-width:76px;min-height:44px;padding:8px 14px}' +
        '.ft-emo-sub{margin:8px 0 14px;color:var(--muted);font-size:13.5px;line-height:1.6}' +
        '.ft-emo-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}' +
        '.ft-emo-card{border:1px solid var(--line);background:var(--card2);border-radius:16px;padding:12px 4px;min-height:76px;display:flex;flex-direction:column;align-items:center;gap:6px;cursor:pointer;font-family:inherit}' +
        '.ft-emo-card.active{background:var(--accent);border-color:var(--accent)}' +
        '.ft-emo-card.active .ft-emo-name{color:#fff}' +
        '.ft-emo-emoji{font-size:26px;line-height:1}' +
        '.ft-emo-name{font-size:13.5px;font-weight:700;color:var(--ink)}' +
        '.ft-emo-talk{margin-top:16px}' +
        '.ft-emo-open{font-size:15px;line-height:1.8;color:var(--ink);background:var(--pink-pale);border-radius:14px;padding:12px 14px;margin:0 0 12px}' +
        '.ft-emo-text{width:100%;min-height:96px;border:1px solid var(--line);border-radius:14px;padding:12px;font-size:14.5px;line-height:1.7;font-family:inherit;background:var(--surface);color:var(--ink);resize:vertical}' +
        '.ft-emo-err{color:var(--accent-deep);font-size:13.5px;margin:8px 0}' +
        '.ft-emo-row{display:flex;gap:10px;margin-top:10px}' +
        '.ft-emo-row .btn-main{flex:1}' +
        '.ft-emo-quiet{text-align:center;padding:26px 8px 6px}' +
        '.ft-emo-pig{font-size:64px;line-height:1;animation:ft-emo-breathe 3s ease-in-out infinite}' +
        '@keyframes ft-emo-breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}' +
        '.ft-emo-quiet-t{font-size:17px;font-weight:800;margin:14px 0 6px}' +
        '.ft-emo-quiet-s{color:var(--muted);font-size:14px;line-height:1.7;margin:0 0 18px}';
      document.head.appendChild(s);
    }
  });
})();
