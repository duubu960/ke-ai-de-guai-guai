/* 可爱的乖乖 — 喜好档案（Phase 3）
 * 渲染到 #me-preferences。「AI 记住了什么」按 10 个分类分组展示已确认的喜好，
 * 每条可编辑、删除，可手动新增。待确认清单里的提取结果必须用户点了「确认」
 * 才进档案；「忽略」则删掉。「从最近聊天里找找喜好」用真实聊天记录提取。 */
(function () {
  'use strict';

  function boot() {
    if (!window.GG || !window.GG.apiFetch) return;
    var root = document.getElementById('me-preferences');
    if (!root) return;
    init(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  var CATEGORIES = [
    { key: 'food', label: '喜欢的食物', icon: '🍓' },
    { key: 'drink', label: '喜欢的饮料', icon: '🥤' },
    { key: 'color', label: '喜欢的颜色', icon: '🎨' },
    { key: 'animal', label: '喜欢的动物', icon: '🐰' },
    { key: 'music', label: '喜欢的音乐', icon: '🎵' },
    { key: 'movie', label: '喜欢的电影', icon: '🎬' },
    { key: 'gift', label: '喜欢的礼物', icon: '🎁' },
    { key: 'activity', label: '喜欢的活动', icon: '⛺' },
    { key: 'dislike', label: '不喜欢的事', icon: '🙅' },
    { key: 'date', label: '重要纪念日', icon: '📅' }
  ];
  var CAT_LABEL = {};
  CATEGORIES.forEach(function (c) { CAT_LABEL[c.key] = c.label; });

  function injectStyle() {
    if (document.querySelector('style[data-feature="preferences"]')) return;
    var st = document.createElement('style');
    st.setAttribute('data-feature', 'preferences');
    st.textContent =
      '.pf-card{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:0 8px 24px rgba(255,105,180,.12);padding:16px 14px;margin-bottom:12px}' +
      '.pf-card h3{margin:0 0 4px;font-size:17px;color:var(--ink)}' +
      '.pf-sub{margin:0 0 12px;font-size:12.5px;color:var(--muted);line-height:1.5}' +
      '.pf-cat{margin:12px 0 6px;font-size:14px;font-weight:800;color:var(--ink)}' +
      '.pf-chips{display:flex;flex-wrap:wrap;gap:8px}' +
      '.pf-chip{display:inline-flex;align-items:center;gap:6px;background:var(--pink-pale);border:1px solid var(--line);border-radius:999px;padding:8px 10px;font-size:13.5px;font-weight:700;color:var(--ink);min-height:44px}' +
      '.pf-chip button{border:none;background:transparent;cursor:pointer;font-size:13px;padding:0 2px;min-width:24px;min-height:24px;color:var(--muted)}' +
      '.pf-chip button:hover{color:var(--accent-deep)}' +
      '.pf-empty{font-size:13.5px;color:var(--muted);line-height:1.6}' +
      '.pf-pend{margin-top:14px;border-top:1px dashed var(--line);padding-top:12px}' +
      '.pf-pend-item{background:var(--card2);border:1px solid var(--line);border-radius:16px;padding:10px 12px;margin-bottom:8px}' +
      '.pf-pend-t{font-size:14px;font-weight:800;color:var(--ink);line-height:1.4}' +
      '.pf-pend-s{font-size:12px;color:var(--muted);margin-top:2px;line-height:1.5}' +
      '.pf-pend-btns{display:flex;gap:8px;margin-top:8px}' +
      '.pf-mini{flex:1;min-height:44px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;font-size:13.5px;font-weight:800;cursor:pointer}' +
      '.pf-mini.primary{background:var(--pink-pale);border-color:var(--pink);color:var(--accent-deep)}' +
      '.pf-form{background:var(--card2);border:1px dashed var(--pink);border-radius:18px;padding:12px;margin-top:12px}' +
      '.pf-form label{display:block;font-size:12.5px;font-weight:800;color:var(--muted);margin:8px 0 4px}' +
      '.pf-form input,.pf-form select{width:100%;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;padding:10px;font-size:14px;background:var(--card);color:var(--ink);font-family:inherit}' +
      '.pf-row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}' +
      '.pf-btn{flex:1;min-height:44px;border:none;border-radius:999px;background:var(--accent);color:#fff;font-weight:800;font-size:14px;cursor:pointer;box-shadow:0 6px 14px rgba(255,105,180,.28);padding:8px 12px}' +
      '.pf-btn.ghost{flex:0 0 auto;background:var(--card);border:1.5px solid var(--line);color:var(--ink);box-shadow:none}' +
      '.pf-btn:disabled{opacity:.6;cursor:default}';
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function asList(d) {
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.items)) return d.items;
    if (d && Array.isArray(d.preferences)) return d.preferences;
    if (d && Array.isArray(d.candidates)) return d.candidates;
    return [];
  }

  function init(root) {
    injectStyle();
    var state = { confirmed: [], pending: [] };

    root.innerHTML =
      '<div class="pf-card">' +
        '<h3>💗 AI 记住了什么</h3>' +
        '<p class="pf-sub">乖乖记住的、关于宝宝的喜好都在这里。点 ✎ 可以改，点 ✕ 可以删；想补充就点下面的按钮。</p>' +
        '<div id="pfList"><p class="pf-empty">正在翻乖乖的记事本…</p></div>' +
        '<div class="pf-pend" id="pfPendWrap" hidden>' +
          '<h3 style="font-size:15px">🤔 等宝宝确认的喜好</h3>' +
          '<p class="pf-sub">这些是乖乖从聊天里听到的，<b>还没进档案</b>。确认了才记下来，不确认就忽略掉，乖乖不会擅自记。</p>' +
          '<div id="pfPendList"></div>' +
        '</div>' +
        '<div class="pf-row">' +
          '<button type="button" class="pf-btn" id="pfAddBtn">＋ 手动记一条喜好</button>' +
          '<button type="button" class="pf-btn ghost" id="pfExtractBtn">🔍 从最近聊天里找找喜好</button>' +
        '</div>' +
        '<div id="pfFormWrap"></div>' +
      '</div>';

    var listEl = root.querySelector('#pfList');
    var pendWrap = root.querySelector('#pfPendWrap');
    var pendListEl = root.querySelector('#pfPendList');
    var formWrap = root.querySelector('#pfFormWrap');

    function apiErr(res, fallback) {
      return res.json().catch(function () { return {}; }).then(function (d) {
        throw new Error((d && d.detail) || (d && d.error) || fallback);
      });
    }

    function renderConfirmed() {
      var byCat = {};
      state.confirmed.forEach(function (p) {
        (byCat[p.category] = byCat[p.category] || []).push(p);
      });
      var html = '';
      var any = false;
      CATEGORIES.forEach(function (cat) {
        var items = byCat[cat.key] || [];
        if (!items.length) return;
        any = true;
        html += '<div class="pf-cat">' + cat.icon + ' ' + esc(cat.label) + '</div><div class="pf-chips">';
        items.forEach(function (p) {
          html += '<span class="pf-chip" data-id="' + p.id + '">' + esc(p.value) +
            '<button type="button" data-act="edit" aria-label="编辑">✎</button>' +
            '<button type="button" data-act="del" aria-label="删除">✕</button></span>';
        });
        html += '</div>';
      });
      if (!any) {
        listEl.innerHTML = '<p class="pf-empty">乖乖的记事本还是空的。宝宝告诉我喜欢什么，我就记下来，以后聊天和选礼物都用得上～</p>';
        return;
      }
      listEl.innerHTML = html;
      listEl.querySelectorAll('.pf-chip').forEach(function (chip) {
        var id = parseInt(chip.getAttribute('data-id'), 10);
        var item = state.confirmed.find(function (p) { return p.id === id; });
        if (!item) return;
        chip.querySelector('[data-act="edit"]').addEventListener('click', function () { editItem(item); });
        chip.querySelector('[data-act="del"]').addEventListener('click', function () { deleteItem(item); });
      });
    }

    function renderPending() {
      if (!state.pending.length) { pendWrap.hidden = true; pendListEl.innerHTML = ''; return; }
      pendWrap.hidden = false;
      pendListEl.innerHTML = '';
      state.pending.forEach(function (p) {
        var el = document.createElement('div');
        el.className = 'pf-pend-item';
        el.innerHTML =
          '<div class="pf-pend-t">' + esc(CAT_LABEL[p.category] || p.category) + '：' + esc(p.value) + '</div>' +
          '<div class="pf-pend-s">乖乖从聊天里听到的，宝宝确认一下再记进档案，好不好？</div>' +
          '<div class="pf-pend-btns">' +
            '<button type="button" class="pf-mini primary" data-act="ok">✓ 确认，记下来</button>' +
            '<button type="button" class="pf-mini" data-act="no">忽略</button>' +
          '</div>';
        el.querySelector('[data-act="ok"]').addEventListener('click', function () { confirmPending(p, el); });
        el.querySelector('[data-act="no"]').addEventListener('click', function () { ignorePending(p, el); });
        pendListEl.appendChild(el);
      });
    }

    /* 确认：新建一条已确认的记录（confirmed:1）；再把待确认那条删掉，避免重复出现。 */
    function confirmPending(p, el) {
      var okBtn = el.querySelector('[data-act="ok"]');
      okBtn.disabled = true;
      okBtn.textContent = '正在记下来…';
      window.GG.apiFetch('/api/preferences', {
        method: 'POST',
        body: JSON.stringify({ category: p.category, value: p.value, confirmed: 1, source: p.source || 'ai' })
      })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '确认失败');
          return res.json();
        })
        .then(function (d) {
          var saved = (d && d.preference) || d;
          if (saved && saved.id) state.confirmed.push(saved);
          else state.confirmed.push({ id: Date.now(), category: p.category, value: p.value, confirmed: 1, source: 'ai' });
          state.pending = state.pending.filter(function (x) { return x !== p; });
          if (p.id) {
            window.GG.apiFetch('/api/preferences/' + p.id, { method: 'DELETE' }).catch(function () {});
          }
          window.GG.say('记下来啦！宝宝喜欢' + p.value + '，乖乖不会忘的～', '', 'happy');
          renderConfirmed();
          renderPending();
        })
        .catch(function (err) {
          okBtn.disabled = false;
          okBtn.textContent = '✓ 确认，记下来';
          window.GG.showNotice(err.message + '，再点一次试试。');
        });
    }

    function ignorePending(p, el) {
      state.pending = state.pending.filter(function (x) { return x !== p; });
      renderPending();
      if (p.id) {
        window.GG.apiFetch('/api/preferences/' + p.id, { method: 'DELETE' }).catch(function () {});
      }
    }

    function editItem(item) {
      var next = window.prompt('改一下「' + (CAT_LABEL[item.category] || item.category) + '」：', item.value);
      if (next == null) return;
      next = next.trim();
      if (!next) { window.GG.showNotice('内容不能为空，改动没有保存。'); return; }
      if (next === item.value) return;
      window.GG.apiFetch('/api/preferences/' + item.id, {
        method: 'PUT',
        body: JSON.stringify({ category: item.category, value: next, confirmed: 1 })
      })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '修改失败');
          return res.json();
        })
        .then(function () {
          item.value = next;
          renderConfirmed();
        })
        .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
    }

    function deleteItem(item) {
      if (!window.confirm('确定删掉「' + item.value + '」吗？乖乖以后就想不起来这条了。')) return;
      window.GG.apiFetch('/api/preferences/' + item.id, { method: 'DELETE' })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '删除失败');
          return res.json().catch(function () { return {}; });
        })
        .then(function () {
          state.confirmed = state.confirmed.filter(function (p) { return p.id !== item.id; });
          renderConfirmed();
        })
        .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
    }

    function openAddForm() {
      formWrap.innerHTML =
        '<form class="pf-form" id="pfForm">' +
          '<label for="pfFCat">是哪一类喜好</label>' +
          '<select id="pfFCat">' + CATEGORIES.map(function (c) {
            return '<option value="' + c.key + '">' + c.icon + ' ' + c.label + '</option>';
          }).join('') + '</select>' +
          '<label for="pfFVal">内容</label>' +
          '<input id="pfFVal" maxlength="60" required placeholder="比如：草莓、粉色、周杰伦…" />' +
          '<div class="pf-row">' +
            '<button type="submit" class="pf-btn">记下来</button>' +
            '<button type="button" class="pf-btn ghost" id="pfCancelBtn">取消</button>' +
          '</div>' +
        '</form>';
      formWrap.querySelector('#pfCancelBtn').addEventListener('click', function () { formWrap.innerHTML = ''; });
      formWrap.querySelector('#pfForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var category = formWrap.querySelector('#pfFCat').value;
        var value = formWrap.querySelector('#pfFVal').value.trim();
        if (!value) { window.GG.showNotice('先写上内容再记下来哦。'); return; }
        window.GG.apiFetch('/api/preferences', {
          method: 'POST',
          body: JSON.stringify({ category: category, value: value, confirmed: 1, source: 'manual' })
        })
          .then(function (res) {
            if (!res.ok) return apiErr(res, '保存失败');
            return res.json();
          })
          .then(function (d) {
            var saved = (d && d.preference) || d;
            if (saved && saved.id) state.confirmed.push(saved);
            else state.confirmed.push({ id: Date.now(), category: category, value: value, confirmed: 1, source: 'manual' });
            formWrap.innerHTML = '';
            window.GG.say('记下来啦，宝宝的喜好乖乖都放在心上～', '', 'happy');
            renderConfirmed();
          })
          .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
      });
    }

    /* 从最近的真实聊天记录里找喜好：只拼用户自己说过的话，交给后端提取。 */
    function extractFromChat() {
      var btn = root.querySelector('#pfExtractBtn');
      btn.disabled = true;
      btn.textContent = '正在翻聊天记录…';
      window.GG.apiFetch('/api/history?limit=30')
        .then(function (res) {
          if (!res.ok) return apiErr(res, '聊天记录拉不到');
          return res.json();
        })
        .then(function (d) {
          var msgs = asList(d.messages || d);
          var userText = msgs
            .filter(function (m) { return m.role === 'user' && m.content; })
            .map(function (m) { return m.content; })
            .join('\n');
          if (!userText.trim()) {
            btn.disabled = false;
            btn.textContent = '🔍 从最近聊天里找找喜好';
            window.GG.showNotice('最近没有聊天记录，乖乖没东西可找。先跟乖乖聊聊天，告诉我你喜欢什么吧。');
            return null;
          }
          return window.GG.apiFetch('/api/preferences/extract', {
            method: 'POST',
            body: JSON.stringify({ text: userText })
          });
        })
        .then(function (res) {
          if (res === null) return null;
          if (!res.ok) return apiErr(res, '提取失败');
          return res.json();
        })
        .then(function (d) {
          btn.disabled = false;
          btn.textContent = '🔍 从最近聊天里找找喜好';
          if (!d) return;
          var cands = asList(d);
          var known = {};
          state.confirmed.forEach(function (p) { known[p.category + '|' + p.value] = true; });
          state.pending.forEach(function (p) { known[p.category + '|' + p.value] = true; });
          var fresh = cands.filter(function (c) { return c && c.category && c.value && !known[c.category + '|' + c.value]; });
          if (!fresh.length) {
            window.GG.showNotice('翻了一遍，没发现新的喜好。宝宝有新喜欢的东西，直接告诉乖乖就好～');
            return;
          }
          fresh.forEach(function (c) {
            state.pending.push({ category: c.category, value: c.value, confirmed: 0, source: 'ai' });
          });
          renderPending();
          window.GG.say('乖乖从聊天里听到 ' + fresh.length + ' 个可能的新喜好，宝宝看一看，喜欢的就点确认～', '', 'happy');
        })
        .catch(function (err) {
          btn.disabled = false;
          btn.textContent = '🔍 从最近聊天里找找喜好';
          window.GG.showNotice(err.message + '，再试一次吧。');
        });
    }

    function load() {
      window.GG.apiFetch('/api/preferences')
        .then(function (res) {
          if (!res.ok) return apiErr(res, '喜好档案拉不到');
          return res.json();
        })
        .then(function (d) {
          state.confirmed = asList(d).filter(function (p) { return p.confirmed; });
          var unconfirmed = asList(d).filter(function (p) { return !p.confirmed; });
          if (unconfirmed.length) {
            state.pending = state.pending.concat(unconfirmed.filter(function (p) {
              return !state.pending.some(function (x) { return x.id === p.id; });
            }));
          }
          renderConfirmed();
          renderPending();
        })
        .catch(function (err) {
          listEl.innerHTML = '<p class="pf-empty">喜好档案暂时拉不到：' + esc(err.message) + '。检查一下网络，刷新页面再试吧。</p>';
        });
      window.GG.apiFetch('/api/preferences/pending')
        .then(function (res) { return res.ok ? res.json() : []; })
        .then(function (d) {
          var list = asList(d);
          list.forEach(function (p) {
            if (!state.pending.some(function (x) { return x.id === p.id; })) state.pending.push(p);
          });
          renderPending();
        })
        .catch(function () {});
    }

    root.querySelector('#pfAddBtn').addEventListener('click', openAddForm);
    root.querySelector('#pfExtractBtn').addEventListener('click', extractFromChat);
    load();
  }
})();
