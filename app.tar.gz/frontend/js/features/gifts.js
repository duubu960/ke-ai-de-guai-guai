/* 可爱的乖乖 — 礼物推荐（Phase 3）
 * 渲染到 #surprise-gifts。GET /api/gifts/recommend 取 6 条推荐（名称/理由/场景/
 * 预算区间标签），按场合芯片在本地过滤显示，不另外发请求；每条可收藏，
 * 收藏夹可查看、可删除。预算只是区间标签，不编具体价格、店铺、链接。
 * 明显不符合已确认喜好的不推——筛选逻辑在服务端，模块只渲染返回结果。 */
(function () {
  'use strict';

  // 注意：CHIPS 必须在 boot() 之前赋值，因为 init() 会同步调用 renderChips()。
  var CHIPS = ['全部', '生日', '纪念日', '日常', '节日', '手工', '低预算'];

  function boot() {
    if (!window.GG || !window.GG.apiFetch) return;
    var root = document.getElementById('surprise-gifts');
    if (!root) return;
    init(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  function injectStyle() {
    if (document.querySelector('style[data-feature="gifts"]')) return;
    var st = document.createElement('style');
    st.setAttribute('data-feature', 'gifts');
    st.textContent =
      '.gf-card{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:0 8px 24px rgba(255,105,180,.12);padding:16px 14px;margin-bottom:12px}' +
      '.gf-card h3{margin:0 0 4px;font-size:17px;color:var(--ink)}' +
      '.gf-sub{margin:0 0 12px;font-size:12.5px;color:var(--muted);line-height:1.5}' +
      '.gf-chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}' +
      '.gf-chip{border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;padding:8px 14px;font-size:13.5px;font-weight:800;cursor:pointer;min-height:44px}' +
      '.gf-chip.active{background:var(--pink-pale);border-color:var(--pink);color:var(--accent-deep)}' +
      '.gf-item{background:var(--card2);border:1px solid var(--line);border-radius:18px;padding:12px;margin-bottom:8px}' +
      '.gf-name{font-size:15px;font-weight:800;color:var(--ink);line-height:1.4}' +
      '.gf-reason{font-size:13.5px;color:var(--ink);line-height:1.6;margin-top:4px}' +
      '.gf-tags{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}' +
      '.gf-tag{background:var(--pink-pale);color:var(--accent-deep);border-radius:999px;padding:3px 9px;font-size:12px;font-weight:800}' +
      '.gf-tag.budget{background:#FFF3C4;color:#7A5A00}' +
      '.gf-fav{margin-top:10px;width:100%;min-height:44px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;font-size:13.5px;font-weight:800;cursor:pointer}' +
      '.gf-fav.faved{background:var(--pink-pale);border-color:var(--pink);color:var(--accent-deep)}' +
      '.gf-fav:disabled{opacity:.6;cursor:default}' +
      '.gf-favlist{margin-top:14px;border-top:1px dashed var(--line);padding-top:12px}' +
      '.gf-favlist h4{margin:0 0 8px;font-size:15px;color:var(--ink)}' +
      '.gf-fav-item{display:flex;align-items:center;gap:8px;background:var(--card);border:1px solid var(--line);border-radius:16px;padding:10px 12px;margin-bottom:8px}' +
      '.gf-fav-body{flex:1;min-width:0}' +
      '.gf-fav-name{font-size:14px;font-weight:800;color:var(--ink)}' +
      '.gf-fav-meta{font-size:12px;color:var(--muted);margin-top:2px}' +
      '.gf-del{flex:0 0 auto;border:none;background:transparent;font-size:16px;cursor:pointer;min-width:44px;min-height:44px;color:var(--muted)}' +
      '.gf-empty{font-size:13.5px;color:var(--muted);line-height:1.6}' +
      '.gf-err{font-size:13px;color:var(--muted);line-height:1.6}';
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function asList(d) {
    if (Array.isArray(d)) return d;
    if (d && Array.isArray(d.items)) return d.items;
    if (d && Array.isArray(d.gifts)) return d.gifts;
    if (d && Array.isArray(d.recommendations)) return d.recommendations;
    if (d && Array.isArray(d.favorites)) return d.favorites;
    return [];
  }

  function init(root) {
    injectStyle();
    var state = { all: [], filter: '全部', favorites: [], favNames: {} };

    root.innerHTML =
      '<div class="gf-card">' +
        '<h3>🎀 给宝宝的礼物推荐</h3>' +
        '<p class="gf-sub">乖乖按宝宝的喜好、快到的纪念日和心愿清单挑的。预算只是大概的区间，喜欢就先收进收藏夹，买不买宝宝说了算～</p>' +
        '<div class="gf-chips" id="gfChips"></div>' +
        '<div id="gfList"><p class="gf-empty">乖乖正在挑礼物…</p></div>' +
        '<div class="gf-favlist"><h4>⭐ 我的礼物收藏夹</h4><div id="gfFavList"><p class="gf-empty">正在翻收藏夹…</p></div></div>' +
      '</div>';

    var chipsEl = root.querySelector('#gfChips');
    var listEl = root.querySelector('#gfList');
    var favListEl = root.querySelector('#gfFavList');

    function apiErr(res, fallback) {
      return res.json().catch(function () { return {}; }).then(function (d) {
        throw new Error((d && d.detail) || (d && d.error) || fallback);
      });
    }

    function matchesFilter(g) {
      var f = state.filter;
      if (f === '全部') return true;
      var hay = [g.occasion || '', g.name || '', g.reason || ''].join(' ');
      if (f === '低预算') return /^(50|100)元以内/.test(g.budget || '') || (g.budget || '').indexOf('元以内') > -1 && /50|100/.test(g.budget || '');
      if (f === '手工') return hay.indexOf('手工') > -1 || hay.indexOf('DIY') > -1;
      return (g.occasion || '').indexOf(f) > -1;
    }

    function renderChips() {
      chipsEl.innerHTML = '';
      CHIPS.forEach(function (c) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'gf-chip' + (state.filter === c ? ' active' : '');
        b.textContent = c;
        b.addEventListener('click', function () {
          state.filter = c;
          renderChips();
          renderList();
        });
        chipsEl.appendChild(b);
      });
    }

    function renderList() {
      var shown = state.all.filter(matchesFilter);
      if (!state.all.length) {
        listEl.innerHTML = '<p class="gf-empty">这次没有合适的推荐。宝宝先在「我的」里多告诉乖乖一点喜好，乖乖再重新挑～</p>';
        return;
      }
      if (!shown.length) {
        listEl.innerHTML = '<p class="gf-empty">这个场合暂时没有合适的推荐，换个场合看看，或者看看全部。</p>';
        return;
      }
      listEl.innerHTML = '';
      shown.forEach(function (g) {
        var faved = !!state.favNames[g.name];
        var el = document.createElement('div');
        el.className = 'gf-item';
        el.innerHTML =
          '<div class="gf-name">🎁 ' + esc(g.name) + '</div>' +
          '<div class="gf-reason">' + esc(g.reason || '') + '</div>' +
          '<div class="gf-tags">' +
            '<span class="gf-tag">' + esc(g.occasion || '日常') + '</span>' +
            (g.budget ? '<span class="gf-tag budget">预算 ' + esc(g.budget) + '</span>' : '') +
          '</div>' +
          '<button type="button" class="gf-fav' + (faved ? ' faved' : '') + '">' + (faved ? '⭐ 已收藏' : '☆ 收藏这份礼物') + '</button>';
        var favBtn = el.querySelector('.gf-fav');
        if (!faved) {
          favBtn.addEventListener('click', function () { favoriteGift(g, favBtn); });
        }
        listEl.appendChild(el);
      });
    }

    function favoriteGift(g, btn) {
      btn.disabled = true;
      btn.textContent = '正在收藏…';
      window.GG.apiFetch('/api/gifts/favorite', {
        method: 'POST',
        body: JSON.stringify({ name: g.name, reason: g.reason || '', occasion: g.occasion || '日常', budget: g.budget || '' })
      })
        .then(function (res) {
          if (!res.ok) return apiErr(res, '收藏失败');
          return res.json();
        })
        .then(function (d) {
          var saved = (d && d.favorite) || d;
          if (saved && saved.id) state.favorites.unshift(saved);
          else state.favorites.unshift({ id: Date.now(), name: g.name, reason: g.reason || '', occasion: g.occasion || '日常', budget: g.budget || '' });
          state.favNames[g.name] = true;
          window.GG.say('「' + g.name + '」收进收藏夹啦，宝宝想买的时候再翻出来看～', '', 'happy');
          window.GG.logEvent('gift_favorite', g.name);
          renderList();
          renderFavorites();
        })
        .catch(function (err) {
          btn.disabled = false;
          btn.textContent = '☆ 收藏这份礼物';
          window.GG.showNotice(err.message + '，再点一次试试。');
        });
    }

    function renderFavorites() {
      if (!state.favorites.length) {
        favListEl.innerHTML = '<p class="gf-empty">收藏夹还是空的，看到喜欢的礼物就点「收藏」，乖乖帮宝宝存着。</p>';
        return;
      }
      favListEl.innerHTML = '';
      state.favorites.forEach(function (f) {
        var el = document.createElement('div');
        el.className = 'gf-fav-item';
        el.innerHTML =
          '<div class="gf-fav-body">' +
            '<div class="gf-fav-name">🎁 ' + esc(f.name) + '</div>' +
            '<div class="gf-fav-meta">' + esc(f.occasion || '日常') + (f.budget ? ' · 预算 ' + esc(f.budget) : '') + '</div>' +
          '</div>' +
          '<button type="button" class="gf-del" aria-label="从收藏夹删除">🗑</button>';
        el.querySelector('.gf-del').addEventListener('click', function () {
          window.GG.apiFetch('/api/gifts/favorites/' + f.id, { method: 'DELETE' })
            .then(function (res) {
              if (!res.ok) return apiErr(res, '删除失败');
              return res.json().catch(function () { return {}; });
            })
            .then(function () {
              state.favorites = state.favorites.filter(function (x) { return x.id !== f.id; });
              delete state.favNames[f.name];
              renderList();
              renderFavorites();
            })
            .catch(function (err) { window.GG.showNotice(err.message + '，再试一次吧。'); });
        });
        favListEl.appendChild(el);
      });
    }

    function load() {
      window.GG.apiFetch('/api/gifts/recommend')
        .then(function (res) {
          if (!res.ok) return apiErr(res, '礼物推荐拉不到');
          return res.json();
        })
        .then(function (d) {
          state.all = asList(d);
          renderChips();
          renderList();
        })
        .catch(function (err) {
          listEl.innerHTML = '<p class="gf-err">礼物推荐暂时拉不到：' + esc(err.message) + '。检查一下网络，刷新页面再试吧。</p>';
        });
      window.GG.apiFetch('/api/gifts/favorites')
        .then(function (res) { return res.ok ? res.json() : []; })
        .then(function (d) {
          state.favorites = asList(d);
          state.favorites.forEach(function (f) { state.favNames[f.name] = true; });
          renderFavorites();
          if (state.all.length) renderList();
        })
        .catch(function () {
          favListEl.innerHTML = '<p class="gf-empty">收藏夹暂时拉不到，等网络好一点再来翻吧。</p>';
        });
    }

    renderChips();
    load();
  }
})();
