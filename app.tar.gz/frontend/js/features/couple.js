/* 可爱的乖乖 — 情侣绑定（v2.2.0）
 * 渲染到 #me-couple。两个人绑在一起之后，回忆、信件、心愿、聊天记录
 * 两个人都能看到；金币、保险箱、照片不共享；解除后共享内容留在发起方名下。
 * 接口（走 window.GG.apiFetch）：GET /api/couple/status，POST /api/couple/create，
 * POST /api/couple/join {code}，POST /api/couple/unbind。 */
(function () {
  'use strict';

  function boot() {
    if (!window.GG || !window.GG.apiFetch) return;
    var root = document.getElementById('me-couple');
    if (!root) return;
    init(root);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  function injectStyle() {
    if (document.querySelector('style[data-feature="couple"]')) return;
    var st = document.createElement('style');
    st.setAttribute('data-feature', 'couple');
    st.textContent =
      '.cp-card{background:var(--card);border:1px solid var(--line);border-radius:24px;box-shadow:0 8px 24px rgba(255,105,180,.12);padding:16px 14px;margin-bottom:12px}' +
      '.cp-card h3{margin:0 0 4px;font-size:17px;color:var(--ink)}' +
      '.cp-sub{margin:0 0 12px;font-size:12.5px;color:var(--muted);line-height:1.5}' +
      '.cp-empty{font-size:13.5px;color:var(--muted);line-height:1.6}' +
      '.cp-row{display:flex;gap:8px;margin-top:12px}' +
      '.cp-btn{flex:1;min-height:44px;border:none;border-radius:999px;background:var(--accent);color:#fff;font-weight:800;font-size:14px;cursor:pointer;box-shadow:0 6px 14px rgba(255,105,180,.28);padding:8px 12px}' +
      '.cp-btn.ghost{flex:0 0 auto;background:var(--card);border:1.5px solid var(--line);color:var(--ink);box-shadow:none}' +
      '.cp-btn:disabled{opacity:.6;cursor:default}' +
      '.cp-input{flex:1;min-width:0;box-sizing:border-box;border:1.5px solid var(--line);border-radius:12px;padding:10px;font-size:15px;letter-spacing:4px;text-align:center;background:var(--card);color:var(--ink);font-family:inherit}' +
      '.cp-input::placeholder{letter-spacing:0;font-size:13.5px}' +
      '.cp-codebox{background:var(--card2);border:1px dashed var(--pink);border-radius:18px;padding:14px 12px;margin-top:12px;text-align:center}' +
      '.cp-code-label{font-size:12.5px;font-weight:800;color:var(--muted)}' +
      '.cp-code{font-size:36px;font-weight:800;letter-spacing:12px;color:var(--accent-deep);margin:6px 0 4px;padding-left:12px}' +
      '.cp-hint{margin:0;font-size:12.5px;color:var(--muted);line-height:1.6}' +
      '.cp-paired{font-size:18px;font-weight:800;color:var(--accent-deep);margin:4px 0}' +
      '.cp-role{font-size:13.5px;color:var(--muted);line-height:1.6;margin:0 0 4px}' +
      '.cp-divider{text-align:center;font-size:12.5px;color:var(--muted);margin:14px 0 2px}' +
      '.cp-note{margin:14px 0 0;font-size:12px;color:var(--muted);line-height:1.7}';
    document.head.appendChild(st);
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function init(root) {
    injectStyle();
    var status = null; // {paired, code, role}
    var myCode = null; // 刚生成的码：只在当前页面内暂存，刷新后要重新生成

    root.innerHTML =
      '<div class="cp-card">' +
        '<h3>💞 情侣绑定</h3>' +
        '<p class="cp-sub">把两部手机绑在一起，回忆、信件、心愿、聊天记录两个人都能看到。</p>' +
        '<div id="cpBody"><p class="cp-empty">正在看看你们是不是已经绑在一起了…</p></div>' +
        '<p class="cp-note">绑完回忆、信件、心愿、聊天记录两个人都能看到；金币、保险箱、照片不共享；解除后，共享内容留在发起方的手机上。</p>' +
      '</div>';

    var bodyEl = root.querySelector('#cpBody');

    function render() {
      var html = '';
      if (status && status.paired) {
        var roleText = status.role === 'b'
          ? '你加入了对方的绑定'
          : (status.joined ? '对方已加入你的绑定' : '等对方加入：把绑定码发给她，她在她的手机上输入就好了');
        html =
          '<p class="cp-paired">已绑定 ✓</p>' +
          '<p class="cp-role">' + roleText + '</p>' +
          (status.code ?
            '<div class="cp-codebox">' +
              '<div class="cp-code-label">你们的绑定码</div>' +
              '<div class="cp-code">' + esc(status.code) + '</div>' +
            '</div>' : '') +
          '<div class="cp-row"><button type="button" class="cp-btn ghost" id="cpUnbindBtn">解除绑定</button></div>';
      } else {
        html =
          '<div class="cp-row"><button type="button" class="cp-btn" id="cpCreateBtn">＋ 生成绑定码</button></div>' +
          (myCode ?
            '<div class="cp-codebox">' +
              '<div class="cp-code-label">你的绑定码</div>' +
              '<div class="cp-code">' + esc(myCode) + '</div>' +
              '<p class="cp-hint">让对方在她的手机上打开「我的」页，输入这个码。关掉页面就看不到了，先把码发给对方。</p>' +
            '</div>' : '') +
          '<div class="cp-divider">或者</div>' +
          '<div class="cp-row">' +
            '<input id="cpJoinInput" class="cp-input" inputmode="numeric" maxlength="6" autocomplete="off" placeholder="输入对方的 6 位绑定码" />' +
            '<button type="button" class="cp-btn ghost" id="cpJoinBtn">输入绑定码加入</button>' +
          '</div>';
      }
      bodyEl.innerHTML = html;
      wire();
    }

    function wire() {
      var createBtn = bodyEl.querySelector('#cpCreateBtn');
      if (createBtn) createBtn.addEventListener('click', createCode);
      var joinBtn = bodyEl.querySelector('#cpJoinBtn');
      if (joinBtn) joinBtn.addEventListener('click', joinCode);
      var joinInput = bodyEl.querySelector('#cpJoinInput');
      if (joinInput) {
        joinInput.addEventListener('input', function () {
          joinInput.value = joinInput.value.replace(/\D/g, '').slice(0, 6);
        });
        joinInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') joinCode();
        });
      }
      var unbindBtn = bodyEl.querySelector('#cpUnbindBtn');
      if (unbindBtn) unbindBtn.addEventListener('click', unbind);
    }

    function loadStatus() {
      window.GG.apiFetch('/api/couple/status')
        .then(function (res) {
          if (!res.ok) throw new Error('绑定状态拉不到');
          return res.json();
        })
        .then(function (d) {
          status = d || { paired: false };
          render();
        })
        .catch(function (err) {
          bodyEl.innerHTML = '<p class="cp-empty">绑定状态暂时拉不到：' + esc(err.message) + '。检查一下网络，刷新页面再试吧。</p>';
        });
    }

    function createCode() {
      var btn = bodyEl.querySelector('#cpCreateBtn');
      if (btn) { btn.disabled = true; btn.textContent = '正在生成…'; }
      window.GG.apiFetch('/api/couple/create', { method: 'POST' })
        .then(function (res) {
          if (!res.ok) throw new Error('生成失败');
          return res.json();
        })
        .then(function (d) {
          myCode = (d && d.code) || '';
          if (!myCode) throw new Error('生成失败');
          render();
        })
        .catch(function (err) {
          window.GG.showNotice(err.message + '，再点一次试试。');
          render();
        });
    }

    function joinCode() {
      var input = bodyEl.querySelector('#cpJoinInput');
      var btn = bodyEl.querySelector('#cpJoinBtn');
      var code = input ? input.value.trim() : '';
      if (!/^\d{6}$/.test(code)) {
        window.GG.showNotice('绑定码是 6 位数字，再检查一下有没有输错。');
        return;
      }
      if (btn) { btn.disabled = true; btn.textContent = '正在加入…'; }
      window.GG.apiFetch('/api/couple/join', { method: 'POST', body: JSON.stringify({ code: code }) })
        .then(function (res) {
          if (res.ok) return res.json();
          if (res.status === 404) throw new Error('这个绑定码不存在，是不是输错了？');
          if (res.status === 400) throw new Error('不能加入自己发起的绑定——这串码是你自己生成的哦。');
          if (res.status === 409) throw new Error('这个码已经有人加入了，或者你已经在别的绑定里了。');
          throw new Error('加入失败');
        })
        .then(function () {
          myCode = null;
          loadStatus();
        })
        .catch(function (err) {
          window.GG.showNotice(err.message + '，再试一次吧。');
          render();
          var again = bodyEl.querySelector('#cpJoinInput');
          if (again) again.value = code;
        });
    }

    function unbind() {
      if (!window.confirm('确定解除绑定吗？解除后，共享的内容会留在发起方的手机上，这边就看不到了。')) return;
      var btn = bodyEl.querySelector('#cpUnbindBtn');
      if (btn) { btn.disabled = true; btn.textContent = '正在解除…'; }
      window.GG.apiFetch('/api/couple/unbind', { method: 'POST' })
        .then(function (res) {
          if (!res.ok) throw new Error('解除失败');
          return res.json().catch(function () { return {}; });
        })
        .then(function () {
          myCode = null;
          status = { paired: false };
          loadStatus();
        })
        .catch(function (err) {
          window.GG.showNotice(err.message + '，再试一次吧。');
          render();
        });
    }

    loadStatus();
  }
})();
