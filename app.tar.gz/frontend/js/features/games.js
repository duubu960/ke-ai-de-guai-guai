// 小游戏乐园（Phase 3）：渲染到 #games-root。
// 接草莓仍在首页，本模块只放一个入口按钮，不重建它。
// 成绩走 POST /api/games/record；服务器每天每游戏最多 30 金币，超限如实提示。
(function(){
  function ready(fn){ if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn(); }

  var GAME_NAMES = {
    guess: '猜数字', memory: '记忆翻牌', wheel: '幸运转盘', reaction: '反应力挑战',
    quiz: '默契小考验', rps: '石头剪刀布', luck: '每日幸运测试', feed: '小猪喂养'
  };

  ready(function(){
    if(!window.GG) return;
    var root = document.getElementById('games-root');
    if(!root) return;
    injectStyle();

    var statusEl = document.createElement('p');
    statusEl.className = 'gm-status';
    statusEl.setAttribute('aria-live', 'polite');
    statusEl.hidden = true;

    root.innerHTML =
      '<div class="gm-intro card">' +
        '<p class="gm-intro-text">接草莓小游戏还在首页等你，那是乖乖最爱玩的。下面是新来的 8 个小游戏，玩完有金币奖励，每天每个游戏最多拿 30 金币。</p>' +
        '<button type="button" class="play-btn gm-strawberry" data-go-strawberry>🍓 去首页玩接草莓</button>' +
        '<p class="gm-coins-line" data-coins-line></p>' +
      '</div>' +
      '<div class="card gm-summary" data-summary><h3 class="gm-h">🏆 我的成绩</h3><p class="gm-empty">还没有游戏记录，玩一局试试吧。</p></div>' +
      '<div class="card gm-records" data-records><h3 class="gm-h">📜 最近玩过</h3><p class="gm-empty">还没有记录。</p></div>' +
      '<div class="gm-list" data-list></div>';
    root.insertBefore(statusEl, root.firstChild);
    updateCoinsLine();

    root.querySelector('[data-go-strawberry]').addEventListener('click', function(){
      if(window.GGNav) window.GGNav.show('home');
      setTimeout(function(){
        var t = document.getElementById('gameToggle');
        if(t && t.getAttribute('aria-expanded') !== 'true') t.click();
        var gs = document.getElementById('gameSheet');
        if(gs) gs.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 120);
    });

    buildGames(root.querySelector('[data-list]'));
    refreshSummary(root);
    refreshRecords(root);

    function updateCoinsLine(){
      var line = root.querySelector('[data-coins-line]');
      if(line) line.textContent = '现在有 ' + (window.GG.coins || 0) + ' 金币 · 换装和游戏奖励都靠它';
    }

    function showStatus(msg){
      statusEl.hidden = false;
      statusEl.textContent = msg;
    }

    // ---- 后端：记一次成绩 ----
    function recordGame(game, score, coins, done){
      if(!coins && !score){ if(done) done(null); return; }
      window.GG.apiFetch('/api/games/record', {
        method: 'POST',
        body: JSON.stringify({ game: game, score: score || 0, coins: coins || 0 })
      }).then(function(res){ return res.json().catch(function(){ return {}; }).then(function(d){ return { status: res.status, d: d }; }); })
      .then(function(r){
        var d = r.d || {};
        if(d.error === 'daily_coin_cap'){
          showStatus('今天这个游戏的金币拿满啦（每天每个游戏最多 30 金币），明天再来，乖乖陪你');
          if(done) done(d);
        }else if(r.status === 200 || r.status === 201){ // 后端新建成功返回 201。
          var awarded = (typeof d.awarded === 'number') ? d.awarded : coins;
          if(awarded > 0) showStatus('这局奖励 +' + awarded + ' 金币，乖乖替你收好啦');
          try{ window.GG.loadStateFromServer().then(function(){ updateCoinsLine(); }).catch(function(){}); }catch(e){}
          try{ window.GG.logEvent('game', game); }catch(e){}
          refreshSummary(root); refreshRecords(root);
          if(done) done(d);
        }else{
          showStatus('成绩没记上（' + (d.error || '服务器开小差了') + '），游戏本身不受影响');
          if(done) done(d);
        }
      }).catch(function(){
        showStatus('成绩没记上（连不上后端），游戏本身不受影响');
        if(done) done(null);
      });
    }

    function refreshSummary(rootEl){
      var box = rootEl.querySelector('[data-summary]');
      window.GG.apiFetch('/api/games/summary').then(function(res){
        if(!res.ok) throw new Error('http ' + res.status);
        return res.json();
      }).then(function(d){
        var games = d && (d.games || d.summary || d);
        var html = '<h3 class="gm-h">🏆 我的成绩</h3>';
        var any = false;
        if(games && typeof games === 'object'){
          var keys = Object.keys(games);
          for(var i = 0; i < keys.length; i++){
            var g = games[keys[i]];
            if(!g) continue;
            var best = (typeof g === 'object') ? (g.best != null ? g.best : g.bestScore) : g;
            var plays = (typeof g === 'object') ? (g.plays != null ? g.plays : g.count) : null;
            if(best == null && plays == null) continue;
            any = true;
            html += '<p class="gm-sum-line"><span>' + esc(GAME_NAMES[keys[i]] || keys[i]) + '</span><span>最佳 ' + esc(best == null ? '—' : best) + (plays != null ? ' · 玩过 ' + plays + ' 次' : '') + '</span></p>';
          }
        }
        if(d && d.totalCoins != null){
          any = true;
          html += '<p class="gm-sum-line"><span>游戏一共赚了</span><span>' + esc(d.totalCoins) + ' 金币</span></p>';
        }
        box.innerHTML = any ? html : html + '<p class="gm-empty">还没有游戏记录，玩一局试试吧。</p>';
      }).catch(function(){
        box.innerHTML = '<h3 class="gm-h">🏆 我的成绩</h3><p class="gm-empty">成绩暂时取不到，检查一下后端连接，游戏照样能玩。</p>';
      });
    }

    function refreshRecords(rootEl){
      var box = rootEl.querySelector('[data-records]');
      window.GG.apiFetch('/api/games/records?limit=10').then(function(res){
        if(!res.ok) throw new Error('http ' + res.status);
        return res.json();
      }).then(function(d){
        var list = (d && d.records) || (Array.isArray(d) ? d : []);
        if(!list.length){
          box.innerHTML = '<h3 class="gm-h">📜 最近玩过</h3><p class="gm-empty">还没有记录。</p>';
          return;
        }
        var html = '<h3 class="gm-h">📜 最近玩过</h3>';
        for(var i = 0; i < list.length; i++){
          var r = list[i] || {};
          var when = r.played_at ? new Date(r.played_at).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
          html += '<p class="gm-sum-line"><span>' + esc(GAME_NAMES[r.game] || r.game || '') + ' · ' + esc(r.score != null ? r.score : '') + ' 分</span><span>' + (r.coins ? '+' + esc(r.coins) + ' 金币' : '') + ' ' + esc(when) + '</span></p>';
        }
        box.innerHTML = html;
      }).catch(function(){
        box.innerHTML = '<h3 class="gm-h">📜 最近玩过</h3><p class="gm-empty">记录暂时取不到，游戏照样能玩。</p>';
      });
    }

    // ---- 8 个游戏卡片 ----
    function gameCard(key, title, sub, buildBody){
      var card = document.createElement('div');
      card.className = 'card gm-card';
      card.innerHTML =
        '<div class="gm-head"><b>' + esc(title) + '</b><span class="gm-sub">' + esc(sub) + '</span></div>' +
        '<div class="gm-body" hidden></div>' +
        '<button type="button" class="play-btn gm-toggle">开始玩</button>';
      var body = card.querySelector('.gm-body');
      var toggle = card.querySelector('.gm-toggle');
      var built = false;
      toggle.addEventListener('click', function(){
        var open = body.hidden;
        body.hidden = !open;
        toggle.textContent = open ? '收起来' : '开始玩';
        if(open && !built){ built = true; buildBody(body, card); }
      });
      return card;
    }
    function resultLine(body){
      var p = document.createElement('p');
      p.className = 'gm-result';
      p.setAttribute('aria-live', 'polite');
      body.appendChild(p);
      return p;
    }

    function buildGames(list){
      // ① 猜数字
      list.appendChild(gameCard('guess', '🔢 猜数字', '1–100，7 次机会，猜中 +10 金币', function(body){
        var target = 1 + Math.floor(Math.random() * 100);
        var tries = 0, over = false;
        var res = resultLine(body);
        body.insertAdjacentHTML('beforeend',
          '<p class="gm-p">乖乖心里想了一个 1 到 100 的数字，你来猜猜。</p>' +
          '<div class="gm-row"><input type="number" class="gm-input" data-guess-input min="1" max="100" inputmode="numeric" placeholder="输入 1–100" />' +
          '<button type="button" class="play-btn" data-guess-go>猜一下</button></div>' +
          '<p class="gm-tries" data-guess-left>还剩 7 次机会</p>' +
          '<button type="button" class="btn-ghost gm-restart" data-guess-new hidden>再来一局</button>');
        var input = body.querySelector('[data-guess-input]');
        var leftEl = body.querySelector('[data-guess-left]');
        var newBtn = body.querySelector('[data-guess-new]');
        function finish(win){
          over = true;
          newBtn.hidden = false;
          if(win){
            var left = 7 - tries;
            res.textContent = '猜中啦！这个数字就是 ' + target + '，你用了 ' + tries + ' 次。';
            recordGame('guess', 10 + left * 2, 10);
          }else{
            res.textContent = '7 次用完啦，答案是 ' + target + '。再试一次？';
            recordGame('guess', 0, 0);
          }
        }
        body.querySelector('[data-guess-go]').addEventListener('click', function(){
          if(over) return;
          var v = parseInt(input.value, 10);
          if(isNaN(v) || v < 1 || v > 100){ res.textContent = '先输入 1 到 100 之间的数字哦。'; return; }
          tries++;
          if(v === target){ finish(true); return; }
          if(tries >= 7){ leftEl.textContent = '机会用完啦'; finish(false); return; }
          leftEl.textContent = '还剩 ' + (7 - tries) + ' 次机会';
          res.textContent = v < target ? v + ' 小了，再大一点。' : v + ' 大了，再小一点。';
          input.value = ''; input.focus();
        });
        newBtn.addEventListener('click', function(){
          target = 1 + Math.floor(Math.random() * 100);
          tries = 0; over = false;
          res.textContent = '';
          leftEl.textContent = '还剩 7 次机会';
          input.value = ''; newBtn.hidden = true;
        });
      }));

      // ② 记忆翻牌
      list.appendChild(gameCard('memory', '🃏 记忆翻牌', '8 对牌，翻得越少分越高', function(body){
        var faces = ['🐷', '🍓', '🌙', '⭐', '🎀', '🍰', '🐰', '🌸'];
        var res = resultLine(body);
        var grid = document.createElement('div');
        grid.className = 'gm-memory';
        body.appendChild(grid);
        var info = document.createElement('p');
        info.className = 'gm-p';
        body.appendChild(info);
        var again = document.createElement('button');
        again.type = 'button';
        again.className = 'btn-ghost gm-restart';
        again.textContent = '再玩一局';
        again.hidden = true;
        body.appendChild(again);
        var deck = [], open = [], lock = false, flips = 0, matched = 0, done = false;
        function start(){
          var arr = faces.concat(faces).slice();
          for(var i = arr.length - 1; i > 0; i--){
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
          }
          deck = arr; open = []; lock = false; flips = 0; matched = 0; done = false;
          grid.innerHTML = '';
          for(var k = 0; k < deck.length; k++){
            var c = document.createElement('button');
            c.type = 'button';
            c.className = 'gm-card-face';
            c.textContent = '？';
            c.setAttribute('data-idx', k);
            c.addEventListener('click', flip);
            grid.appendChild(c);
          }
          info.textContent = '翻了 0 次 · 配对 0/8';
          res.textContent = '';
          again.hidden = true;
        }
        function flip(){
          if(lock || done) return;
          var idx = parseInt(this.getAttribute('data-idx'), 10);
          if(this.classList.contains('open') || this.classList.contains('done')) return;
          this.classList.add('open');
          this.textContent = deck[idx];
          open.push(this);
          flips++;
          info.textContent = '翻了 ' + flips + ' 次 · 配对 ' + matched + '/8';
          if(open.length === 2){
            var a = open[0], b = open[1];
            var ai = parseInt(a.getAttribute('data-idx'), 10), bi = parseInt(b.getAttribute('data-idx'), 10);
            if(deck[ai] === deck[bi]){
              a.classList.add('done'); b.classList.add('done');
              open = [];
              matched++;
              info.textContent = '翻了 ' + flips + ' 次 · 配对 ' + matched + '/8';
              if(matched === 8){
                done = true;
                var score = Math.max(10, 120 - flips);
                res.textContent = '全部配对成功！一共翻了 ' + flips + ' 次，得 ' + score + ' 分。';
                recordGame('memory', score, 15);
                again.hidden = false;
              }
            }else{
              lock = true;
              setTimeout(function(){
                a.classList.remove('open'); b.classList.remove('open');
                a.textContent = '？'; b.textContent = '？';
                open = []; lock = false;
              }, 750);
            }
          }
        }
        again.addEventListener('click', start);
        start();
      }));

      // ③ 幸运转盘
      list.appendChild(gameCard('wheel', '🎡 幸运转盘', '转一转，看看今天的运气', function(body){
        var prizes = [
          { label: '5 金币', coins: 5 }, { label: '一个抱抱', coins: 0 },
          { label: '8 金币', coins: 8 }, { label: '一句情话', coins: 0 },
          { label: '10 金币', coins: 10 }, { label: '小纸条', coins: 0 },
          { label: '幸运星', coins: 0 }, { label: '再来一次', coins: 0 }
        ];
        var res = resultLine(body);
        var wrap = document.createElement('div');
        wrap.className = 'gm-wheel-wrap';
        wrap.innerHTML = '<div class="gm-pointer">▼</div><div class="gm-wheel" data-wheel></div>' +
          '<button type="button" class="play-btn" data-wheel-spin>转一下</button>';
        body.appendChild(wrap);
        var wheel = wrap.querySelector('[data-wheel]');
        var spinning = false, deg = 0;
        wheel.innerHTML = prizes.map(function(p, i){
          return '<span class="gm-wheel-label" style="--a:' + (i * 45) + 'deg">' + esc(p.label) + '</span>';
        }).join('');
        wrap.querySelector('[data-wheel-spin]').addEventListener('click', function(){
          if(spinning) return;
          spinning = true;
          res.textContent = '转呀转呀…';
          deg += 1800 + Math.floor(Math.random() * 360);
          wheel.style.transform = 'rotate(' + deg + 'deg)';
          setTimeout(function(){
            spinning = false;
            var final = ((deg % 360) + 360) % 360;
            var idx = Math.floor(((360 - final) % 360) / 45) % 8;
            var p = prizes[idx];
            if(p.coins > 0){
              res.textContent = '转到了「' + p.label + '」，金币已经记到账上啦。';
              recordGame('wheel', p.coins, p.coins);
            }else if(p.label === '再来一次'){
              res.textContent = '转到了「再来一次」，那就再转一次吧。';
              recordGame('wheel', 0, 0);
            }else{
              res.textContent = '转到了「' + p.label + '」，乖乖这就兑现：' +
                (p.label === '一个抱抱' ? '给你一个大大的拥抱 🤗' :
                 p.label === '一句情话' ? '宝宝，你笑起来的样子最好看。' :
                 p.label === '小纸条' ? '今天也要开开心心的，乖乖在呢。' : '今天会是幸运的一天 ✨');
              recordGame('wheel', 10, 0);
            }
          }, 3100);
        });
      }));

      // ④ 反应力挑战
      list.appendChild(gameCard('reaction', '⚡ 反应力挑战', '绿灯一亮马上点，快过 300 毫秒有奖励', function(body){
        var res = resultLine(body);
        var pad = document.createElement('button');
        pad.type = 'button';
        pad.className = 'gm-react-pad';
        pad.textContent = '点我开始';
        body.appendChild(pad);
        var hint = document.createElement('p');
        hint.className = 'gm-p';
        hint.textContent = '等方块变绿的瞬间点下去，别心急。';
        body.appendChild(hint);
        var state = 'idle', waitTimer = null, startTs = 0, done = false;
        pad.addEventListener('click', function(){
          if(state === 'idle'){
            state = 'waiting';
            pad.classList.add('waiting');
            pad.textContent = '等绿灯…';
            hint.textContent = '别点，等它变绿。';
            waitTimer = setTimeout(function(){
              state = 'ready';
              startTs = Date.now();
              pad.classList.remove('waiting');
              pad.classList.add('ready');
              pad.textContent = '点我！';
            }, 1500 + Math.random() * 2500);
          }else if(state === 'waiting'){
            clearTimeout(waitTimer);
            state = 'idle';
            pad.classList.remove('waiting');
            pad.textContent = '点我开始';
            res.textContent = '太心急啦，绿灯还没亮呢，再来一次。';
          }else if(state === 'ready'){
            var ms = Date.now() - startTs;
            state = 'idle';
            pad.classList.remove('ready');
            pad.textContent = '再来一次';
            var coins = ms < 300 ? 10 : (ms < 500 ? 5 : 2);
            res.textContent = '反应时间 ' + ms + ' 毫秒' + (ms < 300 ? '，好快！' : ms < 500 ? '，不错！' : '，慢慢来，下次更快。');
            recordGame('reaction', Math.max(1, 1000 - ms), coins);
          }
        });
      }));

      // ⑤ 默契小考验
      list.appendChild(gameCard('quiz', '💗 默契小考验', '5 道题，考考你们有多默契', function(body){
        var res = resultLine(body);
        var qEl = document.createElement('div');
        qEl.className = 'gm-quiz';
        body.appendChild(qEl);
        var questions = buildQuizQuestions();
        var qi = 0, correct = 0, answered = false;
        showQ();
        function buildQuizQuestions(){
          var mems = [];
          try{ mems = (window.GG.memories || []).filter(function(m){ return m && m.title; }); }catch(e){}
          if(mems.length){
            var picked = mems.slice(-5);
            return picked.map(function(m){
              var opts = shuffle([
                { t: m.title, ok: true },
                { t: '在月亮上吃火锅', ok: false },
                { t: '和小猪一起环游银河系', ok: false },
                { t: '在云朵上开派对', ok: false }
              ]);
              return { q: '下面哪一个，是你们真实的一起的回忆？', opts: opts };
            });
          }
          return shuffle([
            { q: '可爱的乖乖最爱吃什么？', opts: shuffle([{ t: '草莓', ok: true }, { t: '西瓜', ok: false }, { t: '胡萝卜', ok: false }, { t: '汉堡', ok: false }]) },
            { q: '乖乖有几副面孔轮着来？', opts: shuffle([{ t: '3 副', ok: true }, { t: '1 副', ok: false }, { t: '5 副', ok: false }, { t: '2 副', ok: false }]) },
            { q: '乖乖最喜欢被怎么对待？', opts: shuffle([{ t: '抱抱它', ok: true }, { t: '训它一顿', ok: false }, { t: '不理它', ok: false }, { t: '吓它一跳', ok: false }]) },
            { q: '乖乖睡觉前最想听什么？', opts: shuffle([{ t: '一句晚安', ok: true }, { t: '一道数学题', ok: false }, { t: '天气预报', ok: false }, { t: '新闻联播', ok: false }]) },
            { q: '可爱的乖乖是什么动物？', opts: shuffle([{ t: '小猪', ok: true }, { t: '小猫', ok: false }, { t: '小兔子', ok: false }, { t: '小狗', ok: false }]) }
          ]);
        }
        function shuffle(arr){
          var a = arr.slice();
          for(var i = a.length - 1; i > 0; i--){
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = a[i]; a[i] = a[j]; a[j] = tmp;
          }
          return a;
        }
        function showQ(){
          answered = false;
          if(qi >= questions.length){
            qEl.innerHTML = '<p class="gm-p">考完啦！你答对了 ' + correct + ' / ' + questions.length + ' 道' +
              (correct === questions.length ? '，满分默契！' : correct >= 3 ? '，很默契了！' : '，再去回忆页看看，回来就全对啦。') + '</p>' +
              '<button type="button" class="btn-ghost gm-restart" data-quiz-again>再考一次</button>';
            recordGame('quiz', correct * 20, correct * 2);
            qEl.querySelector('[data-quiz-again]').addEventListener('click', function(){
              qi = 0; correct = 0; questions = buildQuizQuestions(); showQ();
            });
            return;
          }
          var cur = questions[qi];
          var html = '<p class="gm-p">第 ' + (qi + 1) + ' / ' + questions.length + ' 题：' + esc(cur.q) + '</p>';
          for(var i = 0; i < cur.opts.length; i++){
            html += '<button type="button" class="play-btn gm-opt" data-opt="' + i + '">' + esc(cur.opts[i].t) + '</button>';
          }
          qEl.innerHTML = html;
          var btns = qEl.querySelectorAll('[data-opt]');
          for(var b = 0; b < btns.length; b++){
            btns[b].addEventListener('click', function(){
              if(answered) return;
              answered = true;
              var pick = parseInt(this.getAttribute('data-opt'), 10);
              var ok = cur.opts[pick].ok;
              if(ok){ correct++; this.classList.add('gm-right'); res.textContent = '答对啦 ✓'; }
              else{
                this.classList.add('gm-wrong');
                for(var k = 0; k < btns.length; k++){
                  if(cur.opts[parseInt(btns[k].getAttribute('data-opt'), 10)].ok) btns[k].classList.add('gm-right');
                }
                res.textContent = '这道答错了，没关系，下一道加油。';
              }
              setTimeout(function(){ qi++; showQ(); }, 1100);
            });
          }
        }
      }));

      // ⑥ 石头剪刀布
      list.appendChild(gameCard('rps', '✊ 石头剪刀布', '和乖乖对战，赢了 +5 金币', function(body){
        var res = resultLine(body);
        var tally = document.createElement('p');
        tally.className = 'gm-p';
        tally.textContent = '你 0 胜 · 乖乖 0 胜 · 0 平';
        body.appendChild(tally);
        var row = document.createElement('div');
        row.className = 'gm-row';
        row.innerHTML =
          '<button type="button" class="play-btn" data-rps="rock">✊ 石头</button>' +
          '<button type="button" class="play-btn" data-rps="scissors">✌️ 剪刀</button>' +
          '<button type="button" class="play-btn" data-rps="paper">✋ 布</button>';
        body.appendChild(row);
        var wins = 0, losses = 0, draws = 0;
        var names = { rock: '石头', scissors: '剪刀', paper: '布' };
        var beats = { rock: 'scissors', scissors: 'paper', paper: 'rock' };
        var btns = row.querySelectorAll('[data-rps]');
        for(var i = 0; i < btns.length; i++){
          btns[i].addEventListener('click', function(){
            var mine = this.getAttribute('data-rps');
            var pig = ['rock', 'scissors', 'paper'][Math.floor(Math.random() * 3)];
            var outcome;
            if(mine === pig) outcome = 'draw';
            else if(beats[mine] === pig) outcome = 'win';
            else outcome = 'lose';
            if(outcome === 'win'){
              wins++;
              res.textContent = '你出 ' + names[mine] + '，乖乖出 ' + names[pig] + '，你赢啦！';
              recordGame('rps', 100, 5);
            }else if(outcome === 'lose'){
              losses++;
              res.textContent = '你出 ' + names[mine] + '，乖乖出 ' + names[pig] + '，乖乖赢啦，再来一局？';
              recordGame('rps', 0, 0);
            }else{
              draws++;
              res.textContent = '都出 ' + names[mine] + '，平局！';
              recordGame('rps', 50, 0);
            }
            tally.textContent = '你 ' + wins + ' 胜 · 乖乖 ' + losses + ' 胜 · ' + draws + ' 平';
          });
        }
      }));

      // ⑦ 每日幸运测试
      list.appendChild(gameCard('luck', '🍀 每日幸运测试', '每天只能测一次，图个开心', function(body){
        var res = resultLine(body);
        var note = document.createElement('p');
        note.className = 'gm-p gm-note';
        note.textContent = '这就是个图开心的小游戏，不是预测，准不准都别当真哦。';
        body.appendChild(note);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'play-btn';
        btn.textContent = '测测今天的幸运';
        body.appendChild(btn);
        var today = new Date();
        var dateKey = today.getFullYear() + '-' + ('0' + (today.getMonth() + 1)).slice(-2) + '-' + ('0' + today.getDate()).slice(-2);
        var stored = null;
        try{ stored = JSON.parse(window.localStorage.getItem('gg_luck_v1') || 'null'); }catch(e){}
        if(stored && stored.date === dateKey){
          res.textContent = '今天已经测过啦：幸运分 ' + stored.score + '，' + stored.text;
          btn.disabled = true;
          btn.textContent = '明天再来测';
          return;
        }
        btn.addEventListener('click', function(){
          var seed = 0;
          for(var i = 0; i < dateKey.length; i++) seed += dateKey.charCodeAt(i) * (i + 3);
          var score = 60 + (seed * 7 % 40);
          var texts = [
            '今天适合吃点甜的，心情会跟着变好。',
            '出门记得带上好心情，乖乖在家里等你。',
            '今天的你，比昨天更可爱一点。',
            '适合给喜欢的人发一条消息，就现在。',
            '今天会有小惊喜，留意身边的细节。',
            '适合早点睡，乖乖陪你。'
          ];
          var text = texts[seed % texts.length];
          try{ window.localStorage.setItem('gg_luck_v1', JSON.stringify({ date: dateKey, score: score, text: text })); }catch(e){}
          res.textContent = '今日幸运分 ' + score + '，' + text;
          btn.disabled = true;
          btn.textContent = '明天再来测';
          recordGame('luck', score, 5);
        });
      }));

      // ⑧ 小猪喂养
      list.appendChild(gameCard('feed', '🍓 小猪喂养', '看看乖乖饿不饿，去喂它', function(body){
        var meters = {};
        try{ meters = window.GG.meters || {}; }catch(e){}
        var hunger = (typeof meters.hunger === 'number') ? meters.hunger : 72;
        var mood = (typeof meters.mood === 'number') ? meters.mood : 82;
        var energy = (typeof meters.energy === 'number') ? meters.energy : 76;
        body.innerHTML =
          '<p class="gm-p">乖乖现在的状态：</p>' +
          '<p class="gm-sum-line"><span>饱饱</span><span>' + hunger + ' / 100</span></p>' +
          '<p class="gm-sum-line"><span>心情</span><span>' + mood + ' / 100</span></p>' +
          '<p class="gm-sum-line"><span>精力</span><span>' + energy + ' / 100</span></p>' +
          '<p class="gm-p">' + (hunger < 40 ? '乖乖有点饿了，快去喂它一颗草莓吧。' : hunger < 75 ? '乖乖不算很饿，不过草莓它永远吃得下。' : '乖乖吃得饱饱的，心满意足。') + '</p>' +
          '<button type="button" class="play-btn" data-feed-go>🍓 去喂它</button>';
        body.querySelector('[data-feed-go]').addEventListener('click', function(){
          if(window.GGNav) window.GGNav.show('home');
          setTimeout(function(){
            var feedBtn = document.querySelector('.act[data-action="feed"]');
            if(feedBtn) feedBtn.click();
          }, 150);
        });
      }));
    }

    function esc(s){
      return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }

    function injectStyle(){
      if(document.querySelector('style[data-feature="games"]')) return;
      var st = document.createElement('style');
      st.setAttribute('data-feature', 'games');
      st.textContent =
        '.gm-status{background:var(--pink-pale);border:1.5px solid var(--pink);color:var(--ink);border-radius:16px;padding:10px 14px;font-size:13.5px;line-height:1.5;margin:0 0 12px;}' +
        '.gm-intro-text{margin:0 0 12px;color:var(--muted);font-size:14px;line-height:1.65;}' +
        '.gm-strawberry{width:100%;}' +
        '.gm-coins-line{margin:10px 0 0;font-size:13px;color:var(--muted);text-align:center;}' +
        '.gm-h{margin:0 0 8px;font-size:16px;}' +
        '.gm-summary,.gm-records{margin:0 0 12px;}' +
        '.gm-empty{color:var(--muted);font-size:13.5px;margin:0;}' +
        '.gm-sum-line{display:flex;justify-content:space-between;gap:10px;font-size:13.5px;margin:6px 0;color:var(--ink);}' +
        '.gm-sum-line span:last-child{color:var(--muted);text-align:right;}' +
        '.gm-list{display:flex;flex-direction:column;gap:12px;}' +
        '.gm-card{display:flex;flex-direction:column;gap:10px;}' +
        '.gm-head{display:flex;justify-content:space-between;align-items:baseline;gap:10px;}' +
        '.gm-head b{font-size:16px;}' +
        '.gm-sub{font-size:12.5px;color:var(--muted);text-align:right;}' +
        '.gm-body{display:flex;flex-direction:column;gap:10px;}' +
        '.gm-p{margin:0;font-size:14px;line-height:1.6;color:var(--ink);}' +
        '.gm-result{margin:0;font-size:14px;line-height:1.6;font-weight:700;color:var(--accent-deep);min-height:1.4em;}' +
        '.gm-row{display:flex;gap:8px;}' +
        '.gm-row .play-btn{flex:1;}' +
        '.gm-input{flex:1;min-height:48px;border-radius:14px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);padding:10px 14px;font-size:16px;min-width:0;}' +
        '.gm-tries{margin:0;font-size:13px;color:var(--muted);}' +
        '.gm-restart{align-self:flex-start;}' +
        '.gm-opt{width:100%;margin:0 0 8px;text-align:left;}' +
        '.gm-opt.gm-right{background:var(--green-soft);border-color:#7FB98A;color:#2F6B3A;}' +
        '.gm-opt.gm-wrong{background:#FDECEC;border-color:#F2A0A0;color:#8F2F2F;}' +
        '.gm-memory{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}' +
        '.gm-card-face{aspect-ratio:1;border:1.5px solid var(--line);border-radius:14px;background:var(--card2);font-size:22px;cursor:pointer;min-height:48px;}' +
        '.gm-card-face.open{background:var(--card);border-color:var(--pink);}' +
        '.gm-card-face.done{background:var(--pink-pale);border-color:var(--pink);}' +
        '.gm-wheel-wrap{display:flex;flex-direction:column;align-items:center;gap:12px;}' +
        '.gm-pointer{font-size:22px;color:var(--accent-deep);margin-bottom:-14px;z-index:2;line-height:1;}' +
        '.gm-wheel{position:relative;width:230px;height:230px;border-radius:50%;border:4px solid var(--accent-deep);' +
        'background:conic-gradient(#FFD6DE 0 45deg,#FFF3C4 45deg 90deg,#DFF2FF 90deg 135deg,#E4F5E0 135deg 180deg,#F3D9F2 180deg 225deg,#FFE8F1 225deg 270deg,#FFF0DF 270deg 315deg,#DCECCB 315deg 360deg);' +
        'transition:transform 3s cubic-bezier(.15,.8,.25,1);}' +
        '.gm-wheel-label{position:absolute;left:50%;top:50%;font-size:12.5px;font-weight:800;color:#5A3A52;' +
        'transform:rotate(var(--a)) translateY(-88px) rotate(calc(var(--a) * -1));transform-origin:0 0;white-space:nowrap;}' +
        '.gm-react-pad{width:100%;min-height:120px;border-radius:20px;border:2px solid var(--line);background:var(--card2);' +
        'font-size:18px;font-weight:800;cursor:pointer;color:var(--ink);}' +
        '.gm-react-pad.waiting{background:#FDECEC;border-color:#E8A0A0;}' +
        '.gm-react-pad.ready{background:#CDEECC;border-color:#5FA96B;color:#2F6B3A;}' +
        '.gm-note{color:var(--muted);font-size:12.5px;}';
      document.head.appendChild(st);
    }
  });
})();
